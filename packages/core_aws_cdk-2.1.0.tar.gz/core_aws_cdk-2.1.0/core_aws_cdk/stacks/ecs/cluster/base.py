# -*- coding: utf-8 -*-

"""
ECS Cluster Stack for AWS CDK.

This module provides a flexible and production-ready ECS cluster
implementation that supports both Fargate and EC2 launch
types with advanced features.
"""

from typing import Any
from typing import Dict
from typing import Iterable
from typing import List
from typing import Optional

import aws_cdk as cdk
from aws_cdk import (
    Stack,
    Tags,
    aws_cloudwatch as cloudwatch,
    aws_ec2 as ec2,
    aws_ecs as ecs,
    aws_iam as iam,
    aws_autoscaling as autoscaling,
    aws_logs as logs,
)

from core_aws_cdk.stacks.network import NetworkStack


# pylint: disable=too-few-public-methods
# pylint: disable=too-many-instance-attributes
class EC2ManagedScalingConfig:
    """ Managed scaling configuration for the EC2 capacity provider. """

    # pylint: disable=too-many-arguments,too-many-positional-arguments
    def __init__(
        self,
        enable_managed_termination_protection: bool = False,
        maximum_scaling_step_size: int = 10,
        minimum_scaling_step_size: int = 1,
        target_capacity: int = 100,
        status: str = "ENABLED",

        use_custom_scaling_policies: bool = True,
        custom_scale_in_evaluation_periods: int = 3,
        custom_scale_in_threshold: int = 5,
    ) -> None:
        """
        Initialize EC2 managed scaling configuration.

        :param enable_managed_termination_protection:
            Protect instances from scale-in termination.
            (default: False).

        :param maximum_scaling_step_size: Maximum scaling step size for ASG, defaults to 10
        :param minimum_scaling_step_size: Minimum scaling step size for ASG, defaults to 1
        :param status: Scaling status (ENABLED or DISABLED), defaults to "ENABLED"

        :param target_capacity:
            Target capacity percentage, defaults to 100. A targetCapacity
            value of 100% means the cluster should scale to match task
            demand exactly. Values < 100% maintain free capacity
            buffer, which prevents scaling to zero.

        For ETL/batch workloads that need to scale to 0: use 100 (default).
        For persistent services with baseline capacity: use 70-90.

        :param use_custom_scaling_policies:
            If True, adds custom CPU-based scaling policies for faster
            scale-in (default: False). Uses a hybrid approach:
            - ECS Managed Scaling handles task-aware scale-out
            - Custom policies provide 3-minute scale-in (vs 15 minutes with ECS alone)

        :param custom_scale_in_evaluation_periods: Minutes before scaling in (default: 3)
        :param custom_scale_in_threshold: CPU % threshold for scale-in (default: 5%)
        """

        self.enable_managed_termination_protection = enable_managed_termination_protection
        self.maximum_scaling_step_size = maximum_scaling_step_size
        self.minimum_scaling_step_size = minimum_scaling_step_size
        self.target_capacity_percent = target_capacity
        self.status = status

        self.use_custom_scaling_policies = use_custom_scaling_policies
        self.custom_scale_in_evaluation_periods = custom_scale_in_evaluation_periods
        self.custom_scale_in_threshold = custom_scale_in_threshold


# pylint: disable=too-few-public-methods
# pylint: disable=too-many-instance-attributes
class EC2Config:
    """
    EC2 capacity provider configuration.

    Configures EC2 instances for ECS cluster capacity including:
    - Instance type and AMI selection
    - Auto Scaling Group sizing (min/max/desired capacity)
    - Security groups and networking
    - EBS volume configuration
    - Managed scaling policies
    - Health check settings
    """

    # pylint: disable=too-many-positional-arguments
    # pylint: disable=too-many-arguments
    # pylint: disable=too-many-locals
    def __init__(
        self,
        enabled: bool = True,
        ami_id: Optional[str] = None,
        instance_type: str = "t3.micro",
        health_check_grace_period: cdk.Duration = cdk.Duration.seconds(60),
        user_data_commands: Optional[List[str]] = None,
        security_group_ids: Optional[List[str]] = None,
        subnet_ids: Optional[List[str]] = None,
        root_volume_type: ec2.EbsDeviceVolumeType = ec2.EbsDeviceVolumeType.GP3,
        root_volume_size: int = 30,
        encrypted: bool = True,
        managed_scaling: Optional[EC2ManagedScalingConfig] = None,
        max_size: int = 10,
        desired_capacity: int = 0,
        min_size: int = 0,
        target_capacity: int = 100,
    ) -> None:
        """
        :param enabled: Enable EC2 capacity provider, defaults to True.
        :param ami_id: Custom AMI ID (uses latest ECS-optimized AL2023 if None).
        :param instance_type: EC2 instance type, defaults to "t3.micro".
        
        :param health_check_grace_period: Health check grace period, defaults to 60.
        :param user_data_commands: Additional user data commands to run on instance startup.
        :param security_group_ids: List of security group IDs.

        :param subnet_ids:
            List of subnet IDs for ASG. Where to place instances within
            the VPC. Default: - All Private subnets.

        :param root_volume_size: Root volume size in GB, defaults to 30
        :param root_volume_type: Root volume type, defaults to GP3
        :param encrypted: If the volume is encrypted.
        
        :param managed_scaling: Managed scaling configuration (creates default if not provided).
        :param max_size: Maximum ASG size, defaults to 10.
        :param desired_capacity: Desired ASG capacity, defaults to 0.
        :param min_size: Minimum ASG size, defaults to 0.
        :param target_capacity: Target capacity percentage for scaling, defaults to 100
        """

        if not managed_scaling:
            managed_scaling = EC2ManagedScalingConfig()

        self.ami_id = ami_id
        self.instance_type = instance_type
        self.health_check_grace_period = health_check_grace_period
        self.managed_scaling = managed_scaling
        self.enabled = enabled

        self.user_data_commands = user_data_commands
        self.root_volume_size = root_volume_size
        self.root_volume_type = root_volume_type

        self.subnet_ids = subnet_ids
        self.security_group_ids = security_group_ids
        self.encrypted = encrypted

        self.managed_scaling = managed_scaling
        self.target_capacity = target_capacity
        self.max_size = max_size
        self.desired_capacity = desired_capacity
        self.min_size = min_size


class ECSClusterStack(NetworkStack):
    """
    Production-ready ECS Cluster Stack with support for Fargate
    and EC2 capacity providers.

    This stack provides:
    - ECS cluster creation with configurable settings.
    - Fargate and Fargate Spot capacity providers.
    - Optional EC2 capacity provider with Auto Scaling Group.
    - Automatic IAM role creation with security best practices.
    - Container Insights support.
    - Execute command logging.
    - Service Connect namespace support.

    **Example:**

    .. code-block:: python

        from aws_cdk import App, Environment

        from core_aws_cdk.stacks.ecs.cluster.base import (
            EC2ManagedScalingConfig,
            EC2Config
        )

        from core_aws_cdk.stacks.ecs.cluster.base import ECSClusterStack

        stack = ECSClusterStack(
            app,
            "MyTestStackForCluster",
            env=Environment(account="...", region="us-east-1"),
            tags={
                "x": "1",
                "y": "2",
            }
        )

        stack.create_cluster(
            name="my-cluster",
            instance_role=instance_role,
            enable_container_insights=False,
            enable_execute_command_logging=False,
            enable_fargate=True,
            ec2_config=EC2Config(
                enabled=True,
                instance_type="t2.micro",
                managed_scaling=EC2ManagedScalingConfig(
                    use_custom_scaling_policies=True,       # Enable fast scale-in
                    custom_scale_in_evaluation_periods=3,   # Scale in after 3 minutes
                    custom_scale_in_threshold=5,            # When CPU < 5%
                ),
                subnet_ids=[
                    "subnet-xxx",
                    "subnet-yyy",
                ],
            ),
        )
    """

    # pylint: disable=too-many-arguments
    # pylint: disable=too-many-positional-arguments
    def create_cluster(
        self,
        name: str,
        enable_fargate: bool = True,
        ec2_config: Optional[EC2Config] = None,
        vpc: Optional[ec2.IVpc] = None,
        instance_role: Optional[iam.IRole] = None,
        enable_container_insights: bool = True,
        service_connect_namespace: Optional[str] = None,
        enable_execute_command_logging: bool = True,
        **kwargs: Dict[str, Any]
    ) -> ecs.Cluster:
        """
        Create an ECS cluster with Fargate and/or EC2 capacity providers.

        :param name: Name of the ECS cluster
        :param enable_fargate: Enable Fargate and Fargate Spot capacity providers (default: True)
        :param ec2_config: EC2 capacity provider configuration (optional)
        :param vpc: VPC to deploy cluster in (uses default VPC if not specified)
        :param instance_role: IAM role for EC2 instances (required if ec2_config.enabled=True)

        :param enable_container_insights:
            If True, `Container Insights` is enabled which provides enhanced observability
            and a unified view of performance metrics for Amazon Elastic Container Service
            (ECS) workloads, enabling faster troubleshooting and root cause analysis.
            It collects and aggregates detailed performance data, such as CPU and memory
            utilization at the container and task level, and displays this information
            through curated dashboards, which can help identify issues before they impact
            users.

        :param service_connect_namespace:
            The primary purpose of a Service Connect namespace in Amazon ECS is to facilitate
            easy and reliable service-to-service communication between microservices within
            your ECS environment, potentially spanning multiple clusters and VPCs.

        :param enable_execute_command_logging:
            The primary purpose of execute_command logging in Amazon ECS is to enhance
            observability, auditing, and debugging of commands executed
            within containers.

        :param kwargs: Extra arguments to pass to the cluster.
        :return: The cluster.
        """

        is_default_vpc = False
        if not vpc:
            vpc = self.default_vpc
            is_default_vpc = True

        args: Dict[str, Any] = {
            "cluster_name": name,
            "enable_fargate_capacity_providers": enable_fargate,
            "vpc": vpc,
            **kwargs,
        }

        if enable_container_insights:
            args["container_insights"] = True

        if enable_execute_command_logging:
            args["execute_command_configuration"] = ecs.ExecuteCommandConfiguration(
                logging=ecs.ExecuteCommandLogging.OVERRIDE,
                log_configuration=ecs.ExecuteCommandLogConfiguration(
                    cloud_watch_log_group=logs.LogGroup(
                        self,
                        f"{name}-ExecuteCommandLogGroup",
                        log_group_name=f"/aws/ecs/cluster/{name}/CommandLogs",
                        removal_policy=self.default_removal_policy,
                        retention=self.default_log_retention,
                    ),
                ),
            )

        cluster = ecs.Cluster(self, name, **args)

        if service_connect_namespace:
            cluster.add_default_cloud_map_namespace(
                name=service_connect_namespace,
                use_for_service_connect=True,
            )

        if ec2_config and ec2_config.enabled:
            if instance_role is None:
                raise ValueError(
                    "instance_role is required when ec2_config.enabled=True. "
                    "Create an instance role using create_ec2_instance_role() first."
                )

            capacity_provider = self.prepare_ec2_capacity_provider(
                cluster_name=name,
                ec2_config=ec2_config,
                instance_role=instance_role,
                vpc=vpc,
                is_default_vpc=is_default_vpc,
            )

            cluster.add_asg_capacity_provider(capacity_provider)

        self.apply_tags(cluster)
        return cluster

    # pylint: disable=too-many-arguments
    # pylint: disable=too-many-positional-arguments
    def prepare_ec2_capacity_provider(
        self,
        cluster_name: str,
        ec2_config: EC2Config,
        instance_role: iam.IRole,
        vpc: ec2.IVpc,
        is_default_vpc: bool,
    ) -> ecs.AsgCapacityProvider:
        """
        Create and configure EC2 capacity provider with ASG.

        :param cluster_name: Name of the cluster (used for resource naming).
        :param ec2_config: EC2 configuration settings.
        :param instance_role: IAM role for EC2 instances.
        :param vpc: VPC to deploy instances in.
        :param is_default_vpc: Whether using default VPC (affects subnet selection).
        :return: Configured ECS capacity provider.
        """

        # Getting the AMI id...
        machine_image = (
            ec2.MachineImage.generic_linux({self.region: ec2_config.ami_id})
            if ec2_config.ami_id
            else self.get_latest_ecs_ami()
        )

        # Preparing user data...
        user_data = ec2.UserData.for_linux()
        user_data.add_commands(f"echo ECS_CLUSTER={cluster_name} >> /etc/ecs/ecs.config")
        if ec2_config.user_data_commands:
            user_data.add_commands(*ec2_config.user_data_commands)

        # Getting security groups...
        security_groups: List[ec2.ISecurityGroup] = []
        if ec2_config.security_group_ids:
            security_groups = [
                ec2.SecurityGroup.from_security_group_id(
                    self, f"SecurityGroup{i}", sg_id
                )
                for i, sg_id in enumerate(ec2_config.security_group_ids)
            ]

        if ec2_config.subnet_ids:
            subnet_selection = ec2.SubnetSelection(
                subnets=[
                    ec2.Subnet.from_subnet_id(self, id_, id_)
                    for id_ in ec2_config.subnet_ids
                ])

        else:
            if is_default_vpc:
                subnet_selection = ec2.SubnetSelection(
                    subnet_type=ec2.SubnetType.PUBLIC
                )

            else:
                subnet_selection = ec2.SubnetSelection(
                    subnet_type=ec2.SubnetType.PRIVATE_WITH_EGRESS
                )

        launch_template = self.create_launch_template(
            cluster_name=cluster_name,
            ec2_config=ec2_config,
            instance_role=instance_role,
            security_group=security_groups[0] if security_groups else None,
            user_data=user_data,
            machine_image=machine_image,
        )

        auto_scaling_group = self.create_asg(
            cluster_name=cluster_name,
            launch_template=launch_template,
            subnet_selection=subnet_selection,
            ec2_config=ec2_config,
            vpc=vpc,
            security_groups=(
                security_groups[1:]
                if security_groups and len(security_groups) > 1
                else None
            ),
        )

        # # Add security groups if provided and not in launch template...
        # if security_groups and len(security_groups) > 1:
        #     for sg in security_groups[1:]:
        #         auto_scaling_group.add_security_group(sg)

        # When using custom scaling policies, we still need ECS managed scaling
        # for task-aware scale-out, but we'll add custom policies for faster scale-in

        ref = f"{cluster_name}-EC2-CapacityProvider"

        ec2_capacity_provider = ecs.AsgCapacityProvider(
            self,
            ref,
            capacity_provider_name=ref,
            auto_scaling_group=auto_scaling_group,
            instance_warmup_period=120,
            enable_managed_scaling=ec2_config.managed_scaling.status == "ENABLED",
            enable_managed_termination_protection=(
                ec2_config.managed_scaling.enable_managed_termination_protection
            ),
            maximum_scaling_step_size=ec2_config.managed_scaling.maximum_scaling_step_size,
            minimum_scaling_step_size=ec2_config.managed_scaling.minimum_scaling_step_size,
            target_capacity_percent=ec2_config.managed_scaling.target_capacity_percent,
        )

        # Apply custom scaling policies if requested
        if ec2_config.managed_scaling.use_custom_scaling_policies:
            self.add_custom_scaling_policies(
                cluster_name=cluster_name,
                asg=auto_scaling_group,
                scale_in_evaluation_periods=(
                    ec2_config.managed_scaling.custom_scale_in_evaluation_periods
                ),
                scale_in_threshold=(
                    ec2_config.managed_scaling.custom_scale_in_threshold
                ),
            )

        return ec2_capacity_provider

    # pylint: disable=too-many-arguments
    # pylint: disable=too-many-positional-arguments
    def create_launch_template(
        self,
        cluster_name: str,
        ec2_config: EC2Config,
        instance_role: iam.IRole,
        user_data: ec2.UserData,
        machine_image: ec2.IMachineImage,
        security_group: Optional[ec2.ISecurityGroup] = None,
    ) -> ec2.LaunchTemplate:
        """
        Create EC2 launch template for ECS instances.

        :param cluster_name: Name of the cluster (used for resource naming).
        :param ec2_config: EC2 configuration settings.
        :param instance_role: IAM role for EC2 instances.
        :param user_data: User data script for instance initialization.
        :param machine_image: AMI to use for instances.
        :param security_group: Primary security group (optional).
        :return: Configured launch template.
        """

        ref = f"{cluster_name}-LaunchTemplate"

        launch_template = ec2.LaunchTemplate(
            self,
            ref,
            launch_template_name=ref,
            instance_type=ec2.InstanceType(ec2_config.instance_type),
            machine_image=machine_image,
            role=instance_role,
            user_data=user_data,
            security_group=security_group,
            block_devices=[
                ec2.BlockDevice(
                    device_name="/dev/xvda",
                    volume=ec2.BlockDeviceVolume.ebs(
                        volume_size=ec2_config.root_volume_size,
                        volume_type=ec2_config.root_volume_type,
                        encrypted=ec2_config.encrypted,
                    ),
                )
            ],
        )

        self.apply_tags(
            launch_template,
            additional_tags={
                "Name": f"{cluster_name}-Instance",
            },
        )

        return launch_template

    def create_asg(
        self,
        cluster_name: str,
        launch_template: ec2.LaunchTemplate,
        subnet_selection: ec2.SubnetSelection,
        ec2_config: EC2Config,
        vpc: ec2.IVpc,
        security_groups: Optional[Iterable[ec2.ISecurityGroup]] = None,
    ) -> autoscaling.AutoScalingGroup:
        """
        Create Auto Scaling Group for ECS cluster.

        :param cluster_name: Name of the cluster (used for resource naming).
        :param launch_template: Launch template to use.
        :param subnet_selection: Subnet configuration for instances.
        :param ec2_config: EC2 configuration settings.
        :param vpc: VPC to deploy ASG in.
        :param security_groups: Additional security groups to attach (optional).
        :return: Configured Auto Scaling Group.
        """

        asg_params = {
            "auto_scaling_group_name": f"{cluster_name}-ASG",
            "launch_template": launch_template,
            "min_capacity": ec2_config.min_size,
            "max_capacity": ec2_config.max_size,
            "vpc": vpc,
            "vpc_subnets": subnet_selection,
            "health_checks": autoscaling.HealthChecks.ec2(
                grace_period=ec2_config.health_check_grace_period
            ),
            "new_instances_protected_from_scale_in": False,
            "cooldown": cdk.Duration.minutes(1),
        }

        # if ec2_conf.managed_scaling.status != "ENABLED":
        #     asg_params["desired_capacity"] = ec2_conf.desired_capacity

        asg = autoscaling.AutoScalingGroup(
            self,
            f"{cluster_name}-AutoScalingGroup",
            **asg_params  # type: ignore[arg-type]
        )

        if security_groups:
            for sg in security_groups:
                asg.add_security_group(sg)

        Tags.of(asg).add(
            "AmazonECSManaged",
            "true",
            apply_to_launched_instances=True,
        )

        Tags.of(asg).add(
            "ECS_CLUSTER",
            cluster_name,
            apply_to_launched_instances=True,
        )

        return asg

    @staticmethod
    def add_custom_scaling_policies(
        cluster_name: str,
        asg: autoscaling.AutoScalingGroup,
        scale_in_evaluation_periods: int = 3,
        scale_in_period_minutes: int = 1,
        scale_out_threshold: int = 70,
        scale_in_threshold: int = 5,
    ) -> None:
        """
        Add custom scaling policies with CloudWatch alarms for faster
        scale-in. This is useful for ETL/batch workloads
        that need to scale to zero quickly.

        Hybrid Approach:
        - ECS Managed Scaling: Handles task-aware scale-out (scales when tasks are pending).
        - Custom CPU-based policies: Provides aggressive scale-in (3 min vs 15 min)

        This ensures tasks can always trigger scale-out while
        achieving fast scale-in.

        :param cluster_name: The cluster name to use in the references IDs.
        :param asg: The ASG to attach policies to.
        :param scale_in_period_minutes: Period length in minutes (default: 1).

        :param scale_in_evaluation_periods:
            Number of periods before scaling in,
            (default: 3 = 3 minutes).

        :param scale_in_threshold:
            CPU percentage threshold for scale-in.
            (default: 5%).

        :param scale_out_threshold:
            CPU percentage threshold for scale-out.
            (default: 70%).
        """

        # Use target tracking scaling for scale-out (handles
        # scale-out automatically by ECS service)...
        asg.scale_on_cpu_utilization(
            f"{cluster_name}-CpuScaling",
            target_utilization_percent=scale_out_threshold,
        )

        cpu_metric = cloudwatch.Metric(
            id=f"{cluster_name}-CPU-Utilization",
            namespace="AWS/EC2",
            metric_name="CPUUtilization",
            dimensions_map={
                "AutoScalingGroupName": asg.auto_scaling_group_name,
            },
            statistic="Average",
            period=cdk.Duration.minutes(
                scale_in_period_minutes
            ),
        )

        asg.scale_on_metric(
            f"{cluster_name}-ScaleInPolicy",
            metric=cpu_metric,
            scaling_steps=[
                # Scaling in by 1 when CPU is between 0-5%...
                autoscaling.ScalingInterval(
                    upper=scale_in_threshold,
                    change=-1,
                ),
                # No action required when CPU is above threshold (covered
                # by target tracking)...
                autoscaling.ScalingInterval(
                    lower=scale_in_threshold,
                    change=0,
                ),
            ],
            adjustment_type=autoscaling.AdjustmentType.CHANGE_IN_CAPACITY,
            cooldown=cdk.Duration.seconds(60),
            evaluation_periods=scale_in_evaluation_periods,
        )

    def create_ec2_instance_role(
        self,
        prefix: str = "",
    ) -> iam.IRole:
        """
        Creates an IAM role (ECS Instance Role) for EC2 instances
        with SSM and CloudWatch permissions.

        - Used by EC2 instances to register with ECS.
        - Has generic permissions: ECS agent, SSM, CloudWatch.
        - Should be shareable across clusters since it only needs basic ECS functionality.

        :param prefix: Prefix to use to avoid naming collisions.
        :return: The IAM role.
        """

        ref = f"{prefix}Ec2InstanceRole"

        instance_role =  iam.Role(
            self,
            ref,
            role_name=ref,
            description="IAM role for EC2 instances.",
            assumed_by=iam.ServicePrincipal(  # type: ignore[arg-type]
                "ec2.amazonaws.com",
                conditions={
                    "StringEquals": {
                        "aws:SourceAccount": Stack.of(self).account
                    }
                }
            ),
            managed_policies=[
                self.get_iam_policy("service-role/AmazonEC2ContainerServiceforEC2Role"),
                self.get_iam_policy("AmazonSSMManagedInstanceCore"),
                self.get_iam_policy("CloudWatchAgentServerPolicy"),
            ],
        )

        self.apply_tags(instance_role)
        return instance_role  # type: ignore[return-value]

    def create_task_execution_role(
        self,
        prefix: str = "",
    ) -> iam.IRole:
        """
        Creates an IAM role (ECS Task Execution Role) which is used by the
        container agent to make AWS API requests on your behalf.

        - Used by ECS to pull images and write logs.
        - Has generic permissions: ECR pull, CloudWatch Logs.
        - Should be shareable across clusters.

        :param prefix: Prefix to use to avoid naming collisions.
        :return: The IAM role.
        """

        ref = f"{prefix}EcsTaskExecutionRole"

        task_execution_role = iam.Role(
            self,
            ref,
            role_name=ref,
            description="IAM role for ECS task execution.",
            assumed_by=iam.ServicePrincipal(  # type: ignore[arg-type]
                "ecs-tasks.amazonaws.com",
                conditions={
                    "StringEquals": {
                        "aws:SourceAccount": Stack.of(self).account
                    }
                }
            ),
            managed_policies=[
                self.get_iam_policy("service-role/AmazonECSTaskExecutionRolePolicy"),
            ],
        )

        self.apply_tags(task_execution_role)
        return task_execution_role  # type: ignore[return-value]

    @staticmethod
    def get_latest_ecs_ami() -> ec2.IMachineImage:
        """
        Get the latest ECS-optimized Amazon Linux 2023 AMI.
        :return: Machine image for ECS-optimized AL2023.
        """
        return ecs.EcsOptimizedImage.amazon_linux2023()
