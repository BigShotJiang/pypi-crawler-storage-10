# -*- coding: utf-8 -*-

"""
ECS Task Definitions for Testing.

This module provides pre-configured ECS task definitions for testing
cluster capabilities, including CPU stress tests for both EC2 and
Fargate launch types.
"""

from .stress import create_cpu_stress_ec2_task
from .stress import create_cpu_stress_fargate_task


__all__ = [
    "create_cpu_stress_ec2_task",
    "create_cpu_stress_fargate_task",
]
