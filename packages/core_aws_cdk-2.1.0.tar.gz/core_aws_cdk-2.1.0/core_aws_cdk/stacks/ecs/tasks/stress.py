# -*- coding: utf-8 -*-

"""
Sample ECS Task Definitions for Testing.

This module provides sample ECS task definitions that can be used to test
ECS clusters and scaling capabilities. Includes CPU stress tests for both
Fargate and EC2 launch types.
"""

from typing import Optional

from aws_cdk import Duration, RemovalPolicy
from aws_cdk import aws_ecs as ecs
from aws_cdk import aws_iam as iam
from aws_cdk import aws_logs as logs
from constructs import Construct


# pylint: disable=too-many-positional-arguments
# pylint: disable=too-many-arguments
def create_cpu_stress_fargate_task(
    scope: Construct,
    task_id: str,
    execution_role: iam.IRole,
    task_role: Optional[iam.IRole] = None,
    family: str = "CpuStressFargate",
    cpu: int = 256,
    memory_mib: int = 512,
    timeout_seconds: int = 10,
) -> ecs.FargateTaskDefinition:
    """
    Create a Fargate task definition for CPU stress testing.

    This task runs a stress-ng container that performs CPU and memory stress
    tests for a specified duration. Useful for testing Fargate scaling and
    resource allocation.

    :param scope: The scope in which to define this construct.
    :type scope: Construct
    :param task_id: The construct ID for the task definition.
    :type task_id: str
    :param execution_role: IAM role for ECS task execution (pulling images, logs).
    :type execution_role: iam.IRole
    :param task_role: IAM role for the task containers (optional).
    :type task_role: Optional[iam.IRole]
    :param family: Task definition family name, defaults to "CpuStressFargate".
    :type family: str
    :param cpu: CPU units (256 = 0.25 vCPU), defaults to 256.
    :type cpu: int
    :param memory_mib: Memory in MiB, defaults to 512.
    :type memory_mib: int
    :param timeout_seconds: Stress test duration in seconds, defaults to 10.
    :type timeout_seconds: int
    :return: The Fargate task definition.
    :rtype: ecs.FargateTaskDefinition

    Example::

        from aws_cdk import App
        from core_aws_cdk.stacks.ecs.cluster.base import ECSClusterStack
        from core_aws_cdk.stacks.ecs.tasks.samples import create_cpu_stress_fargate_task

        app = App()
        cluster_stack = ECSClusterStack(app, "ClusterStack", cluster_name="test-cluster")

        task_def = create_cpu_stress_fargate_task(
            cluster_stack,
            "CpuStressTask",
            execution_role=cluster_stack.task_execution_role,
            cpu=512,
            memory_mib=1024,
            timeout_seconds=30
        )

        app.synth()
    """

    task_definition = ecs.FargateTaskDefinition(
        scope,
        task_id,
        family=family,
        cpu=cpu,
        memory_limit_mib=memory_mib,
        execution_role=execution_role,
        task_role=task_role,
    )

    # Create log group with custom name and removal policy
    log_group = logs.LogGroup(
        scope,
        f"{task_id}-LogGroup",
        log_group_name=f"/aws/ecs/{family}",
        removal_policy=RemovalPolicy.DESTROY,
        retention=logs.RetentionDays.ONE_DAY,
    )

    task_definition.add_container(
        "CpuStress",
        image=ecs.ContainerImage.from_registry("polinux/stress-ng"),
        command=[
            "stress-ng",
            "--cpu", "1",
            "--vm-bytes", "128M",
            "--timeout", f"{timeout_seconds}s",
        ],
        essential=True,
        logging=ecs.LogDrivers.aws_logs(
            stream_prefix="cpu-stress-fargate",
            log_group=log_group,
        ),
    )

    return task_definition


# pylint: disable=too-many-positional-arguments
# pylint: disable=too-many-arguments
def create_cpu_stress_ec2_task(
    scope: Construct,
    task_id: str,
    execution_role: iam.IRole,
    task_role: Optional[iam.IRole] = None,
    family: str = "CpuStressEC2",
    container_memory_mib: int = 256,
    container_cpu: int = 256,
    timeout_seconds: int = 60,
    enable_health_check: bool = True,
) -> ecs.Ec2TaskDefinition:
    """
    Create an EC2 task definition for CPU stress testing.

    This task runs a stress-ng container that performs CPU and memory stress
    tests for a specified duration. Useful for testing EC2-backed ECS cluster
    scaling and resource allocation.

    :param scope: The scope in which to define this construct.
    :type scope: Construct
    :param task_id: The construct ID for the task definition.
    :type task_id: str
    :param execution_role: IAM role for ECS task execution (pulling images, logs).
    :type execution_role: iam.IRole
    :param task_role: IAM role for the task containers (optional).
    :type task_role: Optional[iam.IRole]
    :param family: Task definition family name, defaults to "CpuStressEC2".
    :type family: str
    :param container_memory_mib: Container memory in MiB, defaults to 256.
    :type container_memory_mib: int
    :param container_cpu: Container CPU units, defaults to 256.
    :type container_cpu: int
    :param timeout_seconds: Stress test duration in seconds, defaults to 60.
    :type timeout_seconds: int
    :param enable_health_check: Enable container health check, defaults to True.
    :type enable_health_check: bool
    :return: The EC2 task definition.
    :rtype: ecs.Ec2TaskDefinition

    Example::

        from aws_cdk import App
        from core_aws_cdk.stacks.ecs.cluster.base import ECSClusterStack
        from core_aws_cdk.stacks.ecs.tasks.samples import create_cpu_stress_ec2_task

        app = App()
        cluster_stack = ECSClusterStack(app, "ClusterStack", cluster_name="test-cluster")

        task_def = create_cpu_stress_ec2_task(
            cluster_stack,
            "CpuStressEC2Task",
            execution_role=cluster_stack.task_execution_role,
            container_memory_mib=512,
            container_cpu=512,
            timeout_seconds=120
        )

        app.synth()
    """

    task_definition = ecs.Ec2TaskDefinition(
        scope,
        task_id,
        family=family,
        network_mode=ecs.NetworkMode.BRIDGE,
        execution_role=execution_role,
        task_role=task_role,
    )

    log_group = logs.LogGroup(
        scope,
        f"{task_id}-LogGroup",
        log_group_name=f"/aws/ecs/{family}",
        retention=logs.RetentionDays.ONE_DAY,
        removal_policy=RemovalPolicy.DESTROY,
    )

    health_check = None
    if enable_health_check:
        health_check = ecs.HealthCheck(
            command=[
                "CMD-SHELL",
                'python -c "import sys; sys.exit(0)" || exit 1',
            ],
            start_period=Duration.seconds(60),
            interval=Duration.seconds(30),
            timeout=Duration.seconds(10),
            retries=3,
        )

    task_definition.add_container(
        "CpuStress",
        image=ecs.ContainerImage.from_registry("polinux/stress-ng"),
        command=[
            "stress-ng",
            "--cpu", "1",
            "--vm-bytes", "128M",
            "--timeout", f"{timeout_seconds}s",
        ],
        memory_limit_mib=container_memory_mib,
        cpu=container_cpu,
        essential=True,
        logging=ecs.LogDrivers.aws_logs(
            stream_prefix="cpu-stress-ec2",
            log_group=log_group,
        ),
        health_check=health_check,
    )

    return task_definition
