# -*- coding: utf-8 -*-

"""Network stack module for VPC and networking resources."""

from .base import NetworkStack


__all__ = [
    "NetworkStack",
]
