# -*- coding: utf-8 -*-

"""Network stack for VPC and networking resources."""

from typing import Any
from typing import List
from typing import Optional

import boto3
from aws_cdk import aws_ec2 as ec2

from core_aws_cdk.stacks.base import BaseStack


class NetworkStack(BaseStack):
    """
    Network stack providing VPC and networking resource management.

    Extends BaseStack to provide:
    - Default VPC lookup with caching.
    - VPC creation with flexible configuration.
    - Network resource tagging and lifecycle management.
    """

    _default_vpc: Optional[ec2.IVpc] = None
    _default_public_subnet_ids: Optional[List[str]] = None
    _default_az: Optional[List[str]] = None

    # pylint: disable=protected-access
    @property
    def default_vpc(self) -> ec2.IVpc:
        """
        Returns the default VPC for the AWS account.

        This method attempts to use CDK's `Vpc.from_lookup()` first for
        context-aware lookup. If that fails (e.g., in programmatic synthesis),
        it falls back to querying AWS directly with boto3 and using
        `Vpc.from_vpc_attributes()`.

        The result is cached at the class level for reuse across instances.

        :return: The default VPC interface.
        """

        if self.__class__._default_vpc:
            return self.__class__._default_vpc

        # Looking for VPC ID using boto3 because `ec2.Vpc.from_lookup` can fail
        # in some scenarios...
        ec2_client = boto3.client("ec2", region_name=self.region)

        response = ec2_client.describe_vpcs(
            Filters=[{
                "Name": "isDefault",
                "Values": ["true"],
            }]
        )

        if not response["Vpcs"]:
            raise RuntimeError("No default VPC found in this region!")

        public_subnet_ids, private_subnet_ids = [], []
        default_vpc = response["Vpcs"][0]
        vpc_id = default_vpc["VpcId"]

        subnets_response = ec2_client.describe_subnets(
            Filters=[{
                "Name": "vpc-id",
                "Values": [vpc_id]
            }]
        )

        availability_zones = sorted(list(set(
            s["AvailabilityZone"]
            for s in subnets_response["Subnets"]
        )))

        for subnet in subnets_response["Subnets"]:
            subnet_id = subnet["SubnetId"]

            # Check if subnet has route to internet gateway (public)...
            route_tables = ec2_client.describe_route_tables(
                Filters=[{
                    "Name": "association.subnet-id",
                    "Values": [subnet_id],
                }]
            )

            is_public = False
            for rt in route_tables.get("RouteTables", []):
                for route in rt.get("Routes", []):
                    if route.get("GatewayId", "").startswith("igw-"):
                        is_public = True
                        break

            if is_public:
                public_subnet_ids.append(subnet_id)

            else:
                private_subnet_ids.append(subnet_id)

        # Default VPCs typically only have public subnets...
        if not public_subnet_ids:
            public_subnet_ids = [
                s["SubnetId"]
                for s in subnets_response["Subnets"]
            ]

        print(f"Resolved VPC via boto3: {vpc_id}")
        print(f"Public subnets: {public_subnet_ids}")
        print(f"Availability zones: {availability_zones}")

        self.__class__._default_vpc = ec2.Vpc.from_vpc_attributes(
            self,
            "DefaultVPC",
            vpc_id=vpc_id,
            availability_zones=availability_zones,
            public_subnet_ids=public_subnet_ids,
            private_subnet_ids=private_subnet_ids if private_subnet_ids else None,
        )

        self.__class__._default_public_subnet_ids = public_subnet_ids
        self.__class__._default_az = availability_zones
        return self.__class__._default_vpc

    # pylint: disable=too-many-positional-arguments
    # pylint: disable=too-many-arguments
    def create_vpc(
        self,
        vpc_id: str,
        availability_zones: Optional[List[str]] = None,
        subnet_configuration: Optional[List[ec2.SubnetConfiguration]] = None,
        max_azs: Optional[int] = None,
        cidr: Optional[str] = None,
        **kwargs: Any
    ) -> ec2.Vpc:
        """
        Create a new VPC with flexible configuration.

        :param vpc_id: Construct ID for the VPC resource.
        :param availability_zones: List of availability zones to use.
        :param subnet_configuration: Custom subnet configuration.
        :param max_azs: Maximum number of availability zones to use.
        :param cidr: CIDR block for the VPC (e.g., "10.0.0.0/16").
        :param kwargs: Additional VPC properties.
        :return: The created VPC instance.

        For additional configuration options, see:
        https://docs.aws.amazon.com/cdk/api/v2/python/aws_cdk.aws_ec2/Vpc.html
        """

        return ec2.Vpc(
            self,
            vpc_id,
            cidr=cidr,
            availability_zones=availability_zones,
            subnet_configuration=subnet_configuration,
            max_azs=max_azs,
            **kwargs)
