# -*- coding: utf-8 -*-

"""
S3 Stack Base Module.

This module provides the base stack class for creating and managing
S3 bucket infrastructure on AWS. It extends BaseStack with S3-specific
functionality and provides convenient methods for bucket creation with
sensible defaults.

**Features:**
- Simplified bucket creation with secure defaults
- Configurable public access blocking
- Lifecycle and versioning management
- Automatic cleanup options for development/test environments
- Consistent tagging and removal policies

IAM Role for External Account S3 Access.

This module provides the mechanism to create an IAM role with fine-grained access
to a specific location (path) within an S3 bucket. The access policy is assigned
to the root of the external account, which is responsible for creating internal
policies to allow its internal roles/users to assume the role.

**Features:**
- Fine-grained S3 access control (prefix-based).
- External account trust with optional External ID.
- Configurable access levels (READ, WRITE, READ_WRITE, FULL).
- Optional bucket listing capability.
- Support for encrypted buckets with KMS keys.
- Optional MFA requirement for role assumption.
- Configurable session duration.
- Comprehensive tagging support.

**Security Considerations:**
- Uses External ID to prevent confused deputy attacks.
- Implements the "least" privilege principle.
- Supports MFA for sensitive operations.
- Account ID validation.
- Session duration controls.
"""

from typing import Any, Dict, List, Optional

from aws_cdk import Duration
from aws_cdk import RemovalPolicy
from aws_cdk import aws_iam as iam
from aws_cdk import aws_kms as kms
from aws_cdk import aws_s3 as s3
from core_mixins import StrEnum

from core_aws_cdk.stacks.base import BaseStack


class AccessLevel(StrEnum):  # type: ignore[misc]
    """
    S3 Access level enumeration.

    :cvar READ: Allows listing and reading objects (GetObject, ListBucket).
    :cvar WRITE: Allows uploading objects (PutObject).
    :cvar READ_WRITE: Allows both reading and writing operations.
    :cvar FULL: Complete access including read, write, and delete operations.
    """

    READ = "READ"
    WRITE = "WRITE"
    READ_WRITE = "READ_WRITE"
    FULL = "FULL"


class BaseS3Stack(BaseStack):
    """
    Base stack for S3 infrastructure. It extends BaseStack to
    provide S3-specific functionality for creating and managing
    buckets with secure defaults and convenient
    configuration options.

    This class serves as the foundation for S3-related stacks and provides
    a consistent interface for bucket creation across the application.

    **Example - Basic bucket creation:**

    .. code-block:: python

        from aws_cdk import App
        from core_aws_cdk.stacks.s3 import BaseS3Stack

        app = App()
        stack = BaseS3Stack(app, "MyS3Stack")

        # Create a simple bucket with defaults
        bucket = stack.create_bucket(
            bucket_id="MyBucket",
            bucket_name="my-data-bucket"
        )
    ..

    **Example - Versioned bucket for production:**

    .. code-block:: python

        from aws_cdk import RemovalPolicy

        # Create production bucket with versioning and retention
        prod_bucket = stack.create_bucket(
            bucket_id="ProdBucket",
            bucket_name="prod-data-bucket",
            versioned=True,
            removal_policy=RemovalPolicy.RETAIN,
            auto_delete_objects=False
        )
    ..
    """

    # pylint: disable=too-many-arguments,too-many-positional-arguments
    def create_bucket(
        self,
        bucket_id: str,
        bucket_name: Optional[str] = None,
        block_public_access: s3.BlockPublicAccess = s3.BlockPublicAccess.BLOCK_ALL,
        removal_policy: Optional[RemovalPolicy] = RemovalPolicy.DESTROY,
        auto_delete_objects: bool = True,
        versioned: bool = False,
        **kwargs: Any
    ) -> s3.Bucket:
        """
        Creates an S3 bucket with sensible security defaults including blocking
        all public access by default. Suitable for both development and production
        use with configurable lifecycle policies.

        :param bucket_id: Unique construct ID for the bucket within the stack.

        :param bucket_name:
            Physical name of the S3 bucket (if None, CloudFormation
            generates a unique name).

        :param block_public_access:
            Public access blocking configuration. Defaults to
            blocking all public access for security.

        :param removal_policy:
            Policy for bucket removal when stack is deleted. Should DESTROY
            for dev/test, RETAIN for production.

        :param auto_delete_objects:
            Automatically delete objects when bucket is destroyed.
            Should be False for production buckets.

        :param versioned: Enable bucket versioning for object history and recovery.

        :param kwargs:
            Additional bucket properties passed to s3.Bucket constructor.
            See: https://docs.aws.amazon.com/cdk/api/v2/python/aws_cdk.aws_s3/Bucket.html

        :return: The created S3 bucket.

        **Example - Development bucket:**

        .. code-block:: python

            dev_bucket = stack.create_bucket(
                bucket_id="DevBucket",
                bucket_name="dev-temp-data",
                removal_policy=RemovalPolicy.DESTROY,
                auto_delete_objects=True
            )
        ..

        **Example - Production bucket with versioning:**

        .. code-block:: python

            from aws_cdk import RemovalPolicy

            prod_bucket = stack.create_bucket(
                bucket_id="ProdBucket",
                bucket_name="prod-critical-data",
                versioned=True,
                removal_policy=RemovalPolicy.RETAIN,
                auto_delete_objects=False,
                lifecycle_rules=[
                    s3.LifecycleRule(
                        transitions=[
                            s3.Transition(
                                storage_class=s3.StorageClass.GLACIER,
                                transition_after=Duration.days(90)
                            )
                        ]
                    )
                ]
            )
        ..

        **Example - Custom encryption:**

        .. code-block:: python

            from aws_cdk import aws_kms as kms

            kms_key = kms.Key(stack, "BucketKey")

            encrypted_bucket = stack.create_bucket(
                bucket_id="EncryptedBucket",
                bucket_name="encrypted-data",
                encryption=s3.BucketEncryption.KMS,
                encryption_key=kms_key
            )
        ..
        """

        return s3.Bucket(
            self,
            bucket_id,
            bucket_name=bucket_name,
            block_public_access=block_public_access,
            removal_policy=removal_policy,
            auto_delete_objects=auto_delete_objects,
            versioned=versioned,
            **kwargs
        )

    # pylint: disable=too-many-arguments,too-many-positional-arguments
    # pylint: disable=too-many-locals
    def create_external_role(
        self,
        construct_id: str,
        role_name: str,
        external_account_id: str,
        prefix: str,
        access_level: AccessLevel = AccessLevel.READ,  # type: ignore[assignment]
        bucket: Optional[s3.IBucket] = None,
        bucket_name: Optional[str] = None,
        external_id: Optional[str] = None,
        allow_list_buckets: bool = False,
        kms_key: Optional[kms.IKey] = None,
        require_mfa: bool = False,
        max_session_duration: Optional[Duration] = None,
        role_description: Optional[str] = None,
        allow_any_principal: bool = False,
        additional_tags: Optional[Dict[str, str]] = None,
    ) -> iam.Role:
        """
        Create an IAM role for external account access to S3 bucket
        prefix. It provides a secure way to grant cross-account S3 access
        with fine-grained permissions scoped to specific bucket
        prefixes. It supports various access levels, optional encryption
        via KMS, and security features like External ID and MFA
        requirements.

        **Example - Basic read-only access:**

        .. code-block:: python

            from core_aws_cdk.stacks.s3 import BaseS3Stack, AccessLevel

            stack = BaseS3Stack(app, "ExternalAccessStack")

            role = stack.create_external_role(
                construct_id="ClientRole",
                role_name="ClientReadAccess",
                external_account_id="123456789012",
                bucket_name="shared-data-bucket",
                prefix="client/reports",
                access_level=AccessLevel.READ
            )
        ..

        **Example - Write access with External ID:**

        .. code-block:: python

            from core_aws_cdk.stacks.s3 import BaseS3Stack, AccessLevel

            stack = BaseS3Stack(app, "ThirdPartyAccess")

            role = stack.create_external_role(
                construct_id="VendorRole",
                role_name="VendorUploadAccess",
                external_account_id="987654321098",
                bucket_name="upload-bucket",
                prefix="vendor/uploads",
                access_level=AccessLevel.WRITE,
                external_id="unique-external-id-from-vendor",
                allow_list_buckets=True
            )
        ..

        **Example - Full access with KMS encryption:**

        .. code-block:: python

            from aws_cdk import aws_kms as kms
            from core_aws_cdk.stacks.s3 import BaseS3Stack, AccessLevel

            stack = BaseS3Stack(app, "SecureFullAccess")
            kms_key = kms.Key(stack, "BucketKey")

            role = stack.create_external_role(
                construct_id="SecureRole",
                role_name="SecureDataAccess",
                external_account_id="111222333444",
                bucket_name="encrypted-bucket",
                prefix="secure/data",
                access_level=AccessLevel.FULL,
                kms_key=kms_key,
                require_mfa=True,
                max_session_duration=Duration.hours(2)
            )
        ..

        **Example - Multiple roles in same stack:**

        .. code-block:: python

            from core_aws_cdk.stacks.s3 import BaseS3Stack, AccessLevel

            stack = BaseS3Stack(app, "MultiRoleStack")

            # Create read-only role for Partner A
            read_role = stack.create_external_role(
                construct_id="PartnerARole",
                role_name="PartnerAReadAccess",
                external_account_id="111111111111",
                bucket_name="shared-bucket",
                prefix="partner-a/data",
                access_level=AccessLevel.READ
            )

            # Create write role for Partner B
            write_role = stack.create_external_role(
                construct_id="PartnerBRole",
                role_name="PartnerBWriteAccess",
                external_account_id="222222222222",
                bucket_name="shared-bucket",
                prefix="partner-b/uploads",
                access_level=AccessLevel.WRITE
            )
        ..

        :param construct_id: Unique construct ID for this role within the stack.
        :param role_name: Name of the IAM role to create.
        :param external_account_id: AWS Account ID (12 digits) of the external account.
        :param prefix: Prefix/path within the bucket where access is granted.
        :param access_level: Access level (READ, WRITE, READ_WRITE, or FULL).
        :param bucket: Existing S3 bucket (if provided, bucket_name is ignored).
        :param bucket_name: Name of the S3 bucket (used if bucket is not provided).
        :param external_id: Optional External ID for confused deputy protection.

        :param allow_list_buckets:
            Allow listing all S3 buckets (metadata only). Default: False.

            **SECURITY WARNING**: This grants s3:ListAllMyBuckets permission,
            which exposes the names and metadata of ALL buckets in your AWS account
            to the external account, even those they cannot access. This is an
            information disclosure that may reveal your infrastructure. Only enable
            this if absolutely required by the external account's tooling.

        :param kms_key: Optional KMS key for encrypted bucket access.
        :param require_mfa: Require MFA for role assumption.
        :param max_session_duration: Maximum session duration (1-12 hours).
        :param role_description: Custom description for the IAM role.
        :param additional_tags: Additional tags to apply to this role (merged with stack tags).

        :param allow_any_principal:
            Allow any IAM user/role in external account to assume role
            directly (default: False, only root).

        :return: The created IAM role.
        :rtype: iam.Role

        :raises ValueError: If neither bucket nor bucket_name is provided.
        :raises ValueError: If external_account_id is not a valid 12-digit account ID.
        :raises ValueError: If prefix is empty or starts with '/'.
        """

        # Validate inputs
        self._validate_inputs(
            external_account_id=external_account_id,
            prefix=prefix,
            bucket=bucket,
            bucket_name=bucket_name
        )

        # Get bucket name (validation ensures one exists)...
        resolved_bucket_name: str = (
            bucket.bucket_name if bucket else bucket_name  # type: ignore[assignment]
        )
        normalized_prefix = prefix.rstrip("/")  # Remove trailing slash if present

        # Create IAM role
        role = self._create_iam_role(
            construct_id=construct_id,
            role_name=role_name,
            external_account_id=external_account_id,
            external_id=external_id,
            require_mfa=require_mfa,
            allow_any_principal=allow_any_principal,
            role_description=role_description,
            max_session_duration=max_session_duration,
            bucket_name=resolved_bucket_name,
            prefix=normalized_prefix,
        )

        # Create and attach policy
        policy = self._create_iam_policy(
            construct_id=f"{construct_id}-Policy",
            role_name=role_name,
            bucket_name=resolved_bucket_name,
            prefix=normalized_prefix,
            access_level=access_level,
            allow_list_buckets=allow_list_buckets,
            kms_key=kms_key,
        )

        role.attach_inline_policy(policy)

        # Apply tags to resources
        all_tags = {**(additional_tags or {})}
        if all_tags:
            self.apply_tags(role, all_tags)
            self.apply_tags(policy, all_tags)

        return role

    def _validate_inputs(
            self,
            external_account_id: str,
            prefix: str,
            bucket: Optional[s3.IBucket],
            bucket_name: Optional[str],
    ) -> None:
        """
        Validate input parameters.

        :param external_account_id: AWS Account ID to validate.
        :param prefix: Bucket prefix to validate.
        :param bucket: Existing bucket reference.
        :param bucket_name: Bucket name.

        :raises ValueError: If validation fails.
        """

        # Validate account ID
        is_valid_account_id = (
                external_account_id and
                len(external_account_id) == 12 and
                external_account_id.isdigit()
        )

        if not is_valid_account_id:
            raise ValueError(
                "external_account_id must be a 12-digit AWS "
                f"account ID, got: {external_account_id}"
            )

        # Validate bucket configuration
        if not bucket and not bucket_name:
            raise ValueError("Either 'bucket' or 'bucket_name' must be provided")

        # Validate prefix
        if not prefix:
            raise ValueError("prefix cannot be empty")

        if prefix.startswith("/"):
            raise ValueError(
                "prefix should not start with '/' (use 'path/to/location' "
                "not '/path/to/location')"
            )

    # pylint: disable=too-many-arguments,too-many-positional-arguments
    def _create_iam_role(
            self,
            construct_id: str,
            role_name: str,
            external_account_id: str,
            external_id: Optional[str],
            require_mfa: bool,
            allow_any_principal: bool,
            role_description: Optional[str],
            max_session_duration: Optional[Duration],
            bucket_name: str,
            prefix: str,
    ) -> iam.Role:
        """
        Create the IAM role with appropriate trust policy.

        :param construct_id: Construct ID for the role.
        :param role_name: Name of the IAM role.
        :param external_account_id: External AWS account ID.
        :param external_id: External ID for trust policy.
        :param require_mfa: Require MFA for role assumption.
        :param allow_any_principal: Allow any principal in external account.
        :param role_description: Custom role description.
        :param max_session_duration: Maximum session duration.
        :param bucket_name: S3 bucket name.
        :param prefix: S3 prefix.

        :return: The created IAM role.
        :rtype: iam.Role
        """

        # Create principal based on allow_any_principal setting...
        principal: iam.IPrincipal

        if allow_any_principal:
            # Allow any user/role in the external account
            principal = iam.AnyPrincipal()  # type: ignore[assignment]

        else:
            # Only allow root of external account (default)
            principal = iam.AccountPrincipal(external_account_id)  # type: ignore[assignment]

        # Generate description
        if not role_description:
            role_description = (
                f"Role for external account {external_account_id} "
                f"to access S3 bucket {bucket_name}/{prefix}"
            )

        # Create role with basic trust policy
        role_kwargs: Dict[str, Any] = {
            "role_name": role_name,
            "description": role_description,
            "assumed_by": principal,
        }

        if max_session_duration:
            role_kwargs["max_session_duration"] = max_session_duration

        # Create the role
        role = iam.Role(self, construct_id, **role_kwargs)

        # Add conditions to trust policy
        if allow_any_principal or external_id or require_mfa:
            # Select the appropriate principal for the policy statement
            stmt_principal = (
                iam.AnyPrincipal() if allow_any_principal else principal
            )

            assume_role_statement = iam.PolicyStatement(
                effect=iam.Effect.ALLOW,
                actions=["sts:AssumeRole"],
                principals=[stmt_principal]  # type: ignore[list-item]
            )

            # Restrict to specific account when using AnyPrincipal
            if allow_any_principal:
                assume_role_statement.add_condition(
                    "StringEquals",
                    {"aws:PrincipalAccount": external_account_id}
                )

            if external_id:
                assume_role_statement.add_condition(
                    "StringEquals",
                    {"sts:ExternalId": external_id}
                )

            if require_mfa:
                assume_role_statement.add_condition(
                    "Bool",
                    {"aws:MultiFactorAuthPresent": "true"}
                )

            # Add the statement with conditions to the trust policy
            if role.assume_role_policy:
                role.assume_role_policy.add_statements(assume_role_statement)

        return role

    # pylint: disable=too-many-arguments,too-many-positional-arguments
    def _create_iam_policy(
            self,
            construct_id: str,
            role_name: str,
            bucket_name: str,
            prefix: str,
            access_level: AccessLevel,
            allow_list_buckets: bool,
            kms_key: Optional[kms.IKey],
    ) -> iam.Policy:
        """
        Create the IAM policy with appropriate S3 permissions.

        :param construct_id: Construct ID for the policy.
        :param role_name: Name of the IAM role.
        :param bucket_name: S3 bucket name.
        :param prefix: S3 prefix.
        :param access_level: Access level for permissions.
        :param allow_list_buckets: Allow listing all buckets.
        :param kms_key: Optional KMS key.

        :return: The created IAM policy.
        :rtype: iam.Policy
        """

        statements: List[iam.PolicyStatement] = []

        # Optional: Allow listing all buckets (SECURITY WARNING)
        # This grants s3:ListAllMyBuckets, which exposes ALL bucket names
        # in the account to the external party, even those without access.
        # Only enable if absolutely required (default: False).
        if allow_list_buckets:
            statements.append(
                iam.PolicyStatement(
                    effect=iam.Effect.ALLOW,
                    actions=[
                        "s3:ListAllMyBuckets",
                    ],
                    resources=[
                        "arn:aws:s3:::*",
                    ]
                )
            )

        # Allow getting bucket location (always needed)
        statements.append(
            iam.PolicyStatement(
                effect=iam.Effect.ALLOW,
                actions=[
                    "s3:GetBucketLocation",
                ],
                resources=[
                    f"arn:aws:s3:::{bucket_name}",
                ]
            )
        )

        # Add access-level specific permissions
        s3_actions = self._get_s3_actions_for_access_level(access_level)

        # ListBucket permission (if applicable)
        if "s3:ListBucket" in s3_actions:
            list_statement = iam.PolicyStatement(
                effect=iam.Effect.ALLOW,
                actions=[
                    "s3:ListBucket",
                ],
                resources=[
                    f"arn:aws:s3:::{bucket_name}",
                ]
            )

            # Add prefix condition - allow listing the prefix itself and its contents
            # This allows both "aws s3 ls s3://bucket/prefix/" and listing objects within it
            list_statement.add_condition(
                "StringLike",
                {
                    "s3:prefix": [
                        f"{prefix}/*",
                        prefix,
                    ]
                }
            )

            statements.append(list_statement)
            s3_actions.remove("s3:ListBucket")

        # Object-level permissions
        if s3_actions:
            statements.append(
                iam.PolicyStatement(
                    effect=iam.Effect.ALLOW,
                    actions=list(s3_actions),
                    resources=[
                        f"arn:aws:s3:::{bucket_name}/{prefix}/*",
                    ]
                )
            )

        # Add KMS permissions if encryption is used
        if kms_key:
            kms_actions = self._get_kms_actions_for_access_level(access_level)

            statements.append(
                iam.PolicyStatement(
                    effect=iam.Effect.ALLOW,
                    actions=kms_actions,
                    resources=[kms_key.key_arn]
                )
            )

        # Create policy
        policy_document = iam.PolicyDocument(statements=statements)

        return iam.Policy(
            self,
            construct_id,
            policy_name=f"{role_name}-s3-access-policy",
            document=policy_document
        )

    @staticmethod
    def _get_s3_actions_for_access_level(access_level: AccessLevel) -> List[str]:
        """
        Get S3 actions based on access level.

        :param access_level: The access level.
        :return: List of S3 actions.
        :rtype: List[str]
        """

        actions: List[str] = []

        if access_level in [AccessLevel.READ, AccessLevel.READ_WRITE, AccessLevel.FULL]:
            actions.extend([
                "s3:GetObject",
                "s3:ListBucket",
            ])

        if access_level in [AccessLevel.WRITE, AccessLevel.READ_WRITE, AccessLevel.FULL]:
            actions.append("s3:PutObject")

        if access_level == AccessLevel.FULL:
            actions.extend([
                "s3:DeleteObject",
                "s3:DeleteObjectVersion",
            ])

        return actions

    @staticmethod
    def _get_kms_actions_for_access_level(access_level: AccessLevel) -> List[str]:
        """
        Get KMS actions based on access level.

        :param access_level: The access level.
        :return: List of KMS actions.
        :rtype: List[str]
        """

        actions = ["kms:DescribeKey"]

        if access_level in [AccessLevel.READ, AccessLevel.READ_WRITE, AccessLevel.FULL]:
            actions.append("kms:Decrypt")

        if access_level in [AccessLevel.WRITE, AccessLevel.READ_WRITE, AccessLevel.FULL]:
            actions.extend([
                "kms:Encrypt",
                "kms:GenerateDataKey"
            ])

        return actions
