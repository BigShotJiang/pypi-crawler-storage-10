# -*- coding: utf-8 -*-

"""
S3 Stack Module.

This module provides AWS CDK constructs for creating and managing S3
infrastructure, including buckets and cross-account access roles.
"""

from .base import AccessLevel
from .base import BaseS3Stack

__all__ = [
    "AccessLevel",
    "BaseS3Stack",
]
