# -*- coding: utf-8 -*-

"""SNS (Simple Notification Service) stack module."""

from .base import BaseSnsStack


__all__ = [
    "BaseSnsStack",
]
