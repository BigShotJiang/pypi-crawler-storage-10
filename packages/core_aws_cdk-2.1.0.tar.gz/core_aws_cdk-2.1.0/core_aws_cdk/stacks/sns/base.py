# -*- coding: utf-8 -*-

"""
SNS Stack for AWS CDK.

This module provides a base stack for creating and managing
Amazon SNS topics with support for standard and FIFO topics,
content-based deduplication, and subscription management.
"""

from typing import Any, Optional

from aws_cdk import aws_sns as sns

from core_aws_cdk.stacks.base import BaseStack


class BaseSnsStack(BaseStack):
    """
    Base SNS stack providing topic creation and management.

    Extends BaseStack to provide:
    - Standard and FIFO topic creation
    - Content-based deduplication for FIFO topics
    - Display name configuration for notifications
    - Automatic tagging and lifecycle policies
    """

    # pylint: disable=too-many-arguments,too-many-positional-arguments
    def create_sns_topic(
        self,
        topic_id: str,
        topic_name: Optional[str] = None,
        display_name: Optional[str] = None,
        fifo: Optional[bool] = None,
        content_based_deduplication: Optional[bool] = None,
        **kwargs: Any
    ) -> sns.Topic:
        """
        Create a new Amazon SNS topic (standard or FIFO).

        :param topic_id: Construct ID for the topic resource.

        :param topic_name:
            Name of the SNS topic (must be unique within account/region).
            FIFO topics must end with .fifo suffix.

        :param display_name:
            Human-readable name shown in notifications
            (SMS, email subject lines)

        :param fifo:
            If True, creates a FIFO (first-in-first-out) topic.
            FIFO topics guarantee message ordering and
            exactly-once delivery.

        :param content_based_deduplication:
            Enable automatic deduplication based on
            message content for FIFO topics. Only applicable
            when fifo=True.

        :param kwargs: Additional topic properties
        :return: The created SNS topic

        For additional configuration options, see:
        https://docs.aws.amazon.com/cdk/api/v2/python/aws_cdk.aws_sns/Topic.html
        """

        return sns.Topic(
            self,
            topic_id,
            topic_name=topic_name,
            content_based_deduplication=content_based_deduplication,
            display_name=display_name,
            fifo=fifo,
            **kwargs
        )
