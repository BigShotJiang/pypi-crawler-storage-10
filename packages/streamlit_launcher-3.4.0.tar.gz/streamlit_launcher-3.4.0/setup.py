from setuptools import setup, find_packages
import os

# Baca README dengan encoding UTF-8
here = os.path.abspath(os.path.dirname(__file__))
with open(os.path.join(here, "README.md"), "r", encoding="utf-8") as f:
    long_description = f.read()

setup(
    name="streamlit_launcher",
    version="3.4.0",
    author="Dwi Bakti N Dev",
    author_email="dwibakti76@gmail.com",
    description=(
        "Streamlit Launcher is an advanced no-code platform that integrates Streamlit, "
        "deep learning, and machine learning into one unified environment. "
        "It allows users to train models, visualize data, and perform complete statistical "
        "and analytical tasks effortlessly without writing any code. With powerful AI-driven "
        "automation, it simplifies complex workflows for research, health, and data science."
    ),
    long_description=long_description,
    long_description_content_type="text/markdown",
    url="https://github.com/royhtml",
    project_urls={
        "Profile": "https://profiledwibaktindev.netlify.app/",
        "Itch.io": "https://royhtml.itch.io/",
        "Facebook": "https://www.facebook.com/Royhtml",
        "Webtoons": "https://www.webtoons.com/id/canvas/mariadb-hari-senin/episode-4-coding-championship/viewer?title_no=1065164&episode_no=4",
        "Global Komik": "https://globalcomix.com/read/dc7f0116-7187-49a0-a27b-62b6c81eb435/1?utm_medium=GCMobileReaderApp&utm_source=share-release&utm_campaign=Royy&utm_term=122186",
        "Portfolio": "https://portofolio-dwi-bakti-n-dev-liard.vercel.app/",
    },
    packages=find_packages(exclude=["tests*"]),
    install_requires=[
        "pillow>=8.0",
        "pyinstaller>=4.0",
        "pyqt5>=5.15",
        "streamlit>=1.0",
        "numpy>=1.21",
        "pandas>=1.3",
        "scikit-learn>=1.0",
        "matplotlib>=3.4",
        "seaborn>=0.11",
        "tensorflow>=2.6",
        "torch>=1.9",
    ],
    entry_points={
        "gui_scripts": [
            "streamlit_launcher=streamlit_launcher.cli:main",
        ],
    },
    include_package_data=True,
    package_data={
        "webscan": ["*.ico", "*.png"],
    },
    classifiers=[
        "Programming Language :: Python :: 3",
        "Topic :: Scientific/Engineering :: Artificial Intelligence",
        "Topic :: Scientific/Engineering :: Information Analysis",
        "Topic :: Scientific/Engineering :: Medical Science Apps.",
        "Topic :: Software Development :: User Interfaces",
        "License :: OSI Approved :: MIT License",
        "Operating System :: OS Independent",
    ],
    python_requires=">=3.7",
)
