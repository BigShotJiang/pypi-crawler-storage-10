
__version__ = '0.3.2'

def version() -> str:
    return __version__

