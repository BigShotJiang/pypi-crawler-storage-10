\# Conversational Tone Detector 💬



\## What This Does

This is a super smart Python package that checks text for its feelings!

\* It tells you if the tone is \*\*Positive, Negative, or Neutral\*\*.

\* It also detects if someone is being \*\*Sarcastic\*\*.

\* It gives a score for the overall feeling (sentiment).



\## How to Get It

You can get it using the 'pip install' command:

```bash

pip install conversational-tone-detector



How to Use It

You use it by importing the detector and feeding it text!



from conversational\_tone\_detector import ToneDetector



detector = ToneDetector()

result = detector.analyze\_tone("I absolutely love Mondays! Great job on the presentation.")



print(result) 

\# This will show you the tone, sarcasm flag, and emotion!



Rules and Thanks

Rules: Check the LICENSE.txt file for the sharing rules.



Author: Anushri Ranade 

