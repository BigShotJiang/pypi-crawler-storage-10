# Outbidd Common Utilities
Contains common utilities for use across Outbidd projects

---

### View Make Commands
```bash
make help
```
