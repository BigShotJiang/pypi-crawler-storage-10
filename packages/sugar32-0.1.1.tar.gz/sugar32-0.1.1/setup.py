from setuptools import setup, find_packages

setup(
    name='sugar32',  
    version='0.1.1',  
    author='renpyuser',
    description='Your pyserial based assistant',
    long_description=open('README.md', encoding='utf-8').read(),
    long_description_content_type='text/markdown',
    url='https://github.com/renpyuser/sugar', 
    packages=find_packages(),
    py_modules=['sugar/sugar'],  
    install_requires=[
        'pyserial',
    ],
    entry_points={
        'console_scripts': [
            'sugar=sugar:cli', 
        ],
    },
    classifiers=[
        'Programming Language :: Python :: 3',
        'License :: OSI Approved :: MIT License',
        'Operating System :: OS Independent',
    ],
    python_requires='>=3.6',
)
