"""
Tests for interpretation module.
"""
