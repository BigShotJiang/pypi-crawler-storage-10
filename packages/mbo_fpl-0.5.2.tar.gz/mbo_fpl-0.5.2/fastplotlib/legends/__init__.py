from .legend import Legend

__all__ = ["Legend"]
