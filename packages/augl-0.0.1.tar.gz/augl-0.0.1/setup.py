from setuptools import setup

setup(
    name='augl',
    version='0.0.1',
    description="Aaron's Universal* Graphing Library",
    long_description='',
    url='https://github.com/aaronhendry/augl',
    author='Aaron Hendry',
    author_email='aaronhendry@users.noreply.github.com',
    packages=[],
    classifiers=['Development Status :: 1 - Planning'],
)
