"""
A simple hello world package.
"""

__version__ = "0.0.1"

def hello():
    """Prints a hello message."""
    print("Hello from the highway package!")
