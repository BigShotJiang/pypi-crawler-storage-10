"""

A small utility to load a CSS-like `.richstyle` stylesheet and convert it
into a `richx.theme.Theme` or a mapping of style names -> style strings usable
by the `rich` library.

Features:
- Simple CSS-like syntax (selectors + block of declarations)
- Variables (like `--primary: #ff0000;`) with substitution
- Basic properties: color, background-color, fg, bg, bold, italic, underline,
  dim, strike, blink, reverse, uppercase, lowercase (transform is informational)
- CLI: `python rich_css_style.py path/to/styles.richstyle` prints a small summary

Usage (in the file):
- `from rich_css_style import load_stylesheet, theme_from_stylesheet`
- `theme = theme_from_stylesheet("./styles.richstyle")`
- `console = Console(theme=theme)`

Note: This aims to be small and dependency-free. It is NOT a complete CSS
implementation but a pragmatic translator from a human-friendly .richstyle
file into `rich` style strings and a Theme.

"""
from __future__ import annotations

import re
import sys
import zipfile
from pathlib import Path
from typing import Dict, Tuple, Optional
from importlib import resources

from richx.style import Style
from richx.theme import Theme

# --------------------------- Parsing utilities --------------------------- #

_SELECTOR_REGEX = re.compile(r"(?P<selector>[^{]+)\{(?P<body>[^}]+)\}", re.DOTALL)
_DECLARATION_REGEX = re.compile(r"(?P<prop>[^:]+):(?P<val>[^;]+);?")
_VAR_REGEX = re.compile(r"--(?P<name>[A-Za-z0-9_-]+)\s*:\s*(?P<value>[^;]+);?")


def _strip(s: str) -> str:
    return s.strip()


def _parse_declarations(block_text: str) -> Dict[str, str]:
    """Return dict of property -> value for text inside { ... }."""
    props: Dict[str, str] = {}
    for match in _DECLARATION_REGEX.finditer(block_text):
        prop = _strip(match.group("prop")).lower()
        val = _strip(match.group("val"))
        props[prop] = val
    return props


# --------------------------- Stylesheet parser --------------------------- #

class StylesheetParseError(Exception):
    pass


def parse_richstyle(text: str) -> Tuple[Dict[str, str], Dict[str, Dict[str, str]]]:
    """
    Parse .richstyle text.

    Returns (variables, rules) where:
      - variables: mapping of var_name -> value (strings, no leading '--')
      - rules: mapping of selector -> { prop: value }
    """
    variables: Dict[str, str] = {}
    rules: Dict[str, Dict[str, str]] = {}

    # First scan for variables defined at top-level (or anywhere)
    for vm in _VAR_REGEX.finditer(text):
        variables[vm.group("name")] = _strip(vm.group("value"))

    # Now find selector blocks
    for m in _SELECTOR_REGEX.finditer(text):
        selector = _strip(m.group("selector"))
        body = m.group("body")
        decls = _parse_declarations(body)
        # Substitute variables in declarations
        for k, v in list(decls.items()):
            decls[k] = _substitute_vars(v, variables)
        # Add rule
        rules[selector] = decls

    return variables, rules


def _substitute_vars(value: str, variables: Dict[str, str]) -> str:
    """Replace occurrences of var(...) and --var references in value."""
    # var(--name)
    def repl_var(m: re.Match) -> str:
        name = m.group("name")
        return variables.get(name, "")

    # var\(\s*--name\s*\)
    value = re.sub(r"var\(\s*--(?P<name>[A-Za-z0-9_-]+)\s*\)", repl_var, value)
    # direct --name usage
    value = re.sub(r"--(?P<name>[A-Za-z0-9_-]+)", lambda m: variables.get(m.group("name"), ""), value)
    return value


# --------------------------- Declaration -> rich style --------------------------- #

def _decls_to_style_string(decls: Dict[str, str]) -> str:
    """Convert declaration dict to a `rich` style string.

    Accepts properties:
      - color / fg
      - background-color / bg / bgcolor
      - bold: true | false
      - italic: true | false
      - underline: true | false
      - dim: true | false
      - strike / strikethrough: true | false
      - blink: true | false
      - reverse: true | false

    Values can be color names or hex like `#ff00aa`.
    """
    parts = []

    # Colors
    color = decls.get("color") or decls.get("fg")
    bgcolor = decls.get("background-color") or decls.get("bg") or decls.get("bgcolor")
    if color:
        parts.append(color)
    if bgcolor:
        parts.append("on "+bgcolor)

    # Boolean properties
    bool_props = [
        ("bold", "bold"),
        ("italic", "italic"),
        ("underline", "underline"),
        ("dim", "dim"),
        ("strike", "strike"),
        ("strikethrough", "strike"),
        ("blink", "blink"),
        ("reverse", "reverse"),
    ]

    for prop_name, token in bool_props:
        if prop_name in decls:
            val = decls[prop_name].lower()
            if val in ("1", "true", "on", "yes"):
                parts.append(token)
            # allow explicit 'false' to remove - do nothing on false

    # Additional shorthand: weight or font-style
    weight = decls.get("font-weight")
    if weight is not None:
        w = weight.strip().lower()
        if w in ("bold", "700", "800", "900"):
            parts.append("bold")

    # text-transform (informational only) - not reflected in style string

    return " ".join(parts).strip()


# --------------------------- Public API --------------------------- #


import tempfile
import shutil

def _read_richstyle_from_zip(zip_path: Path) -> str:
    """
    Read and concatenate all `.richstyle` files inside a zip archive.

    Args:
        zip_path (Path): Path to the zip file containing `.richstyle` files.

    Returns:
        str: Combined contents of all `.richstyle` files.
    """
    
    combined_content = []

    with zipfile.ZipFile(zip_path, "r") as zf:
        richstyle_files = [f for f in zf.namelist() if f.endswith(".richstyle")]
        if not richstyle_files:
            raise FileNotFoundError(f"No `.richstyle` files found in: {zip_path}")

        for name in richstyle_files:
            with zf.open(name) as file:
                text = file.read().decode("utf-8", errors="ignore").strip()
                if text:
                    combined_content.append(text)

    return "\n\n".join(combined_content)


def load_stylesheet(path: str | Path) -> Tuple[Dict[str, str], Dict[str, Dict[str, str]]]:
    """Load and parse a .richstyle file or .zip archive."""
    p = Path(path)
    if not p.exists():
        raise FileNotFoundError(f"Stylesheet not found: {p}")

    if zipfile.is_zipfile(p):
        text = _read_richstyle_from_zip(p)
    else:
        text = p.read_text(encoding="utf8")

    return parse_richstyle(text)

def theme_from_stylesheet(path: str | Path, selector_prefix: Optional[str] = None) -> Theme:
    """Compile a richx.Theme from a .richstyle file.

    If `selector_prefix` is provided, selectors will be prefixed (useful to
    scope rules to a namespace).
    """
    _, rules = load_stylesheet(path)
    mapping: Dict[str, str] = {}
    for selector, decls in rules.items():
        # We use the selector string as the theme key. Allow simple selectors only.
        key = selector.strip()
        if selector_prefix:
            key = f"{selector_prefix}.{key}"
        style_str = _decls_to_style_string(decls)
        # Validate style by trying to parse it with rich
        try:
            Style.parse(style_str)  # type: ignore
        except Exception:
            # If style_str is empty or invalid, fallback to empty string.
            if style_str:
                print(f"Warning: invalid style for selector '{selector}': '{style_str}'", file=sys.stderr)
            style_str = ""
        mapping[key] = style_str
    return Theme(mapping)


def compile_stylesheet_to_dict(path: str | Path) -> Dict[str, str]:
    """Return a mapping selector -> style string (already compiled)."""
    _, rules = load_stylesheet(path)
    out: Dict[str, str] = {}
    for selector, decls in rules.items():
        out[selector] = _decls_to_style_string(decls)
    return out


TEMPLATE_FOLDER = Path(__file__).parent / "template"
TEMPLATE_ZIP_NAME = TEMPLATE_FOLDER.with_suffix(".zip")
TEMPLATE_PASSWORD = b"DEFAULT"  # custom password for template.zip

def _ensure_templates_unpacked() -> None:
    """
    Ensure that built-in themes from `template.zip` are available on disk.

    - Extracts `.richstyle` files from the package archive into `template/`.
    - If the archive is password-protected, retries with password "DEFAULT".
    - Extraction is idempotent — never overwrites existing files.
    """
    # Skip if already unpacked
    if TEMPLATE_FOLDER.exists() and any(TEMPLATE_FOLDER.glob("*.richstyle")):
        return

    TEMPLATE_FOLDER.mkdir(exist_ok=True)

    try:
        with resources.files(__package__).joinpath(TEMPLATE_ZIP_NAME).open("rb") as zip_bytes:
            with zipfile.ZipFile(zip_bytes) as zf:
                members = [m for m in zf.namelist() if m.endswith(".richstyle")]
                if not members:
                    return

                try:
                    # Normal extraction first
                    for member in members:
                        dest = TEMPLATE_FOLDER / Path(member).name
                        if not dest.exists():
                            with zf.open(member) as src, open(dest, "wb") as dst:
                                dst.write(src.read())
                except RuntimeError as e:
                    # Retry with default password if needed
                    if "encrypted" in str(e).lower() or "password" in str(e).lower():
                        try:
                            for member in members:
                                dest = TEMPLATE_FOLDER / Path(member).name
                                if not dest.exists():
                                    with zf.open(member, pwd=TEMPLATE_PASSWORD) as src, open(dest, "wb") as dst:
                                        dst.write(src.read())
                        except RuntimeError:
                            raise RuntimeError(
                                f"[RichX] Could not unlock '{TEMPLATE_ZIP_NAME}' "
                                f"with default password 'DEFAULT'."
                            ) from e
                    else:
                        raise
    except (FileNotFoundError, zipfile.BadZipFile):
        # Safe silent failure skip if no bundled templates
        return

def _load_available_templates() -> Dict[str, Theme]:
    """
    Load all `.richstyle` themes bundled with the package or added by users.

    Returns:
        dict[str, Theme]: Mapping of THEME_NAME -> Theme object.
    """
    templates: Dict[str, Theme] = {}

    _ensure_templates_unpacked()
    if not TEMPLATE_FOLDER.exists():
        return templates

    for i, file in enumerate(TEMPLATE_FOLDER.glob("*.richstyle"), start=1):
        try:
            # Add the file path to ensure the template is discoverable
            sys.path.insert(i, str(file))
            theme_name = file.stem.upper().replace(".", "_") + "_THEME"
            templates[theme_name] = theme_from_stylesheet(file)
        except Exception as e:
            print(f"[RichX] Warning: could not load theme '{file.name}': {e}", file=sys.stderr)

    return templates

_RICHX_TEMPLATES = _load_available_templates()

# --------------------------- Small CLI --------------------------- #
if __name__ == "__main__":
    import argparse
    from richx.console import Console
    import json

    parser = argparse.ArgumentParser(description="Compile a .richstyle file into a rich Theme or JSON mapping.")
    parser.add_argument("path", help=".richstyle file to compile")
    parser.add_argument("--json", action="store_true", help="print mapping as JSON")
    parser.add_argument("--show", action="store_true", help="show a demo using rich Console")
    args = parser.parse_args()

    try:
        mapping = compile_stylesheet_to_dict(args.path)
    except Exception as e:
        print(f"Error parsing stylesheet: {e}")
        raise

    if args.json:
        print(json.dumps(mapping, indent=2))
        sys.exit(0)

    if args.show:
        console = Console()
        console.rule("Stylesheet Preview")
        for sel, style in mapping.items():
            console.print(f"{sel}: {style}", style=style)
        console.rule("End Preview")
        sys.exit(0)  
        print(f"- {sel}: {style}")
