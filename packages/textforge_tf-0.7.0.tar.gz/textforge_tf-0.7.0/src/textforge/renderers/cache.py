"""Render caching for performance optimization.

This module provides caching mechanisms for rendered content to avoid
redundant rendering operations and improve performance.
"""

from __future__ import annotations

from threading import RLock

from ..utils.logging import get_logger

logger = get_logger(__name__)


class RenderCache:
    """Cache for rendered content with configurable size limits."""

    def __init__(self, max_size: int = 1000) -> None:
        self.max_size = max_size
        self._cache: dict[str, object] = {}  # Cache key -> cached content
        self._access_order: list[str] = []  # For LRU eviction
        self._lock = RLock()
        self._hits = 0
        self._misses = 0
        logger.debug(f"Initialized RenderCache with max size {max_size}")

    def get(self, key: str) -> object | None:
        """Get cached content by key."""
        with self._lock:
            if key in self._cache:
                # Move to end (most recently used)
                self._access_order.remove(key)
                self._access_order.append(key)
                self._hits += 1
                logger.debug(f"Cache hit for key '{key}'")
                return self._cache[key]
            else:
                self._misses += 1
                logger.debug(f"Cache miss for key '{key}'")
                return None

    def put(self, key: str, content: object) -> None:
        """Store content in cache."""
        with self._lock:
            if key in self._cache:
                # Update existing entry
                self._access_order.remove(key)
            elif len(self._cache) >= self.max_size:
                # Evict least recently used
                evicted_key = self._access_order.pop(0)
                del self._cache[evicted_key]
                logger.debug(f"Evicted cache entry '{evicted_key}'")

            self._cache[key] = content
            self._access_order.append(key)
            logger.debug(f"Cached content for key '{key}'")

    def invalidate(self, key: str | None = None) -> None:
        """Invalidate cache entries."""
        with self._lock:
            if key is None:
                # Clear entire cache
                self._cache.clear()
                self._access_order.clear()
                logger.debug("Cleared entire render cache")
            else:
                # Remove specific key
                if key in self._cache:
                    del self._cache[key]
                    self._access_order.remove(key)
                    logger.debug(f"Invalidated cache entry '{key}'")

    def get_stats(self) -> dict[str, object]:
        """Get cache statistics."""
        with self._lock:
            total_requests = self._hits + self._misses
            hit_rate = self._hits / total_requests if total_requests > 0 else 0.0
            return {"size": len(self._cache), "max_size": self.max_size, "hits": self._hits, "misses": self._misses, "hit_rate": hit_rate}

    def clear(self) -> None:
        """Clear all cached content."""
        with self._lock:
            self._cache.clear()
            self._access_order.clear()
            self._hits = 0
            self._misses = 0
            logger.debug("Cleared render cache")
