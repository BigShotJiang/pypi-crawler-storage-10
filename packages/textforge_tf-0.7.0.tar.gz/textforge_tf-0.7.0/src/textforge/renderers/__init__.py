"""Renderers package initialization."""

from __future__ import annotations

from importlib import import_module

from .base import RenderBufferOverflowError, Renderer, RenderingError, RenderOutput, UnsupportedRendererError
from .cache import RenderCache
from .export import HTMLRenderer, PDFRenderer, PlainTextRenderer, SVGRenderer
from .interfaces import render_component, update_rendering
from .layers import AnimationLayer, RenderLayer
from .optimization import RenderOptimizer

__all__ = [
    # Base classes
    "Renderer",
    "RenderOutput",
    "RenderingError",
    "UnsupportedRendererError",
    "RenderBufferOverflowError",
    # Layers and effects
    "RenderLayer",
    "AnimationLayer",
    # Optimization
    "RenderCache",
    "RenderOptimizer",
    # Public interfaces
    "render_component",
    "update_rendering",
    # Export renderers
    "HTMLRenderer",
    "PDFRenderer",
    "PlainTextRenderer",
    "SVGRenderer",
]


def __getattr__(name: str) -> object:
    if name in {"cli", "gui", "export"}:
        module = import_module(f"textforge.renderers.{name}")
        globals()[name] = module
        return module
    elif name in {"HTMLRenderer", "PDFRenderer", "PlainTextRenderer", "SVGRenderer"}:
        from .export import HTMLRenderer, PDFRenderer, PlainTextRenderer, SVGRenderer
        if name == "HTMLRenderer":
            return HTMLRenderer
        elif name == "PDFRenderer":
            return PDFRenderer
        elif name == "PlainTextRenderer":
            return PlainTextRenderer
        elif name == "SVGRenderer":
            return SVGRenderer
    raise AttributeError(f"module 'textforge.renderers' has no attribute '{name}'")
