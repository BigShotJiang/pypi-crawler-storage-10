"""Renderable base classes to standardize render/measure across components.

Components should derive from `RenderableBase` or mix in `MeasureMixin` to
provide consistent rendering and measurement hooks, rather than ad-hoc print
helpers. This enables composition and better testing.
"""

from __future__ import annotations

from abc import ABC, abstractmethod
from dataclasses import dataclass
from threading import RLock
from typing import TYPE_CHECKING, Protocol

from ..core import Console, Measure, Renderable
from ..core.diffing.patches import PatchType
from ..core.layout.types import RendererType
from ..utils.logging import get_logger

if TYPE_CHECKING:
    from collections.abc import Callable, Iterable

    from ..core.diffing.patches import Patch
    from ..core.layout.engine import LayoutResult
    from ..core.vdom import VDOMTree
    from ..core.vdom.tree import VDOMNode
    from ..renderers.layers import RenderLayer

logger = get_logger(__name__)


class RenderableBase(Renderable):
    """Base class for components that render to strings via Console."""

    def render(self, console: Console) -> str | Iterable[str] | None:
        raise NotImplementedError

    def to_node(self, console: Console) -> object:  # GuiNode placeholder
        raise NotImplementedError

    def measure(self, console: Console) -> Measure | None:
        rendered = self.render(console)
        if rendered is None:
            return Measure(width=0, height=0)
        if isinstance(rendered, str):
            return Measure.from_text(rendered)
        return Measure.from_text("".join(rendered))


class MeasureMixin:
    """Provide a default measure() implementation using render()."""

    def measure(self: HasRender, console: Console) -> Measure | None:
        rendered = self.render(console)
        if rendered is None:
            return Measure(width=0, height=0)
        if isinstance(rendered, str):
            return Measure.from_text(rendered)
        return Measure.from_text("".join(rendered))


class HasRender(Protocol):
    def render(self, console: Console) -> str | Iterable[str] | None: ...


@dataclass(slots=True)
class RenderOutput:
    """Output from a rendering operation."""

    content: str | bytes
    renderer_type: RendererType
    metadata: dict[str, object] | None = None


class RenderingError(Exception):
    """Base exception for rendering errors."""

    pass


class UnsupportedRendererError(RenderingError):
    """Exception raised when a renderer type is not supported."""

    pass


class RenderBufferOverflowError(RenderingError):
    """Exception raised when render buffer exceeds limits."""

    pass


class Renderer(ABC):
    """Abstract base class for all renderers."""

    def __init__(self, renderer_type: RendererType) -> None:
        self.renderer_type = renderer_type
        self._layers: list[RenderLayer] = []
        self._lock = RLock()
        logger.debug(f"Initialized {self.__class__.__name__} for {renderer_type}")

    @abstractmethod
    def render_tree(self, tree: VDOMTree, layout_result: LayoutResult) -> RenderOutput:
        """Render a VDOM tree with layout."""
        ...

    @abstractmethod
    def apply_patches(self, patches: list[Patch]) -> None:
        """Apply patches to current render state."""
        ...

    def add_layer(self, layer: RenderLayer) -> None:
        """Add a rendering layer."""
        with self._lock:
            self._layers.append(layer)
            # Sort layers by z-index for proper rendering order
            self._layers.sort(key=lambda layer: layer.z_index)
            logger.debug(f"Added layer '{layer.layer_name}' with z-index {layer.z_index} to {self.__class__.__name__}")

    def remove_layer(self, layer: RenderLayer) -> None:
        """Remove a rendering layer."""
        with self._lock:
            if layer in self._layers:
                self._layers.remove(layer)
                logger.debug(f"Removed layer from {self.__class__.__name__}")

    def get_layers(self) -> list[RenderLayer]:
        """Get all rendering layers in z-index order."""
        with self._lock:
            return self._layers.copy()

    def get_current_output(self) -> RenderOutput | None:
        """Get the current render output if available.

        This method should be overridden by subclasses to provide
        access to cached or current render state.

        Returns:
            Current render output or None if not available.
        """
        return None


class CLIRenderer(Renderer):
    """CLI terminal renderer."""

    def __init__(self) -> None:
        """Initialize the CLI renderer."""
        super().__init__(RendererType.CLI)
        self._buffer: list[str] = []
        self._cursor_pos = (0, 0)
        self._current_output: RenderOutput | None = None

    def render_tree(self, tree: VDOMTree, layout_result: LayoutResult) -> RenderOutput:
        """Render a VDOM tree with layout to CLI output.

        Args:
            tree: The VDOM tree to render.
            layout_result: The layout result containing positioning information.

        Returns:
            RenderOutput containing the rendered content and metadata.

        Raises:
            RenderingError: If rendering fails.
        """
        try:
            with self._lock:
                logger.debug(f"Rendering VDOM tree with {len(tree._key_map)} nodes")

                self._buffer.clear()

                # Render base layer
                self._render_base_layer(tree, layout_result)

                # Render additional layers
                for layer in self._layers:
                    layer.render(self._buffer, layout_result)

                output = "".join(self._buffer)
                self._current_output = RenderOutput(content=output, renderer_type=self.renderer_type, metadata={"cursor_pos": self._cursor_pos})
                return self._current_output

        except Exception as e:
            logger.error(f"CLI rendering failed: {e}")
            raise RenderingError(f"Failed to render CLI output: {e}") from e

    def apply_patches(self, patches: list[Patch]) -> None:
        """Apply patches to current CLI render state.

        Args:
            patches: List of patches to apply.

        Raises:
            RenderingError: If patch application fails.
        """
        try:
            with self._lock:
                logger.debug(f"Applying {len(patches)} patches to CLI renderer")

                for patch in patches:
                    self._apply_patch(patch)

        except Exception as e:
            logger.error(f"CLI patch application failed: {e}")
            raise RenderingError(f"Failed to apply patches: {e}") from e

    def _render_base_layer(self, tree: VDOMTree, layout_result: LayoutResult) -> None:
        """Render the base component layer.

        Args:
            tree: The VDOM tree to render.
            layout_result: The layout result with positioning.
        """
        if tree.root is None:
            logger.warning("VDOM tree has no root node")
            return

        def render_node(node: VDOMNode, bounds: tuple[int, int, int, int]) -> None:
            """Recursively render a VDOM node."""
            x, y, width, height = bounds

            # Get component renderer (simplified - would need component registry)
            renderer_func = self._get_component_renderer(node.component_name)
            if renderer_func:
                content = renderer_func(node, bounds)
                self._place_content(content, bounds)

            # Render children (simplified - would need proper layout child bounds)
            for child in node.children:
                # Placeholder child bounds - would need actual layout calculation
                child_bounds = (x, y, width, height)
                render_node(child, child_bounds)

        # Start rendering from root with full layout bounds
        root_bounds = (0, 0, int(layout_result.width), int(layout_result.height))
        render_node(tree.root, root_bounds)

    def _apply_patch(self, patch: Patch) -> None:
        """Apply a single patch to the render state.

        Args:
            patch: The patch to apply.

        Raises:
            RenderingError: If patch application fails.
        """
        try:
            logger.log(5, f"Applying {patch.patch_type.value} patch for key '{patch.key}'")

            if patch.patch_type == PatchType.UPDATE_PROPS:
                if patch.key is None:
                    raise RenderingError("Key required for UPDATE_PROPS patch")
                self._update_component_props(patch.key, patch.data)
                logger.debug(f"Updated properties for component '{patch.key}'")

            elif patch.patch_type == PatchType.ADD_NODE:
                self._add_component(patch.data)
                key = getattr(patch.data, 'key', None) or getattr(patch, 'key', 'unknown')
                logger.debug(f"Added component '{key}'")

            elif patch.patch_type == PatchType.REMOVE_NODE:
                if patch.key is None:
                    raise RenderingError("Key required for REMOVE_NODE patch")
                self._remove_component(patch.key)
                logger.debug(f"Removed component '{patch.key}'")

            elif patch.patch_type == PatchType.REPLACE_ROOT:
                self._replace_root(patch.data)
                logger.debug("Replaced root component")

            elif patch.patch_type == PatchType.MOVE_NODE:
                if patch.key is None:
                    raise RenderingError("Key required for MOVE_NODE patch")
                self._move_component(patch.key, patch.data)
                logger.debug(f"Moved component '{patch.key}' to position {patch.data}")

            else:
                raise RenderingError(f"Unknown patch type: {patch.patch_type}")

        except Exception as e:
            logger.error(f"Failed to apply patch {patch.patch_type.value}: {e}")
            raise RenderingError(f"Patch application failed: {e}") from e

    def _get_component_renderer(self, component_name: str) -> Callable[[VDOMNode, tuple[int, int, int, int]], str] | None:
        """Get renderer function for a component type.

        Args:
            component_name: Name of the component type.

        Returns:
            Renderer function or None if not found.
        """

        # Placeholder - would need component registry
        # For now, return a simple text renderer
        def simple_text_renderer(node: VDOMNode, bounds: tuple[int, int, int, int]) -> str:
            return str(node.props.get("content", ""))

        return simple_text_renderer

    def _place_content(self, content: str, bounds: tuple[int, int, int, int]) -> None:
        """Place content in the buffer at specified bounds.

        Args:
            content: The content to place.
            bounds: (x, y, width, height) bounds.
        """
        x, y, _, _ = bounds

        # Simple placement - would need more sophisticated text layout
        lines = content.split("\n")
        for i, line in enumerate(lines):
            if y + i < len(self._buffer):
                # Replace existing line
                current_line = list(self._buffer[y + i])
                for j, char in enumerate(line):
                    if x + j < len(current_line):
                        current_line[x + j] = char
                self._buffer[y + i] = "".join(current_line)
            else:
                # Extend buffer
                while len(self._buffer) <= y + i:
                    self._buffer.append("")
                padded_line = " " * x + line
                self._buffer[y + i] = padded_line

    def _update_component_props(self, key: str, props: dict[str, object]) -> None:
        """Update properties of a component.

        Args:
            key: Component key.
            props: New properties.
        """
        logger.log(5, f"Updated properties for component '{key}': {list(props.keys())}")

    def _add_component(self, node: VDOMNode) -> None:
        """Add a new component.

        Args:
            node: The VDOM node to add.
        """
        logger.debug(f"Added component '{node.key}' to CLI renderer")

    def _remove_component(self, key: str) -> None:
        """Remove a component.

        Args:
            key: Component key to remove.
        """
        logger.debug(f"Removed component '{key}' from CLI renderer")

    def _replace_root(self, new_root: VDOMNode) -> None:
        """Replace the root component.

        Args:
            new_root: New root VDOM node.
        """
        logger.debug("Replaced CLI renderer root")

    def _move_component(self, key: str, new_position: int) -> None:
        """Move a component to a new position.

        Args:
            key: Component key.
            new_position: New position.
        """
        logger.log(5, f"Moved component '{key}' to position {new_position}")

    def get_current_output(self) -> RenderOutput | None:
        """Get the current render output.

        Returns:
            The most recent render output or None if no rendering has occurred.
        """
        return self._current_output
