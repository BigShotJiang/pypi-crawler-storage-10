"""Live session renderer for interactive CLI applications."""

from __future__ import annotations

import time
from threading import RLock, Thread
from typing import TYPE_CHECKING

from ...utils.logging import get_logger
from ..base import CLIRenderer, RenderingError, RenderOutput

if TYPE_CHECKING:
    from collections.abc import Callable

    from ...core.layout.engine import LayoutResult
    from ...core.vdom import VDOMTree

logger = get_logger(__name__)


class LiveSessionRenderer(CLIRenderer):
    """Renderer for live, interactive CLI sessions with real-time updates."""

    def __init__(self) -> None:
        """Initialize the live session renderer."""
        super().__init__()
        self._render_lock = RLock()
        self._session_active = False
        self._update_thread: Thread | None = None
        self._last_render_time = 0.0
        self._target_fps = 30
        self._frame_interval = 1.0 / self._target_fps
        logger.debug("Initialized LiveSessionRenderer")

    def render_tree(self, tree: VDOMTree, layout_result: LayoutResult) -> RenderOutput:
        """Render VDOM tree for live session.

        Args:
            tree: The VDOM tree to render.
            layout_result: The layout result containing positioning information.

        Returns:
            RenderOutput containing the rendered content and metadata.

        Raises:
            RenderingError: If rendering fails.
        """
        with self._render_lock:
            try:
                logger.debug(f"Rendering VDOM tree with {len(tree._key_map)} nodes for live session")

                self._buffer.clear()

                # Render base layer with live session support
                self._render_live_layer(tree, layout_result)

                # Apply additional layers
                for layer in self._layers:
                    layer.render(self._buffer, layout_result)

                output = "".join(self._buffer)
                self._last_render_time = time.perf_counter()

                return RenderOutput(content=output, renderer_type=self.renderer_type, metadata={"cursor_pos": self._cursor_pos, "live_session": True, "timestamp": self._last_render_time})

            except Exception as e:
                logger.error(f"Live session rendering failed: {e}")
                raise RenderingError(f"Failed to render live session output: {e}") from e

    def apply_patches(self, patches: list[object]) -> None:
        """Apply patches in live session.

        Args:
            patches: List of patches to apply.

        Raises:
            RenderingError: If patch application fails.
        """
        with self._render_lock:
            try:
                logger.debug(f"Applying {len(patches)} patches to live session renderer")

                for patch in patches:
                    self._apply_live_patch(patch)

                # Trigger immediate re-render for live session
                if self._session_active:
                    self._schedule_render()

            except Exception as e:
                logger.error(f"Live session patch application failed: {e}")
                raise RenderingError(f"Failed to apply live session patches: {e}") from e

    def start_session(self) -> None:
        """Start the live session with real-time updates.

        Raises:
            RenderingError: If session start fails.
        """
        with self._render_lock:
            if self._session_active:
                logger.warning("Live session already active")
                return

            try:
                self._session_active = True
                # Start update thread for live rendering
                self._update_thread = Thread(target=self._live_update_loop, daemon=True, name="LiveSessionRenderer")
                self._update_thread.start()
                logger.debug("Started live session with real-time updates")

            except Exception as e:
                self._session_active = False
                logger.error(f"Failed to start live session: {e}")
                raise RenderingError(f"Failed to start live session: {e}") from e

    def stop_session(self) -> None:
        """Stop the live session.

        Raises:
            RenderingError: If session stop fails.
        """
        with self._render_lock:
            if not self._session_active:
                logger.warning("Live session not active")
                return

            try:
                self._session_active = False
                if self._update_thread and self._update_thread.is_alive():
                    self._update_thread.join(timeout=2.0)
                    if self._update_thread.is_alive():
                        logger.warning("Live session thread did not stop gracefully")
                self._update_thread = None
                logger.debug("Stopped live session")

            except Exception as e:
                logger.error(f"Failed to stop live session: {e}")
                raise RenderingError(f"Failed to stop live session: {e}") from e

    def is_session_active(self) -> bool:
        """Check if the live session is currently active.

        Returns:
            True if session is active, False otherwise.
        """
        with self._render_lock:
            return self._session_active

    def set_target_fps(self, fps: int) -> None:
        """Set the target frames per second for live updates.

        Args:
            fps: Target frames per second (1-60).

        Raises:
            ValueError: If fps is out of valid range.
        """
        if not 1 <= fps <= 60:
            raise ValueError("FPS must be between 1 and 60")

        with self._render_lock:
            self._target_fps = fps
            self._frame_interval = 1.0 / fps
            logger.debug(f"Set target FPS to {fps}")

    def _render_live_layer(self, tree: VDOMTree, layout_result: LayoutResult) -> None:
        """Render the base component layer for live session.

        Args:
            tree: The VDOM tree to render.
            layout_result: The layout result with positioning.
        """
        if tree.root is None:
            logger.warning("VDOM tree has no root node")
            return

        def render_node(node: object, bounds: tuple[int, int, int, int]) -> None:
            """Recursively render a VDOM node for live session."""
            # Import here to avoid circular imports
            from ...core.vdom.tree import VDOMNode

            if not isinstance(node, VDOMNode):
                logger.warning(f"Expected VDOMNode, got {type(node)}")
                return

            x, y, width, height = bounds

            # Get component renderer function with live session support
            renderer_func = self._get_component_renderer(node.component_name)
            if renderer_func:
                try:
                    content = renderer_func(node, bounds)
                    self._place_content(content, bounds)
                except Exception as e:
                    logger.error(f"Failed to render component '{node.component_name}': {e}")
                    # Continue with other components

            # Render children with their layout bounds
            # Note: This is simplified - actual implementation would need proper child bounds from layout
            for child in node.children:
                # Placeholder child bounds - would need actual layout calculation
                child_bounds = (x, y, width, height)
                render_node(child, child_bounds)

        # Start rendering from root with full layout bounds
        root_bounds = (0, 0, int(layout_result.width), int(layout_result.height))
        render_node(tree.root, root_bounds)

    def _apply_live_patch(self, patch: object) -> None:
        """Apply a single patch in live session.

        Args:
            patch: The patch to apply.
        """
        # Import here to avoid circular imports
        from ...core.vdom.patcher import Patch, PatchType

        if not isinstance(patch, Patch):
            logger.warning(f"Expected Patch, got {type(patch)}")
            return

        if patch.patch_type == PatchType.UPDATE_PROPS:
            if patch.key is None:
                raise RenderingError("Key required for UPDATE_PROPS patch")
            self._update_component_props(patch.key, patch.data)
        elif patch.patch_type == PatchType.ADD_NODE:
            self._add_component(patch.data)
        elif patch.patch_type == PatchType.REMOVE_NODE:
            if patch.key is None:
                raise RenderingError("Key required for REMOVE_NODE patch")
            self._remove_component(patch.key)
        elif patch.patch_type == PatchType.REPLACE_ROOT:
            self._replace_root(patch.data)
        elif patch.patch_type == PatchType.MOVE_NODE:
            if patch.key is None:
                raise RenderingError("Key required for MOVE_NODE patch")
            self._move_component(patch.key, patch.data)

    def _live_update_loop(self) -> None:
        """Main loop for live session updates."""
        logger.debug("Starting live session update loop")

        while self._session_active:
            try:
                current_time = time.perf_counter()
                time_since_last_render = current_time - self._last_render_time

                if time_since_last_render >= self._frame_interval:
                    # Trigger render update
                    self._perform_live_update()
                    self._last_render_time = current_time
                else:
                    # Sleep for remaining time
                    sleep_time = self._frame_interval - time_since_last_render
                    time.sleep(min(sleep_time, 0.1))  # Cap sleep to prevent long waits

            except Exception as e:
                logger.error(f"Error in live update loop: {e}")
                if self._session_active:
                    time.sleep(0.1)  # Brief pause before retrying

        logger.debug("Live session update loop ended")

    def _perform_live_update(self) -> None:
        """Perform a live update cycle."""
        # This would typically trigger a re-render through the event system
        # For now, it's a placeholder for the live update mechanism
        logger.log(5, "Performing live session update")

    def _schedule_render(self) -> None:
        """Schedule an immediate render update."""
        # Reset last render time to trigger immediate update
        self._last_render_time = 0.0

    def _get_component_renderer(self, component_name: str) -> Callable[[object, tuple[int, int, int, int]], str] | None:
        """Get renderer function for a component type.

        Args:
            component_name: Name of the component type.

        Returns:
            Renderer function or None if not found.
        """
        # Component renderer registry - simplified for now
        # In full implementation, this would be a proper registry
        renderers = {
            "text": self._render_text_component,
            "box": self._render_box_component,
            "button": self._render_button_component,
            "panel": self._render_panel_component,
            "spinner": self._render_spinner_component,
            "progress_bar": self._render_progress_bar_component,
        }

        return renderers.get(component_name, self._render_generic_component)

    def _render_text_component(self, node: object, bounds: tuple[int, int, int, int]) -> str:
        """Render a text component.

        Args:
            node: The VDOM node.
            bounds: (x, y, width, height) bounds.

        Returns:
            Rendered content string.
        """
        from ...core.vdom.tree import VDOMNode

        if not isinstance(node, VDOMNode):
            return ""

        content = str(node.props.get("content", ""))
        return content

    def _render_box_component(self, node: object, bounds: tuple[int, int, int, int]) -> str:
        """Render a box component.

        Args:
            node: The VDOM node.
            bounds: (x, y, width, height) bounds.

        Returns:
            Rendered content string.
        """
        from ...core.vdom.tree import VDOMNode

        if not isinstance(node, VDOMNode):
            return ""

        # Simple box rendering - just return content
        content = str(node.props.get("content", ""))
        return content

    def _render_button_component(self, node: object, bounds: tuple[int, int, int, int]) -> str:
        """Render a button component.

        Args:
            node: The VDOM node.
            bounds: (x, y, width, height) bounds.

        Returns:
            Rendered content string.
        """
        from ...core.vdom.tree import VDOMNode

        if not isinstance(node, VDOMNode):
            return ""

        label = str(node.props.get("label", node.props.get("content", "Button")))
        return f"[{label}]"

    def _render_panel_component(self, node: object, bounds: tuple[int, int, int, int]) -> str:
        """Render a panel component.

        Args:
            node: The VDOM node.
            bounds: (x, y, width, height) bounds.

        Returns:
            Rendered content string.
        """
        from ...core.vdom.tree import VDOMNode

        if not isinstance(node, VDOMNode):
            return ""

        title = node.props.get("title", "")
        content = str(node.props.get("content", ""))

        if title:
            return f"{title}\n{content}"
        return content

    def _render_spinner_component(self, node: object, bounds: tuple[int, int, int, int]) -> str:
        """Render a spinner component for live updates.

        Args:
            node: The VDOM node.
            bounds: (x, y, width, height) bounds.

        Returns:
            Rendered content string.
        """
        from ...core.vdom.tree import VDOMNode

        if not isinstance(node, VDOMNode):
            return ""

        # Simple spinner animation based on time
        spinner_chars = ["|", "/", "-", "\\"]
        frame = int(time.perf_counter() * 4) % len(spinner_chars)
        return spinner_chars[frame]

    def _render_progress_bar_component(self, node: object, bounds: tuple[int, int, int, int]) -> str:
        """Render a progress bar component.

        Args:
            node: The VDOM node.
            bounds: (x, y, width, height) bounds.

        Returns:
            Rendered content string.
        """
        from ...core.vdom.tree import VDOMNode

        if not isinstance(node, VDOMNode):
            return ""

        progress = float(node.props.get("progress", 0.0))
        width = bounds[2] if bounds[2] > 0 else 20

        filled = int(width * progress)
        bar = "█" * filled + "░" * (width - filled)
        percentage = f"{progress * 100:.1f}%"

        return f"[{bar}] {percentage}"

    def _render_generic_component(self, node: object, bounds: tuple[int, int, int, int]) -> str:
        """Render a generic component.

        Args:
            node: The VDOM node.
            bounds: (x, y, width, height) bounds.

        Returns:
            Rendered content string.
        """
        from ...core.vdom.tree import VDOMNode

        if not isinstance(node, VDOMNode):
            return ""

        # Fallback to content property
        return str(node.props.get("content", ""))

    def _update_component_props(self, key: str, props: dict[str, object]) -> None:
        """Update properties of a component.

        Args:
            key: Component key.
            props: New properties.
        """
        logger.log(5, f"Updated properties for component '{key}': {list(props.keys())}")

    def _add_component(self, node: object) -> None:
        """Add a new component.

        Args:
            node: The VDOM node to add.
        """
        from ...core.vdom.tree import VDOMNode

        if isinstance(node, VDOMNode):
            logger.debug(f"Added component '{node.key}' to live session renderer")
        else:
            logger.warning(f"Expected VDOMNode for add_component, got {type(node)}")

    def _remove_component(self, key: str) -> None:
        """Remove a component.

        Args:
            key: Component key to remove.
        """
        logger.debug(f"Removed component '{key}' from live session renderer")

    def _replace_root(self, new_root: object) -> None:
        """Replace the root component.

        Args:
            new_root: New root VDOM node.
        """
        logger.debug("Replaced live session renderer root")

    def _move_component(self, key: str, new_position: int) -> None:
        """Move a component to a new position.

        Args:
            key: Component key.
            new_position: New position.
        """
        logger.log(5, f"Moved component '{key}' to position {new_position}")
