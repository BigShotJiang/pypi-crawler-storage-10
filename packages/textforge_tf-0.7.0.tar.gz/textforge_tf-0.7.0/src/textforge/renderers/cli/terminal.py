"""Terminal renderer for basic CLI output."""

from __future__ import annotations

from threading import RLock
from typing import TYPE_CHECKING, Sequence

from ...utils.logging import get_logger
from ..base import CLIRenderer, RenderingError, RenderOutput

if TYPE_CHECKING:
    from collections.abc import Callable

    from ...core.layout.engine import LayoutResult
    from ...core.vdom import VDOMTree

logger = get_logger(__name__)


class TerminalRenderer(CLIRenderer):
    """Basic terminal renderer for CLI output with full VDOM support."""

    def __init__(self) -> None:
        """Initialize the terminal renderer."""
        super().__init__()
        self._render_lock = RLock()
        logger.debug("Initialized TerminalRenderer")

    def render_tree(self, tree: VDOMTree, layout_result: LayoutResult) -> RenderOutput:
        """Render VDOM tree to terminal output.

        Args:
            tree: The VDOM tree to render.
            layout_result: The layout result containing positioning information.

        Returns:
            RenderOutput containing the rendered content and metadata.

        Raises:
            RenderingError: If rendering fails.
        """
        with self._render_lock:
            try:
                logger.debug(f"Rendering VDOM tree with {len(tree._key_map)} nodes")

                self._buffer.clear()

                # Render base layer
                self._render_base_layer(tree, layout_result)

                # Apply additional layers
                for layer in self._layers:
                    layer.render(self._buffer, layout_result)

                output = "".join(self._buffer)
                return RenderOutput(content=output, renderer_type=self.renderer_type, metadata={"cursor_pos": self._cursor_pos})

            except Exception as e:
                logger.error(f"Terminal rendering failed: {e}")
                raise RenderingError(f"Failed to render terminal output: {e}") from e

    def apply_patches(self, patches: Sequence[object]) -> None:
        """Apply patches to current render state.

        Args:
            patches: List of patches to apply.

        Raises:
            RenderingError: If patch application fails.
        """
        with self._render_lock:
            try:
                logger.debug(f"Applying {len(patches)} patches to terminal renderer")

                for patch in patches:
                    self._apply_patch(patch)

            except Exception as e:
                logger.error(f"Terminal patch application failed: {e}")
                raise RenderingError(f"Failed to apply patches: {e}") from e

    def _render_base_layer(self, tree: VDOMTree, layout_result: LayoutResult) -> None:
        """Render the base component layer.

        Args:
            tree: The VDOM tree to render.
            layout_result: The layout result with positioning.
        """
        if tree.root is None:
            logger.warning("VDOM tree has no root node")
            return

        def render_node(node: object, bounds: tuple[int, int, int, int]) -> None:
            """Recursively render a VDOM node."""
            # Import here to avoid circular imports
            from ...core.vdom.tree import VDOMNode

            if not isinstance(node, VDOMNode):
                logger.warning(f"Expected VDOMNode, got {type(node)}")
                return

            x, y, width, height = bounds

            # Get component renderer function
            renderer_func = self._get_component_renderer(node.component_name)
            if renderer_func:
                try:
                    content = renderer_func(node, bounds)
                    self._place_content(content, bounds)
                except Exception as e:
                    logger.error(f"Failed to render component '{node.component_name}': {e}")
                    # Continue with other components

            # Render children with their layout bounds
            # Note: This is simplified - actual implementation would need proper child bounds from layout
            for child in node.children:
                # Placeholder child bounds - would need actual layout calculation
                child_bounds = (x, y, width, height)
                render_node(child, child_bounds)

        # Start rendering from root with full layout bounds
        root_bounds = (0, 0, int(layout_result.width), int(layout_result.height))
        render_node(tree.root, root_bounds)

    def _apply_patch(self, patch: object) -> None:
        """Apply a single patch to the render state.

        Args:
            patch: The patch to apply.
        """
        # Import here to avoid circular imports
        from ...core.vdom.patcher import Patch, PatchType

        if not isinstance(patch, Patch):
            logger.warning(f"Expected Patch, got {type(patch)}")
            return

        if patch.patch_type == PatchType.UPDATE_PROPS:
            if patch.key is None:
                raise RenderingError("Key required for UPDATE_PROPS patch")
            self._update_component_props(patch.key, patch.data)
        elif patch.patch_type == PatchType.ADD_NODE:
            self._add_component(patch.data)
        elif patch.patch_type == PatchType.REMOVE_NODE:
            if patch.key is None:
                raise RenderingError("Key required for REMOVE_NODE patch")
            self._remove_component(patch.key)
        elif patch.patch_type == PatchType.REPLACE_ROOT:
            self._replace_root(patch.data)
        elif patch.patch_type == PatchType.MOVE_NODE:
            if patch.key is None:
                raise RenderingError("Key required for MOVE_NODE patch")
            self._move_component(patch.key, patch.data)

    def _get_component_renderer(self, component_name: str) -> Callable[[object, tuple[int, int, int, int]], str] | None:
        """Get renderer function for a component type.

        Args:
            component_name: Name of the component type.

        Returns:
            Renderer function or None if not found.
        """
        # Component renderer registry - simplified for now
        # In full implementation, this would be a proper registry
        renderers = {
            "text": self._render_text_component,
            "box": self._render_box_component,
            "button": self._render_button_component,
            "panel": self._render_panel_component,
        }

        return renderers.get(component_name, self._render_generic_component)

    def _render_text_component(self, node: object, bounds: tuple[int, int, int, int]) -> str:
        """Render a text component.

        Args:
            node: The VDOM node.
            bounds: (x, y, width, height) bounds.

        Returns:
            Rendered content string.
        """
        from ...core.vdom.tree import VDOMNode

        if not isinstance(node, VDOMNode):
            return ""

        content = str(node.props.get("content", ""))
        return content

    def _render_box_component(self, node: object, bounds: tuple[int, int, int, int]) -> str:
        """Render a box component.

        Args:
            node: The VDOM node.
            bounds: (x, y, width, height) bounds.

        Returns:
            Rendered content string.
        """
        from ...core.vdom.tree import VDOMNode

        if not isinstance(node, VDOMNode):
            return ""

        # Simple box rendering - just return content
        content = str(node.props.get("content", ""))
        return content

    def _render_button_component(self, node: object, bounds: tuple[int, int, int, int]) -> str:
        """Render a button component.

        Args:
            node: The VDOM node.
            bounds: (x, y, width, height) bounds.

        Returns:
            Rendered content string.
        """
        from ...core.vdom.tree import VDOMNode

        if not isinstance(node, VDOMNode):
            return ""

        label = str(node.props.get("label", node.props.get("content", "Button")))
        return f"[{label}]"

    def _render_panel_component(self, node: object, bounds: tuple[int, int, int, int]) -> str:
        """Render a panel component.

        Args:
            node: The VDOM node.
            bounds: (x, y, width, height) bounds.

        Returns:
            Rendered content string.
        """
        from ...core.vdom.tree import VDOMNode

        if not isinstance(node, VDOMNode):
            return ""

        title = node.props.get("title", "")
        content = str(node.props.get("content", ""))

        if title:
            return f"{title}\n{content}"
        return content

    def _render_generic_component(self, node: object, bounds: tuple[int, int, int, int]) -> str:
        """Render a generic component.

        Args:
            node: The VDOM node.
            bounds: (x, y, width, height) bounds.

        Returns:
            Rendered content string.
        """
        from ...core.vdom.tree import VDOMNode

        if not isinstance(node, VDOMNode):
            return ""

        # Fallback to content property
        return str(node.props.get("content", ""))

    def _update_component_props(self, key: str, props: dict[str, object]) -> None:
        """Update properties of a component.

        Args:
            key: Component key.
            props: New properties.
        """
        logger.log(5, f"Updated properties for component '{key}': {list(props.keys())}")

    def _add_component(self, node: object) -> None:
        """Add a new component.

        Args:
            node: The VDOM node to add.
        """
        from ...core.vdom.tree import VDOMNode

        if isinstance(node, VDOMNode):
            logger.debug(f"Added component '{node.key}' to terminal renderer")
        else:
            logger.warning(f"Expected VDOMNode for add_component, got {type(node)}")

    def _remove_component(self, key: str) -> None:
        """Remove a component.

        Args:
            key: Component key to remove.
        """
        logger.debug(f"Removed component '{key}' from terminal renderer")

    def _replace_root(self, new_root: object) -> None:
        """Replace the root component.

        Args:
            new_root: New root VDOM node.
        """
        logger.debug("Replaced terminal renderer root")

    def _move_component(self, key: str, new_position: int) -> None:
        """Move a component to a new position.

        Args:
            key: Component key.
            new_position: New position.
        """
        logger.log(5, f"Moved component '{key}' to position {new_position}")
