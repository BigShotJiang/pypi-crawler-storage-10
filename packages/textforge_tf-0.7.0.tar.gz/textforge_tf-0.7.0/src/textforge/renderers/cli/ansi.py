"""ANSI renderer for colored CLI output."""

from __future__ import annotations

from threading import RLock
from typing import TYPE_CHECKING, Sequence

from ...utils.logging import get_logger
from ..base import CLIRenderer, RenderingError, RenderOutput

if TYPE_CHECKING:
    from collections.abc import Callable

    from ...core.layout.engine import LayoutResult
    from ...core.vdom import VDOMTree

logger = get_logger(__name__)


class ANSIRenderer(CLIRenderer):
    """ANSI renderer for colored and styled CLI output with full VDOM support."""

    def __init__(self) -> None:
        """Initialize the ANSI renderer."""
        super().__init__()
        self._render_lock = RLock()
        self._ansi_enabled = True
        logger.debug("Initialized ANSIRenderer")

    def render_tree(self, tree: VDOMTree, layout_result: LayoutResult) -> RenderOutput:
        """Render VDOM tree with ANSI styling.

        Args:
            tree: The VDOM tree to render.
            layout_result: The layout result containing positioning information.

        Returns:
            RenderOutput containing the rendered content and metadata.

        Raises:
            RenderingError: If rendering fails.
        """
        with self._render_lock:
            try:
                logger.debug(f"Rendering VDOM tree with {len(tree._key_map)} nodes using ANSI")

                self._buffer.clear()

                # Render base layer with ANSI support
                self._render_ansi_layer(tree, layout_result)

                # Apply additional layers
                for layer in self._layers:
                    layer.render(self._buffer, layout_result)

                output = "".join(self._buffer)
                return RenderOutput(content=output, renderer_type=self.renderer_type, metadata={"cursor_pos": self._cursor_pos, "has_ansi": self._ansi_enabled})

            except Exception as e:
                logger.error(f"ANSI rendering failed: {e}")
                raise RenderingError(f"Failed to render ANSI output: {e}") from e

    def apply_patches(self, patches: Sequence[object]) -> None:
        """Apply patches with ANSI updates.

        Args:
            patches: List of patches to apply.

        Raises:
            RenderingError: If patch application fails.
        """
        with self._render_lock:
            try:
                logger.debug(f"Applying {len(patches)} patches to ANSI renderer")

                for patch in patches:
                    self._apply_ansi_patch(patch)

            except Exception as e:
                logger.error(f"ANSI patch application failed: {e}")
                raise RenderingError(f"Failed to apply ANSI patches: {e}") from e

    def _render_ansi_layer(self, tree: VDOMTree, layout_result: LayoutResult) -> None:
        """Render the base component layer with ANSI styling.

        Args:
            tree: The VDOM tree to render.
            layout_result: The layout result with positioning.
        """
        if tree.root is None:
            logger.warning("VDOM tree has no root node")
            return

        def render_node(node: object, bounds: tuple[int, int, int, int]) -> None:
            """Recursively render a VDOM node with ANSI styling."""
            # Import here to avoid circular imports
            from ...core.vdom.tree import VDOMNode

            if not isinstance(node, VDOMNode):
                logger.warning(f"Expected VDOMNode, got {type(node)}")
                return

            x, y, width, height = bounds

            # Get component renderer function with ANSI support
            renderer_func = self._get_component_renderer(node.component_name)
            if renderer_func:
                try:
                    content = renderer_func(node, bounds)
                    # Apply ANSI styling if enabled
                    if self._ansi_enabled:
                        content = self._apply_ansi_styles(content, node)
                    self._place_content(content, bounds)
                except Exception as e:
                    logger.error(f"Failed to render component '{node.component_name}': {e}")
                    # Continue with other components

            # Render children with their layout bounds
            # Note: This is simplified - actual implementation would need proper child bounds from layout
            for child in node.children:
                # Placeholder child bounds - would need actual layout calculation
                child_bounds = (x, y, width, height)
                render_node(child, child_bounds)

        # Start rendering from root with full layout bounds
        root_bounds = (0, 0, int(layout_result.width), int(layout_result.height))
        render_node(tree.root, root_bounds)

    def _apply_ansi_patch(self, patch: object) -> None:
        """Apply a single patch with ANSI updates.

        Args:
            patch: The patch to apply.
        """
        # Import here to avoid circular imports
        from ...core.vdom.patcher import Patch, PatchType

        if not isinstance(patch, Patch):
            logger.warning(f"Expected Patch, got {type(patch)}")
            return

        if patch.patch_type == PatchType.UPDATE_PROPS:
            if patch.key is None:
                raise RenderingError("Key required for UPDATE_PROPS patch")
            self._update_component_props(patch.key, patch.data)
        elif patch.patch_type == PatchType.ADD_NODE:
            self._add_component(patch.data)
        elif patch.patch_type == PatchType.REMOVE_NODE:
            if patch.key is None:
                raise RenderingError("Key required for REMOVE_NODE patch")
            self._remove_component(patch.key)
        elif patch.patch_type == PatchType.REPLACE_ROOT:
            self._replace_root(patch.data)
        elif patch.patch_type == PatchType.MOVE_NODE:
            if patch.key is None:
                raise RenderingError("Key required for MOVE_NODE patch")
            self._move_component(patch.key, patch.data)

    def _apply_ansi_styles(self, content: str, node: object) -> str:
        """Apply ANSI escape codes to content based on component styling.

        Args:
            content: The content to style.
            node: The VDOM node containing style information.

        Returns:
            ANSI-styled content string.
        """
        from ...core.vdom.tree import VDOMNode

        if not isinstance(node, VDOMNode) or not self._ansi_enabled:
            return content

        # Extract style information from node props
        # This is a simplified implementation - full implementation would integrate with TFS styling
        style_props = node.props.get("style", {})

        ansi_codes: list[str] = []

        # Color styling
        if "color" in style_props:
            color_code = self._color_name_to_ansi(style_props["color"])
            if color_code:
                ansi_codes.append(color_code)

        if "background" in style_props:
            bg_code = self._background_name_to_ansi(style_props["background"])
            if bg_code:
                ansi_codes.append(bg_code)

        # Text styling
        if style_props.get("bold"):
            ansi_codes.append("1")
        if style_props.get("italic"):
            ansi_codes.append("3")
        if style_props.get("underline"):
            ansi_codes.append("4")

        if ansi_codes:
            # Apply ANSI codes and reset at end
            ansi_prefix = f"\x1b[{';'.join(ansi_codes)}m"
            ansi_reset = "\x1b[0m"
            return f"{ansi_prefix}{content}{ansi_reset}"

        return content

    def _color_name_to_ansi(self, color_name: str) -> str | None:
        """Convert color name to ANSI color code.

        Args:
            color_name: Name of the color.

        Returns:
            ANSI color code or None if not supported.
        """
        color_map = {
            "black": "30",
            "red": "31",
            "green": "32",
            "yellow": "33",
            "blue": "34",
            "magenta": "35",
            "cyan": "36",
            "white": "37",
            "bright_black": "90",
            "bright_red": "91",
            "bright_green": "92",
            "bright_yellow": "93",
            "bright_blue": "94",
            "bright_magenta": "95",
            "bright_cyan": "96",
            "bright_white": "97",
        }
        return color_map.get(color_name)

    def _background_name_to_ansi(self, color_name: str) -> str | None:
        """Convert color name to ANSI background color code.

        Args:
            color_name: Name of the color.

        Returns:
            ANSI background color code or None if not supported.
        """
        bg_map = {
            "black": "40",
            "red": "41",
            "green": "42",
            "yellow": "43",
            "blue": "44",
            "magenta": "45",
            "cyan": "46",
            "white": "47",
            "bright_black": "100",
            "bright_red": "101",
            "bright_green": "102",
            "bright_yellow": "103",
            "bright_blue": "104",
            "bright_magenta": "105",
            "bright_cyan": "106",
            "bright_white": "107",
        }
        return bg_map.get(color_name)

    def _get_component_renderer(self, component_name: str) -> Callable[[object, tuple[int, int, int, int]], str] | None:
        """Get renderer function for a component type.

        Args:
            component_name: Name of the component type.

        Returns:
            Renderer function or None if not found.
        """
        # Component renderer registry - simplified for now
        # In full implementation, this would be a proper registry
        renderers = {
            "text": self._render_text_component,
            "box": self._render_box_component,
            "button": self._render_button_component,
            "panel": self._render_panel_component,
        }

        return renderers.get(component_name, self._render_generic_component)

    def _render_text_component(self, node: object, bounds: tuple[int, int, int, int]) -> str:
        """Render a text component.

        Args:
            node: The VDOM node.
            bounds: (x, y, width, height) bounds.

        Returns:
            Rendered content string.
        """
        from ...core.vdom.tree import VDOMNode

        if not isinstance(node, VDOMNode):
            return ""

        content = str(node.props.get("content", ""))
        return content

    def _render_box_component(self, node: object, bounds: tuple[int, int, int, int]) -> str:
        """Render a box component.

        Args:
            node: The VDOM node.
            bounds: (x, y, width, height) bounds.

        Returns:
            Rendered content string.
        """
        from ...core.vdom.tree import VDOMNode

        if not isinstance(node, VDOMNode):
            return ""

        # Simple box rendering - just return content
        content = str(node.props.get("content", ""))
        return content

    def _render_button_component(self, node: object, bounds: tuple[int, int, int, int]) -> str:
        """Render a button component.

        Args:
            node: The VDOM node.
            bounds: (x, y, width, height) bounds.

        Returns:
            Rendered content string.
        """
        from ...core.vdom.tree import VDOMNode

        if not isinstance(node, VDOMNode):
            return ""

        label = str(node.props.get("label", node.props.get("content", "Button")))
        return f"[{label}]"

    def _render_panel_component(self, node: object, bounds: tuple[int, int, int, int]) -> str:
        """Render a panel component.

        Args:
            node: The VDOM node.
            bounds: (x, y, width, height) bounds.

        Returns:
            Rendered content string.
        """
        from ...core.vdom.tree import VDOMNode

        if not isinstance(node, VDOMNode):
            return ""

        title = node.props.get("title", "")
        content = str(node.props.get("content", ""))

        if title:
            return f"{title}\n{content}"
        return content

    def _render_generic_component(self, node: object, bounds: tuple[int, int, int, int]) -> str:
        """Render a generic component.

        Args:
            node: The VDOM node.
            bounds: (x, y, width, height) bounds.

        Returns:
            Rendered content string.
        """
        from ...core.vdom.tree import VDOMNode

        if not isinstance(node, VDOMNode):
            return ""

        # Fallback to content property
        return str(node.props.get("content", ""))

    def _update_component_props(self, key: str, props: dict[str, object]) -> None:
        """Update properties of a component.

        Args:
            key: Component key.
            props: New properties.
        """
        logger.log(5, f"Updated properties for component '{key}': {list(props.keys())}")

    def _add_component(self, node: object) -> None:
        """Add a new component.

        Args:
            node: The VDOM node to add.
        """
        from ...core.vdom.tree import VDOMNode

        if isinstance(node, VDOMNode):
            logger.debug(f"Added component '{node.key}' to ANSI renderer")
        else:
            logger.warning(f"Expected VDOMNode for add_component, got {type(node)}")

    def _remove_component(self, key: str) -> None:
        """Remove a component.

        Args:
            key: Component key to remove.
        """
        logger.debug(f"Removed component '{key}' from ANSI renderer")

    def _replace_root(self, new_root: object) -> None:
        """Replace the root component.

        Args:
            new_root: New root VDOM node.
        """
        logger.debug("Replaced ANSI renderer root")

    def _move_component(self, key: str, new_position: int) -> None:
        """Move a component to a new position.

        Args:
            key: Component key.
            new_position: New position.
        """
        logger.log(5, f"Moved component '{key}' to position {new_position}")
