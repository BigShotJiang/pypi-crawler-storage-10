from __future__ import annotations

from typing import TYPE_CHECKING, Protocol

from ..style import get_style_engine
from ..style.tfs.adapters.cli_mapper import map_to_cli
from ..style.tfs.adapters.gui_mapper import map_to_gui
from ..style.tfs.adapters.tty_mapper import map_to_tty

if TYPE_CHECKING:
    from textforge.style.tfs.tfs_cascade import ResolvedStyle


class CapabilityProvider(Protocol):
    def color_depth(self) -> str: ...  # TRUECOLOR/C256/C16/NONE
    def cell_metrics(self) -> tuple[int, int] | None: ...  # (cell_w_px, cell_h_px)
    def font_metrics(self, profile: str) -> tuple[int, int, int, int] | None: ...  # ascent, descent, advance, line_height
    def supports_feature(self, name: str) -> bool: ...
    def dpi(self) -> float | None: ...
    def pixel_to_cell(self, px: float) -> int: ...
    def percent_of(self, dim: str, value: float) -> float: ...


class BackendAdapter(Protocol):
    def capabilities(self) -> CapabilityProvider: ...
    def paint(self, node: object, resolved_style: object, layout_box: object, content: object | None) -> None: ...


class MainRenderer:
    """Select and wrap a backend adapter per configuration.

    Backends: 'auto' → GUI > TTY > CLI; 'gui'; 'tty'; 'cli'.
    """

    def __init__(self, config: dict[str, object] | None = None) -> None:
        self.config = dict(config or {})
        self._styles = get_style_engine()

    def select_backend(self, preferred: str | None, config: dict[str, object] | None = None) -> BackendAdapter:
        name = (preferred or self.config.get("backend") or "auto").__str__().lower()
        cfg = dict(self.config)
        if config:
            cfg.update(config)

        if name == "auto":
            # GUI > TTY > CLI
            for candidate in ("gui", "tty", "cli"):
                adapter = self._try_make(candidate, cfg)
                if adapter is not None:
                    return adapter
        else:
            adapter = self._try_make(name, cfg)
            if adapter is not None:
                return adapter
        # Fallback to CLI adapter
        adapter = self._try_make("cli", cfg)
        assert adapter is not None
        return adapter

    def _try_make(self, name: str, config: dict[str, object]) -> BackendAdapter | None:
        try:
            if name == "gui":
                from ..renderers.gui.runtime import get_runtime

                rt = get_runtime(create=True)
                if rt is None:
                    return None

                class _GuiCaps:
                    def color_depth(self) -> str:
                        return "TRUECOLOR"

                    def cell_metrics(self) -> tuple[int, int] | None:
                        return (10, 20)

                    def font_metrics(self, profile: str):
                        return None

                    def supports_feature(self, name: str) -> bool:
                        return name in {"outline"}

                    def dpi(self) -> float | None:
                        return 96.0

                    def pixel_to_cell(self, px: float) -> int:
                        return max(0, int(px / 10.0))

                    def percent_of(self, dim: str, value: float) -> float:
                        return value

                class _GuiAdapter:
                    def capabilities(self) -> CapabilityProvider:
                        return _GuiCaps()

                    def paint(self, node: object, resolved_style: ResolvedStyle, layout_box: object, content: object | None) -> None:
                        # Map style to GUI attributes (placeholder integration)
                        _ = map_to_gui(
                            resolved_style,
                            cell_metrics=self.capabilities().cell_metrics,
                            font_metrics=self.capabilities().font_metrics,
                        )

                return _GuiAdapter()

            if name == "tty":

                class _TtyCaps:
                    def color_depth(self) -> str:
                        return "C256"

                    def cell_metrics(self) -> tuple[int, int] | None:
                        return (10, 20)

                    def font_metrics(self, profile: str) -> tuple[int, int] | None:
                        return None

                    def supports_feature(self, name: str) -> bool:
                        return name in {"outline"}

                    def dpi(self) -> float | None:
                        return None

                    def pixel_to_cell(self, px: float) -> int:
                        return max(0, int(px / 10.0))

                    def percent_of(self, dim: str, value: float) -> float:
                        return value

                class _TtyAdapter:
                    def capabilities(self) -> CapabilityProvider:
                        return _TtyCaps()

                    def paint(self, node: object, resolved_style: ResolvedStyle, layout_box: object, content: object | None) -> None:
                        caps = self.capabilities()
                        _ = map_to_tty(
                            resolved_style,
                            pixel_to_cell=caps.pixel_to_cell,
                            color_depth=caps.color_depth,
                        )

                return _TtyAdapter()

            if name == "cli":

                class _CliCaps:
                    def color_depth(self) -> str:
                        return "NONE"

                    def cell_metrics(self) -> tuple[int, int] | None:
                        return None

                    def font_metrics(self, profile: str) -> tuple[int, int] | None:
                        return None

                    def supports_feature(self, name: str) -> bool:
                        return False

                    def dpi(self) -> float | None:
                        return None

                    def pixel_to_cell(self, px: float) -> int:
                        return 0

                    def percent_of(self, dim: str, value: float) -> float:
                        return value

                class _CliAdapter:
                    def capabilities(self) -> CapabilityProvider:
                        return _CliCaps()

                    def paint(self, node: object, resolved_style: ResolvedStyle, layout_box: object, content: object | None) -> None:
                        _ = map_to_cli(resolved_style)

                return _CliAdapter()

        except Exception:
            return None
        return None

    # -- style resolution convenience ------------------------------------------
    def resolve(self, *, node: object, state: dict[str, bool], backend: BackendAdapter) -> object:
        """Resolve styles for a node using the engine and backend capabilities."""
        caps = backend.capabilities()
        return self._styles.resolve(node=node, state=state, caps=caps)
