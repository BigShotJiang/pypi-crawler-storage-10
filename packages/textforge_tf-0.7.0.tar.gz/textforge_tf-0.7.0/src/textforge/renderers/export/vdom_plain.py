"""Plain text export renderer."""

from __future__ import annotations

from threading import RLock
from typing import TYPE_CHECKING

from ...core.layout.types import RendererType
from ...utils.logging import get_logger
from ..base import Renderer, RenderOutput

if TYPE_CHECKING:
    from collections.abc import Sequence

    from textforge.core import VDOMTree
    from textforge.core.layout.engine import LayoutResult
    pass  # Add type imports as needed

logger = get_logger(__name__)


class PlainTextRenderer(Renderer):
    """Renderer for plain text export."""

    def __init__(self) -> None:
        super().__init__(RendererType.CLI)  # Plain text uses CLI renderer type
        self._text_buffer: list[str] = []
        self._render_lock = RLock()
        self._current_tree: VDOMTree | None = None
        self._current_output: RenderOutput | None = None
        logger.debug("Initialized PlainTextRenderer")

    def render_tree(self, tree: VDOMTree, layout_result: LayoutResult) -> RenderOutput:
        """Render VDOM tree to plain text format."""
        with self._render_lock:
            self._text_buffer.clear()
            self._current_tree = tree

            # Render plain text content
            self._render_plain_content(tree, layout_result)

            text_content = "".join(self._text_buffer)
            self._current_output = RenderOutput(content=text_content, renderer_type=RendererType.CLI, metadata={"format": "text", "encoding": "utf-8"})
            return self._current_output

    def get_current_output(self) -> RenderOutput | None:
        """Get the current render output.

        Returns:
            The most recent render output or None if no rendering has occurred.
        """
        return self._current_output

    def apply_patches(self, patches: Sequence[object]) -> None:
        """Apply patches to plain text (not typically used for exports)."""
        with self._render_lock:
            # Plain text exports are typically static
            logger.debug("Plain text patches applied (no-op for exports)")

    def _render_plain_content(self, tree: object, layout_result: object) -> None:
        """Render content as plain text."""
        # Placeholder plain text content
        self._text_buffer.append("Plain text export\n")
        self._text_buffer.append("=================\n\n")
        self._text_buffer.append("This is exported content without formatting.\n")