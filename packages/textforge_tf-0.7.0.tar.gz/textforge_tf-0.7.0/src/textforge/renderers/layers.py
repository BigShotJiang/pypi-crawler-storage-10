"""Rendering layers for composable rendering pipeline.

Layers provide a way to add rendering effects, animations, and overlays
to the base rendering output. Each layer has a z-index for ordering.
"""

from __future__ import annotations

from abc import ABC, abstractmethod
from threading import RLock
from typing import TYPE_CHECKING

from ..utils.logging import get_logger

if TYPE_CHECKING:
    from textforge.components.base import Component

    from ..core.layout.engine import LayoutResult
    from ..effects.animation.keyframes import Animation

logger = get_logger(__name__)


class RenderLayer(ABC):
    """Abstract base class for rendering layers."""

    def __init__(self, layer_name: str, z_index: int = 0) -> None:
        """Initialize a rendering layer.

        Args:
            layer_name: Unique name for this layer.
            z_index: Z-index for layer ordering (higher values render on top).
        """
        self._layer_name = layer_name
        self._z_index = z_index
        self._lock = RLock()
        logger.debug(f"Initialized render layer '{layer_name}' with z-index {z_index}")

    @property
    def layer_name(self) -> str:
        """Get the layer name."""
        return self._layer_name

    @layer_name.setter
    def layer_name(self, value: str) -> None:
        """Set the layer name.

        Args:
            value: The layer name.
        """
        if not value:
            raise ValueError("Layer name cannot be empty")
        self._layer_name = value

    @property
    def z_index(self) -> int:
        """Get the z-index for layer ordering."""
        return self._z_index

    @z_index.setter
    def z_index(self, value: int) -> None:
        """Set the z-index for layer ordering.

        Args:
            value: The z-index value.
        """
        self._z_index = value

    @abstractmethod
    def render(self, buffer: list[str], layout_result: LayoutResult) -> None:
        """Render this layer's content to the buffer.

        Args:
            buffer: The render buffer to write to.
            layout_result: The layout result containing positioning information.
        """
        ...

    @abstractmethod
    def update(self, delta_time: float) -> None:
        """Update layer state for animations.

        Args:
            delta_time: Time elapsed since last update in seconds.
        """
        ...


class AnimationLayer(RenderLayer):
    """Layer for rendering animations and transitions."""

    def __init__(self, layer_name: str = "animation", z_index: int = 10) -> None:
        """Initialize the animation layer.

        Args:
            layer_name: Name for this animation layer.
            z_index: Z-index for layer ordering.
        """
        super().__init__(layer_name, z_index)
        self._animations: dict[str, Animation] = {}
        logger.debug(f"Initialized animation layer '{layer_name}' with z-index {z_index}")

    def render(self, buffer: list[str], layout_result: LayoutResult) -> None:
        """Render active animations.

        Args:
            buffer: The render buffer to write to.
            layout_result: The layout result containing positioning information.
        """
        with self._lock:
            try:
                active_animations = self._get_active_animations()
                if not active_animations:
                    logger.debug(f"No active animations in layer '{self.layer_name}'")
                    return

                logger.debug(f"Rendering {len(active_animations)} animations in layer '{self.layer_name}'")

                for animation in active_animations:
                    self._render_animation(animation, buffer, layout_result)

            except Exception as e:
                logger.error(f"Failed to render animations in layer '{self.layer_name}': {e}")
                raise

    def update(self, delta_time: float) -> None:
        """Update animation state.

        Args:
            delta_time: Time elapsed since last update in seconds.
        """
        with self._lock:
            try:
                completed_animations: list[str] = []

                for animation_id, animation in self._animations.items():
                    animation.update(delta_time)
                    if animation.is_complete():
                        completed_animations.append(animation_id)
                        logger.debug(f"Animation '{animation_id}' completed")

                # Remove completed animations
                for animation_id in completed_animations:
                    del self._animations[animation_id]

                if completed_animations:
                    logger.debug(f"Removed {len(completed_animations)} completed animations from layer '{self.layer_name}'")

            except Exception as e:
                logger.error(f"Failed to update animations in layer '{self.layer_name}': {e}")
                raise

    def add_animation(self, animation: Animation, animation_id: str | None = None) -> str:
        """Add an animation to this layer.

        Args:
            animation: The animation to add.
            animation_id: Optional ID for the animation. Auto-generated if not provided.

        Returns:
            The animation ID.
        """
        with self._lock:
            if animation_id is None:
                animation_id = self._generate_animation_id()

            if animation_id in self._animations:
                raise ValueError(f"Animation with ID '{animation_id}' already exists")

            self._animations[animation_id] = animation
            logger.debug(f"Added animation '{animation_id}' to layer '{self.layer_name}'")
            return animation_id

    def remove_animation(self, animation_id: str) -> None:
        """Remove an animation from this layer.

        Args:
            animation_id: The animation ID to remove.
        """
        with self._lock:
            if animation_id not in self._animations:
                logger.warning(f"Animation '{animation_id}' not found in layer '{self.layer_name}'")
                return

            del self._animations[animation_id]
            logger.debug(f"Removed animation '{animation_id}' from layer '{self.layer_name}'")

    def get_animation(self, animation_id: str) -> Animation | None:
        """Get an animation by ID.

        Args:
            animation_id: The animation ID.

        Returns:
            The animation if found, None otherwise.
        """
        with self._lock:
            return self._animations.get(animation_id)

    def get_active_animations(self) -> list[Animation]:
        """Get all active animations.

        Returns:
            List of active animations.
        """
        with self._lock:
            return [anim for anim in self._animations.values() if not anim.is_complete()]

    def clear_animations(self) -> None:
        """Clear all animations from this layer."""
        with self._lock:
            count = len(self._animations)
            self._animations.clear()
            logger.debug(f"Cleared {count} animations from layer '{self.layer_name}'")

    def _get_active_animations(self) -> list[Animation]:
        """Get currently active animations.

        Returns:
            List of active animations.
        """
        return [anim for anim in self._animations.values() if not anim.is_complete()]

    def _render_animation(self, animation: Animation, buffer: list[str], layout_result: LayoutResult) -> None:
        """Render a single animation.

        Args:
            animation: The animation to render.
            buffer: The render buffer.
            layout_result: The layout result.
        """
        try:
            # Get current animation state
            state = animation.get_current_state()

            # Apply animation transforms to component bounds
            transformed_bounds = self._apply_transforms(layout_result, state.transforms)

            # Render the animated component
            self._render_animated_component(animation.component, transformed_bounds, buffer)

        except Exception as e:
            logger.error(f"Failed to render animation for component '{animation.component.component_name}': {e}")
            # Continue with other animations rather than failing completely

    def _apply_transforms(self, layout_result: LayoutResult, transforms: list[str]) -> LayoutResult:
        """Apply animation transforms to layout result.

        Args:
            layout_result: The original layout result.
            transforms: List of transforms to apply.

        Returns:
            Transformed layout result.
        """
        # For now, return the original layout result
        # In a full implementation, this would apply translation, scale, rotation, etc.
        # TODO: Implement transform application for layout bounds
        return layout_result

    def _render_animated_component(self, component: Component, bounds: tuple[int, int, int, int], buffer: list[str]) -> None:
        """Render an animated component.

        Args:
            component: The component to render.
            bounds: The transformed bounds.
            buffer: The render buffer.
        """
        # Simplified rendering - in full implementation would delegate to component's render method
        # with transformed bounds
        # TODO: Implement proper component rendering with bounds
        logger.debug(f"Rendering animated component '{component.component_name}'")

    def _generate_animation_id(self) -> str:
        """Generate a unique animation ID.

        Returns:
            A unique animation ID.
        """
        import uuid

        return f"anim_{uuid.uuid4().hex[:8]}"
