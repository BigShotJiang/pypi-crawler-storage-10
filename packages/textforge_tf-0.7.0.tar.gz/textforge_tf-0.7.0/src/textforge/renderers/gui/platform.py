# textforge/renderers/gui/platform.py

from __future__ import annotations

import platform
from enum import Enum
from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from collections.abc import Callable

    from .window import Window


class Platform(Enum):
    """Supported GUI platforms."""

    WINDOWS = "windows"
    MACOS = "macos"
    LINUX = "linux"


def detect_platform() -> Platform:
    """Detect the current operating system platform."""
    system = platform.system().lower()
    if system == "windows":
        return Platform.WINDOWS
    elif system == "darwin":
        return Platform.MACOS
    elif system == "linux":
        return Platform.LINUX
    else:
        # Default to Linux for other Unix-like systems
        return Platform.LINUX


def create_window(
    title: str = "Textforge Window",
    width: int = 800,
    height: int = 600,
    on_key: Callable[[str], None] | None = None,
) -> Window:
    """Create a platform-appropriate window instance."""
    platform_type = detect_platform()

    if platform_type == Platform.WINDOWS:
        from .backends.win32.window import Win32Window

        return Win32Window(title, width, height, on_key)
    elif platform_type == Platform.MACOS:
        from .backends.cocoa.window import CocoaWindow

        return CocoaWindow(title, width, height, on_key)
    elif platform_type == Platform.LINUX:
        from .backends.gtk.window import GtkWindow

        return GtkWindow(title, width, height, on_key)
    else:
        raise RuntimeError(f"Unsupported platform: {platform_type}")


def get_supported_platforms() -> list[Platform]:
    """Get list of supported platforms."""
    return [Platform.WINDOWS, Platform.MACOS, Platform.LINUX]


def is_platform_supported(platform_type: Platform | None = None) -> bool:
    """Check if the current or specified platform is supported."""
    if platform_type is None:
        platform_type = detect_platform()
    return platform_type in get_supported_platforms()
