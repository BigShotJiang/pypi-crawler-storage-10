"""Adapter to convert GuiNode trees to LayoutNode trees for layout computation."""

from __future__ import annotations

from typing import TYPE_CHECKING

from ...core.layout.engine import LayoutNode, LayoutStyle, MeasureFunc

if TYPE_CHECKING:
    from ...style.tfs.tfs_cascade import ResolvedStyle
    from .types import GuiNode


def _resolved_style_to_layout_style(resolved_style: ResolvedStyle | None, component_name: str = "") -> LayoutStyle:
    """Convert TFS ResolvedStyle to LayoutStyle for layout computation."""
    if resolved_style is None:
        return LayoutStyle()

    style = LayoutStyle()

    # Convert dimensions
    if resolved_style.width is not None:
        # Convert length to pixels (simplified - assume px for now)
        style.width = int(getattr(resolved_style.width, "value", 0))
    if resolved_style.height is not None:
        style.height = int(getattr(resolved_style.height, "value", 0))
    if resolved_style.min_width is not None:
        style.min_width = int(getattr(resolved_style.min_width, "value", 0))
    if resolved_style.min_height is not None:
        style.min_height = int(getattr(resolved_style.min_height, "value", 0))
    if resolved_style.max_width is not None:
        style.max_width = int(getattr(resolved_style.max_width, "value", 0))
    if resolved_style.max_height is not None:
        style.max_height = int(getattr(resolved_style.max_height, "value", 0))

    # Convert padding (simplified - take first value if it's an insets object)
    if resolved_style.padding is not None:
        padding_val = getattr(resolved_style.padding, "top", None)
        if padding_val is not None:
            style.padding = int(getattr(padding_val, "value", 0))
        else:
            # Try direct value
            try:
                style.padding = int(resolved_style.padding)
            except (TypeError, ValueError):
                pass

    # Convert margin (simplified)
    if resolved_style.margin is not None:
        margin_val = getattr(resolved_style.margin, "top", None)
        if margin_val is not None:
            style.margin = int(getattr(margin_val, "value", 0))
        else:
            try:
                style.margin = int(resolved_style.margin)
            except (TypeError, ValueError):
                pass

    # Convert flex properties
    style.flex_grow = getattr(resolved_style, "flex_grow", 0.0) or 0.0
    style.flex_shrink = getattr(resolved_style, "flex_shrink", 1.0) or 1.0
    if resolved_style.flex_basis is not None:
        style.flex_basis = int(getattr(resolved_style.flex_basis, "value", 0))

    # Convert flex direction
    flex_direction = getattr(resolved_style, "flex_direction", "row") or "row"
    style.direction = flex_direction

    # Convert flex wrap
    flex_wrap = getattr(resolved_style, "flex_wrap", "nowrap") or "nowrap"
    style.wrap = flex_wrap == "wrap"

    # Convert justify content
    justify_content = getattr(resolved_style, "justify_content", "flex-start") or "flex-start"
    if justify_content == "flex-start":
        style.justify = "start"
    elif justify_content == "flex-end":
        style.justify = "end"
    elif justify_content == "center":
        style.justify = "center"
    elif justify_content == "space-between":
        style.justify = "space-between"
    elif justify_content == "space-around":
        style.justify = "space-around"
    elif justify_content == "space-evenly":
        style.justify = "space-evenly"
    else:
        style.justify = "start"  # default

    # Convert align items
    align_items = getattr(resolved_style, "align_items", "stretch") or "stretch"
    if align_items == "flex-start":
        style.align = "start"
    elif align_items == "flex-end":
        style.align = "end"
    elif align_items == "center":
        style.align = "center"
    elif align_items == "stretch":
        style.align = "stretch"
    else:
        style.align = "stretch"  # default

    return style


def _create_measure_func(node: GuiNode) -> MeasureFunc:
    """Create a measure function for a GuiNode."""

    def measure(available_width: int | None, available_height: int | None) -> tuple[int, int]:
        # For text nodes, estimate based on text length
        if node.component_name == "text" and node.text:
            text_len = len(node.text)
            # Rough estimate: ~10px per character, 20px height
            width = min(text_len * 10, available_width or 800)
            height = 20
            return width, height
        elif node.component_name == "title" and node.text:
            # Title is larger
            text_len = len(node.text)
            width = min(text_len * 12, available_width or 800)
            height = 30
            return width, height
        elif node.component_name == "paragraph" and node.text:
            # Paragraph wraps
            text_len = len(node.text)
            width = available_width or 400
            # Rough estimate of wrapped lines
            chars_per_line = max(1, width // 10)
            lines = (text_len + chars_per_line - 1) // chars_per_line
            height = lines * 16
            return width, height
        elif node.component_name in ("waveform", "spectrogram", "graph_canvas", "grid_map", "mini_map"):
            # Complex visualization components - constrain to available space
            width = min(available_width or 800, 800)  # Max 800px wide
            height = 150  # Fixed height for complex components
            return width, height
        else:
            # Default size for other components
            return min(200, available_width or 200), 50

    return measure


def build_layout_tree(node: GuiNode) -> LayoutNode:
    """Convert a GuiNode tree to a LayoutNode tree for layout computation."""
    layout_style = _resolved_style_to_layout_style(node.style, node.component_name)

    # If this is a root node with no style, set it to column layout for console-like stacking
    if node.component_name == "root" and node.style is None:
        layout_style.direction = "column"
        layout_style.align = "start"

    # Create a measure function for this node
    measure_func = _create_measure_func(node)

    ln = LayoutNode(style=layout_style, measure=measure_func)

    # For complex components, include children but mark them as absolutely positioned
    if node.component_name in ("waveform", "spectrogram", "graph_canvas", "grid_map", "mini_map"):
        # Children are positioned by the component's renderer using normalized coordinates
        # but we still include them in layout to ensure they get positioned relative to parent
        for child in node.children:
            child_ln = build_layout_tree(child)
            # Mark as absolutely positioned - don't let flex layout move them
            child_ln.style.width = 0
            child_ln.style.height = 0
            ln.add(child_ln)
    else:
        for child in node.children:
            child_ln = build_layout_tree(child)
            ln.add(child_ln)

    return ln


def apply_layout_back(node: GuiNode, layout: LayoutNode, offset_x: int = 0, offset_y: int = 0) -> None:
    """Apply computed layout back to the GuiNode tree."""
    # The layout.layout.x,y are relative to parent's content area, so add the parent's offset
    node.x = layout.layout.x + offset_x
    node.y = layout.layout.y + offset_y
    node.width = layout.layout.width
    node.height = layout.layout.height

    # For complex components, children are positioned by renderers using normalized coordinates
    if node.component_name in ("waveform", "spectrogram", "graph_canvas", "grid_map", "mini_map"):
        # Position children at the component's origin - renderers will adjust using normalized coords
        for child in node.children:
            child.x = node.x
            child.y = node.y
            child.width = 0  # Not used by renderers
            child.height = 0  # Not used by renderers
        return

    # For children, the offset is this node's position plus its padding
    if node.style and hasattr(node.style, "padding") and node.style.padding:
        padding = node.style.padding
        padding_left = int(padding.left.value) if hasattr(padding, "left") and hasattr(padding.left, "value") else 0
        padding_top = int(padding.top.value) if hasattr(padding, "top") and hasattr(padding.top, "value") else 0
        child_offset_x = node.x + padding_left
        child_offset_y = node.y + padding_top
    else:
        child_offset_x = node.x
        child_offset_y = node.y

    for ch_g, ch_l in zip(node.children, layout.children, strict=False):
        apply_layout_back(ch_g, ch_l, child_offset_x, child_offset_y)
