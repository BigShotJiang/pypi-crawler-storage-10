from __future__ import annotations

import ctypes
import ctypes.wintypes as wt
import hashlib
import threading
from typing import TYPE_CHECKING, Any

from ...utils.logging import get_logger
from .gui_layout import compute_layout_tree
from .types import GuiNode

if TYPE_CHECKING:
    from collections.abc import Callable

    from textforge.style.tfs.tfs_cascade import ResolvedStyle


# ---- 64-bit safe integral types for WinAPI WNDPROC ---------------------------------
LRESULT = ctypes.c_longlong  # LONG_PTR
WPARAM = ctypes.c_size_t  # UINT_PTR
LPARAM = ctypes.c_size_t  # LONG_PTR

# ---- Correct WNDPROC signature ----
WNDPROC = ctypes.WINFUNCTYPE(
    LRESULT,
    wt.HWND,
    wt.UINT,
    WPARAM,
    LPARAM,
)

# ---- Win32 constants ----------------------------------------------------------------
CS_HREDRAW = 0x0002
CS_VREDRAW = 0x0001

WM_DESTROY = 0x0002
WM_SIZE = 0x0005
WM_PAINT = 0x000F
WM_ERASEBKGND = 0x0014
WM_KEYDOWN = 0x0100
WM_LBUTTONDOWN = 0x0201

SW_SHOW = 5
WHITE_BRUSH = 0

TRANSPARENT = 1  # SetBkMode

# ---- DLLs ---------------------------------------------------------------------------
user32 = ctypes.WinDLL("user32", use_last_error=True)
gdi32 = ctypes.WinDLL("gdi32", use_last_error=True)
kernel32 = ctypes.WinDLL("kernel32", use_last_error=True)

# ---- Prototypes: make ctypes aware of exact signatures ------------------------------
# RegisterClassW
user32.RegisterClassW.argtypes = [ctypes.c_void_p]  # pointer to WNDCLASS (passed byref)
user32.RegisterClassW.restype = wt.ATOM

# CreateWindowExW
user32.CreateWindowExW.argtypes = [
    wt.DWORD,
    wt.LPCWSTR,
    wt.LPCWSTR,
    wt.DWORD,
    ctypes.c_int,
    ctypes.c_int,
    ctypes.c_int,
    ctypes.c_int,
    wt.HWND,
    wt.HMENU,
    wt.HINSTANCE,
    ctypes.c_void_p,
]
user32.CreateWindowExW.restype = wt.HWND

# ShowWindow / UpdateWindow
user32.ShowWindow.argtypes = [wt.HWND, ctypes.c_int]
user32.ShowWindow.restype = wt.BOOL
user32.UpdateWindow.argtypes = [wt.HWND]
user32.UpdateWindow.restype = wt.BOOL

# DefWindowProcW
user32.DefWindowProcW.argtypes = [wt.HWND, wt.UINT, WPARAM, LPARAM]
user32.DefWindowProcW.restype = LRESULT

# Message pump
user32.TranslateMessage.argtypes = [ctypes.POINTER(wt.MSG)]
user32.TranslateMessage.restype = wt.BOOL
user32.DispatchMessageW.argtypes = [ctypes.POINTER(wt.MSG)]
user32.DispatchMessageW.restype = LRESULT

# Painting
user32.BeginPaint.argtypes = [wt.HWND, ctypes.c_void_p]
user32.BeginPaint.restype = wt.HDC
user32.EndPaint.argtypes = [wt.HWND, ctypes.c_void_p]
user32.EndPaint.restype = wt.BOOL
user32.InvalidateRect.argtypes = [wt.HWND, ctypes.c_void_p, wt.BOOL]
user32.InvalidateRect.restype = wt.BOOL
user32.PostQuitMessage.argtypes = [ctypes.c_int]
user32.PostQuitMessage.restype = None
user32.PostMessageW.argtypes = [wt.HWND, wt.UINT, WPARAM, LPARAM]
user32.PostMessageW.restype = wt.BOOL
user32.LoadCursorW.argtypes = [wt.HINSTANCE, wt.LPCWSTR]
user32.LoadCursorW.restype = wt.HCURSOR

# GDI
gdi32.GetStockObject.argtypes = [ctypes.c_int]
gdi32.GetStockObject.restype = wt.HGDIOBJ
gdi32.CreateFontW.argtypes = [
    ctypes.c_int,
    ctypes.c_int,
    ctypes.c_int,
    ctypes.c_int,
    ctypes.c_int,
    wt.BOOL,
    wt.BOOL,
    wt.BOOL,
    ctypes.c_uint,
    ctypes.c_uint,
    ctypes.c_uint,
    ctypes.c_uint,
    ctypes.c_uint,
    wt.LPCWSTR,
]
gdi32.CreateFontW.restype = wt.HFONT
gdi32.SelectObject.argtypes = [wt.HDC, wt.HGDIOBJ]
gdi32.SelectObject.restype = wt.HGDIOBJ
gdi32.DeleteObject.argtypes = [wt.HGDIOBJ]
gdi32.DeleteObject.restype = wt.BOOL
gdi32.SetTextColor.argtypes = [wt.HDC, wt.COLORREF]
gdi32.SetTextColor.restype = wt.COLORREF
gdi32.TextOutW.argtypes = [wt.HDC, ctypes.c_int, ctypes.c_int, wt.LPCWSTR, ctypes.c_int]
gdi32.TextOutW.restype = wt.BOOL
gdi32.SetBkMode.argtypes = [wt.HDC, ctypes.c_int]
gdi32.SetBkMode.restype = ctypes.c_int
gdi32.MoveToEx.argtypes = [wt.HDC, ctypes.c_int, ctypes.c_int, ctypes.c_void_p]
gdi32.MoveToEx.restype = wt.BOOL
gdi32.LineTo.argtypes = [wt.HDC, ctypes.c_int, ctypes.c_int]
gdi32.LineTo.restype = wt.BOOL
gdi32.CreateSolidBrush.argtypes = [wt.COLORREF]
gdi32.CreateSolidBrush.restype = wt.HBRUSH
gdi32.CreatePen.argtypes = [ctypes.c_int, ctypes.c_int, wt.COLORREF]
gdi32.CreatePen.restype = wt.HPEN

# Kernel32
kernel32.GetModuleHandleW.argtypes = [wt.LPCWSTR]
kernel32.GetModuleHandleW.restype = wt.HMODULE


def MAKEINTRESOURCE(i: int) -> wt.LPCWSTR:
    return ctypes.cast(i, wt.LPCWSTR)


def _translate_virtual_key(value: int) -> str:
    mapping = {
        0x08: "backspace",
        0x09: "tab",
        0x0D: "enter",
        0x1B: "escape",
        0x20: "space",
        0x70: "f1",
        0x71: "f2",
        0x72: "f3",
        0x73: "f4",
        0x74: "f5",
        0x75: "f6",
        0x76: "f7",
        0x77: "f8",
        0x78: "f9",
        0x79: "f10",
        0x7A: "f11",
        0x7B: "f12",
    }
    if value in mapping:
        return mapping[value]
    if 0x30 <= value <= 0x39:
        return chr(value)
    if 0x41 <= value <= 0x5A:
        return chr(value).lower()
    return ""


def _approx_text_width(text: str) -> int:
    return len(text) * 10  # naive monospace approx


def _parse_css_color(css: str | None) -> tuple[int, int, int]:
    if not css:
        return (0, 0, 0)
    try:
        if css.startswith("#") and len(css) == 7:
            return (int(css[1:3], 16), int(css[3:5], 16), int(css[5:7], 16))
        if css.startswith("rgb(") and css.endswith(")"):
            parts = css[4:-1].split(",")
            return (int(parts[0]), int(parts[1]), int(parts[2]))
    except Exception:
        pass
    return (0, 0, 0)


class Win32Window:
    def __init__(
        self,
        title: str = "Textforge Window",
        width: int = 800,
        height: int = 600,
        on_key: Callable[[str], None] | None = None,
    ):
        self.title = title
        self.width = width
        self.height = height
        self._hwnd: wt.HWND | None = None
        self._thread: threading.Thread | None = None
        self._running = False
        self._frame_text = ""
        self._lock = threading.Lock()
        self._ready = threading.Event()
        self._error: Exception | None = None
        self._on_key = on_key
        self._root_component: GuiNode | None = None
        self._gui_root: GuiNode | None = None
        # Layout caching for performance
        self._cached_layout_tree: Any | None = None
        self._cached_viewport: tuple[int, int] | None = None
        self._layout_dirty: bool = True
        # LRU cache for layout computations - cache key is (tree_hash, viewport)
        self._layout_cache: dict[tuple[str, tuple[int, int]], tuple[Any, dict[str, Any]]] = {}
        self._layout_cache_max_size = 10  # Keep last 10 layout computations
        # Dirty rectangle tracking for incremental rendering
        self._dirty_rects: list[wt.RECT] = []
        self._full_redraw_needed = True
        self._resolve_style_fn: Callable[[Any, dict[str, bool], Any], Any] | None = None
        self._register_and_start()

    @property
    def viewport_w(self) -> int:
        """Get the current viewport width."""
        return self.width

    @property
    def viewport_h(self) -> int:
        """Get the current viewport height."""
        return self.height

    def _compute_tree_hash(self, node: GuiNode) -> str:
        """Compute a hash of the component tree structure for caching."""

        def hash_node(n: GuiNode) -> str:
            # Include component name, text, and state in hash
            state_str = str(sorted(n.state.items())) if n.state else ""
            children_hashes = [hash_node(child) for child in n.children]
            content = f"{n.component_name}|{n.text or ''}|{state_str}|{''.join(children_hashes)}"
            return hashlib.md5(content.encode("utf-8")).hexdigest()

        return hash_node(node)

    def _get_cached_layout(self, tree_hash: str, viewport: tuple[int, int]) -> tuple[Any, dict[str, Any]] | None:
        """Get cached layout if available."""
        return self._layout_cache.get((tree_hash, viewport))

    def _set_cached_layout(self, tree_hash: str, viewport: tuple[int, int], layout_data: tuple[Any, dict[str, Any]]) -> None:
        """Cache layout computation result."""
        if len(self._layout_cache) >= self._layout_cache_max_size:
            # Simple LRU: remove oldest entry
            oldest_key = next(iter(self._layout_cache))
            del self._layout_cache[oldest_key]
        self._layout_cache[(tree_hash, viewport)] = layout_data

    def _extract_layout_positions(self, node: GuiNode) -> dict[str, Any]:
        """Extract layout positions from GuiNode tree for caching."""
        positions: dict[str, Any] = {"x": node.x, "y": node.y, "width": node.width, "height": node.height}
        if node.children:
            positions["children"] = [self._extract_layout_positions(child) for child in node.children]
        return positions

    def _restore_layout_positions(self, node: GuiNode, positions: dict[str, Any]) -> None:
        """Restore layout positions to GuiNode tree from cache."""
        node.x = positions["x"]
        node.y = positions["y"]
        node.width = positions["width"]
        node.height = positions["height"]
        if "children" in positions and node.children:
            for child, child_positions in zip(node.children, positions["children"], strict=False):
                self._restore_layout_positions(child, child_positions)

    def _mark_rect_dirty(self, x: int, y: int, width: int, height: int) -> None:
        """Mark a specific rectangle as needing redraw."""
        rect = wt.RECT(x, y, x + width, y + height)
        self._dirty_rects.append(rect)

    def _clear_dirty_rects(self) -> None:
        """Clear all dirty rectangles."""
        self._dirty_rects.clear()
        self._full_redraw_needed = False

    def _mark_changed_components_dirty(self, old_root: GuiNode, new_root: GuiNode) -> None:
        """Compare old and new component trees and mark changed regions as dirty."""

        def compare_nodes(old_node: GuiNode, new_node: GuiNode) -> None:
            # Check if this node has changed
            if old_node.component_name != new_node.component_name or old_node.text != new_node.text or old_node.state != new_node.state:
                # Node changed - mark its entire bounds as dirty
                self._mark_rect_dirty(old_node.x, old_node.y, old_node.width, old_node.height)
                return

            # Compare children
            old_children = old_node.children
            new_children = new_node.children

            # If children count changed, mark entire parent area
            if len(old_children) != len(new_children):
                self._mark_rect_dirty(old_node.x, old_node.y, old_node.width, old_node.height)
                return

            # Compare each child recursively
            for old_child, new_child in zip(old_children, new_children, strict=False):
                compare_nodes(old_child, new_child)

        compare_nodes(old_root, new_root)

    def _invalidate_dirty_rects(self) -> None:
        """Invalidate all accumulated dirty rectangles."""
        if not self._dirty_rects:
            return

        for rect in self._dirty_rects:
            user32.InvalidateRect(self._hwnd, ctypes.byref(rect), True)

        self._clear_dirty_rects()

    def _hit_test_gui_node(self, node: GuiNode | None, x: int, y: int, offset_x: int = 0, offset_y: int = 0) -> GuiNode | None:
        """Return the deepest GuiNode that contains the given client coordinates."""
        if node is None:
            return None
        abs_x = offset_x + node.x
        abs_y = offset_y + node.y
        width = max(1, node.width)
        height = max(1, node.height)
        if not (abs_x <= x < abs_x + width and abs_y <= y < abs_y + height):
            return None
        for child in reversed(node.children):
            hit = self._hit_test_gui_node(child, x, y, abs_x, abs_y)
            if hit is not None:
                return hit
        return node

    def _dispatch_gui_click(self, node: GuiNode | None, x: int, y: int) -> bool:
        """Dispatch a click event to the closest interactive node metadata."""
        if node is None:
            return False
        target = node
        metadata = getattr(target, "metadata", {})
        callback = metadata.get("on_click")
        if callable(callback):
            try:
                callback({"x": x, "y": y, "node": target})
            except Exception as exc:
                get_logger().warning(f"GUI click handler raised: {exc}")
            return True
        renderable_ref = metadata.get("renderable")
        if renderable_ref is not None:
            try:
                renderable = renderable_ref() if callable(renderable_ref) else renderable_ref
            except ReferenceError:
                renderable = None
            if renderable is not None and hasattr(renderable, "handle_click"):
                try:
                    renderable.handle_click({"x": x, "y": y, "node": target})
                except Exception as exc:
                    get_logger().warning(f"Renderable click handler failed: {exc}")
                return True
        return False

    def _handle_mouse_click(self, lparam: int) -> None:
        """Translate a Win32 mouse click into component interaction callbacks."""
        x = ctypes.c_int16(lparam & 0xFFFF).value
        y = ctypes.c_int16((lparam >> 16) & 0xFFFF).value
        if self._gui_root is None:
            return
        hit_node: GuiNode | None = None
        for child in reversed(self._gui_root.children):
            hit_node = self._hit_test_gui_node(child, x, y, self._gui_root.x, self._gui_root.y)
            if hit_node is not None:
                break
        if hit_node is None:
            hit_node = self._hit_test_gui_node(self._gui_root, x, y)
        if hit_node is None or hit_node.component_name == "root":
            return
        print(f"DEBUG: Win32Window._handle_mouse_click hit {hit_node.component_name} at ({x},{y})")
        self._dispatch_gui_click(hit_node, x, y)

    def render_gui_node(self, root: GuiNode) -> None:
        """Render a GuiNode tree to the window."""
        # For the dual-renderer system, store the root and mark dirty regions
        old_root = self._gui_root
        self._gui_root = root
        self._layout_dirty = True  # Mark layout as dirty when GUI root changes
        print(f"DEBUG: Win32Window.render_gui_node hwnd_ready={self._hwnd is not None} had_old_root={old_root is not None}")

        if self._hwnd:
            if old_root is None:
                # First render - invalidate entire window
                user32.InvalidateRect(self._hwnd, None, True)
                # Post WM_PAINT message to trigger repaint
                user32.PostMessageW(self._hwnd, WM_PAINT, 0, 0)
                print("DEBUG: Win32Window.render_gui_node queued initial WM_PAINT")
            else:
                # Incremental update - mark changed components as dirty
                self._mark_changed_components_dirty(old_root, root)
                self._invalidate_dirty_rects()
                # Post WM_PAINT message to trigger repaint
                user32.PostMessageW(self._hwnd, WM_PAINT, 0, 0)
                print("DEBUG: Win32Window.render_gui_node queued incremental WM_PAINT")
        else:
            # Mark full redraw needed for when window becomes available
            self._full_redraw_needed = True
            print("DEBUG: Win32Window.render_gui_node stored root for later redraw")

    def set_root_component(self, component: GuiNode) -> None:
        self._root_component = component
        if self._hwnd:
            # Mark full redraw needed for legacy component system
            self._full_redraw_needed = True
            user32.InvalidateRect(self._hwnd, None, True)

    def set_style_resolver(self, resolver_fn: Callable[[Any, dict[str, bool], Any], Any]) -> None:
        """resolver_fn: (node, state: dict[str,bool], caps) -> ResolvedStyle"""
        self._resolve_style_fn = resolver_fn
        if self._hwnd:
            # Style changes may affect entire layout, so full redraw
            self._full_redraw_needed = True
            user32.InvalidateRect(self._hwnd, None, True)

    class _GdiMeasurer:
        def __init__(self, gdi32: Any, user32: Any, hdc: Any) -> None:
            self.gdi32 = gdi32
            self.user32 = user32
            self.hdc = hdc

        def _select_font(self, style: Any) -> None:
            px = 14
            face = "Consolas"
            weight = 400
            if getattr(style, "font_size", None) and getattr(style.font_size, "value", None) is not None:
                if getattr(style.font_size, "unit", "px") == "px":
                    px = int(round(float(style.font_size.value)))
            if getattr(style, "font", None):
                face = style.font
            if getattr(style, "weight", None):
                try:
                    weight = int(style.weight)
                except Exception:
                    weight = 700 if str(style.weight).lower() in ("bold", "600", "700", "800", "900") else 400
            hfont = gdi32.CreateFontW(-px, 0, 0, 0, weight, False, False, False, 0, 0, 0, 0, 0, face)
            old = gdi32.SelectObject(self.hdc, hfont)
            return hfont, old

        def measure_text(self, text: str, style: Any) -> tuple[int, int]:
            # Select font, call GetTextExtentPoint32W
            from ctypes import byref

            class SIZE(ctypes.Structure):
                _fields_ = [("cx", ctypes.c_long), ("cy", ctypes.c_long)]

            hfont, old = self._select_font(style)
            size = SIZE()
            # Declare prototype (once)
            try:
                _ = self.gdi32.GetTextExtentPoint32W
            except AttributeError:
                pass
            self.gdi32.GetTextExtentPoint32W.argtypes = [wt.HDC, wt.LPCWSTR, ctypes.c_int, ctypes.POINTER(SIZE)]
            self.gdi32.GetTextExtentPoint32W.restype = wt.BOOL
            self.gdi32.GetTextExtentPoint32W(self.hdc, text, len(text), byref(size))
            self.gdi32.SelectObject(self.hdc, old)
            self.gdi32.DeleteObject(hfont)
            return int(size.cx), int(size.cy)

    class _Win32Canvas:
        # LRU cache for GDI resources - shared across all canvas instances
        _font_cache: dict[tuple[int, int, str], wt.HFONT] = {}
        _brush_cache: dict[tuple[int, int, int, int], wt.HBRUSH] = {}
        _pen_cache: dict[tuple[int, tuple[int, int, int, int]], wt.HPEN] = {}
        _cache_max_size = 50  # Maximum cached resources per type

        def __init__(self, gdi32: Any, user32: Any, hdc: Any, viewport_w: int, viewport_h: int) -> None:
            self.gdi32 = gdi32
            self.user32 = user32
            self.hdc = hdc
            self.viewport_w = viewport_w
            self.viewport_h = viewport_h
            self._stack: list[tuple[int, int, int, int]] = []

        def save(self) -> None:
            # Save DC state (GDI SaveDC returns an int; we can ignore exact handle)
            pass

        def restore(self) -> None:
            pass

        @classmethod
        def _get_cached_font(cls, gdi32: Any, px: int, weight: int, face: str) -> wt.HFONT:
            """Get cached font or create new one."""
            # Validate parameters
            px = max(8, min(72, px))  # Reasonable font size range
            weight = max(100, min(900, weight))  # Valid weight range
            face = face or "Arial"  # Default fallback font

            key = (px, weight, face)
            if key in cls._font_cache:
                return cls._font_cache[key]

            # Create new font
            hfont: wt.HFONT = gdi32.CreateFontW(-px, 0, 0, 0, weight, False, False, False, 0, 0, 0, 0, 0, face)

            # Validate font creation
            if not hfont:
                # Fallback to system font if creation failed
                hfont = gdi32.GetStockObject(17)  # SYSTEM_FONT

            # Cache it with LRU eviction
            if len(cls._font_cache) >= cls._cache_max_size:
                oldest_key = next(iter(cls._font_cache))
                if cls._font_cache[oldest_key]:  # Only delete if valid
                    gdi32.DeleteObject(cls._font_cache[oldest_key])
                del cls._font_cache[oldest_key]

            cls._font_cache[key] = hfont
            return hfont

        @classmethod
        def _get_cached_brush(cls, gdi32: Any, color: tuple[int, int, int, int]) -> wt.HBRUSH:
            """Get cached brush or create new one."""
            # Validate color components
            r, g, b, a = color
            r = max(0, min(255, r))
            g = max(0, min(255, g))
            b = max(0, min(255, b))
            validated_color = (r, g, b, a)

            key = validated_color
            if key in cls._brush_cache:
                return cls._brush_cache[key]

            # Create new brush
            colorref = (b << 16) | (g << 8) | r  # BGR format
            hbrush: wt.HBRUSH = gdi32.CreateSolidBrush(colorref)

            # Validate brush creation
            if not hbrush:
                # Fallback to a default brush if creation failed
                hbrush = gdi32.GetStockObject(0)  # WHITE_BRUSH

            # Cache it with LRU eviction
            if len(cls._brush_cache) >= cls._cache_max_size:
                oldest_key = next(iter(cls._brush_cache))
                if cls._brush_cache[oldest_key]:  # Only delete if valid
                    gdi32.DeleteObject(cls._brush_cache[oldest_key])
                del cls._brush_cache[oldest_key]

            cls._brush_cache[key] = hbrush
            return hbrush

        @classmethod
        def _get_cached_pen(cls, gdi32: Any, width: int, color: tuple[int, int, int, int]) -> wt.HPEN:
            """Get cached pen or create new one."""
            # Validate color components
            r, g, b, a = color
            r = max(0, min(255, r))
            g = max(0, min(255, g))
            b = max(0, min(255, b))
            validated_color = (r, g, b, a)

            key = (width, validated_color)
            if key in cls._pen_cache:
                return cls._pen_cache[key]

            # Create new pen
            colorref = (b << 16) | (g << 8) | r  # BGR format
            hpen: wt.HPEN = gdi32.CreatePen(0, width, colorref)

            # Validate pen creation
            if not hpen:
                # Fallback to a default pen if creation failed
                hpen = gdi32.GetStockObject(7)  # BLACK_PEN

            # Cache it with LRU eviction
            if len(cls._pen_cache) >= cls._cache_max_size:
                oldest_key = next(iter(cls._pen_cache))
                if cls._pen_cache[oldest_key]:  # Only delete if valid
                    gdi32.DeleteObject(cls._pen_cache[oldest_key])
                del cls._pen_cache[oldest_key]

            cls._pen_cache[key] = hpen
            return hpen

        def _colorref(self, rgba: tuple[int, int, int, int]) -> int:
            r, g, b, _a = rgba
            return (b << 16) | (g << 8) | r

        def fill_rect(self, x: int, y: int, w: int, h: int, color: tuple[int, int, int, int]) -> None:
            # Validate and clamp all parameters
            try:
                x = int(x)
                y = int(y)
                w = int(w)
                h = int(h)
            except (ValueError, TypeError, OverflowError):
                return  # Skip invalid rectangles

            # Clamp coordinates to prevent overflow (Windows RECT uses LONG which is 32-bit)
            # Clamp individual values first, then ensure the final rect coordinates are valid
            x = max(-32768, min(32767, x))
            y = max(-32768, min(32767, y))
            w = max(0, min(32767, w))
            h = max(0, min(32767, h))

            # Skip empty rectangles
            if w <= 0 or h <= 0:
                return

            # Ensure right/bottom don't overflow
            right = min(32767, x + w)
            bottom = min(32767, y + h)

            # Use cached brush
            brush = self._get_cached_brush(self.gdi32, color)
            if not brush:
                return  # Skip if brush creation failed

            rect = wt.RECT(x, y, right, bottom)
            try:
                self.user32.FillRect(self.hdc, ctypes.byref(rect), brush)
            except (ctypes.ArgumentError, OSError):
                # Silently ignore GDI errors
                pass

        def stroke_rect(self, x: int, y: int, w: int, h: int, color: tuple[int, int, int, int], width: int) -> None:
            # Validate parameters
            try:
                x = int(x)
                y = int(y)
                w = int(w)
                h = int(h)
                width = int(width)
            except (ValueError, TypeError, OverflowError):
                return

            # Clamp coordinates
            x = max(-32768, min(32767, x))
            y = max(-32768, min(32767, y))
            w = max(0, min(32767, w))
            h = max(0, min(32767, h))
            width = max(1, min(32, width))  # Reasonable pen width

            # Use cached pen
            pen = self._get_cached_pen(self.gdi32, width, color)
            if not pen:
                return

            try:
                old_pen = self.gdi32.SelectObject(self.hdc, pen)
                # NULL brush so we don't fill
                null_br = self.gdi32.GetStockObject(5)  # HOLLOW_BRUSH
                old_br = self.gdi32.SelectObject(self.hdc, null_br)
                self.gdi32.MoveToEx(self.hdc, x, y, None)
                self.gdi32.LineTo(self.hdc, x + w, y)
                self.gdi32.LineTo(self.hdc, x + w, y + h)
                self.gdi32.LineTo(self.hdc, x, y + h)
                self.gdi32.LineTo(self.hdc, x, y)
                self.gdi32.SelectObject(self.hdc, old_pen)
                self.gdi32.SelectObject(self.hdc, old_br)
            except (ctypes.ArgumentError, OSError):
                pass

        def draw_text(
            self,
            x: int,
            y: int,
            text: str,
            color: tuple[int, int, int, int],
            font_face: str | None,
            px: int,
            weight: int | str | None,
        ) -> None:
            # Validate parameters
            try:
                x = int(x)
                y = int(y)
                px = int(px)
            except (ValueError, TypeError, OverflowError):
                return

            if not text:
                return

            # Normalize weight
            w = 400
            if weight is not None:
                try:
                    w = int(weight)
                except Exception:
                    w = 700 if str(weight).lower() in ("bold", "600", "700", "800", "900") else 400
            face = font_face or "Consolas"

            # Clamp coordinates
            x = max(-32768, min(32767, x))
            y = max(-32768, min(32767, y))

            # Use cached font
            hfont = self._get_cached_font(self.gdi32, px, w, face)
            if not hfont:
                return

            try:
                old = self.gdi32.SelectObject(self.hdc, hfont)
                # Validate and clamp color
                r, g, b, _ = color
                r = max(0, min(255, r))
                g = max(0, min(255, g))
                b = max(0, min(255, b))
                colorref = (b << 16) | (g << 8) | r
                self.gdi32.SetTextColor(self.hdc, colorref)
                self.gdi32.SetBkMode(self.hdc, 1)  # TRANSPARENT
                # TextOutW
                self.gdi32.TextOutW(self.hdc, x, y, text, len(text))
                self.gdi32.SelectObject(self.hdc, old)
            except (ctypes.ArgumentError, OSError):
                pass

    # ----------------------- Window Thread -----------------------
    def _register_and_start(self) -> None:
        def run() -> None:
            try:

                class WNDCLASS(ctypes.Structure):
                    _fields_ = [
                        ("style", wt.UINT),
                        ("lpfnWndProc", WNDPROC),
                        ("cbClsExtra", ctypes.c_int),
                        ("cbWndExtra", ctypes.c_int),
                        ("hInstance", wt.HINSTANCE),
                        ("hIcon", wt.HICON),
                        ("hCursor", wt.HCURSOR),
                        ("hbrBackground", wt.HBRUSH),
                        ("lpszMenuName", wt.LPCWSTR),
                        ("lpszClassName", wt.LPCWSTR),
                    ]

                wc = WNDCLASS()
                wc.style = CS_HREDRAW | CS_VREDRAW
                wc.lpfnWndProc = WNDPROC(self._wndproc)
                wc.hInstance = kernel32.GetModuleHandleW(None)
                wc.hCursor = user32.LoadCursorW(None, MAKEINTRESOURCE(32512))
                wc.hbrBackground = gdi32.GetStockObject(WHITE_BRUSH)
                wc.lpszClassName = "TextforgeWndClass"

                atom = user32.RegisterClassW(ctypes.byref(wc))
                if atom == 0:
                    err = ctypes.get_last_error()
                    if err not in (0, 1410):  # ERROR_CLASS_ALREADY_EXISTS
                        raise ctypes.WinError(err)

                hwnd = user32.CreateWindowExW(
                    0,
                    wc.lpszClassName,
                    self.title,
                    0x00CF0000,  # WS_OVERLAPPEDWINDOW
                    100,
                    100,
                    self.width,
                    self.height,
                    None,
                    None,
                    wc.hInstance,
                    None,
                )
                if not hwnd:
                    raise ctypes.WinError(ctypes.get_last_error() or 0)

                self._hwnd = hwnd
                user32.ShowWindow(hwnd, SW_SHOW)
                user32.UpdateWindow(hwnd)
                self._running = True
                self._ready.set()
                if self._gui_root is not None or self._full_redraw_needed:
                    print("DEBUG: Win32Window._register_and_start scheduling deferred paint")
                    user32.InvalidateRect(hwnd, None, True)
                    user32.PostMessageW(hwnd, WM_PAINT, 0, 0)

                msg = wt.MSG()
                while user32.GetMessageW(ctypes.byref(msg), None, 0, 0) != 0:
                    user32.TranslateMessage(ctypes.byref(msg))
                    user32.DispatchMessageW(ctypes.byref(msg))

            except Exception as exc:
                self._error = exc
                get_logger().debug(f"Window thread error: {exc}")
                self._ready.set()
            finally:
                self._running = False
                if not self._ready.is_set():
                    self._ready.set()

        self._thread = threading.Thread(target=run, daemon=True)
        self._thread.start()

    # ------------------- Message Pump / Drawing -------------------
    def _wndproc(self, hwnd: wt.HWND, msg: wt.UINT, wparam: wt.WPARAM, lparam: wt.LPARAM) -> int:
        try:
            if msg == WM_ERASEBKGND:
                print("WNDPROC: WM_ERASEBKGND")
                return 0  # Let Windows erase the background
            if msg == WM_SIZE:  # Window was resized
                # Extract new client area size from lparam
                width: int = lparam & 0xFFFF
                height: int = (lparam >> 16) & 0xFFFF
                print(f"WNDPROC: WM_SIZE - new size {width}x{height}")
                self.width = width
                self.height = height
                # Clear cached viewport and mark layout as dirty since viewport changed
                self._cached_viewport = None
                self._layout_dirty = True
                # Invalidate entire window to force complete redraw
                user32.InvalidateRect(hwnd, None, True)
                return 0
            if msg == WM_PAINT:
                print("WNDPROC: WM_PAINT")
                return self._paint(hwnd)
            if msg == WM_LBUTTONDOWN:
                self._handle_mouse_click(lparam)
                return 0
            if msg == WM_KEYDOWN:
                return self._key(msg, wparam)
            if msg == WM_DESTROY:
                user32.PostQuitMessage(0)
                return 0
        except Exception as e:
            get_logger().debug(f"WndProc error: {e}")

        return user32.DefWindowProcW(hwnd, msg, wparam, lparam)

    def _paint(self, hwnd: wt.HWND) -> int:
        print("PAINT: _paint called")

        class PAINTSTRUCT(ctypes.Structure):
            _fields_ = [
                ("hdc", wt.HDC),
                ("fErase", wt.BOOL),
                ("rcPaint", wt.RECT),
                ("fRestore", wt.BOOL),
                ("fIncUpdate", wt.BOOL),
                ("rgbReserved", wt.BYTE * 32),
            ]

        ps = PAINTSTRUCT()
        hdc = user32.BeginPaint(hwnd, ctypes.byref(ps))
        print(f"PAINT: BeginPaint returned hdc={hdc}, rect=({ps.rcPaint.left},{ps.rcPaint.top})-({ps.rcPaint.right},{ps.rcPaint.bottom})")

        try:
            # Get the full client area dimensions
            rect = wt.RECT()
            user32.GetClientRect(hwnd, ctypes.byref(rect))
            viewport_w = max(0, rect.right - rect.left)
            viewport_h = max(0, rect.bottom - rect.top)
            current_viewport = (viewport_w, viewport_h)

            # Create canvas for this paint operation
            canvas = self._Win32Canvas(gdi32, user32, hdc, viewport_w, viewport_h)

            # Clear the entire background to white to prevent old content from showing through
            canvas.fill_rect(0, 0, viewport_w, viewport_h, (255, 255, 255, 255))

            # Check for new dual-renderer system first
            if self._gui_root:
                from ...core.layout.engine import compute_layout
                from .gui_renderer import render_tree
                from .layout_adapter import apply_layout_back, build_layout_tree

                try:
                    # Use hash-based LRU caching for layout computations
                    tree_hash = self._compute_tree_hash(self._gui_root)
                    _ = (tree_hash, current_viewport)

                    cached_layout = self._get_cached_layout(tree_hash, current_viewport)
                    if cached_layout is None or self._layout_dirty:
                        # Compute new layout
                        self._cached_layout_tree = build_layout_tree(self._gui_root)
                        compute_layout(self._cached_layout_tree, available_width=viewport_w, available_height=viewport_h)
                        apply_layout_back(self._gui_root, self._cached_layout_tree)

                        # Cache the result (store layout tree and applied positions)
                        layout_positions = self._extract_layout_positions(self._gui_root)
                        self._set_cached_layout(tree_hash, current_viewport, (self._cached_layout_tree, layout_positions))
                        self._cached_viewport = current_viewport
                        self._layout_dirty = False
                    else:
                        # Restore cached layout positions
                        self._cached_layout_tree, layout_positions = cached_layout
                        self._restore_layout_positions(self._gui_root, layout_positions)

                    print("PAINT: Calling render_tree")
                    render_tree(canvas, self._gui_root)
                    print("PAINT: render_tree completed")
                    # Clear dirty rects after successful render
                    self._clear_dirty_rects()
                except Exception as e:
                    print(f"PAINT: ERROR during GUI rendering: {e}")
                    import traceback

                    traceback.print_exc()
                return 0

            # If no component tree yet, do nothing (keeps old behavior safe)
            if not self._root_component or not self._resolve_style_fn:
                return 0

            # Viewport from client rect
            rect = wt.RECT()
            user32.GetClientRect(hwnd, ctypes.byref(rect))
            viewport_w = max(0, rect.right - rect.left)
            viewport_h = max(0, rect.bottom - rect.top)

            measurer = self._GdiMeasurer(gdi32, user32, hdc)
            canvas = self._Win32Canvas(gdi32, user32, hdc, viewport_w, viewport_h)

            # Minimal caps object the style engine expects
            class _Caps:
                def color_depth(self) -> int:
                    return 16777216

                def dpi(self) -> float:
                    return 96.0

                def cell_metrics(self) -> tuple[int, int]:
                    return (8, 16)

                def width(self) -> int:
                    return viewport_w

                def height(self) -> int:
                    return viewport_h

                def supports_unicode(self) -> bool:
                    return True

            caps = _Caps()

            # TODO: Legacy rendering path layout computation - currently not used
            _ = compute_layout_tree(
                self._root_component,
                viewport_w=viewport_w,
                viewport_h=viewport_h,
                resolve_style=self._resolve_style_fn,
                caps=caps,
                measurer=measurer,
                base_font_px=14.0,
            )
            # TODO: Legacy rendering path - render_tree expects GuiNode but gets GuiBox
            # render_tree(canvas, layout_root)
        finally:
            user32.EndPaint(hwnd, ctypes.byref(ps))
        return 0

    def _key(self, _msg: wt.UINT, wparam: wt.WPARAM) -> int:
        token = _translate_virtual_key(int(wparam))
        if token and self._on_key:
            try:
                self._on_key(token)
            except Exception as e:
                get_logger().warning(f"Key callback failed: {e}")
        return 0

    # ----------------------- Public API ---------------------------
    def wait_until_ready(self, timeout: float | None = 2.0) -> bool:
        self._ready.wait(timeout)
        return self._hwnd is not None and self._error is None

    def update_text(self, text: str) -> None:
        """Adapt legacy 'frame text' into a minimal GuiComponent for the layout/renderer."""

        # Local, minimal component that satisfies the GuiComponent protocol
        class _TextNode(GuiNode):
            component_name = "text"

            def __init__(self, txt: str) -> None:
                self.text = txt
                self.state: dict[str, bool] = {}
                self.children: list[GuiNode] = []

        comp = _TextNode(text)
        self.set_root_component(comp)

        # Provide a trivial resolver until your real TFS-based resolver is plugged
        def _resolve(_node: GuiNode, _state: dict[str, bool], _caps: _Caps) -> ResolvedStyle:
            class _S:
                background = None
                color = "#ffffff"
                font = None
                font_size = None
                weight = None
                padding = None
                border = None
                border_color = None

            return _S()

        self.set_style_resolver(_resolve)

        if self._hwnd:
            user32.InvalidateRect(self._hwnd, None, True)

    def stop(self) -> None:
        hwnd = self._hwnd
        if hwnd:
            user32.PostMessageW(hwnd, WM_DESTROY, 0, 0)
        t = self._thread
        if t and t.is_alive():
            t.join(timeout=0.5)
        # Clear all cached state
        self._hwnd = None
        self._running = False
        self._gui_root = None
        self._cached_layout_tree = None
        self._cached_viewport = None
        self._layout_cache.clear()
        self._dirty_rects.clear()
        self._layout_dirty = True
