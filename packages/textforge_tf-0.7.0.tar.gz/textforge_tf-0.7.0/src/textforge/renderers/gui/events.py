# textforge/renderers/gui/events.py

"""Cross-platform event handling abstractions."""

from __future__ import annotations

from abc import ABC, abstractmethod
from dataclasses import dataclass
from enum import Enum
from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from collections.abc import Callable


class EventType(Enum):
    """Cross-platform event types."""

    KEY_DOWN = "key_down"
    KEY_UP = "key_up"
    MOUSE_DOWN = "mouse_down"
    MOUSE_UP = "mouse_up"
    MOUSE_MOVE = "mouse_move"
    WINDOW_RESIZE = "window_resize"
    WINDOW_CLOSE = "window_close"
    WINDOW_FOCUS = "window_focus"
    WINDOW_BLUR = "window_blur"


class MouseButton(Enum):
    """Cross-platform mouse button enumeration."""

    LEFT = "left"
    RIGHT = "right"
    MIDDLE = "middle"
    X1 = "x1"
    X2 = "x2"


@dataclass
class KeyEvent:
    """Cross-platform key event data."""

    key: str
    modifiers: set[str] | None = None  # shift, ctrl, alt, meta

    def __post_init__(self):
        if self.modifiers is None:
            self.modifiers = set()


@dataclass
class MouseEvent:
    """Cross-platform mouse event data."""

    x: int
    y: int
    button: MouseButton | None = None
    modifiers: set[str] | None = None  # shift, ctrl, alt, meta

    def __post_init__(self):
        if self.modifiers is None:
            self.modifiers = set()


@dataclass
class WindowEvent:
    """Cross-platform window event data."""

    width: int | None = None
    height: int | None = None
    focused: bool | None = None


@dataclass
class Event:
    """Generic event container."""

    type: EventType
    data: KeyEvent | MouseEvent | WindowEvent | None = None
    timestamp: float | None = None


class EventHandler(ABC):
    """Abstract base class for platform-specific event handlers."""

    def __init__(self, window: object):
        self.window = window

    @abstractmethod
    def translate_key_event(self, platform_event: object) -> KeyEvent | None:
        """Translate platform-specific key event to cross-platform KeyEvent."""
        pass

    @abstractmethod
    def translate_mouse_event(self, platform_event: object) -> MouseEvent | None:
        """Translate platform-specific mouse event to cross-platform MouseEvent."""
        pass

    @abstractmethod
    def translate_window_event(self, platform_event: object) -> WindowEvent | None:
        """Translate platform-specific window event to cross-platform WindowEvent."""
        pass


class EventDispatcher:
    """Central event dispatcher for cross-platform events."""

    def __init__(self):
        self._listeners: dict[EventType, list[Callable[[Event], None]]] = {}
        self._platform_handler: EventHandler | None = None

    def set_platform_handler(self, handler: EventHandler) -> None:
        """Set the platform-specific event handler."""
        self._platform_handler = handler

    def add_listener(self, event_type: EventType, callback: Callable[[Event], None]) -> None:
        """Add an event listener for a specific event type."""
        if event_type not in self._listeners:
            self._listeners[event_type] = []
        self._listeners[event_type].append(callback)

    def remove_listener(self, event_type: EventType, callback: Callable[[Event], None]) -> None:
        """Remove an event listener."""
        if event_type in self._listeners:
            self._listeners[event_type].remove(callback)
            if not self._listeners[event_type]:
                del self._listeners[event_type]

    def dispatch(self, event: Event) -> None:
        """Dispatch an event to all registered listeners."""
        if event.type in self._listeners:
            for callback in self._listeners[event.type]:
                try:
                    callback(event)
                except Exception as e:
                    # Log error but continue dispatching to other listeners
                    from ...utils.logging import get_logger

                    get_logger().error(f"Event callback failed: {e}")

    def handle_platform_event(self, platform_event_type: str, platform_event: object) -> None:
        """Handle a platform-specific event and dispatch cross-platform equivalent."""
        if not self._platform_handler:
            return

        event = None

        # Translate platform event to cross-platform event
        if platform_event_type == "key":
            event = self._platform_handler.translate_key_event(platform_event)
            if event:
                self.dispatch(Event(EventType.KEY_DOWN, event))
        elif platform_event_type == "mouse":
            event = self._platform_handler.translate_mouse_event(platform_event)
            if event:
                # Determine event type based on platform event
                event_type = EventType.MOUSE_MOVE  # Default
                self.dispatch(Event(event_type, event))
        elif platform_event_type == "window":
            event = self._platform_handler.translate_window_event(platform_event)
            if event:
                # Determine event type based on platform event
                event_type = EventType.WINDOW_RESIZE  # Default
                self.dispatch(Event(event_type, event))


# Global event dispatcher instance
_global_dispatcher = EventDispatcher()


def get_event_dispatcher() -> EventDispatcher:
    """Get the global event dispatcher instance."""
    return _global_dispatcher
