# textforge/renderers/gui/backends/cocoa/window.py

from __future__ import annotations

import threading
from typing import TYPE_CHECKING

from .....utils.logging import get_logger
from ...types import GuiNode
from ...window import Window

if TYPE_CHECKING:
    from collections.abc import Callable


class CocoaWindow(Window):
    """macOS Cocoa backend implementation of the Window interface."""

    def __init__(
        self,
        title: str = "Textforge Window",
        width: int = 800,
        height: int = 600,
        on_key: Callable[[str], None] | None = None,
    ):
        super().__init__(title, width, height, on_key)
        self._ns_window = None
        self._thread: threading.Thread | None = None
        self._running = False
        self._lock = threading.Lock()
        self._ready = threading.Event()
        self._error: Exception | None = None
        self._root_component: GuiNode | None = None
        self._gui_root: GuiNode | None = None
        self._resolve_style_fn: Callable[[object, dict[str, bool], object], object] | None = None
        self._register_and_start()

    @property
    def viewport_w(self) -> int:
        """Get the current viewport width."""
        return self.width

    @property
    def viewport_h(self) -> int:
        """Get the current viewport height."""
        return self.height

    def render_gui_node(self, root: GuiNode) -> None:
        """Render a GuiNode tree to the window."""
        with self._lock:
            self._gui_root = root
            # Trigger redraw on main thread
            if self._ns_window:
                self._schedule_redraw()

    def set_root_component(self, component: GuiNode) -> None:
        with self._lock:
            self._root_component = component
            if self._ns_window:
                self._schedule_redraw()

    def set_style_resolver(self, resolver_fn: Callable[[GuiNode, dict[str, bool], _Caps], Style]) -> None:
        """resolver_fn: (node, state: dict[str,bool], caps) -> ResolvedStyle"""
        with self._lock:
            self._resolve_style_fn = resolver_fn
            if self._ns_window:
                self._schedule_redraw()

    def _register_and_start(self) -> None:
        """Initialize Cocoa window on main thread."""

        def run() -> None:
            try:
                # Import Cocoa modules - these require running on main thread
                import objc

                # Ensure we're on the main thread
                if not objc.runtime.CFRunLoopGetCurrent() == objc.runtime.CFRunLoopGetMain():
                    # Schedule window creation on main thread
                    self._create_window_on_main_thread()
                    return

                self._create_cocoa_window()

            except Exception as exc:
                self._error = exc
                get_logger().error(f"Cocoa window initialization error: {exc}")
                self._ready.set()

        self._thread = threading.Thread(target=run, daemon=True)
        self._thread.start()

    def _create_window_on_main_thread(self) -> None:
        """Schedule window creation on the main thread."""
        try:
            import objc  # type: ignore (only on mac/darwin)
            from Foundation import NSObject  # type: ignore (only on mac/darwin)

            class WindowCreator(NSObject):
                def initWithWindow_(self, window: CocoaWindow):
                    self.window = window
                    return self

                def createWindow_(self, timer: object):
                    self.window._create_cocoa_window()

            creator = WindowCreator.alloc().initWithWindow_(self)
            # Schedule on main run loop
            objc.runtime.CFRunLoopPerformBlock(objc.runtime.CFRunLoopGetMain(), objc.runtime.kCFRunLoopCommonModes, creator.createWindow_)
        except Exception as e:
            self._error = e
            self._ready.set()

    def _create_cocoa_window(self) -> None:
        """Create the actual NSWindow and NSView."""
        try:
            from AppKit import NSApplication, NSBackingStoreBuffered, NSScreen, NSWindow  # type: ignore (only on mac/darwin)
            from Foundation import NSMakeRect  # type: ignore (only on mac/darwin)

            # Get screen dimensions for centering
            screen = NSScreen.mainScreen()
            screen_rect = screen.frame()

            # Center the window
            x = (screen_rect.size.width - self.width) / 2
            y = (screen_rect.size.height - self.height) / 2

            # Create window
            style_mask = (
                1 << 0  # NSTitledWindowMask
                | 1 << 1  # NSClosableWindowMask
                | 1 << 2  # NSMiniaturizableWindowMask
                | 1 << 3  # NSResizableWindowMask
            )

            self._ns_window = NSWindow.alloc().initWithContentRect_styleMask_backing_defer_(NSMakeRect(x, y, self.width, self.height), style_mask, NSBackingStoreBuffered, False)

            self._ns_window.setTitle_(self.title)
            self._ns_window.setDelegate_(self)

            # Create custom view for drawing
            content_rect = self._ns_window.contentRectForFrameRect_(self._ns_window.frame())
            self._custom_view = CocoaDrawingView.alloc().initWithFrame_(content_rect)
            self._custom_view.setWindow_(self)
            self._ns_window.setContentView_(self._custom_view)

            # Make window key and order front
            app = NSApplication.sharedApplication()
            self._ns_window.makeKeyAndOrderFront_(None)
            self._running = True
            self._ready.set()

            # Start run loop if this is the main thread
            app.run()

        except Exception as e:
            self._error = e
            get_logger().error(f"Failed to create Cocoa window: {e}")
            self._ready.set()

    def _schedule_redraw(self) -> None:
        """Schedule a redraw on the main thread."""
        if self._ns_window and self._custom_view:
            try:
                import objc
                from Foundation import NSObject

                class RedrawScheduler(NSObject):
                    def initWithView_(self, view: CocoaDrawingView):
                        self.view = view
                        return self

                    def redraw_(self, timer: object):
                        self.view.setNeedsDisplay_(True)

                scheduler = RedrawScheduler.alloc().initWithView_(self._custom_view)
                objc.runtime.CFRunLoopPerformBlock(objc.runtime.CFRunLoopGetMain(), objc.runtime.kCFRunLoopCommonModes, scheduler.redraw_)
            except Exception as e:
                get_logger().error(f"Failed to schedule redraw: {e}")

    def windowDidResize_(self, notification: object) -> None:
        """Handle window resize."""
        if self._ns_window:
            content_rect = self._ns_window.contentRectForFrameRect_(self._ns_window.frame())
            self.width = int(content_rect.size.width)
            self.height = int(content_rect.size.height)
            self._schedule_redraw()

    def windowWillClose_(self, notification: object) -> None:
        """Handle window close."""
        self._running = False

    def _translate_key_event(self, event: object) -> str:
        """Translate NSEvent to key string."""
        chars = event.characters()
        if chars and len(chars) > 0:
            key = str(chars[0])
            # Handle special keys
            key_code = event.keyCode()
            if key_code == 36:  # Return
                return "enter"
            elif key_code == 51:  # Delete
                return "backspace"
            elif key_code == 53:  # Escape
                return "escape"
            elif key_code == 48:  # Tab
                return "tab"
            elif key_code == 49:  # Space
                return "space"
            else:
                return key.lower() if key.isalpha() else key
        return ""

    def wait_until_ready(self, timeout: float | None = 2.0) -> bool:
        self._ready.wait(timeout)
        return self._ns_window is not None and self._error is None

    def update_text(self, text: str) -> None:
        """Adapt legacy 'frame text' into a minimal GuiComponent for the layout/renderer."""

        # Local, minimal component that satisfies the GuiComponent protocol
        class _TextNode(GuiNode):
            component_name = "text"

            def __init__(self, txt: str) -> None:
                self.text: str = txt
                self.state: dict[str, bool] = {}
                self.children: list[GuiNode] = []

        comp = _TextNode(text)
        self.set_root_component(comp)

        # Provide a trivial resolver until your real TFS-based resolver is plugged
        def _resolve(_node: GuiNode, _state: dict[str, bool], _caps: _Caps) -> Style:
            class _S:
                background = None
                color = "#ffffff"
                font = None
                font_size = None
                weight = None
                padding = None
                border = None
                border_color = None

            return _S()

        self.set_style_resolver(_resolve)
        self._schedule_redraw()

    def stop(self) -> None:
        if self._ns_window:
            try:
                from AppKit import NSApplication

                app = NSApplication.sharedApplication()
                app.terminate_(None)
            except Exception as e:
                get_logger().error(f"Error stopping Cocoa window: {e}")

        t = self._thread
        if t and t.is_alive():
            t.join(timeout=0.5)

        # Clear state
        self._ns_window = None
        self._running = False
        self._gui_root = None


class CocoaDrawingView:
    """Custom NSView for handling drawing operations."""

    def initWithFrame_(self, frame: object) -> object:
        self = super().initWithFrame_(frame)
        self.window_ref = None
        return self

    def setWindow_(self, window: object) -> None:
        self.window_ref = window

    def drawRect_(self, rect: object) -> None:
        """Draw the view content."""
        if not self.window_ref:
            return

        try:
            from AppKit import NSColor, NSGraphicsContext, NSRectFill

            context = NSGraphicsContext.currentContext()
            # Create Cocoa canvas implementation
            canvas = CocoaCanvas(context, rect.size.width, rect.size.height)

            # Clear background
            NSColor.whiteColor().set()
            NSRectFill(rect)

            # Render GUI content
            if self.window_ref._gui_root:
                from ...core.layout.engine import compute_layout
                from ...gui_renderer import render_tree
                from ...layout_adapter import apply_layout_back, build_layout_tree

                try:
                    # Compute layout
                    layout_tree = build_layout_tree(self.window_ref._gui_root)
                    compute_layout(layout_tree, available_width=int(rect.size.width), available_height=int(rect.size.height))
                    apply_layout_back(self.window_ref._gui_root, layout_tree)

                    # Render
                    render_tree(canvas, self.window_ref._gui_root)
                except Exception as e:
                    get_logger().error(f"Cocoa rendering error: {e}")

        except Exception as e:
            get_logger().error(f"Cocoa drawRect error: {e}")


class CocoaCanvas:
    """Cocoa-based Canvas implementation."""

    def __init__(self, context, width: int, height: int):
        self.context = context
        self.viewport_w = width
        self.viewport_h = height

    def save(self) -> None:
        """Save graphics state."""
        self.context.saveGraphicsState()

    def restore(self) -> None:
        """Restore graphics state."""
        self.context.restoreGraphicsState()

    def fill_rect(self, x: int, y: int, w: int, h: int, color: tuple[int, int, int, int]) -> None:
        """Fill a rectangle with color."""
        try:
            from AppKit import NSColor
            from Foundation import NSMakeRect

            r, g, b, a = color
            ns_color = NSColor.colorWithCalibratedRed_green_blue_alpha_(r / 255.0, g / 255.0, b / 255.0, a / 255.0)
            ns_color.set()
            rect = NSMakeRect(x, y, w, h)
            from AppKit import NSRectFill

            NSRectFill(rect)
        except Exception as e:
            get_logger().error(f"Cocoa fill_rect error: {e}")

    def stroke_rect(self, x: int, y: int, w: int, h: int, color: tuple[int, int, int, int], width: int) -> None:
        """Stroke a rectangle outline."""
        try:
            from AppKit import NSColor
            from Foundation import NSMakeRect

            r, g, b, a = color
            ns_color = NSColor.colorWithCalibratedRed_green_blue_alpha_(r / 255.0, g / 255.0, b / 255.0, a / 255.0)
            ns_color.set()
            rect = NSMakeRect(x, y, w, h)
            # Set line width
            from AppKit import NSBezierPath

            path = NSBezierPath.bezierPathWithRect_(rect)
            path.setLineWidth_(width)
            path.stroke()
        except Exception as e:
            get_logger().error(f"Cocoa stroke_rect error: {e}")

    def draw_text(
        self,
        x: int,
        y: int,
        text: str,
        color: tuple[int, int, int, int],
        font_face: str | None,
        px: int,
        weight: int | str | None,
    ) -> None:
        """Draw text at position."""
        try:
            from AppKit import NSColor, NSFont, NSString
            from Foundation import NSMakePoint

            # Set color
            r, g, b, a = color
            ns_color = NSColor.colorWithCalibratedRed_green_blue_alpha_(r / 255.0, g / 255.0, b / 255.0, a / 255.0)
            ns_color.set()

            # Create font
            face = font_face or "Helvetica"
            # Convert weight to NSFontWeight
            if isinstance(weight, str):
                if weight.lower() in ("bold", "600", "700", "800", "900"):
                    weight_val = 0.4  # NSFontWeightBold
                else:
                    weight_val = 0.0  # NSFontWeightRegular
            elif isinstance(weight, int):
                weight_val = min(0.8, max(-0.8, (weight - 400) / 1000.0))
            else:
                weight_val = 0.0

            font = NSFont.fontWithName_size_(face, px)
            if not font:
                font = NSFont.systemFontOfSize_(px)

            # Draw text
            point = NSMakePoint(x, y)
            ns_string = NSString.stringWithString_(text)
            ns_string.drawAtPoint_withAttributes_(point, {"NSFont": font, "NSForegroundColor": ns_color})

        except Exception as e:
            get_logger().error(f"Cocoa draw_text error: {e}")
