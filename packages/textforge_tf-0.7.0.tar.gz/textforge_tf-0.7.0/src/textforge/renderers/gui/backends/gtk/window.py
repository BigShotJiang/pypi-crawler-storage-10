# textforge/renderers/gui/backends/gtk/window.py

from __future__ import annotations

import threading
from typing import TYPE_CHECKING, Any

from .....utils.logging import get_logger
from ...types import GuiNode
from ...window import Window

if TYPE_CHECKING:
    from collections.abc import Callable


class GtkWindow(Window):
    """Linux GTK backend implementation of the Window interface."""

    def __init__(
        self,
        title: str = "Textforge Window",
        width: int = 800,
        height: int = 600,
        on_key: Callable[[str], None] | None = None,
    ):
        super().__init__(title, width, height, on_key)
        self._gtk_window = None
        self._drawing_area = None
        self._thread: threading.Thread | None = None
        self._running = False
        self._lock = threading.Lock()
        self._ready = threading.Event()
        self._error: Exception | None = None
        self._root_component: GuiNode | None = None
        self._gui_root: GuiNode | None = None
        self._resolve_style_fn: Callable[[object, dict[str, bool], object], object] | None = None
        self._register_and_start()

    @property
    def viewport_w(self) -> int:
        """Get the current viewport width."""
        return self.width

    @property
    def viewport_h(self) -> int:
        """Get the current viewport height."""
        return self.height

    def render_gui_node(self, root: GuiNode) -> None:
        """Render a GuiNode tree to the window."""
        with self._lock:
            self._gui_root = root
            # Trigger redraw
            if self._drawing_area:
                self._schedule_redraw()

    def set_root_component(self, component: GuiNode) -> None:
        with self._lock:
            self._root_component = component
            if self._drawing_area:
                self._schedule_redraw()

    def set_style_resolver(self, resolver_fn: Callable[[GuiNode, dict[str, bool], Any], Any]) -> None:
        """resolver_fn: (node, state: dict[str,bool], caps) -> ResolvedStyle"""
        with self._lock:
            self._resolve_style_fn = resolver_fn
            if self._drawing_area:
                self._schedule_redraw()

    def _register_and_start(self) -> None:
        """Initialize GTK window."""

        def run() -> None:
            try:
                import gi

                gi.require_version("Gtk", "3.0")
                from gi.repository import GLib, Gtk

                # Initialize GTK if not already done
                if not Gtk.is_initialized():
                    Gtk.init(None)

                # Create window on main thread
                GLib.idle_add(self._create_gtk_window)

                # Start GTK main loop
                Gtk.main()

            except Exception as exc:
                self._error = exc
                get_logger().error(f"GTK window initialization error: {exc}")
                self._ready.set()

        self._thread = threading.Thread(target=run, daemon=True)
        self._thread.start()

    def _create_gtk_window(self) -> None:
        """Create the GTK window and drawing area."""
        try:
            import gi

            gi.require_version("Gtk", "3.0")
            from gi.repository import Gtk

            # Create window
            self._gtk_window = Gtk.Window(title=self.title)
            self._gtk_window.set_default_size(self.width, self.height)
            self._gtk_window.set_position(Gtk.WindowPosition.CENTER)

            # Create drawing area
            self._drawing_area = Gtk.DrawingArea()
            self._drawing_area.set_size_request(self.width, self.height)
            self._gtk_window.add(self._drawing_area)

            # Connect signals
            self._gtk_window.connect("destroy", self._on_window_destroy)
            self._gtk_window.connect("configure-event", self._on_configure_event)
            self._gtk_window.connect("key-press-event", self._on_key_press)
            self._drawing_area.connect("draw", self._on_draw)

            # Show window
            self._gtk_window.show_all()
            self._running = True
            self._ready.set()

        except Exception as e:
            self._error = e
            get_logger().error(f"Failed to create GTK window: {e}")
            self._ready.set()

    def _schedule_redraw(self) -> None:
        """Schedule a redraw of the drawing area."""
        if self._drawing_area:
            try:
                import gi

                gi.require_version("Gtk", "3.0")
                from gi.repository import GLib

                GLib.idle_add(self._drawing_area.queue_draw)
            except Exception as e:
                get_logger().error(f"Failed to schedule redraw: {e}")

    def _on_window_destroy(self, widget: object) -> None:
        """Handle window destroy event."""
        self._running = False
        try:
            import gi

            gi.require_version("Gtk", "3.0")
            from gi.repository import Gtk

            Gtk.main_quit()
        except Exception as e:
            get_logger().error(f"Error in destroy handler: {e}")

    def _on_configure_event(self, widget: object, event: object) -> None:
        """Handle window configure (resize) event."""
        self.width = event.width
        self.height = event.height
        return False

    def _on_key_press(self, widget: object, event: object) -> None:
        """Handle key press events."""
        if self._on_key:
            key_name = self._translate_gdk_key(event)
            if key_name:
                try:
                    self._on_key(key_name)
                except Exception as e:
                    get_logger().warning(f"Key callback failed: {e}")
        return False

    def _translate_gdk_key(self, event: object) -> str:
        """Translate GDK key event to key string."""
        try:
            import gi

            gi.require_version("Gtk", "3.0")
            from gi.repository import Gdk

            keyval = event.keyval
            # Map common keys
            key_mapping = {
                Gdk.KEY_Return: "enter",
                Gdk.KEY_KP_Enter: "enter",
                Gdk.KEY_BackSpace: "backspace",
                Gdk.KEY_Delete: "delete",
                Gdk.KEY_Tab: "tab",
                Gdk.KEY_Escape: "escape",
                Gdk.KEY_space: "space",
                Gdk.KEY_F1: "f1",
                Gdk.KEY_F2: "f2",
                Gdk.KEY_F3: "f3",
                Gdk.KEY_F4: "f4",
                Gdk.KEY_F5: "f5",
                Gdk.KEY_F6: "f6",
                Gdk.KEY_F7: "f7",
                Gdk.KEY_F8: "f8",
                Gdk.KEY_F9: "f9",
                Gdk.KEY_F10: "f10",
                Gdk.KEY_F11: "f11",
                Gdk.KEY_F12: "f12",
            }

            if keyval in key_mapping:
                return key_mapping[keyval]

            # Handle alphanumeric keys
            if Gdk.KEY_a <= keyval <= Gdk.KEY_z:
                return chr(keyval).lower()
            if Gdk.KEY_A <= keyval <= Gdk.KEY_Z:
                return chr(keyval).lower()
            if Gdk.KEY_0 <= keyval <= Gdk.KEY_9:
                return chr(keyval)

        except Exception as e:
            get_logger().error(f"Key translation error: {e}")

        return ""

    def _on_draw(self, widget: object, cr: object) -> None:
        """Handle draw event."""
        try:
            import gi

            gi.require_version("Gtk", "3.0")

            # Get allocation
            allocation = widget.get_allocation()
            width = allocation.width
            height = allocation.height

            # Create GTK canvas
            canvas = GtkCanvas(cr, width, height)

            # Clear background
            cr.set_source_rgb(1.0, 1.0, 1.0)  # White
            cr.rectangle(0, 0, width, height)
            cr.fill()

            # Render GUI content
            if self._gui_root:
                from ...core.layout.engine import compute_layout
                from ...gui_renderer import render_tree
                from ...layout_adapter import apply_layout_back, build_layout_tree

                try:
                    # Compute layout
                    layout_tree = build_layout_tree(self._gui_root)
                    compute_layout(layout_tree, available_width=width, available_height=height)
                    apply_layout_back(self._gui_root, layout_tree)

                    # Render
                    render_tree(canvas, self._gui_root)
                except Exception as e:
                    get_logger().error(f"GTK rendering error: {e}")

        except Exception as e:
            get_logger().error(f"GTK draw error: {e}")

        return False

    def wait_until_ready(self, timeout: float | None = 2.0) -> bool:
        self._ready.wait(timeout)
        return self._gtk_window is not None and self._error is None

    def update_text(self, text: str) -> None:
        """Adapt legacy 'frame text' into a minimal GuiComponent for the layout/renderer."""

        # Local, minimal component that satisfies the GuiComponent protocol
        class _TextNode(GuiNode):
            component_name = "text"

            def __init__(self, txt: str) -> None:
                self.text: str = txt
                self.state: dict[str, bool] = {}
                self.children: list[GuiNode] = []

        comp = _TextNode(text)
        self.set_root_component(comp)

        # Provide a trivial resolver until your real TFS-based resolver is plugged
        def _resolve(_node, _state, _caps):
            class _S:
                background = None
                color = "#ffffff"
                font = None
                font_size = None
                weight = None
                padding = None
                border = None
                border_color = None

            return _S()

        self.set_style_resolver(_resolve)
        self._schedule_redraw()

    def stop(self) -> None:
        if self._gtk_window:
            try:
                import gi

                gi.require_version("Gtk", "3.0")
                from gi.repository import GLib, Gtk

                def quit_main():
                    Gtk.main_quit()

                GLib.idle_add(quit_main)
            except Exception as e:
                get_logger().error(f"Error stopping GTK window: {e}")

        t = self._thread
        if t and t.is_alive():
            t.join(timeout=0.5)

        # Clear state
        self._gtk_window = None
        self._running = False
        self._gui_root = None


class GtkCanvas:
    """GTK-based Canvas implementation using Cairo."""

    def __init__(self, cr, width: int, height: int):
        self.cr = cr  # Cairo context
        self.viewport_w = width
        self.viewport_h = height

    def save(self) -> None:
        """Save graphics state."""
        self.cr.save()

    def restore(self) -> None:
        """Restore graphics state."""
        self.cr.restore()

    def fill_rect(self, x: int, y: int, w: int, h: int, color: tuple[int, int, int, int]) -> None:
        """Fill a rectangle with color."""
        try:
            r, g, b, a = color
            self.cr.set_source_rgba(r / 255.0, g / 255.0, b / 255.0, a / 255.0)
            self.cr.rectangle(x, y, w, h)
            self.cr.fill()
        except Exception as e:
            get_logger().error(f"GTK fill_rect error: {e}")

    def stroke_rect(self, x: int, y: int, w: int, h: int, color: tuple[int, int, int, int], width: int) -> None:
        """Stroke a rectangle outline."""
        try:
            r, g, b, a = color
            self.cr.set_source_rgba(r / 255.0, g / 255.0, b / 255.0, a / 255.0)
            self.cr.set_line_width(width)
            self.cr.rectangle(x, y, w, h)
            self.cr.stroke()
        except Exception as e:
            get_logger().error(f"GTK stroke_rect error: {e}")

    def draw_text(
        self,
        x: int,
        y: int,
        text: str,
        color: tuple[int, int, int, int],
        font_face: str | None,
        px: int,
        weight: int | str | None,
    ) -> None:
        """Draw text at position."""
        try:
            # Set color
            r, g, b, a = color
            self.cr.set_source_rgba(r / 255.0, g / 255.0, b / 255.0, a / 255.0)

            # Set font
            face = font_face or "Sans"
            # Convert weight to Pango weight
            if isinstance(weight, str):
                if weight.lower() in ("bold", "600", "700", "800", "900"):
                    weight_val = "bold"
                else:
                    weight_val = "normal"
            elif isinstance(weight, int):
                if weight >= 600:
                    weight_val = "bold"
                else:
                    weight_val = "normal"
            else:
                weight_val = "normal"

            self.cr.select_font_face(face, 0, weight_val)  # CAIRO_FONT_SLANT_NORMAL, CAIRO_FONT_WEIGHT_*
            self.cr.set_font_size(px)

            # Draw text (adjust Y for baseline)
            self.cr.move_to(x, y + px * 0.8)  # Approximate baseline adjustment
            self.cr.show_text(text)

        except Exception as e:
            get_logger().error(f"GTK draw_text error: {e}")
