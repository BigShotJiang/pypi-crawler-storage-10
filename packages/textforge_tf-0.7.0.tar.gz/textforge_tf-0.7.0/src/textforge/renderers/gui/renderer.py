# textforge/renderers/gui/renderer.py

"""Cross-platform GUI renderer that works with all backends."""

from __future__ import annotations

from .gui_renderer import render_tree

# Re-export the main rendering function for convenience
__all__ = ["render_tree"]
