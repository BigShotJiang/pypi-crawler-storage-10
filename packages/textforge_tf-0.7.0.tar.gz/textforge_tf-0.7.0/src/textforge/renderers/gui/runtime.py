"""Runtime glue between Console streams and the native GUI window.

This module centralises management of a singleton GUI runtime so that the
``Console`` backend can present Textforge frames without each caller having to
coordinate window lifecycle or message pumps.

The runtime exposes a lightweight ``GuiStream`` object that mimics ``TextIO``
and understands two main operations:

* regular ``write``/``flush`` calls append to the current frame (useful for
  drop-in ``print`` compatibility)
* ``present_frame`` replaces the entire frame, which is how ``Console.live``
  drives real-time updates

The implementation prefers the native Win32 window (see ``win32_window``) and
falls back to a headless collector that simply writes to ``stdout`` when a GUI
cannot be created (for example during CI runs).
"""

from __future__ import annotations

import io
import os
import queue
import sys
import threading
from typing import TYPE_CHECKING, TextIO

from ...utils.logging import get_logger

if TYPE_CHECKING:
    from textforge.renderers.gui.window import Window

_RUNTIME_LOCK = threading.Lock()
_RUNTIME: GuiRuntime | None = None


class Surface:
    """String frame surface with simple dimension tracking (runtime-local)."""

    def __init__(self) -> None:
        self._frame: str = ""
        self.width: int = 0
        self.height: int = 0

    def set_frame(self, text: str) -> None:
        self._frame = text
        lines = text.split("\n")
        self.height = len(lines)
        self.width = max((len(line) for line in lines), default=0)

    def get_frame(self) -> str:
        return self._frame


def get_runtime(create: bool = True) -> GuiRuntime | None:
    """Return the process-wide GUI runtime, creating it on demand."""
    global _RUNTIME
    with _RUNTIME_LOCK:
        if _RUNTIME is None and create:
            _RUNTIME = GuiRuntime()
        return _RUNTIME


class GuiRuntime:
    """Owns the GUI surface, native window and shared key queue."""

    def __init__(self) -> None:
        self._lock = threading.Lock()
        self._frame: str = ""
        self.surface = Surface()
        self._key_queue: queue.Queue[str] | None = None
        self._refcount = 0
        self._window = self._create_native_window()
        # Ensure the GUI window thread starts
        if self._window is not None and hasattr(self._window, "wait_until_ready"):
            self._window.wait_until_ready(2.0)
        self._fallback_stream: TextIO | None = None
        if self._window is None:
            self._fallback_stream = sys.stdout
        else:
            self._window.update_text("")
        print(f"DEBUG: GuiRuntime initialized window={'present' if self._window else 'missing'}, fallback={'stdout' if self._fallback_stream is sys.stdout else 'none'}")

    # -- window creation helpers -------------------------------------------------
    def _create_native_window(self) -> Window | None:
        # Honour an env flag so automated tests can disable window creation.
        if os.environ.get("TEXTFORGE_HEADLESS", "").lower() in {"1", "true", "yes"}:
            return None
        try:
            from .win32_window import Win32Window
        except Exception:
            return None

        key_queue: queue.Queue[str] = queue.Queue()

        def _on_key(token: str) -> None:
            if token:
                key_queue.put(token)

        try:
            print("Creating win32 window...")
            window = Win32Window("Test", 960, 640, on_key=_on_key)
            print("Window created:", window)

            if not window.wait_until_ready():
                print("Window NOT ready, error:", window._error)
                window.stop()
                return None
        except Exception as e:
            get_logger().debug(f"GUI window creation failed: {e}, falling back to stdout")
            return None
        self._key_queue = key_queue
        return window

    # -- reference counting ------------------------------------------------------
    def create_stream(self) -> GuiStream:
        with self._lock:
            self._refcount += 1
            current_refcount = self._refcount
        stream = GuiStream(self)
        # Attempt to create the window eagerly so the first write shows up immediately.
        ensured = self.ensure_window()
        print(f"DEBUG: GuiRuntime.create_stream refcount={current_refcount} ensured_window={ensured}")
        return stream

    def release_stream(self) -> None:
        destroy = False
        with self._lock:
            self._refcount -= 1
            if self._refcount <= 0:
                destroy = True
        if destroy:
            self.shutdown()

    # -- presentation ------------------------------------------------------------
    def append_text(self, chunk: str) -> None:
        if not chunk:
            return
        with self._lock:
            self._frame += chunk
            frame = self._frame
        self.surface.set_frame(frame)
        print(f"DEBUG: GuiRuntime.append_text chunk_len={len(chunk)} window_present={self._window is not None}")
        self._send_to_window(frame, incremental=chunk)

    def present_frame(self, text: str) -> None:
        with self._lock:
            self._frame = text
        self.surface.set_frame(text)
        print(f"DEBUG: GuiRuntime.present_frame text_len={len(text)} window_present={self._window is not None}")
        self._send_to_window(text, incremental=None)

    def clear(self) -> None:
        self.present_frame("")

    def _send_to_window(self, text: str, *, incremental: str | None) -> None:
        if self._window is None:
            print("DEBUG: GuiRuntime._send_to_window missing window, attempting ensure")
            self.ensure_window()
        if self._window is not None:
            try:
                self._window.update_text(text)
                print(f"DEBUG: GuiRuntime._send_to_window delivered text len={len(text)} incremental={incremental is not None}")
                return
            except Exception:
                # Window died → fall back to stdout for the rest of the run
                self._window = None
                if self._fallback_stream is None:
                    self._fallback_stream = sys.stdout  # <— add this line
        if self._fallback_stream is not None:
            try:
                payload = incremental if incremental is not None else text
                self._fallback_stream.write(payload)
                self._fallback_stream.flush()
                print(f"DEBUG: GuiRuntime._send_to_window wrote to fallback len={len(payload)}")
            except Exception as e:
                get_logger().debug(f"Failed to write to fallback stream: {e}")

    # -- key handling ------------------------------------------------------------
    def get_key_queue(self) -> queue.Queue[str] | None:
        return self._key_queue

    def ensure_window(self) -> bool:
        if self._window is not None:
            print("DEBUG: GuiRuntime.ensure_window found existing window")
            return True
        new_window = self._create_native_window()
        if new_window is not None:
            self._window = new_window
            with self._lock:
                current_frame = self._frame
            try:
                new_window.update_text(current_frame)
                print("DEBUG: GuiRuntime.ensure_window pushed cached text to new window")
            except Exception as e:
                get_logger().debug(f"Failed to update text on new window: {e}")
            print("DEBUG: GuiRuntime.ensure_window created new window instance")
            return True
        print("DEBUG: GuiRuntime.ensure_window failed to create window")
        return False

    # -- lifecycle ----------------------------------------------------------------
    def shutdown(self) -> None:
        with _RUNTIME_LOCK:
            global _RUNTIME
            if _RUNTIME is self:
                _RUNTIME = None
        if self._window is not None:
            try:
                self._window.stop()
            except Exception as e:
                get_logger().debug(f"Failed to stop window during shutdown: {e}")
            self._window = None
        # Clear frame so future get_runtime(False) returns a clean slate.
        with self._lock:
            self._frame = ""
            self.surface.set_frame("")
        self._key_queue = None


class GuiStream(io.TextIOBase):
    """Stream handed to ``Console`` when the GUI backend is selected."""

    def __init__(self, runtime: GuiRuntime) -> None:
        super().__init__()
        self._runtime = runtime
        self._buffer: list[str] = []
        self._closed = False

    # -- textio api --------------------------------------------------------------
    @property
    def encoding(self) -> str:
        return "utf-8"

    def writable(self) -> bool:
        return True

    def write(self, text: str) -> int:
        if self._closed:
            raise ValueError("I/O operation on closed GUI stream")
        self._buffer.append(text)
        buffered_len = sum(len(part) for part in self._buffer)
        print(f"DEBUG: GuiStream.write buffered_len={buffered_len}")
        return len(text)

    def flush(self) -> None:
        if self._closed or not self._buffer:
            return
        chunk = "".join(self._buffer)
        self._buffer.clear()
        # Make sure a window is present for first-time writers
        self._runtime.ensure_window()  # <— add (harmless if already created)
        print(f"DEBUG: GuiStream.flush flushing_len={len(chunk)}")
        self._runtime.append_text(chunk)

    # -- console live integration ------------------------------------------------
    def present_frame(self, text: str) -> None:
        if self._closed:
            return
        # Clear any pending buffered writes to avoid stale data when switching
        # from append-mode (print) to full-frame mode (live sessions).
        self._buffer.clear()
        print(f"DEBUG: GuiStream.present_frame text_len={len(text)}")
        self._runtime.present_frame(text)

    def update_text(self, text: str) -> None:
        """Update the GUI with new text (used by live sessions)."""
        print(f"DEBUG: GuiStream.update_text text_len={len(text)}")
        self.present_frame(text)

    def clear_frame(self) -> None:
        if self._closed:
            return
        self._buffer.clear()
        print("DEBUG: GuiStream.clear_frame")
        self._runtime.clear()

    @property
    def surface(self) -> Surface:
        return self._runtime.surface

    def close(self) -> None:
        if self._closed:
            return
        try:
            self.flush()
        finally:
            self._runtime.release_stream()
            self._closed = True
            print("DEBUG: GuiStream.close invoked")

    # -- Helpers used by tests and utilities ------------------------------------
    def get_key_queue(self) -> queue.Queue[str] | None:
        print("DEBUG: GuiStream.get_key_queue called")
        return self._runtime.get_key_queue()
