# textforge/renderers/gui/types.py

from __future__ import annotations

from dataclasses import dataclass, field
from typing import TYPE_CHECKING, Protocol

if TYPE_CHECKING:
    from ...core.layout.engine import LayoutStyle
    from ...style.tfs.tfs_cascade import ResolvedStyle


class Canvas(Protocol):
    """Abstract immediate-mode drawing API in pixels."""

    def save(self) -> None: ...
    def restore(self) -> None: ...
    def fill_rect(self, x: int, y: int, w: int, h: int, color: tuple[int, int, int, int]) -> None: ...
    def stroke_rect(self, x: int, y: int, w: int, h: int, color: tuple[int, int, int, int], width: int) -> None: ...
    def draw_text(
        self,
        x: int,
        y: int,
        text: str,
        color: tuple[int, int, int, int],
        font_face: str | None,
        px: int,
        weight: int | str | None,
    ) -> None: ...


@dataclass
class GuiNode:
    component_name: str
    text: str | None = None
    children: list[GuiNode] = field(default_factory=list)
    state: dict[str, bool] = field(default_factory=dict)
    style: ResolvedStyle | None = None
    layout_style: LayoutStyle | None = None
    metadata: dict[str, object] = field(default_factory=dict)

    # Layout rectangle from compute_layout
    x: int = 0
    y: int = 0
    width: int = 0
    height: int = 0
