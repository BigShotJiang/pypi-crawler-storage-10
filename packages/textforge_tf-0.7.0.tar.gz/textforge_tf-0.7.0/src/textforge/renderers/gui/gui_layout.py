# textforge/renderers/gui/gui_layout.py
from __future__ import annotations

from collections.abc import Callable
from dataclasses import dataclass
from typing import TYPE_CHECKING, Any, Protocol

if TYPE_CHECKING:
    from textforge.renderers.gui.types import GuiNode

    from ...style.tfs.tfs_values import Length


@dataclass(slots=True)
class GuiBox:
    """Computed box for one component, in absolute pixel coordinates."""

    x: int
    y: int
    width: int
    height: int
    component: Any
    style: Any  # ResolvedStyle
    children: list[GuiBox]


class TextMeasurer(Protocol):
    def measure_text(self, text: str, style: object) -> tuple[int, int] | None:
        """Return (width_px, height_px). Style is your ResolvedStyle."""


ResolveStyleFn = Callable[[object, dict[str, bool], object], Any]  # (node, state, caps) -> ResolvedStyle


# ---- Utilities ----------------------------------------------------------------


def _px_from_length(length: Length | None, basis: int, em_px: float = 16.0) -> int | None:
    if length is None:
        return None
    u = getattr(length, "unit", "px")
    v = float(getattr(length, "value", 0.0))
    if u == "px":
        return int(round(v))
    if u == "%":
        return int(round(basis * (v / 100.0)))
    if u == "em":
        return int(round(v * em_px))
    if u == "cell":
        # GUI is pixel-native; treat "cell" as em-sized square
        return int(round(v * em_px))
    # Fallback = px
    return int(round(v))


def _style_number(value: float | int | None, default: float = 0.0) -> float:
    if value is None:
        return default
    return float(value)


def _content_intrinsic_size(text: str | None, measurer: TextMeasurer, style: object) -> tuple[int, int]:
    if not text:
        return (0, 0)
    result = measurer.measure_text(text, style)
    if result is None:
        return (0, 0)
    w, h = result
    return (max(0, w), max(0, h))


# ---- Flex layout (single-line or wrap=false first pass) -----------------------


@dataclass(slots=True)
class _BoxModel:
    pad_t: int = 0
    pad_r: int = 0
    pad_b: int = 0
    pad_l: int = 0
    mar_t: int = 0
    mar_r: int = 0
    mar_b: int = 0
    mar_l: int = 0
    bor_w: int = 0  # uniform border width for first pass


def _insets_px(style: object, container_w: int, container_h: int, em_px: float) -> _BoxModel:
    bm = _BoxModel()
    pad = getattr(style, "padding", None)
    if pad:
        bm.pad_t = _px_from_length(getattr(pad, "top", None), container_h, em_px) or 0
        bm.pad_r = _px_from_length(getattr(pad, "right", None), container_w, em_px) or 0
        bm.pad_b = _px_from_length(getattr(pad, "bottom", None), container_h, em_px) or 0
        bm.pad_l = _px_from_length(getattr(pad, "left", None), container_w, em_px) or 0
    mar = getattr(style, "margin", None)
    if mar:
        bm.mar_t = _px_from_length(getattr(mar, "top", None), container_h, em_px) or 0
        bm.mar_r = _px_from_length(getattr(mar, "right", None), container_w, em_px) or 0
        bm.mar_b = _px_from_length(getattr(mar, "bottom", None), container_h, em_px) or 0
        bm.mar_l = _px_from_length(getattr(mar, "left", None), container_w, em_px) or 0
    bor = getattr(style, "border", None)
    if bor and getattr(bor, "width", 0.0):
        bm.bor_w = int(round(float(bor.width)))
    return bm


@dataclass(slots=True)
class _FlexItem:
    """Represents a flex item with computed properties."""

    node: GuiNode
    style: object
    box: GuiBox | None = None
    flex_grow: float = 0.0
    flex_shrink: float = 1.0
    flex_basis: Length | None = None
    main_size: int = 0
    cross_size: int = 0
    main_start: int = 0
    cross_start: int = 0


def _compute_flexbox_layout(
    children: list[GuiNode],
    container_style: object,
    container_x: int,
    container_y: int,
    container_w: int,
    container_h: int,
    resolve_style: ResolveStyleFn,
    caps: object,
    measurer: TextMeasurer,
    em_px: float,
) -> list[GuiBox]:
    """Implement proper flexbox layout algorithm with justify-content and align-items support."""
    # Debug logging for flex layout overlapping issue
    import logging

    logger = logging.getLogger(__name__)
    logger.debug(f"_compute_flexbox_layout: container_style={container_style}, children={len(children)}, container_w={container_w}, container_h={container_h}")

    direction = getattr(container_style, "flex_direction", "row")
    justify_content = getattr(container_style, "justify_content", "flex-start")
    align_items = getattr(container_style, "align_items", "stretch")
    flex_wrap = getattr(container_style, "flex_wrap", "nowrap")

    # Create flex items
    flex_items: list[_FlexItem] = []
    for child in children:
        child_style = resolve_style(child, getattr(child, "state", {}), caps)
        item = _FlexItem(
            node=child,
            style=child_style,
            flex_grow=getattr(child_style, "flex_grow", 0.0) or 0.0,
            flex_shrink=getattr(child_style, "flex_shrink", 1.0) or 1.0,
            flex_basis=getattr(child_style, "flex_basis", None),
        )
        flex_items.append(item)

    # Determine main and cross axes
    is_row = direction in ("row", "row-reverse")
    main_axis_size = container_w if is_row else container_h
    cross_axis_size = container_h if is_row else container_w

    # Phase 1: Determine flex base size and hypothetical main size
    for item in flex_items:
        # Compute flex base size
        if item.flex_basis is not None:
            item.main_size = _px_from_length(item.flex_basis, main_axis_size, em_px) or 0
        else:
            # Use content size as base
            content_w, content_h = _content_intrinsic_size(getattr(item.node, "text", None), measurer, item.style)
            item.main_size = content_w if is_row else content_h

    # Phase 2: Resolve flexible lengths
    total_flex_grow = sum(item.flex_grow for item in flex_items)
    total_flex_shrink = sum(item.flex_shrink for item in flex_items)
    total_base_size = sum(item.main_size for item in flex_items)

    if total_base_size > main_axis_size and total_flex_shrink > 0:
        # Shrink items
        excess = total_base_size - main_axis_size
        for item in flex_items:
            shrink_factor = item.flex_shrink / total_flex_shrink
            item.main_size -= excess * shrink_factor
    elif total_base_size < main_axis_size and total_flex_grow > 0:
        # Grow items
        remaining = main_axis_size - total_base_size
        for item in flex_items:
            grow_factor = item.flex_grow / total_flex_grow
            item.main_size += remaining * grow_factor

    # Phase 3: Position items along main axis (justify-content)
    current_main_pos = 0
    if justify_content == "flex-end":
        current_main_pos = main_axis_size - sum(item.main_size for item in flex_items)
    elif justify_content == "center":
        current_main_pos = (main_axis_size - sum(item.main_size for item in flex_items)) // 2
    elif justify_content == "space-between":
        total_items = len(flex_items)
        if total_items > 1:
            spacing = (main_axis_size - sum(item.main_size for item in flex_items)) // (total_items - 1)
            current_main_pos = 0
        else:
            current_main_pos = (main_axis_size - sum(item.main_size for item in flex_items)) // 2
    elif justify_content == "space-around":
        total_items = len(flex_items)
        spacing = (main_axis_size - sum(item.main_size for item in flex_items)) // (total_items * 2)
        current_main_pos = spacing
    elif justify_content == "space-evenly":
        total_items = len(flex_items)
        spacing = (main_axis_size - sum(item.main_size for item in flex_items)) // (total_items + 1)
        current_main_pos = spacing

    # Phase 4: Position items along cross axis (align-items) and create boxes
    result_boxes: list[GuiBox] = []
    for i, item in enumerate(flex_items):
        # Set main axis position
        item.main_start = current_main_pos
        current_main_pos += item.main_size

        # Add spacing for space-between/space-around/space-evenly
        if justify_content == "space-between" and i < len(flex_items) - 1:
            spacing = (main_axis_size - sum(item.main_size for item in flex_items)) // (len(flex_items) - 1)
            current_main_pos += spacing
        elif justify_content in ("space-around", "space-evenly"):
            total_items = len(flex_items)
            if justify_content == "space-around":
                spacing = (main_axis_size - sum(item.main_size for item in flex_items)) // (total_items * 2)
            else:
                spacing = (main_axis_size - sum(item.main_size for item in flex_items)) // (total_items + 1)
            current_main_pos += spacing

        # Determine cross axis size and position
        if align_items == "stretch":
            item.cross_size = cross_axis_size
            item.cross_start = 0
        elif align_items == "flex-start":
            # Use content size for cross axis
            content_w, content_h = _content_intrinsic_size(getattr(item.node, "text", None), measurer, item.style)
            item.cross_size = content_h if is_row else content_w
            item.cross_start = 0
        elif align_items == "flex-end":
            content_w, content_h = _content_intrinsic_size(getattr(item.node, "text", None), measurer, item.style)
            item.cross_size = content_h if is_row else content_w
            item.cross_start = cross_axis_size - item.cross_size
        elif align_items == "center":
            content_w, content_h = _content_intrinsic_size(getattr(item.node, "text", None), measurer, item.style)
            item.cross_size = content_h if is_row else content_w
            item.cross_start = (cross_axis_size - item.cross_size) // 2
        else:  # baseline or stretch
            item.cross_size = cross_axis_size
            item.cross_start = 0

        # Create the actual GuiBox
        if is_row:
            x = container_x + item.main_start
            y = container_y + item.cross_start
            width = item.main_size
            height = item.cross_size
        else:
            x = container_x + item.cross_start
            y = container_y + item.main_start
            width = item.cross_size
            height = item.main_size

        # Compute child boxes recursively
        child_boxes = []
        if hasattr(item.node, "children") and item.node.children:
            # Recursively layout children
            child_boxes = _compute_flexbox_layout(item.node.children, item.style, x, y, width, height, resolve_style, caps, measurer, em_px)

        box = GuiBox(
            x=x,
            y=y,
            width=width,
            height=height,
            component=item.node,
            style=item.style,
            children=child_boxes,
        )
        result_boxes.append(box)

    return result_boxes


def _compute_flex_layout(
    comp: GuiNode,
    style: object,
    avail_x: int,
    avail_y: int,
    avail_w: int,
    avail_h: int,
    resolve_style: ResolveStyleFn,
    caps: object,
    measurer: TextMeasurer,
    em_px: float,
) -> GuiBox:
    # Resolve own box model
    bm = _insets_px(style, avail_w, avail_h, em_px)

    # Resolve own width/height (content box)
    raw_w = _px_from_length(getattr(style, "width", None), avail_w, em_px)
    raw_h = _px_from_length(getattr(style, "height", None), avail_h, em_px)

    # Content intrinsic
    cont_w, cont_h = _content_intrinsic_size(getattr(comp, "text", None), measurer, style)

    # Flex sizing basics
    content_w = raw_w if raw_w is not None else cont_w
    content_h = raw_h if raw_h is not None else cont_h

    inner_x = avail_x + bm.mar_l + bm.bor_w + bm.pad_l
    inner_y = avail_y + bm.mar_t + bm.bor_w + bm.pad_t

    # If this is a flex container, we need to lay out children inside inner box.
    direction = getattr(style, "flex_direction", None) or "row"
    is_flex_container = (getattr(style, "display", None) == "flex") or bool(comp.children)

    # Initial inner box size (may expand to children)
    inner_w = max(0, (raw_w if raw_w is not None else content_w))
    inner_h = max(0, (raw_h if raw_h is not None else content_h))

    child_boxes: list[GuiBox] = []

    if is_flex_container and comp.children:
        # Implement proper flexbox algorithm
        child_boxes = _compute_flexbox_layout(comp.children, style, inner_x, inner_y, inner_w, inner_h, resolve_style, caps, measurer, em_px)

    # Total border box
    total_w = bm.mar_l + bm.bor_w + bm.pad_l + inner_w + bm.pad_r + bm.bor_w + bm.mar_r
    total_h = bm.mar_t + bm.bor_w + bm.pad_t + inner_h + bm.pad_b + bm.bor_w + bm.mar_b

    return GuiBox(
        x=avail_x,
        y=avail_y,
        width=total_w,
        height=total_h,
        component=comp,
        style=style,
        children=child_boxes,
    )


def compute_layout_tree(
    root: GuiNode,
    *,
    viewport_w: int,
    viewport_h: int,
    resolve_style: ResolveStyleFn,
    caps: object,
    measurer: TextMeasurer,
    base_font_px: float = 16.0,
) -> GuiBox:
    """Compute a full GuiBox tree for a component hierarchy."""
    root_style = resolve_style(root, getattr(root, "state", {}), caps)
    # Root starts at 0,0 and can expand; clamp to viewport
    box = _compute_flex_layout(
        root,
        root_style,
        0,
        0,
        viewport_w,
        viewport_h,
        resolve_style,
        caps,
        measurer,
        base_font_px,
    )
    # Ensure it never exceeds viewport
    box.width = min(box.width, viewport_w)
    box.height = min(box.height, viewport_h)
    return box
