# textforge/renderers/gui/gui_renderer.py
from __future__ import annotations

from collections.abc import Callable
from typing import Protocol

from ...core.layout.engine import LayoutStyle
from ...style.tfs.adapters.gui_mapper import map_to_gui
from ...style.tfs.tfs_values import HSLA, RGBA
from .types import GuiNode


class Canvas(Protocol):
    """Abstract immediate-mode drawing API in pixels."""

    def save(self) -> None: ...
    def restore(self) -> None: ...
    def fill_rect(self, x: int, y: int, w: int, h: int, color: tuple[int, int, int, int]) -> None: ...
    def stroke_rect(self, x: int, y: int, w: int, h: int, color: tuple[int, int, int, int], width: int) -> None: ...
    def draw_text(
        self,
        x: int,
        y: int,
        text: str,
        color: tuple[int, int, int, int],
        font_face: str | None,
        px: int,
        weight: int | str | None,
    ) -> None: ...


_DrawFunc = Callable[[Canvas, GuiNode], None]


def _color_spec_to_rgba(color_spec: object) -> tuple[int, int, int, int] | None:
    """Convert a color spec to RGBA tuple, or None if not a color."""
    if isinstance(color_spec, RGBA):
        return (color_spec.r, color_spec.g, color_spec.b, int(255 * color_spec.a))
    elif isinstance(color_spec, HSLA):
        # Convert HSLA to RGBA (simplified conversion)
        # This is a basic HSL to RGB conversion
        h, s, l_val = color_spec.h / 360.0, color_spec.s, color_spec.lightness
        c = (1 - abs(2 * l_val - 1)) * s
        x = c * (1 - abs((h * 6) % 2 - 1))
        m = l_val - c / 2

        if 0 <= h < 1 / 6:
            r, g, b = c, x, 0
        elif 1 / 6 <= h < 2 / 6:
            r, g, b = x, c, 0
        elif 2 / 6 <= h < 3 / 6:
            r, g, b = 0, c, x
        elif 3 / 6 <= h < 4 / 6:
            r, g, b = 0, x, c
        elif 4 / 6 <= h < 5 / 6:
            r, g, b = x, 0, c
        else:
            r, g, b = c, 0, x

        return (int((r + m) * 255), int((g + m) * 255), int((b + m) * 255), int(255 * color_spec.a))
    elif isinstance(color_spec, str):
        # Handle hex colors
        if color_spec.startswith("#") and len(color_spec) == 7:
            return (int(color_spec[1:3], 16), int(color_spec[3:5], 16), int(color_spec[5:7], 16), 255)
        elif color_spec.startswith("#") and len(color_spec) == 9:
            return (
                int(color_spec[1:3], 16),
                int(color_spec[3:5], 16),
                int(color_spec[5:7], 16),
                int(color_spec[7:9], 16),
            )
    return None


_REGISTRY: dict[str, _DrawFunc] = {}


def register(kind: str):
    """Decorator to register a draw function for a component type."""

    def _wrap(fn: _DrawFunc) -> _DrawFunc:
        _REGISTRY[kind] = fn
        return fn

    return _wrap


def render_tree(canvas: Canvas, root: GuiNode) -> None:
    """Render a GuiNode tree to the canvas."""
    # First compute layout for the entire tree
    from ...core.layout.engine import LayoutNode, compute_layout

    def _build_layout_tree(node: GuiNode) -> LayoutNode:
        """Convert GuiNode tree to LayoutNode tree for layout computation."""
        layout_style = node.layout_style if node.layout_style else LayoutStyle()
        layout_node = LayoutNode(style=layout_style)

        # Copy computed layout back to GuiNode
        layout_node.layout.x = node.x
        layout_node.layout.y = node.y
        layout_node.layout.width = node.width
        layout_node.layout.height = node.height

        # Recursively build children
        for child in node.children:
            child_layout_node = _build_layout_tree(child)
            layout_node.add(child_layout_node)

        return layout_node

    # Build layout tree and compute layout
    layout_root = _build_layout_tree(root)
    compute_layout(layout_root)

    # Copy computed layout back to GuiNode tree
    def _copy_layout_back(layout_node: LayoutNode, gui_node: GuiNode) -> None:
        gui_node.x = layout_node.layout.x
        gui_node.y = layout_node.layout.y
        gui_node.width = layout_node.layout.width
        gui_node.height = layout_node.layout.height

        for layout_child, gui_child in zip(layout_node.children, gui_node.children, strict=False):
            _copy_layout_back(layout_child, gui_child)

    _copy_layout_back(layout_root, root)

    # Now render the tree
    _render_node(canvas, root)


def _render_node(canvas: Canvas, node: GuiNode) -> None:
    """Render a single node and its children."""
    print(f"RENDER_NODE: Processing {node.component_name} at ({node.x},{node.y}) {node.width}x{node.height}, text='{node.text[:50] if node.text else None}'".encode("ascii", "ignore").decode("ascii"))
    # Skip rendering the root node - it's just a container
    if node.component_name != "root":
        fn = _REGISTRY.get(node.component_name)
        if fn:
            print(f"RENDER_NODE: Found renderer for {node.component_name}: {fn.__name__}")
            try:
                fn(canvas, node)
                print(f"RENDER_NODE: Successfully rendered {node.component_name}")
            except Exception as e:
                print(f"RENDER_NODE: ERROR in renderer {fn.__name__} for {node.component_name}: {e}")
                import traceback

                traceback.print_exc()
                # Fallback: draw a colored rectangle for renderer errors
                try:
                    canvas.fill_rect(node.x, node.y, node.width, node.height, (255, 0, 0, 128))  # Semi-transparent red
                except Exception as e2:
                    print(f"RENDER_NODE: ERROR drawing fallback rect: {e2}")
        else:
            print(f"RENDER_NODE: NO RENDERER for {node.component_name} - using fallback rect at ({node.x},{node.y}) {node.width}x{node.height}")
            # Fallback: draw a colored rectangle for missing renderers
            try:
                canvas.fill_rect(node.x, node.y, node.width, node.height, (255, 0, 0, 128))  # Semi-transparent red
            except Exception as e:
                print(f"RENDER_NODE: ERROR drawing fallback rect: {e}")

    print(f"RENDER_NODE: Processing {len(node.children)} children for {node.component_name}")
    for i, ch in enumerate(node.children):
        print(f"RENDER_NODE: Child {i}: {ch.component_name} at ({ch.x},{ch.y}) {ch.width}x{ch.height}")
        _render_node(canvas, ch)
    print(f"RENDER_NODE: {node.component_name} processing complete")


# Example draw functions
@register("text")
def _draw_text(canvas: Canvas, node: GuiNode) -> None:
    """Draw a text node."""
    if node.text:
        # Extract styling information
        color = (230, 232, 234, 255)  # default
        font_face = None
        px = 14
        weight = None

        # Use gui_mapper to extract drawing attributes
        gui_attrs = map_to_gui(node.style, cell_metrics=lambda: (8, 16), font_metrics=lambda profile: 16)

        if "fg" in gui_attrs and gui_attrs["fg"]:
            # Convert color spec to RGBA tuple (simplified)
            fg_color = gui_attrs["fg"]
            if hasattr(fg_color, "r"):
                color = (
                    int(fg_color.r),
                    int(fg_color.g),
                    int(fg_color.b),
                    int(255 * float(getattr(fg_color, "a", 1.0))),
                )
            elif isinstance(fg_color, str):
                # Handle hex colors
                if fg_color.startswith("#") and len(fg_color) == 7:
                    color = (int(fg_color[1:3], 16), int(fg_color[3:5], 16), int(fg_color[5:7], 16), 255)

            if "font_size_px" in gui_attrs and gui_attrs["font_size_px"]:
                px = gui_attrs["font_size_px"]

            if "font_profile" in gui_attrs and gui_attrs["font_profile"]:
                font_face = gui_attrs["font_profile"]

        canvas.draw_text(node.x, node.y, node.text or "", color=color, font_face=font_face, px=px, weight=weight)


@register("title")
def _draw_title(canvas: Canvas, node: GuiNode) -> None:
    """Draw a title node."""
    if node.text:
        # Title styling: larger, bolder text
        color = (0, 0, 0, 255)  # Black text
        font_face = None
        px = 24  # Larger font
        weight = "bold"

        # Use gui_mapper to extract drawing attributes
        gui_attrs = map_to_gui(node.style, cell_metrics=lambda: (8, 16), font_metrics=lambda profile: 16)

        if "fg" in gui_attrs and gui_attrs["fg"]:
            # Convert color spec to RGBA tuple (simplified)
            fg_color = gui_attrs["fg"]
            if hasattr(fg_color, "r"):
                color = (
                    int(fg_color.r),
                    int(fg_color.g),
                    int(fg_color.b),
                    int(255 * float(getattr(fg_color, "a", 1.0))),
                )
            elif isinstance(fg_color, str):
                # Handle hex colors
                if fg_color.startswith("#") and len(fg_color) == 7:
                    color = (int(fg_color[1:3], 16), int(fg_color[3:5], 16), int(fg_color[5:7], 16), 255)

            if "font_size_px" in gui_attrs and gui_attrs["font_size_px"]:
                px = gui_attrs["font_size_px"]

            if "font_profile" in gui_attrs and gui_attrs["font_profile"]:
                font_face = gui_attrs["font_profile"]

        canvas.draw_text(node.x, node.y, node.text or "", color=color, font_face=font_face, px=px, weight=weight)

for _level in range(1, 7):
    _REGISTRY[f"title{_level}"] = _draw_title


@register("box")
def _draw_box(canvas: Canvas, node: GuiNode) -> None:
    """Draw a generic container box."""
    bg_color = (245, 245, 247, 255)
    border_color = (206, 212, 218, 255)

    if node.style:
        gui_attrs = map_to_gui(node.style, cell_metrics=lambda: (8, 16), font_metrics=lambda profile: 16)
        if "bg" in gui_attrs and gui_attrs["bg"]:
            bg_spec = gui_attrs["bg"]
            if hasattr(bg_spec, "r"):
                bg_color = (
                    int(bg_spec.r),
                    int(bg_spec.g),
                    int(bg_spec.b),
                    int(255 * float(getattr(bg_spec, "a", 1.0))),
                )
        if "border_color" in gui_attrs and gui_attrs["border_color"]:
            border_spec = gui_attrs["border_color"]
            if hasattr(border_spec, "r"):
                border_color = (
                    int(border_spec.r),
                    int(border_spec.g),
                    int(border_spec.b),
                    int(255 * float(getattr(border_spec, "a", 1.0))),
                )

    width = max(node.width, 1)
    height = max(node.height, 1)
    canvas.fill_rect(node.x, node.y, width, height, bg_color)
    canvas.stroke_rect(node.x, node.y, width, height, border_color, 1)


@register("panel")
def _draw_panel(canvas: Canvas, node: GuiNode) -> None:
    """Draw a panel container."""
    # Panel styling - similar to box but different color scheme
    bg_color = (35, 39, 44, 255)
    border_color = (80, 86, 95, 255)
    border_width = 2

    if node.style:
        gui_attrs = map_to_gui(node.style, cell_metrics=lambda: (8, 16), font_metrics=lambda profile: 16)
        if "bg" in gui_attrs and gui_attrs["bg"]:
            bg_color_spec = gui_attrs["bg"]
            if hasattr(bg_color_spec, "r"):
                bg_color = (
                    int(bg_color_spec.r),
                    int(bg_color_spec.g),
                    int(bg_color_spec.b),
                    int(255 * float(getattr(bg_color_spec, "a", 1.0))),
                )

    canvas.fill_rect(node.x, node.y, node.width, node.height, bg_color)
    canvas.stroke_rect(node.x, node.y, node.width, node.height, border_color, border_width)
    if node.text:
        canvas.draw_text(node.x + 12, node.y + 18, node.text, color=(230, 232, 234, 255), font_face=None, px=14, weight="bold")


@register("card")
def _draw_card(canvas: Canvas, node: GuiNode) -> None:
    """Draw a card container."""
    # Card styling - clean white background with subtle border
    bg_color = (255, 255, 255, 255)
    border_color = (200, 200, 200, 255)
    border_width = 1

    if node.style:
        gui_attrs = map_to_gui(node.style, cell_metrics=lambda: (8, 16), font_metrics=lambda profile: 16)
        if "bg" in gui_attrs and gui_attrs["bg"]:
            bg_color_spec = gui_attrs["bg"]
            if hasattr(bg_color_spec, "r"):
                bg_color = (
                    int(bg_color_spec.r),
                    int(bg_color_spec.g),
                    int(bg_color_spec.b),
                    int(255 * float(getattr(bg_color_spec, "a", 1.0))),
                )

    canvas.fill_rect(node.x, node.y, node.width, node.height, bg_color)
    canvas.stroke_rect(node.x, node.y, node.width, node.height, border_color, border_width)


@register("blockquote")
def _draw_blockquote(canvas: Canvas, node: GuiNode) -> None:
    """Draw a blockquote."""
    if node.text:
        # Blockquote styling - indented with quote character
        color = (150, 150, 150, 255)  # Gray text
        quote_color = (100, 150, 100, 255)  # Green quote mark

        if node.style:
            gui_attrs = map_to_gui(node.style, cell_metrics=lambda: (8, 16), font_metrics=lambda profile: 16)
            if "fg" in gui_attrs and gui_attrs["fg"]:
                fg_color = gui_attrs["fg"]
                if hasattr(fg_color, "r"):
                    color = (
                        int(fg_color.r),
                        int(fg_color.g),
                        int(fg_color.b),
                        int(255 * float(getattr(fg_color, "a", 1.0))),
                    )

        # Draw quote character
        canvas.draw_text(node.x + 10, node.y + 10, "┃", color=quote_color, font_face=None, px=14, weight=None)

        # Draw text with indentation
        canvas.draw_text(node.x + 30, node.y + 10, node.text, color=color, font_face=None, px=14, weight=None)


@register("graph_point")
def _draw_graph_point(canvas: Canvas, node: GuiNode) -> None:
    """Draw a single point on a graph."""
    if node.text:
        # Parse the coordinate from text like "(2.18,0.82)"
        try:
            coords = node.text.strip("()").split(",")
            if len(coords) == 2:
                float(coords[0])
                float(coords[1])
                # For now, just draw a small dot - actual positioning should be handled by parent
                canvas.fill_rect(node.x, node.y, 2, 2, (0, 255, 0, 255))  # Green dot
        except (ValueError, IndexError):
            pass


@register("waveform_point")
def _draw_waveform_point(canvas: Canvas, node: GuiNode) -> None:
    """Draw a single point on a waveform."""
    if node.text:
        try:
            # Parse the amplitude value
            amplitude = float(node.text)
            # Draw a single pixel line at the amplitude
            center_y = node.y + 1  # Center of the 2-pixel height
            y_offset = int(amplitude * 50)  # Scale the amplitude
            canvas.fill_rect(node.x, center_y + y_offset, 1, 1, (0, 255, 255, 255))  # Cyan dot
        except (ValueError, TypeError):
            pass


@register("spectrogram_cell")
def _draw_spectrogram_cell(canvas: Canvas, node: GuiNode) -> None:
    """Draw a single cell in a spectrogram."""
    if node.text:
        # Use different intensities based on the character
        if node.text == "█":
            canvas.fill_rect(node.x, node.y, node.width, node.height, (255, 255, 0, 255))  # Yellow for high intensity
        elif node.text == "░":
            canvas.fill_rect(node.x, node.y, node.width, node.height, (64, 64, 0, 255))  # Dark yellow for low intensity
        else:
            canvas.fill_rect(node.x, node.y, node.width, node.height, (32, 32, 32, 255))  # Dark gray for background


@register("map_cell")
def _draw_map_cell(canvas: Canvas, node: GuiNode) -> None:
    """Draw a single cell in a mini-map."""
    if node.text:
        # Draw the character
        canvas.draw_text(node.x, node.y, node.text, color=(255, 255, 255, 255), font_face="Consolas", px=8, weight=None)


@register("paragraph")
def _draw_paragraph(canvas: Canvas, node: GuiNode) -> None:
    """Draw a paragraph node."""
    if node.text:
        # Use same text styling as text component
        color = (230, 232, 234, 255)
        font_face = None
        px = 14
        weight = None

        gui_attrs = {}
        if node.style:
            # node.style is guaranteed to be ResolvedStyle here due to the if check
            gui_attrs = map_to_gui(node.style, cell_metrics=lambda: (8, 16), font_metrics=lambda profile: 16)

        if "fg" in gui_attrs and gui_attrs["fg"]:
            fg_color = gui_attrs["fg"]
            if hasattr(fg_color, "r"):
                color = (
                    int(fg_color.r),
                    int(fg_color.g),
                    int(fg_color.b),
                    int(255 * float(getattr(fg_color, "a", 1.0))),
                )
            elif isinstance(fg_color, str):
                if fg_color.startswith("#") and len(fg_color) == 7:
                    color = (int(fg_color[1:3], 16), int(fg_color[3:5], 16), int(fg_color[5:7], 16), 255)

            if "font_size_px" in gui_attrs and gui_attrs["font_size_px"]:
                px = gui_attrs["font_size_px"]

            if "font_profile" in gui_attrs and gui_attrs["font_profile"]:
                font_face = gui_attrs["font_profile"]

        canvas.draw_text(node.x, node.y, node.text or "", color=color, font_face=font_face, px=px, weight=weight)


# Data component draw functions
@register("table")
def _draw_table(canvas: Canvas, node: GuiNode) -> None:
    """Draw a table node."""
    # Draw table background
    bg_color = (40, 44, 49, 255)
    if node.style:
        gui_attrs = map_to_gui(node.style, cell_metrics=lambda: (8, 16), font_metrics=lambda profile: 16)
        if "bg" in gui_attrs and gui_attrs["bg"]:
            bg_color_spec = gui_attrs["bg"]
            if hasattr(bg_color_spec, "r"):
                bg_color = (
                    int(bg_color_spec.r),
                    int(bg_color_spec.g),
                    int(bg_color_spec.b),
                    int(255 * float(getattr(bg_color_spec, "a", 1.0))),
                )
    canvas.fill_rect(node.x, node.y, node.width, node.height, bg_color)


@register("table_header_cell")
def _draw_table_header_cell(canvas: Canvas, node: GuiNode) -> None:
    """Draw a table header cell."""
    if node.text:
        color = (255, 255, 255, 255)  # White text for headers
        canvas.draw_text(node.x, node.y, node.text or "", color=color, font_face=None, px=14, weight="bold")


@register("table_cell")
def _draw_table_cell(canvas: Canvas, node: GuiNode) -> None:
    """Draw a table cell."""
    if node.text:
        color = (230, 232, 234, 255)  # Default text color
        canvas.draw_text(node.x, node.y, node.text or "", color=color, font_face=None, px=14, weight=None)


@register("chart")
def _draw_chart(canvas: Canvas, node: GuiNode) -> None:
    """Draw a chart node."""
    bg_color = (30, 34, 39, 255)
    if node.style:
        gui_attrs = map_to_gui(node.style, cell_metrics=lambda: (8, 16), font_metrics=lambda profile: 16)
        if "bg" in gui_attrs and gui_attrs["bg"]:
            bg_color_spec = gui_attrs["bg"]
            if hasattr(bg_color_spec, "r"):
                bg_color = (
                    int(bg_color_spec.r),
                    int(bg_color_spec.g),
                    int(bg_color_spec.b),
                    int(255 * float(getattr(bg_color_spec, "a", 1.0))),
                )
    canvas.fill_rect(node.x, node.y, node.width, node.height, bg_color)


@register("bar")
def _draw_bar(canvas: Canvas, node: GuiNode) -> None:
    """Draw a bar in a chart."""
    bar_color = (70, 130, 180, 255)  # Steel blue
    canvas.fill_rect(node.x, node.y, node.width, node.height, bar_color)


@register("key_value")
def _draw_key_value(canvas: Canvas, node: GuiNode) -> None:
    """Draw a key-value list."""
    bg_color = (25, 29, 34, 255)
    if node.style:
        gui_attrs = map_to_gui(node.style, cell_metrics=lambda: (8, 16), font_metrics=lambda profile: 16)
        if "bg" in gui_attrs and gui_attrs["bg"]:
            bg_color_spec = gui_attrs["bg"]
            if hasattr(bg_color_spec, "r"):
                bg_color = (
                    int(bg_color_spec.r),
                    int(bg_color_spec.g),
                    int(bg_color_spec.b),
                    int(255 * float(getattr(bg_color_spec, "a", 1.0))),
                )
    canvas.fill_rect(node.x, node.y, node.width, node.height, bg_color)


@register("key")
def _draw_key(canvas: Canvas, node: GuiNode) -> None:
    """Draw a key in key-value pair."""
    if node.text:
        color = (150, 150, 150, 255)  # Gray for keys
        canvas.draw_text(node.x, node.y, node.text or "", color=color, font_face=None, px=14, weight=None)


@register("value")
def _draw_value(canvas: Canvas, node: GuiNode) -> None:
    """Draw a value in key-value pair."""
    if node.text:
        color = (230, 232, 234, 255)  # Default for values
        canvas.draw_text(node.x, node.y, node.text or "", color=color, font_face=None, px=14, weight=None)


@register("code_block")
def _draw_code_block(canvas: Canvas, node: GuiNode) -> None:
    """Draw a code block."""
    bg_color = (20, 24, 29, 255)  # Dark background for code
    if node.style:
        gui_attrs = map_to_gui(node.style, cell_metrics=lambda: (8, 16), font_metrics=lambda profile: 16)
        if "bg" in gui_attrs and gui_attrs["bg"]:
            bg_color_spec = gui_attrs["bg"]
            if hasattr(bg_color_spec, "r"):
                bg_color = (
                    int(bg_color_spec.r),
                    int(bg_color_spec.g),
                    int(bg_color_spec.b),
                    int(255 * float(getattr(bg_color_spec, "a", 1.0))),
                )
    canvas.fill_rect(node.x, node.y, node.width, node.height, bg_color)


@register("code_line")
def _draw_code_line(canvas: Canvas, node: GuiNode) -> None:
    """Draw a line of code."""
    if node.text:
        color = (200, 220, 240, 255)  # Light blue for code
        canvas.draw_text(node.x, node.y, node.text or "", color=color, font_face="monospace", px=12, weight=None)


# Decorative component draw functions
@register("divider")
def _draw_divider(canvas: Canvas, node: GuiNode) -> None:
    """Draw a divider line."""
    line_color = (100, 100, 100, 255)
    if node.style:
        gui_attrs = map_to_gui(node.style, cell_metrics=lambda: (8, 16), font_metrics=lambda profile: 16)
        if "fg" in gui_attrs and gui_attrs["fg"]:
            fg_color = gui_attrs["fg"]
            if hasattr(fg_color, "r"):
                line_color = (
                    int(fg_color.r),
                    int(fg_color.g),
                    int(fg_color.b),
                    int(255 * float(getattr(fg_color, "a", 1.0))),
                )

    # Draw horizontal line
    canvas.stroke_rect(node.x, node.y + node.height // 2, node.width, 1, line_color, 1)

    # Draw text if present
    if node.text:
        text_color = (230, 232, 234, 255)
        text = node.text  # Local variable to help type checker
        canvas.draw_text(
            node.x + node.width // 2 - len(text) * 4,
            node.y + node.height // 2 - 7,
            text,
            color=text_color,
            font_face=None,
            px=14,
            weight=None,
        )


@register("banner")
def _draw_banner(canvas: Canvas, node: GuiNode) -> None:
    """Draw a banner."""
    if node.text:
        bg_color = (60, 80, 100, 255)
        text_color = (255, 255, 255, 255)

        if node.style:
            # node.style is guaranteed to be ResolvedStyle here due to the if check
            gui_attrs = map_to_gui(node.style, cell_metrics=lambda: (8, 16), font_metrics=lambda profile: 16)
            if "bg" in gui_attrs and gui_attrs["bg"]:
                bg_color_spec = gui_attrs["bg"]
                if hasattr(bg_color_spec, "r"):
                    bg_color = (
                        int(bg_color_spec.r),
                        int(bg_color_spec.g),
                        int(bg_color_spec.b),
                        int(255 * float(getattr(bg_color_spec, "a", 1.0))),
                    )
            if "fg" in gui_attrs and gui_attrs["fg"]:
                fg_color = gui_attrs["fg"]
                if hasattr(fg_color, "r"):
                    text_color = (
                        int(fg_color.r),
                        int(fg_color.g),
                        int(fg_color.b),
                        int(255 * float(getattr(fg_color, "a", 1.0))),
                    )

        canvas.fill_rect(node.x, node.y, node.width, node.height, bg_color)
        canvas.draw_text(node.x + 10, node.y + 10, node.text or "", color=text_color, font_face=None, px=18, weight="bold")


@register("tooltip")
def _draw_tooltip(canvas: Canvas, node: GuiNode) -> None:
    """Draw a tooltip."""
    bg_color = (50, 50, 50, 255)
    border_color = (150, 150, 150, 255)

    if node.style:
        gui_attrs = map_to_gui(node.style, cell_metrics=lambda: (8, 16), font_metrics=lambda profile: 16)
        if "bg" in gui_attrs and gui_attrs["bg"]:
            bg_color_spec = gui_attrs["bg"]
            if hasattr(bg_color_spec, "r"):
                bg_color = (
                    int(bg_color_spec.r),
                    int(bg_color_spec.g),
                    int(bg_color_spec.b),
                    int(255 * float(getattr(bg_color_spec, "a", 1.0))),
                )

    canvas.fill_rect(node.x, node.y, node.width, node.height, bg_color)
    canvas.stroke_rect(node.x, node.y, node.width, node.height, border_color, 1)


@register("timeline")
def _draw_timeline(canvas: Canvas, node: GuiNode) -> None:
    """Draw a timeline."""
    bg_color = (25, 29, 34, 255)
    if node.style:
        gui_attrs = map_to_gui(node.style, cell_metrics=lambda: (8, 16), font_metrics=lambda profile: 16)
        if "bg" in gui_attrs and gui_attrs["bg"]:
            bg_color_spec = gui_attrs["bg"]
            if hasattr(bg_color_spec, "r"):
                bg_color = (
                    int(bg_color_spec.r),
                    int(bg_color_spec.g),
                    int(bg_color_spec.b),
                    int(255 * float(getattr(bg_color_spec, "a", 1.0))),
                )
    canvas.fill_rect(node.x, node.y, node.width, node.height, bg_color)


@register("timeline_event")
def _draw_timeline_event(canvas: Canvas, node: GuiNode) -> None:
    """Draw a timeline event marker."""
    marker_color = (100, 150, 100, 255)  # Green for markers
    canvas.fill_rect(node.x, node.y, 8, 8, marker_color)


@register("ascii_art")
def _draw_ascii_art(canvas: Canvas, node: GuiNode) -> None:
    """Draw ASCII art."""
    if node.text:
        color = (200, 200, 200, 255)
        if node.style:
            # node.style is guaranteed to be ResolvedStyle here due to the if check
            gui_attrs = map_to_gui(node.style, cell_metrics=lambda: (8, 16), font_metrics=lambda profile: 16)
            if "fg" in gui_attrs and gui_attrs["fg"]:
                fg_color = gui_attrs["fg"]
                if hasattr(fg_color, "r"):
                    color = (
                        int(fg_color.r),
                        int(fg_color.g),
                        int(fg_color.b),
                        int(255 * float(getattr(fg_color, "a", 1.0))),
                    )

        # For simplicity, just draw the text - real ASCII art would need more complex rendering
        canvas.draw_text(node.x, node.y, node.text or "", color=color, font_face="monospace", px=12, weight=None)


# Feedback component draw functions
@register("badge")
def _draw_badge(canvas: Canvas, node: GuiNode) -> None:
    """Draw a badge."""
    if node.text:
        # Default badge styling
        bg_color = (0, 123, 255, 255)  # Blue background
        text_color = (255, 255, 255, 255)  # White text
        padding = 8

        if node.style:
            # node.style is guaranteed to be ResolvedStyle here due to the if check
            gui_attrs = map_to_gui(node.style, cell_metrics=lambda: (8, 16), font_metrics=lambda profile: 16)
            if "bg" in gui_attrs and gui_attrs["bg"]:
                bg_color_spec = gui_attrs["bg"]
                if hasattr(bg_color_spec, "r"):
                    bg_color = (
                        int(bg_color_spec.r),
                        int(bg_color_spec.g),
                        int(bg_color_spec.b),
                        int(255 * float(getattr(bg_color_spec, "a", 1.0))),
                    )
            if "fg" in gui_attrs and gui_attrs["fg"]:
                fg_color = gui_attrs["fg"]
                if hasattr(fg_color, "r"):
                    text_color = (
                        int(fg_color.r),
                        int(fg_color.g),
                        int(fg_color.b),
                        int(255 * float(getattr(fg_color, "a", 1.0))),
                    )

        # Draw rounded rectangle background
        canvas.fill_rect(node.x, node.y, node.width, node.height, bg_color)
        # Draw text
        canvas.draw_text(
            node.x + padding,
            node.y + node.height // 2 - 6,
            node.text,
            color=text_color,
            font_face=None,
            px=14,
            weight="bold",
        )


@register("rating")
def _draw_rating(canvas: Canvas, node: GuiNode) -> None:
    """Draw a rating display."""
    star_color = (255, 193, 7, 255)  # Amber/gold
    x_offset = node.x

    for child in node.children:
        if child.component_name == "rating_star":
            if child.text == "filled":
                canvas.draw_text(x_offset, node.y, "★", color=star_color, font_face=None, px=16, weight=None)
            elif child.text == "half":
                canvas.draw_text(x_offset, node.y, "☆", color=star_color, font_face=None, px=16, weight=None)
            else:  # empty
                canvas.draw_text(x_offset, node.y, "☆", color=(150, 150, 150, 255), font_face=None, px=16, weight=None)
            x_offset += 20
        elif child.component_name == "rating_value":
            canvas.draw_text(x_offset + 10, node.y, child.text or "", color=(100, 100, 100, 255), font_face=None, px=14, weight=None)


@register("toast")
def _draw_toast(canvas: Canvas, node: GuiNode) -> None:
    """Draw a toast notification."""
    # Default toast styling based on type
    bg_color = (70, 80, 90, 255)  # Dark gray background
    border_color = (100, 110, 120, 255)

    toast_type = "info"
    for child in node.children:
        if child.component_name == "toast_type":
            toast_type = child.text or "info"
            break

    # Color based on type
    if toast_type == "success":
        bg_color = (40, 167, 69, 255)
    elif toast_type == "warning":
        bg_color = (255, 193, 7, 255)
    elif toast_type == "error":
        bg_color = (220, 53, 69, 255)

    if node.style:
        gui_attrs = map_to_gui(node.style, cell_metrics=lambda: (8, 16), font_metrics=lambda profile: 16)
        if "bg" in gui_attrs and gui_attrs["bg"]:
            bg_color_spec = gui_attrs["bg"]
            if hasattr(bg_color_spec, "r"):
                bg_color = (
                    int(bg_color_spec.r),
                    int(bg_color_spec.g),
                    int(bg_color_spec.b),
                    int(255 * float(getattr(bg_color_spec, "a", 1.0))),
                )

    canvas.fill_rect(node.x, node.y, node.width, node.height, bg_color)
    canvas.stroke_rect(node.x, node.y, node.width, node.height, border_color, 1)

    if node.text:
        text_color = (255, 255, 255, 255)
        canvas.draw_text(node.x + 10, node.y + 10, node.text or "", color=text_color, font_face=None, px=14, weight=None)


@register("console_panel")
def _draw_console_panel(canvas: Canvas, node: GuiNode) -> None:
    """Draw a console panel."""
    bg_color = (20, 24, 29, 255)  # Dark background
    border_color = (70, 76, 85, 255)

    if node.style:
        gui_attrs = map_to_gui(node.style, cell_metrics=lambda: (8, 16), font_metrics=lambda profile: 16)
        if "bg" in gui_attrs and gui_attrs["bg"]:
            bg_color_spec = gui_attrs["bg"]
            if hasattr(bg_color_spec, "r"):
                bg_color = (
                    int(bg_color_spec.r),
                    int(bg_color_spec.g),
                    int(bg_color_spec.b),
                    int(255 * float(getattr(bg_color_spec, "a", 1.0))),
                )

    canvas.fill_rect(node.x, node.y, node.width, node.height, bg_color)
    canvas.stroke_rect(node.x, node.y, node.width, node.height, border_color, 1)

    y_offset = node.y + 10
    for child in node.children:
        if child.component_name == "title":
            canvas.draw_text(
                node.x + 10,
                y_offset,
                child.text or "",
                color=(255, 255, 255, 255),
                font_face=None,
                px=16,
                weight="bold",
            )
            y_offset += 25
        elif child.component_name == "console_line":
            canvas.draw_text(
                node.x + 10,
                y_offset,
                child.text or "",
                color=(200, 220, 240, 255),
                font_face="monospace",
                px=12,
                weight=None,
            )
            y_offset += 15


@register("snackbar")
def _draw_snackbar(canvas: Canvas, node: GuiNode) -> None:
    """Draw a snackbar."""
    bg_color = (50, 50, 50, 255)
    text_color = (255, 255, 255, 255)

    snackbar_type = "info"
    for child in node.children:
        if child.component_name == "snackbar_type":
            snackbar_type = child.text or "info"
            break

    # Color based on type
    if snackbar_type == "success":
        bg_color = (40, 167, 69, 255)
    elif snackbar_type == "warning":
        bg_color = (255, 193, 7, 255)
    elif snackbar_type == "error":
        bg_color = (220, 53, 69, 255)

    if node.style:
        gui_attrs = map_to_gui(node.style, cell_metrics=lambda: (8, 16), font_metrics=lambda profile: 16)
        if "bg" in gui_attrs and gui_attrs["bg"]:
            bg_color_spec = gui_attrs["bg"]
            if hasattr(bg_color_spec, "r"):
                bg_color = (
                    int(bg_color_spec.r),
                    int(bg_color_spec.g),
                    int(bg_color_spec.b),
                    int(255 * float(getattr(bg_color_spec, "a", 1.0))),
                )

    canvas.fill_rect(node.x, node.y, node.width, node.height, bg_color)

    if node.text:
        canvas.draw_text(node.x + 10, node.y + node.height // 2 - 6, node.text, color=text_color, font_face=None, px=14, weight=None)


@register("alert_banner")
def _draw_alert_banner(canvas: Canvas, node: GuiNode) -> None:
    """Draw an alert banner."""
    bg_color = (255, 255, 255, 255)  # White background
    text_color = (0, 0, 0, 255)  # Black text
    border_color = (200, 200, 200, 255)

    alert_type = "info"
    for child in node.children:
        if child.component_name == "alert_type":
            alert_type = child.text or "info"
            break

    # Color based on type
    if alert_type == "success":
        bg_color = (212, 237, 218, 255)
        text_color = (21, 87, 36, 255)
        border_color = (40, 167, 69, 255)
    elif alert_type == "warning":
        bg_color = (255, 243, 205, 255)
        text_color = (133, 100, 4, 255)
        border_color = (255, 193, 7, 255)
    elif alert_type == "error":
        bg_color = (248, 215, 218, 255)
        text_color = (114, 28, 36, 255)
        border_color = (220, 53, 69, 255)

    if node.style:
        gui_attrs = map_to_gui(node.style, cell_metrics=lambda: (8, 16), font_metrics=lambda profile: 16)
        if "bg" in gui_attrs and gui_attrs["bg"]:
            bg_color_spec = gui_attrs["bg"]
            if hasattr(bg_color_spec, "r"):
                bg_color = (
                    int(bg_color_spec.r),
                    int(bg_color_spec.g),
                    int(bg_color_spec.b),
                    int(255 * float(getattr(bg_color_spec, "a", 1.0))),
                )
        if "fg" in gui_attrs and gui_attrs["fg"]:
            fg_color = gui_attrs["fg"]
            if hasattr(fg_color, "r"):
                text_color = (
                    int(fg_color.r),
                    int(fg_color.g),
                    int(fg_color.b),
                    int(255 * float(getattr(fg_color, "a", 1.0))),
                )

    canvas.fill_rect(node.x, node.y, node.width, node.height, bg_color)
    canvas.stroke_rect(node.x, node.y, node.width, node.height, border_color, 2)

    if node.text:
        canvas.draw_text(node.x + 15, node.y + node.height // 2 - 6, node.text, color=text_color, font_face=None, px=14, weight=None)


# Interactive component draw functions
@register("button")
def _draw_button(canvas: Canvas, node: GuiNode) -> None:
    """Draw an interactive button."""
    bg_color = (52, 120, 246, 255)
    border_color = (35, 94, 210, 255)
    text_color = (255, 255, 255, 255)

    if node.style:
        gui_attrs = map_to_gui(node.style, cell_metrics=lambda: (8, 16), font_metrics=lambda profile: 16)
        if "bg" in gui_attrs and gui_attrs["bg"]:
            bg_spec = gui_attrs["bg"]
            if hasattr(bg_spec, "r"):
                bg_color = (
                    int(bg_spec.r),
                    int(bg_spec.g),
                    int(bg_spec.b),
                    int(255 * float(getattr(bg_spec, "a", 1.0))),
                )
        if "fg" in gui_attrs and gui_attrs["fg"]:
            fg_spec = gui_attrs["fg"]
            if hasattr(fg_spec, "r"):
                text_color = (
                    int(fg_spec.r),
                    int(fg_spec.g),
                    int(fg_spec.b),
                    int(255 * float(getattr(fg_spec, "a", 1.0))),
                )

    width = max(node.width, 80)
    height = max(node.height, 32)
    canvas.fill_rect(node.x, node.y, width, height, bg_color)
    canvas.stroke_rect(node.x, node.y, width, height, border_color, 1)

    if node.text:
        approx_text_width = len(node.text) * 7
        text_x = node.x + max(8, (width - approx_text_width) // 2)
        baseline = node.y + height // 2 + 5
        canvas.draw_text(text_x, baseline, node.text, color=text_color, font_face=None, px=14, weight="bold")


@register("checkbox")
def _draw_checkbox(canvas: Canvas, node: GuiNode) -> None:
    """Draw a checkbox."""
    # Default checkbox styling
    box_color = (100, 100, 100, 255)
    check_color = (255, 255, 255, 255)

    checked = False
    label_text = ""
    for child in node.children:
        if child.component_name == "checkbox_label":
            label_text = child.text or ""
        elif child.component_name == "checkbox_state":
            checked = child.text == "checked"

    if node.style:
        gui_attrs = map_to_gui(node.style, cell_metrics=lambda: (8, 16), font_metrics=lambda profile: 16)
        if "fg" in gui_attrs and gui_attrs["fg"]:
            fg_color = gui_attrs["fg"]
            if hasattr(fg_color, "r"):
                box_color = (
                    int(fg_color.r),
                    int(fg_color.g),
                    int(fg_color.b),
                    int(255 * float(getattr(fg_color, "a", 1.0))),
                )

    # Draw checkbox box
    canvas.fill_rect(node.x, node.y, 16, 16, box_color)
    if checked:
        canvas.fill_rect(node.x + 4, node.y + 4, 8, 8, check_color)

    # Draw label
    if label_text:
        canvas.draw_text(node.x + 24, node.y + 12, label_text, color=(230, 232, 234, 255), font_face=None, px=14, weight=None)


@register("radio")
def _draw_radio(canvas: Canvas, node: GuiNode) -> None:
    """Draw a radio button."""
    circle_color = (100, 100, 100, 255)
    dot_color = (255, 255, 255, 255)

    selected = False
    label_text = ""
    for child in node.children:
        if child.component_name == "radio_label":
            label_text = child.text or ""
        elif child.component_name == "radio_state":
            selected = child.text == "selected"

    if node.style:
        gui_attrs = map_to_gui(node.style, cell_metrics=lambda: (8, 16), font_metrics=lambda profile: 16)
        if "fg" in gui_attrs and gui_attrs["fg"]:
            fg_color = gui_attrs["fg"]
            if hasattr(fg_color, "r"):
                circle_color = (
                    int(fg_color.r),
                    int(fg_color.g),
                    int(fg_color.b),
                    int(255 * float(getattr(fg_color, "a", 1.0))),
                )

    # Draw radio circle
    canvas.stroke_rect(node.x, node.y, 16, 16, circle_color, 2)
    if selected:
        canvas.fill_rect(node.x + 4, node.y + 4, 8, 8, dot_color)

    # Draw label
    if label_text:
        canvas.draw_text(node.x + 24, node.y + 12, label_text, color=(230, 232, 234, 255), font_face=None, px=14, weight=None)


@register("toggle")
def _draw_toggle(canvas: Canvas, node: GuiNode) -> None:
    """Draw a toggle switch."""
    bg_color = (150, 150, 150, 255)  # Off state
    knob_color = (255, 255, 255, 255)

    is_on = False
    label_text = ""
    for child in node.children:
        if child.component_name == "toggle_label":
            label_text = child.text or ""
        elif child.component_name == "toggle_state":
            is_on = child.text == "on"

    if is_on:
        bg_color = (40, 167, 69, 255)  # Green for on state

    if node.style:
        gui_attrs = map_to_gui(node.style, cell_metrics=lambda: (8, 16), font_metrics=lambda profile: 16)
        if "fg" in gui_attrs and gui_attrs["fg"]:
            fg_color = gui_attrs["fg"]
            if hasattr(fg_color, "r"):
                bg_color = (
                    int(fg_color.r),
                    int(fg_color.g),
                    int(fg_color.b),
                    int(255 * float(getattr(fg_color, "a", 1.0))),
                )

    # Draw toggle background
    canvas.fill_rect(node.x, node.y, 36, 20, bg_color)

    # Draw knob
    knob_x = node.x + 18 if is_on else node.x + 2
    canvas.fill_rect(knob_x, node.y + 2, 16, 16, knob_color)

    # Draw label
    if label_text:
        canvas.draw_text(node.x + 44, node.y + 14, label_text, color=(230, 232, 234, 255), font_face=None, px=14, weight=None)


@register("slider")
def _draw_slider(canvas: Canvas, node: GuiNode) -> None:
    """Draw a slider."""
    track_color = (100, 100, 100, 255)
    knob_color = (255, 255, 255, 255)

    label_text = ""
    percentage = 0.0
    for child in node.children:
        if child.component_name == "slider_label":
            label_text = child.text or ""
        elif child.component_name == "slider_percentage":
            try:
                percentage = float(child.text or "0")
            except ValueError:
                percentage = 0.0

    if node.style:
        gui_attrs = map_to_gui(node.style, cell_metrics=lambda: (8, 16), font_metrics=lambda profile: 16)
        if "fg" in gui_attrs and gui_attrs["fg"]:
            fg_color = gui_attrs["fg"]
            if hasattr(fg_color, "r"):
                track_color = (
                    int(fg_color.r),
                    int(fg_color.g),
                    int(fg_color.b),
                    int(255 * float(getattr(fg_color, "a", 1.0))),
                )

    # Draw track
    track_width = node.width - 60  # Leave space for label
    canvas.stroke_rect(node.x, node.y + 8, track_width, 4, track_color, 2)

    # Draw knob
    knob_x = node.x + int(percentage * (track_width - 12))
    canvas.fill_rect(knob_x, node.y + 4, 12, 12, knob_color)

    # Draw label and value
    if label_text:
        canvas.draw_text(node.x, node.y + 4, label_text, color=(230, 232, 234, 255), font_face=None, px=14, weight=None)


@register("form")
def _draw_form(canvas: Canvas, node: GuiNode) -> None:
    """Draw a form."""
    bg_color = (30, 34, 39, 255)

    if node.style:
        gui_attrs = map_to_gui(node.style, cell_metrics=lambda: (8, 16), font_metrics=lambda profile: 16)
        if "bg" in gui_attrs and gui_attrs["bg"]:
            bg_color_spec = gui_attrs["bg"]
            if hasattr(bg_color_spec, "r"):
                bg_color = (
                    int(bg_color_spec.r),
                    int(bg_color_spec.g),
                    int(bg_color_spec.b),
                    int(255 * float(getattr(bg_color_spec, "a", 1.0))),
                )

    canvas.fill_rect(node.x, node.y, node.width, node.height, bg_color)

    y_offset = node.y + 10
    for child in node.children:
        if child.component_name == "form_title":
            canvas.draw_text(
                node.x + 10,
                y_offset,
                child.text or "",
                color=(255, 255, 255, 255),
                font_face=None,
                px=18,
                weight="bold",
            )
            y_offset += 30
        elif child.component_name == "form_field":
            field_label = ""
            field_value = ""
            for field_child in child.children:
                if field_child.component_name == "field_label":
                    field_label = field_child.text or ""
                elif field_child.component_name == "field_value":
                    field_value = field_child.text or ""

            canvas.draw_text(
                node.x + 10,
                y_offset,
                f"{field_label}: {field_value}",
                color=(200, 220, 240, 255),
                font_face=None,
                px=14,
                weight=None,
            )
            y_offset += 20
        elif child.component_name == "form_submit":
            # Draw submit button
            canvas.fill_rect(node.x + 10, y_offset - 5, 80, 24, (70, 130, 180, 255))
            canvas.draw_text(
                node.x + 15,
                y_offset + 8,
                child.text or "",
                color=(255, 255, 255, 255),
                font_face=None,
                px=14,
                weight=None,
            )


# Layout component draw functions
@register("columns")
def _draw_columns(canvas: Canvas, node: GuiNode) -> None:
    """Draw a column layout."""
    bg_color = (35, 39, 44, 255)
    if node.style:
        gui_attrs = map_to_gui(node.style, cell_metrics=lambda: (8, 16), font_metrics=lambda profile: 16)
        if "bg" in gui_attrs and gui_attrs["bg"]:
            bg_color_spec = gui_attrs["bg"]
            if hasattr(bg_color_spec, "r"):
                bg_color = (
                    int(bg_color_spec.r),
                    int(bg_color_spec.g),
                    int(bg_color_spec.b),
                    int(255 * float(getattr(bg_color_spec, "a", 1.0))),
                )

    canvas.fill_rect(node.x, node.y, node.width, node.height, bg_color)


@register("column")
def _draw_column(canvas: Canvas, node: GuiNode) -> None:
    """Draw a column within a column layout."""
    # Columns are positioned by the layout engine, just draw background if needed
    pass


@register("grid")
def _draw_grid(canvas: Canvas, node: GuiNode) -> None:
    """Draw a grid layout."""
    bg_color = (40, 44, 49, 255)
    border_color = (70, 76, 85, 255)

    if node.style:
        gui_attrs = map_to_gui(node.style, cell_metrics=lambda: (8, 16), font_metrics=lambda profile: 16)
        if "bg" in gui_attrs and gui_attrs["bg"]:
            bg_color_spec = gui_attrs["bg"]
            if hasattr(bg_color_spec, "r"):
                bg_color = (
                    int(bg_color_spec.r),
                    int(bg_color_spec.g),
                    int(bg_color_spec.b),
                    int(255 * float(getattr(bg_color_spec, "a", 1.0))),
                )

    canvas.fill_rect(node.x, node.y, node.width, node.height, bg_color)
    canvas.stroke_rect(node.x, node.y, node.width, node.height, border_color, 1)


@register("grid_header_cell")
def _draw_grid_header_cell(canvas: Canvas, node: GuiNode) -> None:
    """Draw a grid header cell."""
    if node.text:
        # Header background
        canvas.fill_rect(node.x, node.y, node.width, node.height, (60, 64, 69, 255))
        # Header text
        canvas.draw_text(
            node.x + 5,
            node.y + node.height // 2 - 6,
            node.text,
            color=(255, 255, 255, 255),
            font_face=None,
            px=14,
            weight="bold",
        )


@register("grid_cell")
def _draw_grid_cell(canvas: Canvas, node: GuiNode) -> None:
    """Draw a grid cell."""
    if node.text:
        canvas.draw_text(
            node.x + 5,
            node.y + node.height // 2 - 6,
            node.text,
            color=(230, 232, 234, 255),
            font_face=None,
            px=14,
            weight=None,
        )


@register("tree")
def _draw_tree(canvas: Canvas, node: GuiNode) -> None:
    """Draw a tree structure."""
    bg_color = (30, 34, 39, 255)

    if node.style:
        gui_attrs = map_to_gui(node.style, cell_metrics=lambda: (8, 16), font_metrics=lambda profile: 16)
        if "bg" in gui_attrs and gui_attrs["bg"]:
            bg_color_spec = gui_attrs["bg"]
            if hasattr(bg_color_spec, "r"):
                bg_color = (
                    int(bg_color_spec.r),
                    int(bg_color_spec.g),
                    int(bg_color_spec.b),
                    int(255 * float(getattr(bg_color_spec, "a", 1.0))),
                )

    canvas.fill_rect(node.x, node.y, node.width, node.height, bg_color)


@register("tree_node")
def _draw_tree_node(canvas: Canvas, node: GuiNode) -> None:
    """Draw a tree node."""
    if node.text:
        # Simple tree node rendering
        canvas.draw_text(node.x + 10, node.y + 10, node.text, color=(230, 232, 234, 255), font_face=None, px=14, weight=None)


# Navigation component draw functions
@register("menu")
def _draw_menu(canvas: Canvas, node: GuiNode) -> None:
    """Draw a menu."""
    bg_color = (45, 49, 54, 255)
    border_color = (70, 76, 85, 255)

    if node.style:
        gui_attrs = map_to_gui(node.style, cell_metrics=lambda: (8, 16), font_metrics=lambda profile: 16)
        if "bg" in gui_attrs and gui_attrs["bg"]:
            bg_color_spec = gui_attrs["bg"]
            if hasattr(bg_color_spec, "r"):
                bg_color = (
                    int(bg_color_spec.r),
                    int(bg_color_spec.g),
                    int(bg_color_spec.b),
                    int(255 * float(getattr(bg_color_spec, "a", 1.0))),
                )

    canvas.fill_rect(node.x, node.y, node.width, node.height, bg_color)
    canvas.stroke_rect(node.x, node.y, node.width, node.height, border_color, 1)

    y_offset = node.y + 10
    for child in node.children:
        if child.component_name == "menu_title":
            canvas.draw_text(
                node.x + 10,
                y_offset,
                child.text or "",
                color=(255, 255, 255, 255),
                font_face=None,
                px=16,
                weight="bold",
            )
            y_offset += 30
        elif child.component_name == "menu_option":
            text_color = (150, 150, 150, 255)  # Default
            if "selected" in child.state:
                text_color = (255, 193, 7, 255)  # Gold for selected
            canvas.draw_text(node.x + 10, y_offset, child.text or "", color=text_color, font_face=None, px=14, weight=None)
            y_offset += 20


@register("horizontal_menu")
def _draw_horizontal_menu(canvas: Canvas, node: GuiNode) -> None:
    """Draw a horizontal menu."""
    x_offset = node.x
    for child in node.children:
        if child.component_name == "menu_option":
            text_color = (150, 150, 150, 255)  # Default
            if "selected" in child.state:
                text_color = (255, 193, 7, 255)  # Gold for selected
                # Draw selection background
                canvas.fill_rect(child.x, child.y, child.width, child.height, (60, 64, 69, 255))

            text = child.text or ""
            canvas.draw_text(x_offset, node.y + 10, text, color=text_color, font_face=None, px=14, weight=None)
            x_offset += len(text) * 8 + 20  # Approximate spacing


@register("breadcrumbs")
def _draw_breadcrumbs(canvas: Canvas, node: GuiNode) -> None:
    """Draw breadcrumbs."""
    x_offset = node.x
    for child in node.children:
        if child.component_name == "breadcrumb_segment":
            text_color = (150, 150, 150, 255)  # Default
            if "current" in child.state:
                text_color = (230, 232, 234, 255)  # White for current

            breadcrumb_text = child.text or ""
            canvas.draw_text(x_offset, node.y + 10, breadcrumb_text, color=text_color, font_face=None, px=14, weight=None)
            x_offset += len(breadcrumb_text) * 8 + 5
        elif child.component_name == "breadcrumb_separator":
            sep_text = child.text or ""
            canvas.draw_text(x_offset, node.y + 10, sep_text, color=(100, 100, 100, 255), font_face=None, px=14, weight=None)
            x_offset += len(sep_text) * 8 + 5


@register("tabs")
def _draw_tabs(canvas: Canvas, node: GuiNode) -> None:
    """Draw tabs."""
    tab_height = 30
    x_offset = node.x

    for child in node.children:
        if child.component_name == "tab":
            # Draw tab background
            bg_color = (50, 54, 59, 255)
            if "selected" in child.state:
                bg_color = (70, 74, 79, 255)

            canvas.fill_rect(x_offset, node.y, child.width, tab_height, bg_color)
            canvas.stroke_rect(x_offset, node.y, child.width, tab_height, (100, 106, 115, 255), 1)

            # Draw tab text
            text_color = (180, 182, 184, 255)
            if "selected" in child.state:
                text_color = (255, 255, 255, 255)

            canvas.draw_text(x_offset + 10, node.y + 8, child.text or "", color=text_color, font_face=None, px=14, weight=None)

            x_offset += child.width


@register("accordion")
def _draw_accordion(canvas: Canvas, node: GuiNode) -> None:
    """Draw an accordion."""
    y_offset = node.y
    for child in node.children:
        if child.component_name == "accordion_section":
            # Draw section header
            header_bg = (60, 64, 69, 255)
            if "expanded" in child.state:
                header_bg = (80, 84, 89, 255)

            canvas.fill_rect(node.x, y_offset, node.width, 30, header_bg)
            canvas.stroke_rect(node.x, y_offset, node.width, 30, (100, 106, 115, 255), 1)

            # Draw expand/collapse icon
            icon = "+" if "expanded" not in child.state else "-"
            canvas.draw_text(node.x + 10, y_offset + 8, icon, color=(255, 255, 255, 255), font_face=None, px=16, weight="bold")

            # Draw section title
            for subchild in child.children:
                if subchild.component_name == "accordion_title":
                    canvas.draw_text(
                        node.x + 30,
                        y_offset + 8,
                        subchild.text or "",
                        color=(255, 255, 255, 255),
                        font_face=None,
                        px=14,
                        weight=None,
                    )
                    break

            y_offset += 30

            # Draw content if expanded
            if "expanded" in child.state:
                content_bg = (40, 44, 49, 255)
                content_height = 0
                for subchild in child.children:
                    if subchild.component_name == "accordion_content":
                        lines = (subchild.text or "").split("\n")
                        content_height = len(lines) * 20 + 20
                        canvas.fill_rect(node.x, y_offset, node.width, content_height, content_bg)
                        canvas.stroke_rect(node.x, y_offset, node.width, content_height, (70, 76, 85, 255), 1)

                        for i, line in enumerate(lines):
                            canvas.draw_text(
                                node.x + 10,
                                y_offset + 10 + i * 20,
                                line,
                                color=(230, 232, 234, 255),
                                font_face=None,
                                px=14,
                                weight=None,
                            )
                        break
                y_offset += content_height


# Status component draw functions
@register("progress_bar")
def _draw_progress_bar(canvas: Canvas, node: GuiNode) -> None:
    """Draw a progress bar."""
    # Draw background
    canvas.fill_rect(node.x, node.y, node.width, 20, (40, 44, 49, 255))
    canvas.stroke_rect(node.x, node.y, node.width, 20, (70, 76, 85, 255), 1)

    # Draw fill
    fill_percentage = 0.0
    for child in node.children:
        if child.component_name == "progress_fill":
            try:
                fill_percentage = float((child.text or "0").rstrip("%")) / 100.0
            except (ValueError, AttributeError):
                pass
            break

    fill_width = int(node.width * fill_percentage)
    if fill_width > 0:
        canvas.fill_rect(node.x, node.y, fill_width, 20, (0, 123, 255, 255))

    # Draw label
    for child in node.children:
        if child.component_name == "progress_label" and child.text:
            canvas.draw_text(node.x + 5, node.y + 3, child.text, color=(255, 255, 255, 255), font_face=None, px=12, weight=None)
            break


@register("status_bar")
def _draw_status_bar(canvas: Canvas, node: GuiNode) -> None:
    """Draw a status bar."""
    bg_color = (35, 39, 44, 255)
    if node.style:
        gui_attrs = map_to_gui(node.style, cell_metrics=lambda: (8, 16), font_metrics=lambda profile: 16)
        if "bg" in gui_attrs and gui_attrs["bg"]:
            bg_color_spec = gui_attrs["bg"]
            if hasattr(bg_color_spec, "r"):
                bg_color = (
                    int(bg_color_spec.r),
                    int(bg_color_spec.g),
                    int(bg_color_spec.b),
                    int(255 * float(getattr(bg_color_spec, "a", 1.0))),
                )

    canvas.fill_rect(node.x, node.y, node.width, 25, bg_color)
    canvas.stroke_rect(node.x, node.y, node.width, 25, (70, 76, 85, 255), 1)

    x_offset = node.x + 10
    for child in node.children:
        if child.component_name == "status_item":
            for subchild in child.children:
                if subchild.component_name == "status_label":
                    text = subchild.text or ""
                    canvas.draw_text(x_offset, node.y + 5, text + ":", color=(150, 150, 150, 255), font_face=None, px=12, weight=None)
                    x_offset += len(text) * 7 + 10
                elif subchild.component_name == "status_value":
                    value_text = subchild.text or ""
                    canvas.draw_text(x_offset, node.y + 5, value_text, color=(230, 232, 234, 255), font_face=None, px=12, weight=None)
                    x_offset += len(value_text) * 7 + 20


@register("segmented_bar")
def _draw_segmented_bar(canvas: Canvas, node: GuiNode) -> None:
    """Draw a segmented bar."""
    x_offset = node.x
    for child in node.children:
        if child.component_name == "segment":
            # Draw segment background
            canvas.fill_rect(x_offset, node.y, child.width, 20, (50, 54, 59, 255))
            canvas.stroke_rect(x_offset, node.y, child.width, 20, (70, 76, 85, 255), 1)

            # Draw segment text
            canvas.draw_text(
                x_offset + 5,
                node.y + 3,
                child.text or "",
                color=(230, 232, 234, 255),
                font_face=None,
                px=12,
                weight=None,
            )
            x_offset += child.width + 5


@register("spinner")
def _draw_spinner(canvas: Canvas, node: GuiNode) -> None:
    """Draw a spinner."""
    for child in node.children:
        if child.component_name == "spinner_icon":
            canvas.draw_text(node.x, node.y, child.text or "", color=(0, 123, 255, 255), font_face=None, px=16, weight=None)
        elif child.component_name == "spinner_text":
            canvas.draw_text(node.x + 20, node.y, child.text or "", color=(230, 232, 234, 255), font_face=None, px=14, weight=None)


@register("meter")
def _draw_meter(canvas: Canvas, node: GuiNode) -> None:
    """Draw a meter."""
    # Draw background
    canvas.fill_rect(node.x, node.y, node.width, 15, (40, 44, 49, 255))
    canvas.stroke_rect(node.x, node.y, node.width, 15, (70, 76, 85, 255), 1)

    # Draw fill
    fill_percentage = 0.0
    for child in node.children:
        if child.component_name == "meter_fill":
            try:
                fill_percentage = float((child.text or "0").rstrip("%")) / 100.0
            except (ValueError, AttributeError):
                pass
            break

    fill_width = int(node.width * fill_percentage)
    if fill_width > 0:
        canvas.fill_rect(node.x, node.y, fill_width, 15, (34, 197, 94, 255))

    # Draw label
    for child in node.children:
        if child.component_name == "meter_label" and child.text:
            canvas.draw_text(node.x + 5, node.y + 2, child.text, color=(255, 255, 255, 255), font_face=None, px=11, weight=None)
            break


@register("compass")
def _draw_compass(canvas: Canvas, node: GuiNode) -> None:
    """Draw a compass."""
    # Draw compass circle
    center_x = node.x + node.width // 2
    center_y = node.y + node.height // 2
    radius = min(node.width, node.height) // 2 - 5

    canvas.fill_rect(center_x - radius, center_y - radius, radius * 2, radius * 2, (40, 44, 49, 255))
    canvas.stroke_rect(center_x - radius, center_y - radius, radius * 2, radius * 2, (70, 76, 85, 255), 2)

    # Draw heading text
    for child in node.children:
        if child.component_name == "compass_heading":
            canvas.draw_text(
                center_x - 20,
                center_y + radius + 15,
                child.text or "",
                color=(230, 232, 234, 255),
                font_face=None,
                px=12,
                weight=None,
            )
            break


@register("gauge_dial")
def _draw_gauge_dial(canvas: Canvas, node: GuiNode) -> None:
    """Draw a gauge dial."""
    # Draw gauge background
    center_x = node.x + node.width // 2
    center_y = node.y + node.height // 2
    radius = min(node.width, node.height) // 2 - 5

    canvas.fill_rect(center_x - radius, center_y - radius, radius * 2, radius * 2, (40, 44, 49, 255))
    canvas.stroke_rect(center_x - radius, center_y - radius, radius * 2, radius * 2, (70, 76, 85, 255), 2)

    # Draw needle based on percentage
    needle_percentage = 0.0
    for child in node.children:
        if child.component_name == "gauge_needle":
            try:
                needle_percentage = float((child.text or "0").rstrip("%")) / 100.0
            except (ValueError, AttributeError):
                pass
            break

    # Draw needle line
    angle = needle_percentage * 180 - 90  # -90 to +90 degrees
    import math

    needle_x = center_x + int(radius * 0.8 * math.cos(math.radians(angle)))
    needle_y = center_y + int(radius * 0.8 * math.sin(math.radians(angle)))

    canvas.draw_text(center_x - 2, center_y - 2, "•", color=(255, 0, 0, 255), font_face=None, px=20, weight=None)
    # Draw needle (simplified as a line)
    canvas.draw_text(needle_x - 1, needle_y - 1, "•", color=(255, 255, 255, 255), font_face=None, px=8, weight=None)

    # Draw label
    for child in node.children:
        if child.component_name == "gauge_label" and child.text:
            canvas.draw_text(
                center_x - len(child.text) * 3,
                center_y + radius + 15,
                child.text,
                color=(230, 232, 234, 255),
                font_face=None,
                px=12,
                weight=None,
            )
            break


@register("weather_indicator")
def _draw_weather_indicator(canvas: Canvas, node: GuiNode) -> None:
    """Draw a weather indicator."""
    x_offset = node.x
    for child in node.children:
        if child.component_name == "weather_condition":
            # Weather icon (simplified)
            icon = "☀"  # Default sun
            text = (child.text or "").lower()
            if "rain" in text:
                icon = "🌧"
            elif "cloud" in text:
                icon = "☁"
            elif "snow" in text:
                icon = "❄"
            elif "storm" in text:
                icon = "⛈"

            canvas.draw_text(x_offset, node.y, icon, color=(255, 193, 7, 255), font_face=None, px=20, weight=None)
            canvas.draw_text(
                x_offset + 25,
                node.y + 5,
                child.text or "",
                color=(230, 232, 234, 255),
                font_face=None,
                px=14,
                weight=None,
            )
            x_offset += 30 + len(child.text or "") * 7
        elif child.component_name == "weather_temperature":
            temp_text = child.text or ""
            canvas.draw_text(x_offset, node.y + 5, temp_text, color=(255, 255, 255, 255), font_face=None, px=14, weight="bold")
            x_offset += len(temp_text) * 7 + 10


@register("thermometer")
def _draw_thermometer(canvas: Canvas, node: GuiNode) -> None:
    """Draw a thermometer."""
    # Draw thermometer tube
    tube_width = 20
    tube_height = 100
    canvas.fill_rect(node.x + node.width // 2 - tube_width // 2, node.y, tube_width, tube_height, (70, 76, 85, 255))
    canvas.stroke_rect(node.x + node.width // 2 - tube_width // 2, node.y, tube_width, tube_height, (100, 106, 115, 255), 2)

    # Draw mercury
    fill_percentage = 0.0
    for child in node.children:
        if child.component_name == "thermometer_fill":
            try:
                fill_percentage = float((child.text or "0").rstrip("%")) / 100.0
            except (ValueError, AttributeError):
                pass
            break

    mercury_height = int(tube_height * fill_percentage)
    if mercury_height > 0:
        canvas.fill_rect(
            node.x + node.width // 2 - tube_width // 2 + 2,
            node.y + tube_height - mercury_height,
            tube_width - 4,
            mercury_height,
            (220, 53, 69, 255),
        )

    # Draw bulb at bottom
    bulb_radius = 12
    bulb_center_y = node.y + tube_height + bulb_radius - 2
    canvas.fill_rect(
        node.x + node.width // 2 - bulb_radius,
        bulb_center_y - bulb_radius,
        bulb_radius * 2,
        bulb_radius * 2,
        (70, 76, 85, 255),
    )
    if fill_percentage > 0:
        canvas.fill_rect(
            node.x + node.width // 2 - bulb_radius + 2,
            bulb_center_y - bulb_radius + 2,
            (bulb_radius - 1) * 2,
            (bulb_radius - 1) * 2,
            (220, 53, 69, 255),
        )

    # Draw label
    for child in node.children:
        if child.component_name == "thermometer_label" and child.text:
            canvas.draw_text(
                node.x + node.width // 2 - len(child.text) * 3,
                node.y - 20,
                child.text,
                color=(230, 232, 234, 255),
                font_face=None,
                px=12,
                weight=None,
            )
            break


# Visual component draw functions
@register("graph_canvas")
def _draw_graph_canvas(canvas: Canvas, node: GuiNode) -> None:
    """Draw a graph canvas."""
    # Draw graph background
    canvas.fill_rect(node.x, node.y, node.width, node.height, (30, 34, 39, 255))
    canvas.stroke_rect(node.x, node.y, node.width, node.height, (70, 76, 85, 255), 1)

    # Draw axes (simplified)
    canvas.draw_text(node.x + 5, node.y + node.height - 5, "0", color=(150, 150, 150, 255), font_face=None, px=10, weight=None)

    # Draw points
    for child in node.children:
        if child.component_name == "graph_point":
            # Scale normalized coordinates to actual size
            x_pos = node.x + int((child.x / 100.0) * node.width)
            y_pos = node.y + int((child.y / 100.0) * node.height)
            canvas.draw_text(x_pos, y_pos, "•", color=(0, 123, 255, 255), font_face=None, px=8, weight=None)


@register("waveform")
def _draw_waveform(canvas: Canvas, node: GuiNode) -> None:
    """Draw a waveform."""
    # Draw waveform background
    canvas.fill_rect(node.x, node.y, node.width, node.height, (25, 29, 34, 255))
    canvas.stroke_rect(node.x, node.y, node.width, node.height, (70, 76, 85, 255), 1)

    # Draw center line
    center_y = node.y + node.height // 2
    canvas.draw_text(node.x, center_y, "─" * node.width, color=(100, 106, 115, 255), font_face=None, px=10, weight=None)

    # Position and draw waveform children
    for child in node.children:
        if child.component_name == "waveform_point":
            # Position child relative to waveform bounds
            # Assume child has normalized coordinates (0-100 range)
            if hasattr(child, "x") and hasattr(child, "y"):
                x_pos = node.x + int((child.x / 100.0) * node.width)
                y_pos = node.y + int((child.y / 100.0) * node.height)
            else:
                # Default positioning if no coordinates
                x_pos = node.x + node.width // 2
                y_pos = node.y + node.height // 2

            # Update child position for rendering
            child.x = x_pos
            child.y = y_pos

            # Draw point
            canvas.draw_text(x_pos, y_pos, "•", color=(34, 197, 94, 255), font_face=None, px=6, weight=None)


@register("spectrogram")
def _draw_spectrogram(canvas: Canvas, node: GuiNode) -> None:
    """Draw a spectrogram."""
    # Draw spectrogram background
    canvas.fill_rect(node.x, node.y, node.width, node.height, (20, 24, 29, 255))
    canvas.stroke_rect(node.x, node.y, node.width, node.height, (70, 76, 85, 255), 1)

    # Draw cells
    for child in node.children:
        if child.component_name == "spectrogram_cell":
            x_pos = node.x + child.x * 8  # Approximate cell width
            y_pos = node.y + child.y * 12  # Approximate cell height
            intensity = 1.0 if child.text == "█" else 0.3
            color = (int(255 * intensity), int(100 * intensity), int(150 * intensity), 255)
            canvas.draw_text(x_pos, y_pos, child.text or "", color=color, font_face=None, px=12, weight=None)


@register("image_block")
def _draw_image_block(canvas: Canvas, node: GuiNode) -> None:
    """Draw an image block."""
    # Draw placeholder background
    canvas.fill_rect(node.x, node.y, node.width, node.height, (40, 44, 49, 255))
    canvas.stroke_rect(node.x, node.y, node.width, node.height, (100, 106, 115, 255), 2)

    # Draw placeholder text
    for child in node.children:
        if child.component_name == "image_placeholder":
            canvas.draw_text(
                node.x + 10,
                node.y + node.height // 2 - 10,
                child.text or "",
                color=(150, 150, 150, 255),
                font_face=None,
                px=14,
                weight=None,
            )
            break


@register("grid_map")
def _draw_grid_map(canvas: Canvas, node: GuiNode) -> None:
    """Draw a grid map."""
    # Draw grid background
    canvas.fill_rect(node.x, node.y, node.width, node.height, (30, 34, 39, 255))

    # Draw grid cells
    cell_size = 12  # Approximate cell size
    for child in node.children:
        if child.component_name == "grid_cell":
            x_pos = node.x + child.x * cell_size
            y_pos = node.y + child.y * cell_size

            # Different colors for different cell types
            if child.text == "#":
                color = (34, 197, 94, 255)  # Green for walls
            elif child.text == ".":
                color = (150, 150, 150, 255)  # Gray for floors
            elif child.text == "@":
                color = (255, 193, 7, 255)  # Gold for player
            else:
                color = (100, 100, 100, 255)  # Default

            canvas.fill_rect(x_pos, y_pos, cell_size - 1, cell_size - 1, color)


@register("mini_map")
def _draw_mini_map(canvas: Canvas, node: GuiNode) -> None:
    """Draw a mini map."""
    # Draw map background
    canvas.fill_rect(node.x, node.y, node.width, node.height, (25, 29, 34, 255))
    canvas.stroke_rect(node.x, node.y, node.width, node.height, (70, 76, 85, 255), 1)

    # Draw map cells
    cell_size = 8  # Smaller cells for mini map
    for child in node.children:
        if child.component_name == "map_cell":
            x_pos = node.x + child.x * cell_size
            y_pos = node.y + child.y * cell_size

            # Color based on cell content
            if child.text in ["#", "█"]:
                color = (34, 197, 94, 255)  # Green for walls
            elif child.text in [".", " "]:
                color = (50, 54, 59, 255)  # Dark for empty
            elif child.text == "@":
                color = (255, 193, 7, 255)  # Gold for player
            else:
                color = (100, 100, 100, 255)  # Default

            canvas.fill_rect(x_pos, y_pos, cell_size - 1, cell_size - 1, color)
