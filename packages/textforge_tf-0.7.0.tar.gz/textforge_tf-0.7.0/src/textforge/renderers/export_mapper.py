from __future__ import annotations

from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from ..style.tfs.tfs_cascade import ResolvedStyle


def to_html_attrs(resolved: ResolvedStyle) -> dict[str, str]:
    attrs: dict[str, str] = {}
    if resolved.color:
        attrs["color"] = str(resolved.color)
    if resolved.background:
        attrs["background-color"] = str(resolved.background)
    if resolved.border is not None:
        w = int(resolved.border.width)
        attrs["border-width"] = f"{w}px"
        attrs["border-style"] = resolved.border.style or "solid"
    if resolved.border_color:
        attrs["border-color"] = str(resolved.border_color)
    if resolved.padding is not None:
        t, r, b, left = (
            int(resolved.padding.top.value),
            int(resolved.padding.right.value),
            int(resolved.padding.bottom.value),
            int(resolved.padding.left.value),
        )
        attrs["padding"] = f"{t}px {r}px {b}px {left}px"
    return attrs
