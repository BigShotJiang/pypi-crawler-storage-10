"""Public rendering interfaces for the Textforge rendering subsystem.

This module provides the main public API functions for rendering components
and updating render state, as specified in SUBSYSTEM_ARCHITECTURE.md.
"""

from __future__ import annotations

from typing import TYPE_CHECKING

from ..core.layout.types import Bounds, RendererType
from ..utils.logging import get_logger
from .base import Renderer, RenderingError, RenderOutput

if TYPE_CHECKING:
    from ..components.base import RenderableComponent
    from ..core.layout.engine import LayoutResult
    from ..core.vdom import Patch, VDOMTree

logger = get_logger(__name__)


def render_component(component: RenderableComponent, renderer_type: RendererType, layout: LayoutResult | None = None) -> RenderOutput:
    """Render a component with specified renderer.

    This function provides the main public interface for rendering components
    to different output formats (CLI, GUI, export formats). It handles the
    complete rendering pipeline including layout calculation, VDOM tree
    creation, and final output generation.

    Args:
        component: The renderable component to render.
        renderer_type: The target renderer type (CLI, GUI, etc.).
        layout: Optional pre-calculated layout result. If None, layout will
            be calculated automatically.

    Returns:
        RenderOutput containing the rendered content and metadata.

    Raises:
        RenderingError: If rendering fails due to invalid component state,
            unsupported renderer type, or rendering pipeline errors.
        UnsupportedRendererError: If the specified renderer type is not
            supported for the component.

    Example:
        >>> from textforge.components import Text
        >>> from textforge.core.layout.types import RendererType
        >>> component = Text("Hello World")
        >>> output = render_component(component, RendererType.CLI)
        >>> print(output.content)
        Hello World
    """
    try:
        logger.debug(f"Rendering component '{component.component_name}' with {renderer_type}")

        # Import here to avoid circular imports
        from ..core.layout.engine import LayoutEngine
        from ..core.vdom.tree import VDOMTree

        # Convert component to renderable if needed
        if not hasattr(component, 'get_layout_style'):
            # This is a regular Component, convert to renderable
            renderable_component = component.to_renderable()
        else:
            # This is already a renderable component
            renderable_component = component

        # Calculate layout if not provided
        if layout is None:
            layout_engine = LayoutEngine()
            # Use default bounds - in practice this would be determined by context
            container_bounds = Bounds(x=0, y=0, width=80, height=24)
            layout = layout_engine.calculate_layout(renderable_component, container_bounds, renderer_type)
            logger.debug(f"Calculated layout: {layout.width}x{layout.height}")

        # Create VDOM tree
        vdom_tree = VDOMTree(renderer_type=renderer_type)
        key = vdom_tree.add_component(renderable_component)
        # Set the first component as the root
        if vdom_tree.root is None and key in vdom_tree._key_map:
            vdom_tree.root = vdom_tree._key_map[key]
        logger.debug(f"Created VDOM tree with root component key: {key}")

        # Get appropriate renderer
        renderer = _get_renderer(renderer_type)

        # Render the tree
        output = renderer.render_tree(vdom_tree, layout)
        logger.debug(f"Successfully rendered component to {len(output.content)} chars")

        return output

    except Exception as e:
        logger.error(f"Failed to render component: {e}")
        raise RenderingError(f"Component rendering failed: {e}") from e


def update_rendering(tree: VDOMTree, patches: list[Patch], renderer_type: RendererType) -> RenderOutput:
    """Update rendering with patches.

    This function applies VDOM patches to an existing render tree and returns
    the updated output. It's optimized for incremental updates and real-time
    rendering scenarios.

    Args:
        tree: The VDOM tree to update.
        patches: List of patches to apply to the tree.
        renderer_type: The target renderer type.

    Returns:
        RenderOutput containing the updated rendered content and metadata.

    Raises:
        RenderingError: If patch application or rendering fails.
        InvalidVDOMOperationError: If patches are invalid for the tree state.

    Example:
        >>> # After initial render
        >>> tree = VDOMTree(renderer_type=RendererType.CLI)
        >>> key = tree.add_component(Text("Hello"))
        >>> patches = tree.update_component(key, Text("Hello World"))
        >>> output = update_rendering(tree, patches, RendererType.CLI)
        >>> print(output.content)
        Hello World
    """
    try:
        logger.debug(f"Updating rendering with {len(patches)} patches for {renderer_type}")

        # Get appropriate renderer
        renderer = _get_renderer(renderer_type)

        # Apply patches to the tree
        for patch in patches:
            logger.log(5, f"Applying patch: {patch.patch_type} on {patch.key}")

        # Apply patches to renderer state
        renderer.apply_patches(patches)

        # Get current output (renderer maintains its own state)
        output = renderer.get_current_output()
        if output is None:
            # Fallback: re-render if no cached output available
            output = _get_current_renderer_output(renderer, tree)
        logger.debug(f"Successfully updated rendering to {len(output.content)} chars")

        return output

    except Exception as e:
        logger.error(f"Failed to update rendering: {e}")
        raise RenderingError(f"Rendering update failed: {e}") from e


def _get_renderer(renderer_type: RendererType) -> Renderer:
    """Get the appropriate renderer instance for the given type.

    Args:
        renderer_type: The renderer type to get.

    Returns:
        Renderer instance.

    Raises:
        UnsupportedRendererError: If renderer type is not supported.
    """
    from .base import UnsupportedRendererError

    try:
        if renderer_type == RendererType.CLI:
            from .base import CLIRenderer
            return CLIRenderer()
        elif renderer_type == RendererType.TTY:
            # TTY is a specialized CLI renderer with ANSI support
            from .cli.ansi import ANSIRenderer
            return ANSIRenderer()
        elif renderer_type == RendererType.GUI:
            # GUI renderer - use window-based renderer
            from .gui.window import WindowRenderer
            return WindowRenderer()
        elif renderer_type == RendererType.SVG:
            from .export import SVGRenderer
            return SVGRenderer()
        elif renderer_type == RendererType.HTML:
            from .export import HTMLRenderer
            return HTMLRenderer()
        elif renderer_type == RendererType.PDF:
            from .export import PDFRenderer
            return PDFRenderer()
        else:
            raise UnsupportedRendererError(f"Unknown renderer type: {renderer_type}")
    except ImportError as e:
        raise UnsupportedRendererError(f"Renderer implementation not available: {e}") from e


def _get_current_renderer_output(renderer: Renderer, tree: VDOMTree) -> RenderOutput:
    """Get the current output from a renderer.

    This is a placeholder implementation. In practice, each renderer would
    maintain its own output state and provide a method to retrieve it.

    Args:
        renderer: The renderer instance.
        tree: The current VDOM tree.

    Returns:
        Current render output.
    """
    # Placeholder - in real implementation, renderer would track its output
    # For now, re-render the tree
    from ..core.layout.engine import LayoutEngine
    from ..core.layout.types import Bounds

    layout_engine = LayoutEngine()
    container_bounds = Bounds(x=0, y=0, width=80, height=24)
    layout = layout_engine.calculate_layout(tree.get_component(tree._key_map[next(iter(tree._key_map))].key), container_bounds, tree.renderer_type)

    return renderer.render_tree(tree, layout)
