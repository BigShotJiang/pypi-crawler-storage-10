from .cli import main

try:
    from .utils.io import ensure_windows_valid_stdin

    ensure_windows_valid_stdin()
except Exception:
    pass

if __name__ == "__main__":
    # Same programmatic fallback for `python -m textforge`
    import sys as _sys

    try:
        raise SystemExit(main(_sys.argv[1:]))
    except SystemExit:
        raise
    except Exception as _exc:
        print(f"Error: {_exc}")
        raise SystemExit(1) from _exc
