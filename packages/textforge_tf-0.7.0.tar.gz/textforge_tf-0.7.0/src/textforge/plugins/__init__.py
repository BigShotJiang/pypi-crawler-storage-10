"""Plugin system for Textforge extensibility.

This module provides interfaces and base classes for extending Textforge
functionality through plugins, including custom components, renderers,
styles, and event handlers.
"""

from __future__ import annotations

from .interfaces import (
    ComponentPlugin,
    EventPlugin,
    ExportPlugin,
    LayoutPlugin,
    Plugin,
    RendererPlugin,
    StylePlugin,
)
from .manager import (
    PluginManager,
    discover_plugins,
    get_plugin_manager,
    load_plugin,
    unload_plugin,
)
from .registry import PluginRegistry

__all__ = [
    "Plugin",
    "ComponentPlugin",
    "RendererPlugin",
    "StylePlugin",
    "EventPlugin",
    "LayoutPlugin",
    "ExportPlugin",
    "PluginManager",
    "PluginRegistry",
    "get_plugin_manager",
    "load_plugin",
    "unload_plugin",
    "discover_plugins",
]
