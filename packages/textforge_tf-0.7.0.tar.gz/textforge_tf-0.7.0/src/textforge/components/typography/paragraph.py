"""Paragraph typography component."""

from __future__ import annotations

from typing import TYPE_CHECKING

from ...core.console import Console, Measure
from ...utils.logging import get_logger
from ..base import RenderableComponent, TypographyBase

if TYPE_CHECKING:
    from ...style.subsystem import StylingContext

logger = get_logger(__name__)


class Paragraph(TypographyBase):
    """A paragraph component for body text content.

    Provides semantic structure for paragraphs with appropriate text
    wrapping, justification, and styling.
    """

    def __init__(self, text: str, **kwargs: object) -> None:
        """Initialize the paragraph component.

        Args:
            text: The paragraph text content.
            **kwargs: Additional keyword arguments passed to parent.
        """
        super().__init__(**kwargs)
        self._text = text

    @property
    def component_name(self) -> str:
        """Return the component name for styling purposes."""
        return "paragraph"

    def to_renderable(self, styling_context: StylingContext | None = None) -> ParagraphRenderable:
        """Convert this paragraph to a renderable component.

        Args:
            styling_context: Optional styling context for this component.

        Returns:
            A ParagraphRenderable instance.
        """
        from ...style.subsystem import StylingContext

        context = styling_context or StylingContext(component_name=self.component_name)
        return ParagraphRenderable(
            component_name=self.component_name,
            text=self._text,
            styling_context=context,
        )


class ParagraphRenderable(RenderableComponent):
    """Renderable version of paragraph components."""

    def __init__(
        self,
        component_name: str,
        text: str,
        styling_context: StylingContext,
    ) -> None:
        """Initialize the renderable paragraph component.

        Args:
            component_name: The name of the component.
            text: The paragraph text content.
            styling_context: The styling context for this component.
        """
        super().__init__(component_name, styling_context)
        self.text = text

    def render(self, console: Console) -> str | list[str] | None:
        """Render the paragraph component.

        Args:
            console: The console to render to.

        Returns:
            The rendered paragraph as a list of strings.
        """
        logger.log(5, f"Rendering paragraph: {self.component_name}")  # Use level 5 for TRACE

        # Get resolved style for styling
        _ = self.get_resolved_style(console)

        # Wrap text to fit within typical width (80 chars)
        wrapped_lines = self._wrap_text(self.text, 80)
        return wrapped_lines

    def measure(self, console: Console) -> Measure:
        """Measure the paragraph with text wrapping.

        Args:
            console: The console context for measurement.

        Returns:
            Measure object with width and height for the paragraph.
        """
        logger.log(5, f"Measuring paragraph: {self.component_name}")  # Use level 5 for TRACE

        # Wrap text and count lines
        wrapped_lines = self._wrap_text(self.text, 80)
        width = max(len(line) for line in wrapped_lines) if wrapped_lines else 0
        height = len(wrapped_lines)

        return Measure(width, height)

    def _wrap_text(self, text: str, max_width: int) -> list[str]:
        """Wrap text to fit within the specified width.

        Args:
            text: The text to wrap.
            max_width: Maximum width in characters.

        Returns:
            List of wrapped text lines.
        """
        if max_width <= 0:
            return [text]

        lines: list[str] = []
        for paragraph in text.split("\n"):
            if not paragraph:
                lines.append("")
                continue

            words = paragraph.split()
            current_line = ""

            for word in words:
                # Check if adding this word would exceed the width
                if current_line and len(current_line) + len(word) + 1 > max_width:
                    lines.append(current_line)
                    current_line = word
                elif current_line:
                    current_line += " " + word
                else:
                    current_line = word

            if current_line:
                lines.append(current_line)

        return lines


__all__ = ["Paragraph", "ParagraphRenderable"]
