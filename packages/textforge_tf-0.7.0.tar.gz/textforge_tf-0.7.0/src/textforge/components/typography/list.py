"""List typography component."""

from __future__ import annotations

from typing import TYPE_CHECKING

from ...core.console import Console, Measure
from ...utils.logging import get_logger
from ..base import RenderableComponent, TypographyBase

if TYPE_CHECKING:
    from ...style.subsystem import StylingContext

logger = get_logger(__name__)


class List(TypographyBase):
    """A list component for displaying ordered or unordered lists.

    Provides semantic structure for lists with appropriate bullet points,
    numbering, and indentation.
    """

    def __init__(self, items: list[str], ordered: bool = False, **kwargs: object) -> None:
        """Initialize the list component.

        Args:
            items: List of text items to display.
            ordered: Whether this is an ordered (numbered) list, defaults to False.
            **kwargs: Additional keyword arguments passed to parent.
        """
        super().__init__(**kwargs)
        self._items = items
        self._ordered = ordered

    @property
    def items(self) -> list[str]:
        """Get the list items."""
        return self._items.copy()

    @items.setter
    def items(self, value: list[str]) -> None:
        """Set the list items.

        Args:
            value: The new list items.
        """
        self._items = value

    @property
    def ordered(self) -> bool:
        """Get whether this is an ordered list."""
        return self._ordered

    @ordered.setter
    def ordered(self, value: bool) -> None:
        """Set whether this is an ordered list.

        Args:
            value: True for ordered, False for unordered.
        """
        self._ordered = value

    @property
    def component_name(self) -> str:
        """Return the component name for styling purposes."""
        return "list"

    def to_renderable(self, styling_context: StylingContext | None = None) -> ListRenderable:
        """Convert this list to a renderable component.

        Args:
            styling_context: Optional styling context for this component.

        Returns:
            A ListRenderable instance.
        """
        from ...style.subsystem import StylingContext

        context = styling_context or StylingContext(component_name=self.component_name)
        return ListRenderable(
            component_name=self.component_name,
            items=self._items,
            ordered=self._ordered,
            styling_context=context,
        )


class ListRenderable(RenderableComponent):
    """Renderable version of list components."""

    def __init__(
        self,
        component_name: str,
        items: list[str],
        ordered: bool,
        styling_context: StylingContext,
    ) -> None:
        """Initialize the renderable list component.

        Args:
            component_name: The name of the component type.
            items: The original list items.
            ordered: Whether this is an ordered list.
            styling_context: The styling context for this component.
        """
        super().__init__(component_name, styling_context)
        self.items = items
        self.ordered = ordered

    def render(self, console: Console) -> str | list[str] | None:
        """Render the list component.

        Args:
            console: The console to render to.

        Returns:
            The rendered list as a list of strings.
        """
        logger.log(5, f"Rendering list: {self.component_name}")  # Use level 5 for TRACE

        # Get resolved style for styling
        _ = self.get_resolved_style(console)

        if not self.items:
            return []

        formatted_lines: list[str] = []
        for i, item in enumerate(self.items, 1):
            if self.ordered:
                prefix = f"{i}. "
            else:
                prefix = "• "
            formatted_lines.append(f"{prefix}{item}")

        return formatted_lines

    def measure(self, console: Console) -> Measure:
        """Measure the list component.

        Args:
            console: The console context for measurement.

        Returns:
            Measure object with width and height for the list.
        """
        logger.log(5, f"Measuring list: {self.component_name}")  # Use level 5 for TRACE

        if not self.items:
            return Measure(0, 0)

        # Account for bullet/number prefix in width calculation
        prefix_width = 3  # "• " or "1. " width

        # Measure each item
        max_item_width = 0
        total_height = len(self.items)

        for item in self.items:
            item_width = len(item) + prefix_width
            max_item_width = max(max_item_width, item_width)

        return Measure(max_item_width, total_height)


__all__ = ["List", "ListRenderable"]
