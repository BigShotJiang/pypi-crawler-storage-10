"""Backward-compatible import for typography base classes."""

from __future__ import annotations

from ..base import TypographyBase

__all__ = ["TypographyBase"]