"""Title typography component."""

from __future__ import annotations

from typing import TYPE_CHECKING

from ...core.console import Console, Measure
from ...utils.logging import get_logger
from ..base import RenderableComponent, TypographyBase

if TYPE_CHECKING:
    from ...renderers.gui.types import GuiNode
    from ...style.subsystem import StylingContext

logger = get_logger(__name__)


class Title(TypographyBase):
    """A title component for headings and section titles.

    Provides semantic structure for titles with appropriate styling
    and accessibility features.
    """

    def __init__(self, text: str, level: int = 1, **kwargs: object) -> None:
        """Initialize the title component.

        Args:
            text: The title text content.
            level: The heading level (1-6), defaults to 1.
            **kwargs: Additional keyword arguments passed to parent.
        """
        super().__init__(**kwargs)
        if not 1 <= level <= 6:
            raise ValueError("Title level must be between 1 and 6")
        self._text = text
        self._level = level

    @property
    def level(self) -> int:
        """Get the heading level."""
        return self._level

    @level.setter
    def level(self, value: int) -> None:
        """Set the heading level.

        Args:
            value: The new heading level (1-6).

        Raises:
            ValueError: If level is not between 1 and 6.
        """
        if not 1 <= value <= 6:
            raise ValueError("Title level must be between 1 and 6")
        self._level = value

    @property
    def component_name(self) -> str:
        """Return the component name for styling purposes."""
        return f"title{self._level}"

    def to_renderable(self, styling_context: StylingContext | None = None) -> TitleRenderable:
        """Convert this title to a renderable component.

        Args:
            styling_context: Optional styling context for this component.

        Returns:
            A TitleRenderable instance.
        """
        from ...style.subsystem import StylingContext

        context = styling_context or StylingContext(component_name=self.component_name)
        return TitleRenderable(
            component_name=self.component_name,
            text=self._text,
            level=self._level,
            styling_context=context,
        )


class TitleRenderable(RenderableComponent):
    """Renderable version of title components."""

    def __init__(
        self,
        component_name: str,
        text: str,
        level: int,
        styling_context: StylingContext,
    ) -> None:
        """Initialize the renderable title component.

        Args:
            component_name: The name of the component type.
            text: The title text content.
            level: The heading level.
            styling_context: The styling context for this component.
        """
        super().__init__(component_name, styling_context)
        self.text = text
        self.level = level

    def render(self, console: Console) -> str | list[str] | None:
        """Render the title component.

        Args:
            console: The console to render to.

        Returns:
            The rendered title as a string.
        """
        logger.log(5, f"Rendering title: {self.component_name}")  # Use level 5 for TRACE

        # Get resolved style for styling
        _ = self.get_resolved_style(console)

        # Format title text based on level
        formatted_text = self._format_title_text(self.text, self.level)
        return formatted_text

    def measure(self, console: Console) -> Measure:
        """Measure the title component's preferred size.

        Args:
            console: The console context for measurement.

        Returns:
            Measure object with width and height for the title.
        """
        logger.log(5, f"Measuring title: {self.component_name}")  # Use level 5 for TRACE

        formatted_text = self._format_title_text(self.text, self.level)
        width = len(formatted_text)
        height = 1
        return Measure(width, height)

    def _format_title_text(self, text: str, level: int) -> str:
        """Format title text based on heading level.

        Args:
            text: The raw title text.
            level: The heading level.

        Returns:
            Formatted title text.
        """
        # Basic formatting - could be enhanced with styling
        if level == 1:
            return text.upper()
        elif level == 2:
            return text.title()
        else:
            return text

    def to_node(self, console: Console) -> GuiNode:
        """Convert the title component into a GUI node.

        Args:
            console: Console context used for style resolution.

        Returns:
            GuiNode: Node populated with formatted title text for GUI rendering.
        """

        node = super().to_node(console)
        node.text = self._format_title_text(self.text, self.level)
        node.state[f"level_{self.level}"] = True
        return node


__all__ = ["Title", "TitleRenderable"]
