"""Feedback components (badges, ratings, notifications)."""

from __future__ import annotations

import time
from dataclasses import dataclass, field
from typing import TYPE_CHECKING, Literal

from ..core.text.symbols import Symbols
from ..renderers.base import RenderableBase
from ..renderers.gui.types import GuiNode
from ..style.colors import Color

if TYPE_CHECKING:
    from collections.abc import Iterable

__all__ = [
    "Badge",
    "Rating",
    "Toast",
    "ToastManager",
    "ConsolePanel",
    "Snackbar",
    "AlertBanner",
    "badge",
    "rating",
    "toast",
    "toast_manager",
    "console_panel",
    "snackbar",
    "alert_banner",
]


class Badge:
    """Create inline badges and tags."""

    BRACKETS: dict[str, tuple[str, str]] = {
        "square": ("[", "]"),
        "round": ("(", ")"),
        "angle": ("<", ">"),
    }

    @staticmethod
    def render(
        text: str,
        *,
        style: Literal["square", "round", "angle"] = "square",
        color: str = "cyan",
        bg_color: str | None = None,
    ) -> str:
        left, right = Badge.BRACKETS.get(style, Badge.BRACKETS["square"])
        text_color = Color.get_color(color)
        result = f"{text_color}{left}{text}{right}{Color.RESET}"
        if bg_color:
            bg = Color.BG_COLORS.get(f"bg_{bg_color}", "")
            result = bg + result + Color.RESET
        return result


class Rating:
    """Build rating displays using ASCII glyphs."""

    SYMBOLS: dict[str, dict[str, str]] = {
        "stars": {"filled": "*", "empty": "-"},
        "hearts": {"filled": "<3", "empty": "< >"},
        "circles": {"filled": "o", "empty": "()"},
        "squares": {"filled": "[]", "empty": "[]"},
    }

    @staticmethod
    def render(
        rating: float,
        max_rating: int = 5,
        *,
        style: Literal["stars", "hearts", "circles", "squares"] = "stars",
        color: str = "gold",
        show_value: bool = True,
        allow_half: bool = True,
    ) -> str:
        rating = max(0.0, min(float(rating), float(max_rating)))
        syms = Rating.SYMBOLS.get(style, Rating.SYMBOLS["stars"])
        filled_units = int(rating)
        half_unit = allow_half and (rating - filled_units) >= 0.5
        empty_units = max_rating - filled_units - (1 if half_unit else 0)

        glyphs: list[str] = []
        glyphs.extend(syms["filled"] for _ in range(filled_units))
        if half_unit:
            glyphs.append(":")  # half indicator
        glyphs.extend(syms["empty"] for _ in range(max(0, empty_units)))

        rating_color = Color.get_color(color)
        text = rating_color + " ".join(glyphs) + Color.RESET
        if show_value:
            text += f" {rating:.1f}/{max_rating}"
        return text


def badge(
    text: str,
    *,
    style: Literal["square", "round", "angle"] = "square",
    color: str = "cyan",
    bg_color: str | None = None,
) -> _BadgeRenderable:
    """Return a renderable badge."""
    return _BadgeRenderable(text=text, style=style, color=color, bg_color=bg_color)


def rating(
    rating: float,
    max_rating: int = 5,
    style: Literal["stars", "hearts", "circles", "squares"] = "stars",
    color: str = "yellow",
    show_value: bool = False,
) -> _RatingRenderable:
    """Return a renderable rating."""
    return _RatingRenderable(
        rating=rating,
        max_rating=max_rating,
        style=style,
        color=color,
        show_value=show_value,
    )


@dataclass
class ToastMessage:
    """Internal representation of a toast within the manager."""

    text: str
    tone: Literal["info", "success", "warning", "error"]
    width: int
    border_style: str
    ascii_mode: bool | None = None
    created_at: float = field(default_factory=time.monotonic)
    duration: float | None = None

    def expired(self, now: float) -> bool:
        return self.duration is not None and now - self.created_at >= self.duration


class Toast:
    """Transient toast/growl notification."""

    ICONS = {"info": "[i]", "success": "[+]", "warning": "[!]", "error": "[x]"}
    COLORS = {"info": "info", "success": "success", "warning": "warning", "error": "error"}

    @staticmethod
    def render(
        message: str,
        *,
        tone: Literal["info", "success", "warning", "error"] = "info",
        width: int = 60,
        border_style: str = "rounded",
        blank_lines_before: int = 0,
        blank_lines_after: int = 0,
        ascii_mode: bool | None = None,
    ) -> str:
        return Toast._render_box(
            message=message,
            tone=tone,
            width=width,
            border_style=border_style,
            blank_lines_before=blank_lines_before,
            blank_lines_after=blank_lines_after,
            ascii_mode=ascii_mode,
        )

    @staticmethod
    def _render_box(
        message: str,
        tone: Literal["info", "success", "warning", "error"],
        width: int,
        border_style: str,
        blank_lines_before: int = 0,
        blank_lines_after: int = 0,
        ascii_mode: bool | None = None,
    ) -> str:
        symbols = Symbols.get_symbols(border_style, ascii_mode)
        col = Color.get_color(Toast.COLORS.get(tone, "info"))
        icon = Toast.ICONS.get(tone, "[i]")
        inner_width = max(10, width - 2)
        text = f" {icon} {message} "
        content = text[:inner_width] if len(text) > inner_width else text
        padding = max(0, inner_width - len(content))
        lines: list[str] = []
        for _ in range(blank_lines_before):
            lines.append("")
        lines.append(symbols["top_left"] + symbols["horizontal"] * inner_width + symbols["top_right"])
        lines.append(symbols["vertical"] + col + content + Color.RESET + " " * padding + symbols["vertical"])
        lines.append(symbols["bottom_left"] + symbols["horizontal"] * inner_width + symbols["bottom_right"])
        for _ in range(blank_lines_after):
            lines.append("")
        return "\n".join(lines)


class ToastManager:
    """Small helper to manage stacked toast/growl notifications."""

    def __init__(self) -> None:
        self._messages: list[ToastMessage] = []

    def push(
        self,
        message: str,
        *,
        tone: Literal["info", "success", "warning", "error"] = "info",
        width: int = 60,
        border_style: str = "rounded",
        duration: float | None = 4.0,
        ascii_mode: bool | None = None,
    ) -> None:
        self._messages.append(
            ToastMessage(
                text=message,
                tone=tone,
                width=width,
                border_style=border_style,
                ascii_mode=ascii_mode,
                duration=duration,
            )
        )
        self.cleanup()

    def cleanup(self) -> None:
        """Remove expired notifications."""
        now = time.monotonic()
        self._messages = [msg for msg in self._messages if not msg.expired(now)]

    def render(self) -> None:
        """Render all active toasts stacked vertically."""
        self.cleanup()
        for idx, message in enumerate(self._messages):
            print(
                Toast._render_box(
                    message=message.text,
                    tone=message.tone,
                    width=message.width,
                    border_style=message.border_style,
                    blank_lines_before=1 if idx > 0 else 0,
                    ascii_mode=message.ascii_mode,
                )
            )

    def clear(self) -> None:
        """Clear the manager without rendering."""
        self._messages.clear()


_TOAST_MANAGER = ToastManager()


def toast(
    text: str,
    type: Literal["info", "success", "warning", "error"] = "info",
    duration: int | None = None,
    width: int = 60,
    border_style: str = "rounded",
) -> _ToastRenderable:
    """Return a renderable toast notification."""
    return _ToastRenderable(
        text=text,
        type=type,
        duration=duration,
        width=width,
        border_style=border_style,
    )


def toast_manager() -> ToastManager:
    """Return the module-level toast manager instance."""
    return _TOAST_MANAGER


class ConsolePanel:
    """A simple console-like panel for streaming lines."""

    @staticmethod
    def render(
        lines: Iterable[str],
        *,
        width: int = 80,
        height: int | None = None,
        border_style: str = "box",
        title: str | None = None,
        color: str | None = None,
        blank_lines_before: int = 0,
        blank_lines_after: int = 0,
        ascii_mode: bool | None = None,
    ) -> str:
        out: list[str] = []
        for _ in range(blank_lines_before):
            out.append("")

        symbols = Symbols.get_symbols(border_style, ascii_mode)
        col = Color.get_color(color) if color else ""
        reset = Color.RESET if color else ""
        inner_width = max(2, width - 2)

        # Add title if provided
        if title:
            title_len = len(title) + 2  # Add padding
            title_bar = f" {title} "
            if title_len <= inner_width:
                left_pad = (inner_width - title_len) // 2
                right_pad = inner_width - title_len - left_pad
                title_line = symbols["vertical"] + " " * left_pad + title_bar + " " * right_pad + symbols["vertical"]
            else:
                title_line = symbols["vertical"] + title_bar[: inner_width - 2] + " " + symbols["vertical"]
            out.append(symbols["top_left"] + symbols["horizontal"] * inner_width + symbols["top_right"])
            out.append(title_line)
            out.append(symbols["t_right"] + symbols["horizontal"] * inner_width + symbols["t_left"])
        else:
            out.append(symbols["top_left"] + symbols["horizontal"] * inner_width + symbols["top_right"])

        content_lines = list(lines)
        if height is not None:
            content_lines = content_lines[-height:]
        for raw in content_lines:
            visible_len = len(raw)
            pad = max(0, inner_width - visible_len)
            out.append(symbols["vertical"] + col + raw + reset + " " * pad + symbols["vertical"])

        out.append(symbols["bottom_left"] + symbols["horizontal"] * inner_width + symbols["bottom_right"])
        for _ in range(blank_lines_after):
            out.append("")
        return "\n".join(out)


class Snackbar:
    """One-line notification bar."""

    ICONS = {"info": "[i]", "success": "[+]", "warning": "[!]", "error": "[x]"}

    @staticmethod
    def render(
        message: str,
        *,
        tone: Literal["info", "success", "warning", "error"] = "info",
        width: int = 80,
        align: Literal["left", "center", "right"] = "center",
        border_style: str = "single",
        blank_lines_before: int = 0,
        blank_lines_after: int = 0,
        ascii_mode: bool | None = None,
    ) -> str:
        out: list[str] = []
        for _ in range(blank_lines_before):
            out.append("")

        col = Color.get_color(Toast.COLORS.get(tone, "info"))
        icon = Snackbar.ICONS.get(tone, "[i]")
        full_message = f"{icon} {message}"

        if width and len(full_message) < width - 4:  # Account for borders
            symbols = Symbols.get_symbols(border_style, ascii_mode)
            inner_width = width - 2

            # Create the snackbar with border
            out.append(symbols["top_left"] + symbols["horizontal"] * inner_width + symbols["top_right"])

            # Align the message
            if align == "center":
                padding = (inner_width - len(full_message)) // 2
                line = symbols["vertical"] + " " * padding + col + full_message + Color.RESET + " " * (inner_width - len(full_message) - padding) + symbols["vertical"]
            elif align == "right":
                padding = inner_width - len(full_message)
                line = symbols["vertical"] + " " * padding + col + full_message + Color.RESET + symbols["vertical"]
            else:  # left
                line = symbols["vertical"] + " " + col + full_message + Color.RESET + " " * (inner_width - len(full_message) - 1) + symbols["vertical"]

            out.append(line)
            out.append(symbols["bottom_left"] + symbols["horizontal"] * inner_width + symbols["bottom_right"])
        else:
            # Simple one-line version
            out.append(f"{col}{full_message}{Color.RESET}")

        for _ in range(blank_lines_after):
            out.append("")

        return "\n".join(out)


class AlertBanner:
    """Loud banner for important alerts."""

    @staticmethod
    def render(
        message: str,
        *,
        tone: Literal["info", "success", "warning", "error"] = "info",
        width: int = 80,
    ) -> str:
        col = Color.get_color(Toast.COLORS.get(tone, "info"))
        inner_width = max(2, width)
        text = f" {message} "
        if len(text) > inner_width:
            text = text[:inner_width]
        pad = max(0, inner_width - len(text))
        line = col + "=" * inner_width + Color.RESET
        return "\n".join([line, col + text + " " * pad + Color.RESET, line])


def console_panel(
    lines: list[str],
    *,
    width: int = 80,
    height: int | None = None,
    border_style: str = "box",
    title: str | None = None,
    blank_lines_before: int = 0,
    blank_lines_after: int = 0,
) -> _ConsolePanelRenderable:
    """Return a renderable console panel."""
    return _ConsolePanelRenderable(
        lines=lines,
        width=width,
        height=height,
        border_style=border_style,
        title=title,
        blank_lines_before=blank_lines_before,
        blank_lines_after=blank_lines_after,
    )


def snackbar(
    text: str,
    type: Literal["info", "success", "warning", "error"] = "info",
    width: int = 80,
    align: Literal["left", "center", "right"] = "center",
    border_style: str = "single",
    blank_lines_before: int = 0,
    blank_lines_after: int = 0,
) -> _SnackbarRenderable:
    """Render a snackbar notification."""
    return _SnackbarRenderable(
        text=text,
        type=type,
        width=width,
        align=align,
        border_style=border_style,
        blank_lines_before=blank_lines_before,
        blank_lines_after=blank_lines_after,
    )


def alert_banner(
    text: str,
    type: Literal["info", "success", "warning", "error"] = "info",
    width: int = 80,
    border_style: str = "double",
    blank_lines_before: int = 0,
    blank_lines_after: int = 0,
) -> _AlertBannerRenderable:
    """Render an alert banner."""
    return _AlertBannerRenderable(
        text=text,
        type=type,
        width=width,
        border_style=border_style,
        blank_lines_before=blank_lines_before,
        blank_lines_after=blank_lines_after,
    )


# Renderable classes for GUI support
@dataclass(slots=True)
class _BadgeRenderable(RenderableBase):
    """Renderable wrapper for Badge.render that returns strings."""

    text: str
    style: Literal["square", "round", "angle"] = "square"
    color: str = "cyan"
    bg_color: str | None = None

    def render(self, console: object) -> str:
        return Badge.render(self.text, style=self.style, color=self.color, bg_color=self.bg_color)

    def to_node(self, console: object) -> GuiNode:
        node = GuiNode("badge", text=self.text)
        return node


@dataclass(slots=True)
class _RatingRenderable(RenderableBase):
    """Renderable wrapper for Rating.render that returns strings."""

    rating: float
    max_rating: int = 5
    style: Literal["stars", "hearts", "circles", "squares"] = "stars"
    color: str = "yellow"
    show_value: bool = False

    def render(self, console: object) -> str:
        return Rating.render(
            self.rating,
            max_rating=self.max_rating,
            style=self.style,
            color=self.color,
            show_value=self.show_value,
        )

    def to_node(self, console: object) -> GuiNode:
        node = GuiNode("rating")
        # Create filled and empty rating elements
        for i in range(self.max_rating):
            if i < int(self.rating):
                node.children.append(GuiNode("rating_star", text="filled"))
            elif i < self.rating:
                node.children.append(GuiNode("rating_star", text="half"))
            else:
                node.children.append(GuiNode("rating_star", text="empty"))
        if self.show_value:
            node.children.append(GuiNode("rating_value", text=str(self.rating)))
        return node


@dataclass(slots=True)
class _ToastRenderable(RenderableBase):
    """Renderable wrapper for Toast.render that returns strings."""

    text: str
    type: Literal["info", "success", "warning", "error"] = "info"
    duration: int | None = None
    width: int = 60
    border_style: str = "rounded"

    def render(self, console: object) -> str:
        return Toast.render(
            self.text,
            tone=self.type,
            width=self.width,
            border_style=self.border_style,
        )

    def to_node(self, console: object) -> GuiNode:
        node = GuiNode("toast", text=self.text)
        node.children.append(GuiNode("toast_type", text=self.type))
        return node


@dataclass(slots=True)
class _ConsolePanelRenderable(RenderableBase):
    """Renderable wrapper for ConsolePanel.render that returns strings."""

    lines: list[str]
    width: int = 80
    height: int | None = None
    border_style: str = "box"
    title: str | None = None
    blank_lines_before: int = 0
    blank_lines_after: int = 0

    def render(self, console: object) -> str:
        return ConsolePanel.render(
            self.lines,
            width=self.width,
            height=self.height,
            border_style=self.border_style,
            title=self.title,
            blank_lines_before=self.blank_lines_before,
            blank_lines_after=self.blank_lines_after,
        )

    def to_node(self, console: object) -> GuiNode:
        node = GuiNode("console_panel")
        if self.title:
            node.children.append(GuiNode("title", text=self.title))
        for line in self.lines[-self.height :] if self.height else self.lines:
            node.children.append(GuiNode("console_line", text=line))
        return node


@dataclass(slots=True)
class _SnackbarRenderable(RenderableBase):
    """Renderable wrapper for Snackbar.render that returns strings."""

    text: str
    type: Literal["info", "success", "warning", "error"] = "info"
    width: int = 80
    align: Literal["left", "center", "right"] = "center"
    border_style: str = "single"
    blank_lines_before: int = 0
    blank_lines_after: int = 0

    def render(self, console: object) -> str:
        return Snackbar.render(
            self.text,
            tone=self.type,
            width=self.width,
            align=self.align,
            border_style=self.border_style,
            blank_lines_before=self.blank_lines_before,
            blank_lines_after=self.blank_lines_after,
        )

    def to_node(self, console: object) -> GuiNode:
        node = GuiNode("snackbar", text=self.text)
        node.children.append(GuiNode("snackbar_type", text=self.type))
        return node


@dataclass(slots=True)
class _AlertBannerRenderable(RenderableBase):
    """Renderable wrapper for AlertBanner.render that returns strings."""

    text: str
    type: Literal["info", "success", "warning", "error"] = "info"
    width: int = 80
    border_style: str = "double"
    blank_lines_before: int = 0
    blank_lines_after: int = 0

    def render(self, console: object) -> str:
        return AlertBanner.render(
            self.text,
            tone=self.type,
            width=self.width,
        )

    def to_node(self, console: object) -> GuiNode:
        node = GuiNode("alert_banner", text=self.text)
        node.children.append(GuiNode("alert_type", text=self.type))
        return node
