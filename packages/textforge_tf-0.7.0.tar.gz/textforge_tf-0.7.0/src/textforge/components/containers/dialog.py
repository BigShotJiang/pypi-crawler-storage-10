"""Dialog container component."""

from __future__ import annotations

from dataclasses import dataclass
from typing import TYPE_CHECKING

from ...core.console import Console, Measure
from ...utils.logging import get_logger
from ..base import ContainerRenderable
from .base import ContainerBase

if TYPE_CHECKING:
    from ...style.subsystem import StylingContext

logger = get_logger(__name__)


class Dialog(ContainerBase):
    """A dialog container component for modal interactions."""

    def __init__(self, title: str | None = None, modal: bool = True, **kwargs: object) -> None:
        """Initialize the dialog container.

        Args:
            title: Optional title for the dialog.
            modal: Whether the dialog is modal (blocks interaction with other components).
            **kwargs: Additional keyword arguments passed to parent.
        """
        super().__init__(**kwargs)
        self.title = title
        self.modal = modal

    @property
    def component_name(self) -> str:
        """Return the component name for styling purposes."""
        return "dialog"

    def to_renderable(self, styling_context: StylingContext | None = None) -> DialogRenderable:
        """Convert this dialog to a renderable dialog.

        Args:
            styling_context: The styling context for this component.

        Returns:
            A DialogRenderable instance.
        """
        from ...style.subsystem import StylingContext

        context = styling_context or StylingContext(component_name=self.component_name)
        renderable = DialogRenderable(
            component_name=self.component_name,
            styling_context=context,
            title=self.title,
            modal=self.modal,
        )

        # Add children to renderable
        for child in self.children:
            renderable.add_child(child.to_renderable(context))

        return renderable


@dataclass(slots=True)
class DialogRenderable(ContainerRenderable):
    """Renderable dialog container component."""

    title: str | None = None
    modal: bool = True

    def render(self, console: Console) -> str | list[str] | None:
        """Render the dialog container with title and children.

        Args:
            console: The console to render to.

        Returns:
            The rendered output as string, list of strings, or None.
        """
        logger.log(5, f"Rendering dialog: {self.component_name}")  # Use level 5 for TRACE

        # Get resolved style for styling
        _ = self.get_resolved_style(console)

        rendered_parts: list[str] = []

        # Render title if present
        if self.title:
            rendered_parts.append(self.title)

        # Render children
        for child in self.children:
            child_output = child.render(console)
            if child_output is None:
                continue
            elif isinstance(child_output, str):
                rendered_parts.append(child_output)
            elif isinstance(child_output, list):
                rendered_parts.extend(child_output)

        return "\n".join(rendered_parts) if rendered_parts else ""

    def measure(self, console: Console) -> Measure:
        """Measure the dialog container's preferred size including title and children.

        Args:
            console: The console context for measurement.

        Returns:
            Measure object with width and height for the dialog.
        """
        logger.log(5, f"Measuring dialog: {self.component_name}")  # Use level 5 for TRACE

        total_height = 0
        max_width = 0

        # Measure title if present
        if self.title:
            title_width = len(self.title)
            max_width = max(max_width, title_width)
            total_height += 1  # Assume title height is 1 line

        # Measure children
        for child in self.children:
            child_measure = child.measure(console)
            max_width = max(max_width, child_measure.width)
            total_height += child_measure.height

        return Measure(max_width, total_height)


__all__ = ["Dialog"]
