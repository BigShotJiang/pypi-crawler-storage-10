"""Panel container component."""

from __future__ import annotations

from typing import TYPE_CHECKING, Any

from textforge.style.tfs.tfs_values import Length

from ...core.console import Console, Measure
from ...utils.logging import get_logger
from ..base import Component, ContainerRenderable
from .base import ContainerBase

if TYPE_CHECKING:
    from collections.abc import Sequence

    from ...renderers.gui.types import GuiNode
    from ...style.subsystem import StylingContext


logger = get_logger(__name__)


Numeric = int | float
NumericLike = Numeric | Length


class Panel(ContainerBase):
    """A panel container component with a border and title."""

    def __init__(
        self,
        title: str | None = None,
        children: Sequence[Component] | None = None,
        **kwargs: object,
    ) -> None:
        super().__init__(children=children, **kwargs)
        self.title: str | None = title

    @property
    def component_name(self) -> str:
        return "panel"

    def to_renderable(self, styling_context: StylingContext | None = None) -> PanelRenderable:
        return PanelRenderable(
            component_name=self.component_name,
            styling_context=styling_context,
            title=self.title,
            children=self.children,
        )


class PanelRenderable(ContainerRenderable):
    """Renderable panel container component."""

    def __init__(
        self,
        component_name: str,
        styling_context: StylingContext | None,
        title: str | None,
        children: list[Component],
    ) -> None:
        super().__init__(component_name, styling_context)
        self.title: str | None = title
        for child in children:
            child_renderable = child.to_renderable(styling_context)
            self.add_child(child_renderable)

    # ------------------------------------------------------------------

    def _resolve_length(self, val: Any) -> float:
        """Convert any Length-like or numeric value into a float."""
        if val is None:
            return 0.0
        if hasattr(val, "to_pixels") and callable(getattr(val, "to_pixels")):
            try:
                px_val = float(val.to_pixels())  # type: ignore[call-arg, attr-defined]
                return px_val
            except Exception:
                return 0.0
        if isinstance(val, (int, float)):
            return float(val)
        try:
            return float(val)
        except Exception:
            return 0.0

    # ------------------------------------------------------------------

    def render(self, console: Console) -> str | list[str] | None:
        from ...core.text.symbols import Symbols

        symbols: dict[str, str] = Symbols.get_symbols("box")

        resolved_style: Any = self.get_resolved_style(console)
        padding: Any = getattr(resolved_style, "padding", None)

        pad_top: float
        pad_right: float
        pad_bottom: float
        pad_left: float

        if padding is None:
            pad_top = pad_right = pad_bottom = pad_left = 0.0
        else:
            pad_top = self._resolve_length(getattr(padding, "top", 0))
            pad_right = self._resolve_length(getattr(padding, "right", 0))
            pad_bottom = self._resolve_length(getattr(padding, "bottom", 0))
            pad_left = self._resolve_length(getattr(padding, "left", 0))

        rendered_parts: list[str] = []
        if self.children:
            for child in self.children:
                child_output = child.render(console)
                if child_output is None:
                    continue
                if isinstance(child_output, str):
                    rendered_parts.append(child_output)
                elif isinstance(child_output, list):
                    rendered_parts.extend([str(x) for x in child_output])

        content: str = "\n".join(rendered_parts) if rendered_parts else ""
        lines: list[str] = content.splitlines() if content else []

        content_width: int = max((len(line) for line in lines), default=0)
        content_height: int = len(lines)

        inner_width: int = int(content_width + pad_left + pad_right)
        inner_height: int = int(content_height + pad_top + pad_bottom)
        total_width: int = inner_width + 2

        # Build borders
        if self.title:
            title_len = len(self.title)
            if title_len + 4 <= total_width:
                left_border = symbols["top_left"] + symbols["horizontal"]
                right_count = max(int(total_width - title_len - 3), 0)
                right_border = symbols["horizontal"] * right_count + symbols["top_right"]
                top_border = f"{left_border} {self.title} {right_border}"
            else:
                top_border = (
                    symbols["top_left"]
                    + symbols["horizontal"] * (total_width - 2)
                    + symbols["top_right"]
                )
        else:
            top_border = (
                symbols["top_left"]
                + symbols["horizontal"] * (total_width - 2)
                + symbols["top_right"]
            )

        bottom_border = (
            symbols["bottom_left"]
            + symbols["horizontal"] * (total_width - 2)
            + symbols["bottom_right"]
        )

        side_borders: list[str] = [
            symbols["vertical"] + " " * inner_width + symbols["vertical"]
            for _ in range(inner_height)
        ]

        panel_lines: list[str] = [top_border]

        for i, line in enumerate(lines):
            padded_line = (
                " " * int(pad_left)
                + line.ljust(content_width)
                + " " * int(pad_right)
            )
            if i < len(side_borders):
                side_borders[i] = symbols["vertical"] + padded_line + symbols["vertical"]

        while len(side_borders) < inner_height:
            side_borders.append(
                symbols["vertical"] + " " * inner_width + symbols["vertical"]
            )

        panel_lines.extend(side_borders)
        panel_lines.append(bottom_border)
        return "\n".join(panel_lines)

    # ------------------------------------------------------------------

    def measure(self, console: Console) -> Measure:
        resolved_style: Any = self.get_resolved_style(console)
        padding: Any = getattr(resolved_style, "padding", None)

        pad_top: float = self._resolve_length(getattr(padding, "top", 0)) if padding else 0.0
        pad_right: float = self._resolve_length(getattr(padding, "right", 0)) if padding else 0.0
        pad_bottom: float = self._resolve_length(getattr(padding, "bottom", 0)) if padding else 0.0
        pad_left: float = self._resolve_length(getattr(padding, "left", 0)) if padding else 0.0

        if not self.children:
            min_width: int = int(4 + pad_left + pad_right)
            min_height: int = int(3 + pad_top + pad_bottom)
            if self.title:
                min_width = max(min_width, int(len(self.title) + 4 + pad_left + pad_right))
            return Measure(min_width, min_height)

        max_child_width: int = 0
        total_child_height: int = 0
        for child in self.children:
            child_measure = child.measure(console)
            max_child_width = max(max_child_width, child_measure.width)
            total_child_height += child_measure.height

        content_width: int = int(max_child_width + pad_left + pad_right)
        content_height: int = int(total_child_height + pad_top + pad_bottom)

        panel_width: int = content_width + 2
        panel_height: int = content_height + 2

        if self.title:
            title_width: int = int(len(self.title) + 4 + pad_left + pad_right)
            panel_width = max(panel_width, title_width)

        return Measure(panel_width, panel_height)

    # ------------------------------------------------------------------

    def to_node(self, console: Console) -> GuiNode:
        node: GuiNode = super().to_node(console)
        if self.title:
            node.text = self.title
        return node
