"""Box container component."""

from __future__ import annotations

from dataclasses import dataclass
from typing import TYPE_CHECKING

from ...core.console import Console, Measure
from ...utils.logging import get_logger
from ..base import ContainerRenderable
from .base import ContainerBase

if TYPE_CHECKING:
    from ...style.subsystem import StylingContext

logger = get_logger(__name__)


class Box(ContainerBase):
    """A basic container component that holds and stacks child components vertically."""

    @property
    def component_name(self) -> str:
        """Return the component name for styling purposes."""
        return "box"

    def to_renderable(self, styling_context: StylingContext | None = None) -> BoxRenderable:
        """Convert this box to a renderable box.

        Args:
            styling_context: The styling context for this component.

        Returns:
            A BoxRenderable instance.
        """
        logger.debug(f"Converting box to renderable: {self.component_name}")
        from ...style.subsystem import StylingContext

        context = styling_context or StylingContext(component_name=self.component_name)
        renderable = BoxRenderable(
            component_name=self.component_name,
            styling_context=context,
        )
        # Add children to the renderable
        for child in self.children:
            child_renderable = child.to_renderable(context)
            renderable.add_child(child_renderable)
        return renderable


@dataclass(slots=True)
class BoxRenderable(ContainerRenderable):
    """Renderable box container component that stacks children vertically."""

    def render(self, console: Console) -> str | list[str] | None:
        """Render the box container and its children stacked vertically.

        Args:
            console: The console to render to.

        Returns:
            The rendered output as string, list of strings, or None.
        """
        logger.log(5, f"Rendering box container: {self.component_name}")  # Use level 5 for TRACE

        if not self.children:
            return ""

        rendered_parts: list[str] = []
        for child in self.children:
            child_output = child.render(console)
            if child_output is None:
                continue
            if isinstance(child_output, list):
                rendered_parts.extend(child_output)
            else:
                rendered_parts.append(str(child_output))

        return "\n".join(rendered_parts) if rendered_parts else ""

    def measure(self, console: Console) -> Measure:
        """Measure the box container's preferred size by stacking children vertically.

        Args:
            console: The console context for measurement.

        Returns:
            Measure object with width and height for the box.
        """
        if not self.children:
            return Measure(0, 0)

        width = 0
        height = 0
        for child in self.children:
            child_measure = child.measure(console)
            width = max(width, child_measure.width)
            height += child_measure.height
        return Measure(width, height)
