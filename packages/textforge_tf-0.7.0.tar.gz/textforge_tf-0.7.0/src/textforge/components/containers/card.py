"""Card container component."""

from __future__ import annotations

from dataclasses import dataclass
from typing import TYPE_CHECKING

from ...core.console import Console, Measure
from ...utils.logging import get_logger
from ..base import Component, ContainerRenderable, RenderableComponent
from .base import ContainerBase

if TYPE_CHECKING:
    from ...style.subsystem import StylingContext

logger = get_logger(__name__)


class Card(ContainerBase):
    """A card container component with header, body, and footer sections."""

    def __init__(self, header: Component | None = None, footer: Component | None = None, **kwargs: object) -> None:
        """Initialize the card container.

        Args:
            header: Optional header component for the card.
            footer: Optional footer component for the card.
            **kwargs: Additional keyword arguments passed to parent.
        """
        super().__init__(**kwargs)
        self.header = header
        self.footer = footer

    @property
    def component_name(self) -> str:
        """Return the component name for styling purposes."""
        return "card"

    def to_renderable(self, styling_context: StylingContext | None = None) -> CardRenderable:
        """Convert this card to a renderable card.

        Args:
            styling_context: The styling context for this component.

        Returns:
            A CardRenderable instance.
        """
        from ...style.subsystem import StylingContext

        context = styling_context or StylingContext(component_name=self.component_name)
        renderable = CardRenderable(
            component_name=self.component_name,
            styling_context=context,
        )

        # Add header, footer, and children to renderable
        if self.header:
            renderable.header = self.header.to_renderable(context)
        if self.footer:
            renderable.footer = self.footer.to_renderable(context)
        for child in self.children:
            renderable.add_child(child.to_renderable(context))

        return renderable


@dataclass(slots=True)
class CardRenderable(ContainerRenderable):
    """Renderable card container component."""

    header: RenderableComponent | None = None
    footer: RenderableComponent | None = None

    def render(self, console: Console) -> str | list[str] | None:
        """Render the card container with header, body, and footer sections.

        Args:
            console: The console to render to.

        Returns:
            The rendered output as string, list of strings, or None.
        """
        logger.log(5, f"Rendering card: {self.component_name}")  # Use level 5 for TRACE

        # Get resolved style for styling
        _ = self.get_resolved_style(console)

        rendered_parts: list[str] = []

        # Render header if present
        if self.header:
            header_output = self.header.render(console)
            if header_output:
                if isinstance(header_output, str):
                    rendered_parts.append(header_output)
                else:
                    rendered_parts.extend(header_output)

        # Render body (children)
        body_parts: list[str] = []
        for child in self.children:
            child_output = child.render(console)
            if child_output:
                if isinstance(child_output, str):
                    body_parts.append(child_output)
                else:
                    body_parts.extend(child_output)

        if body_parts:
            rendered_parts.append("\n".join(body_parts))

        # Render footer if present
        if self.footer:
            footer_output = self.footer.render(console)
            if footer_output:
                if isinstance(footer_output, str):
                    rendered_parts.append(footer_output)
                else:
                    rendered_parts.extend(footer_output)

        return "\n\n".join(rendered_parts) if rendered_parts else ""

    def measure(self, console: Console) -> Measure:
        """Measure the card container's preferred size including header, body, and footer.

        Args:
            console: The console context for measurement.

        Returns:
            Measure object with width and height for the card.
        """
        logger.log(5, f"Measuring card: {self.component_name}")  # Use level 5 for TRACE

        total_height = 0
        max_width = 0

        # Measure header if present
        if self.header:
            header_measure = self.header.measure(console)
            max_width = max(max_width, header_measure.width)
            total_height += header_measure.height

        # Measure children (body)
        for child in self.children:
            child_measure = child.measure(console)
            max_width = max(max_width, child_measure.width)
            total_height += child_measure.height

        # Measure footer if present
        if self.footer:
            footer_measure = self.footer.measure(console)
            max_width = max(max_width, footer_measure.width)
            total_height += footer_measure.height

        # Add spacing between sections (header-body, body-footer)
        section_spacing = 2  # Double newline
        num_sections = sum([1 for x in [self.header, bool(self.children), self.footer] if x])
        if num_sections > 1:
            total_height += section_spacing * (num_sections - 1)

        return Measure(max_width, total_height)


__all__ = ["Card"]
