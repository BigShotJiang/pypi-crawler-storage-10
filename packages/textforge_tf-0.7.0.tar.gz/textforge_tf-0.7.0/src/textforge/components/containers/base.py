"""Backward-compatible import for container base classes."""

from __future__ import annotations

from ..base import ContainerBase

__all__ = ["ContainerBase"]
