"""Interactive components (forms and controls).

These components provide simple interactive prompts using stdin/stdout so they
work in any terminal. They also support static rendering to preview states in
showcases and demos.
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import TYPE_CHECKING, Any, Literal

from ..core import render_call
from ..renderers.base import RenderableBase
from ..renderers.gui.types import GuiNode
from ..style.colors import Color

if TYPE_CHECKING:
    from collections.abc import Callable

__all__ = [
    "Checkbox",
    "Radio",
    "Toggle",
    "Slider",
    "Form",
    "checkbox",
    "radio",
    "toggle",
    "slider",
    "form",
]


class Checkbox:
    @staticmethod
    def render(
        label: str,
        checked: bool = False,
        color: str = "accent",
        interactive: bool = False,
        *,
        input_func: Callable[[], str] | None = None,
    ) -> bool | None:
        box = "☑" if checked else "☐"
        col = Color.get_color(color)
        line = f"{col}{box}{Color.RESET} {label}"
        print(line)
        if not interactive:
            return None
        print("Toggle? [y/N] ", end="")
        try:
            reader = input_func or input
            ans = reader().strip().lower()
        except EOFError:
            return checked
        return checked if not ans else ans.startswith("y")

    @staticmethod
    def render_static(label: str, checked: bool = False, color: str = "accent") -> str:
        """Render checkbox as string without interaction."""
        box = "☑" if checked else "☐"
        col = Color.get_color(color)
        return f"{col}{box}{Color.RESET} {label}"


class Radio:
    @staticmethod
    def render(
        label: str,
        selected: bool = False,
        color: str = "accent",
        interactive: bool = False,
        *,
        input_func: Callable[[], str] | None = None,
    ) -> bool | None:
        dot = "◉" if selected else "◯"
        col = Color.get_color(color)
        line = f"{col}{dot}{Color.RESET} {label}"
        print(line)
        if not interactive:
            return None
        print("Select? [y/N] ", end="")
        try:
            reader = input_func or input
            ans = reader().strip().lower()
        except EOFError:
            return selected
        return selected if not ans else ans.startswith("y")

    @staticmethod
    def render_static(label: str, selected: bool = False, color: str = "accent") -> str:
        """Render radio button as string without interaction."""
        dot = "◉" if selected else "◯"
        col = Color.get_color(color)
        return f"{col}{dot}{Color.RESET} {label}"


class Toggle:
    @staticmethod
    def render(
        label: str,
        on: bool = False,
        color_on: str = "green",
        color_off: str = "gray",
        interactive: bool = False,
        *,
        input_func: Callable[[], str] | None = None,
    ) -> bool | None:
        col = Color.get_color(color_on if on else color_off)
        state = "ON " if on else "OFF"
        print(f"{label}: {col}[ {state} ]{Color.RESET}")
        if not interactive:
            return None
        print("Toggle? [y/N] ", end="")
        try:
            reader = input_func or input
            ans = reader().strip().lower()
        except EOFError:
            return on
        return on if not ans else not on

    @staticmethod
    def render_static(label: str, on: bool = False, color_on: str = "green", color_off: str = "gray") -> str:
        """Render toggle as string without interaction."""
        col = Color.get_color(color_on if on else color_off)
        state = "ON " if on else "OFF"
        return f"{label}: {col}[ {state} ]{Color.RESET}"


class Slider:
    @staticmethod
    def render(
        label: str,
        value: float = 0,
        minimum: float = 0,
        maximum: float = 100,
        width: int = 20,
        color: str = "primary",
        interactive: bool = False,
        *,
        input_func: Callable[[], str] | None = None,
    ) -> float | None:
        pct = 0 if maximum <= minimum else (value - minimum) / (maximum - minimum)
        pct = max(0.0, min(1.0, pct))
        filled = int(width * pct)
        bar = "█" * filled + "░" * (width - filled)
        col = Color.get_color(color)
        print(f"{label}: {col}[{bar}]{Color.RESET} {value:.2f}")
        if not interactive:
            return None
        print(f"Enter value ({minimum}..{maximum}): ", end="")
        try:
            reader = input_func or input
            text = reader().strip()
        except EOFError:
            return value
        try:
            num = float(text)
        except ValueError:
            return value
        return max(minimum, min(maximum, num))

    @staticmethod
    def render_static(
        label: str,
        value: float,
        minimum: float = 0,
        maximum: float = 100,
        width: int = 20,
        color: str = "primary",
    ) -> str:
        """Render slider as string without interaction."""
        pct = 0 if maximum <= minimum else (value - minimum) / (maximum - minimum)
        pct = max(0.0, min(1.0, pct))
        filled = int(width * pct)
        bar = "█" * filled + "░" * (width - filled)
        col = Color.get_color(color)
        return f"{label}: {col}[{bar}]{Color.RESET} {value:.2f}"


@dataclass(slots=True)
class FormField:
    name: str
    kind: Literal["text", "number", "checkbox", "radio", "toggle", "slider"]
    label: str
    options: list[str] | None = None
    default: Any | None = None


class Form:
    @staticmethod
    def render(
        title: str,
        fields: list[FormField],
        interactive: bool = False,
        width: int = 60,
        *,
        input_func: Callable[[], str] | None = None,
    ) -> dict[str, Any] | None:
        from ..components.containers import Dialog

        Dialog.render(title, "Fill the form below:", buttons=["Submit"], selected_button=0, width=width)
        results: dict[str, Any] = {}
        for f in fields:
            label = f.label
            if f.kind == "text":
                if interactive:
                    print(f"{label}: ", end="")
                    try:
                        reader = input_func or input
                        results[f.name] = reader()
                    except EOFError:
                        results[f.name] = f.default
                else:
                    print(f"{label}: {f.default if f.default is not None else ''}")
            elif f.kind == "number":
                if interactive:
                    print(f"{label}: ", end="")
                    try:
                        reader = input_func or input
                        results[f.name] = float(reader())
                    except Exception:
                        results[f.name] = f.default
                else:
                    print(f"{label}: {f.default if f.default is not None else 0}")
            elif f.kind == "checkbox":
                val = Checkbox.render(label, bool(f.default), interactive=interactive)
                results[f.name] = bool(val) if val is not None else bool(f.default)
            elif f.kind == "radio":
                selected = 0
                if isinstance(f.default, int):
                    selected = f.default
                opts = f.options or []
                for i, opt in enumerate(opts):
                    Radio.render(opt, selected == i)
                if interactive:
                    print("Select index: ", end="")
                    try:
                        reader = input_func or input
                        idx = int(reader())
                    except Exception:
                        idx = selected
                    results[f.name] = opts[idx] if 0 <= idx < len(opts) else (opts[selected] if opts else None)
                else:
                    results[f.name] = opts[selected] if opts else None
            elif f.kind == "toggle":
                val = Toggle.render(label, bool(f.default), interactive=interactive)
                results[f.name] = bool(val) if val is not None else bool(f.default)
            elif f.kind == "slider":
                dv = float(f.default) if isinstance(f.default, (int, float)) else 0.0
                val = Slider.render(label, dv, 0, 100, interactive=interactive)
                results[f.name] = float(val) if isinstance(val, (int, float)) else dv
        return results if interactive else None

    @staticmethod
    def render_static(fields: list[FormField], title: str | None = None, submit_label: str = "Submit", color: str = "accent") -> str:
        """Render form as string without interaction."""
        lines: list[str] = []
        if title:
            lines.append(title)
            lines.append("-" * len(title))

        for f in fields:
            label = f.label
            default_display = f.default if f.default is not None else ""
            lines.append(f"{label}: {default_display}")

        lines.append(f"\n[{submit_label}]")
        return "\n".join(lines)


def checkbox(label: str, checked: bool = False, color: str = "accent") -> _CheckboxRenderable:
    """Return a renderable checkbox component."""
    return _CheckboxRenderable(
        label=label,
        checked=checked,
        color=color,
    )


def radio(label: str, selected: bool = False, color: str = "accent") -> _RadioRenderable:
    """Return a renderable radio button component."""
    return _RadioRenderable(
        label=label,
        selected=selected,
        color=color,
    )


def toggle(label: str, state: bool = False, color: str = "accent") -> _ToggleRenderable:
    """Return a renderable toggle component."""
    return _ToggleRenderable(
        label=label,
        state=state,
        color=color,
    )


def slider(
    label: str,
    value: float,
    min_value: float = 0.0,
    max_value: float = 100.0,
    step: float = 1.0,
    width: int = 20,
    color: str = "accent",
) -> _SliderRenderable:
    """Return a renderable slider component."""
    return _SliderRenderable(
        label=label,
        value=value,
        min_value=min_value,
        max_value=max_value,
        step=step,
        width=width,
        color=color,
    )


def form(*args: object, **kwargs: object):
    return render_call(Form.render, *args, **kwargs)


# Renderable classes for GUI support
@dataclass(slots=True)
class _CheckboxRenderable(RenderableBase):
    """Renderable wrapper for Checkbox.render that returns strings."""

    label: str
    checked: bool = False
    color: str = "accent"

    def render(self, console: object) -> str:
        return Checkbox.render_static(self.label, self.checked, self.color)

    def to_node(self, console: object) -> GuiNode:
        node = GuiNode("checkbox")
        node.children.append(GuiNode("checkbox_label", text=self.label))
        node.children.append(GuiNode("checkbox_state", text="checked" if self.checked else "unchecked"))
        return node


@dataclass(slots=True)
class _RadioRenderable(RenderableBase):
    """Renderable wrapper for Radio.render that returns strings."""

    label: str
    selected: bool = False
    color: str = "accent"

    def render(self, console: object) -> str:
        return Radio.render_static(self.label, self.selected, self.color)

    def to_node(self, console: object) -> GuiNode:
        node = GuiNode("radio")
        node.children.append(GuiNode("radio_label", text=self.label))
        node.children.append(GuiNode("radio_state", text="selected" if self.selected else "unselected"))
        return node


@dataclass(slots=True)
class _ToggleRenderable(RenderableBase):
    """Renderable wrapper for Toggle.render that returns strings."""

    label: str
    state: bool = False
    color: str = "accent"

    def render(self, console: object) -> str:
        return Toggle.render_static(self.label, self.state, self.color)

    def to_node(self, console: object) -> GuiNode:
        node = GuiNode("toggle")
        node.children.append(GuiNode("toggle_label", text=self.label))
        node.children.append(GuiNode("toggle_state", text="on" if self.state else "off"))
        return node


@dataclass(slots=True)
class _SliderRenderable(RenderableBase):
    """Renderable wrapper for Slider.render that returns strings."""

    label: str
    value: float
    min_value: float = 0.0
    max_value: float = 100.0
    step: float = 1.0
    width: int = 20
    color: str = "accent"

    def render(self, console: object) -> str:
        return Slider.render_static(self.label, self.value, self.min_value, self.max_value, self.width, self.color)

    def to_node(self, console: object) -> GuiNode:
        node = GuiNode("slider")
        node.children.append(GuiNode("slider_label", text=self.label))
        node.children.append(GuiNode("slider_value", text=str(self.value)))
        # Calculate percentage for visual representation
        percentage = (self.value - self.min_value) / (self.max_value - self.min_value)
        node.children.append(GuiNode("slider_percentage", text=f"{percentage:.2f}"))
        return node


@dataclass(slots=True)
class _FormRenderable(RenderableBase):
    """Renderable wrapper for Form.render that returns strings."""

    fields: list[dict[str, object]]
    title: str | None = None
    submit_label: str = "Submit"
    color: str = "accent"

    def render(self, console: object) -> str:
        # Convert dict fields to FormField objects
        form_fields: list[FormField] = []
        for field_dict in self.fields:
            form_fields.append(FormField(**field_dict))
        return Form.render_static(form_fields, self.title, self.submit_label, self.color)

    def to_node(self, console: object) -> GuiNode:
        node = GuiNode("form")
        if self.title:
            node.children.append(GuiNode("form_title", text=self.title))

        for field in self.fields:
            field_node = GuiNode("form_field")
            field_node.children.append(GuiNode("field_label", text=field.get("label", "")))
            field_node.children.append(GuiNode("field_type", text=field.get("type", "text")))
            field_node.children.append(GuiNode("field_value", text=str(field.get("value", ""))))
            node.children.append(field_node)

        node.children.append(GuiNode("form_submit", text=self.submit_label))
        return node
