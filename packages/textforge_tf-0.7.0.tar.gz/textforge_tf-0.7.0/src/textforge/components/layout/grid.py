"""Grid layout component."""

from __future__ import annotations

from dataclasses import dataclass
from typing import TYPE_CHECKING

from ...core.console import Console, Measure
from ...utils.logging import get_logger
from ..base import ContainerBase, ContainerRenderable

if TYPE_CHECKING:
    from ...style.subsystem import StylingContext

logger = get_logger(__name__)


class Grid(ContainerBase):
    """Grid layout component that arranges children in a grid pattern."""

    def __init__(
        self,
        columns: int | str | None = None,
        rows: int | str | None = None,
        gap: int = 1,
        column_gap: int | None = None,
        row_gap: int | None = None,
        **kwargs: object,
    ) -> None:
        """Initialize the grid layout.

        Args:
            columns: Number of columns or column template.
            rows: Number of rows or row template.
            gap: Default gap between cells.
            column_gap: Gap between columns (overrides gap).
            row_gap: Gap between rows (overrides gap).
            **kwargs: Additional keyword arguments passed to parent.
        """
        super().__init__(**kwargs)
        self.columns = columns
        self.rows = rows
        self.gap = max(0, gap)
        self.column_gap = column_gap if column_gap is not None else self.gap
        self.row_gap = row_gap if row_gap is not None else self.gap

    @property
    def component_name(self) -> str:
        """Return the component name for styling purposes."""
        return "grid"

    def to_renderable(self, styling_context: StylingContext | None = None) -> GridRenderable:
        """Convert this grid layout to a renderable component.

        Args:
            styling_context: The styling context for this component.

        Returns:
            A GridRenderable instance.
        """
        from ...style.subsystem import StylingContext

        context = styling_context or StylingContext(component_name=self.component_name)
        renderable = GridRenderable(
            component_name=self.component_name,
            styling_context=context,
            columns=self.columns,
            rows=self.rows,
            gap=self.gap,
            column_gap=self.column_gap,
            row_gap=self.row_gap,
        )

        # Add children to renderable
        for child in self.children:
            renderable.add_child(child.to_renderable(context))

        return renderable


@dataclass(slots=True)
class GridRenderable(ContainerRenderable):
    """Renderable grid layout component."""

    columns: int | str | None = None
    rows: int | str | None = None
    gap: int = 1
    column_gap: int = 1
    row_gap: int = 1

    def render(self, console: Console) -> str | list[str] | None:
        """Render the grid layout and all its children.

        Args:
            console: The console to render to.

        Returns:
            The rendered layout as a list of strings.
        """
        logger.log(5, f"Rendering grid: {self.component_name}")  # Use level 5 for TRACE

        # Get resolved style for styling
        _ = self.get_resolved_style(console)

        if not self.children:
            return []

        # Simple grid implementation
        return self._render_simple_grid()

    def _render_simple_grid(self) -> list[str]:
        """Render children in a simple grid layout.

        Returns:
            List of strings representing the grid layout.
        """
        if not self.children:
            return []

        # Get console from the render method context
        console = Console()  # Create a console instance for rendering

        # Determine grid dimensions
        num_columns = self._calculate_columns()
        num_rows = self._calculate_rows(len(self.children), num_columns)

        # Calculate cell sizes
        cell_width, cell_height = self._calculate_cell_sizes(num_columns, num_rows)

        # Create grid
        result_lines: list[str] = []

        for row in range(num_rows):
            row_parts: list[str] = []

            for col in range(num_columns):
                child_index = row * num_columns + col
                if child_index < len(self.children):
                    child = self.children[child_index]
                    child_output = child.render(console)

                    # Get content for this cell
                    if child_output is None:
                        cell_content = ""
                    elif isinstance(child_output, str):
                        # Take first line and truncate to cell width
                        cell_content = child_output.split('\n')[0][:cell_width].ljust(cell_width)
                    elif isinstance(child_output, list) and child_output:
                        # Take first line and truncate to cell width
                        cell_content = child_output[0][:cell_width].ljust(cell_width)
                    else:
                        cell_content = " " * cell_width
                else:
                    cell_content = " " * cell_width

                row_parts.append(cell_content)

                # Add column gap (except after last column)
                if col < num_columns - 1:
                    row_parts.append(" " * self.column_gap)

            result_lines.append("".join(row_parts))

            # Add row gap (except after last row)
            if row < num_rows - 1 and self.row_gap > 0:
                result_lines.extend([""] * self.row_gap)

        return result_lines

    def _calculate_columns(self) -> int:
        """Calculate the number of columns.

        Returns:
            Number of columns in the grid.
        """
        if isinstance(self.columns, int):
            return max(1, self.columns)
        elif isinstance(self.columns, str):
            # Parse template like "1fr 2fr 1fr"
            parts = self.columns.split()
            return len(parts)
        else:
            # Auto-calculate based on children count
            return max(1, int(len(self.children) ** 0.5))

    def _calculate_rows(self, child_count: int, columns: int) -> int:
        """Calculate the number of rows.

        Args:
            child_count: Number of child components.
            columns: Number of columns.

        Returns:
            Number of rows needed.
        """
        if isinstance(self.rows, int):
            return max(1, self.rows)
        else:
            # Calculate rows based on children and columns
            return (child_count + columns - 1) // columns

    def _calculate_cell_sizes(self, columns: int, rows: int) -> tuple[int, int]:
        """Calculate the size of each grid cell.

        Args:
            columns: Number of columns.
            rows: Number of rows.

        Returns:
            Tuple of (cell_width, cell_height).
        """
        # Simple implementation - fixed cell sizes
        cell_width = 20  # Fixed width per cell
        cell_height = 3  # Fixed height per cell

        return cell_width, cell_height

    def measure(self, console: Console) -> Measure:
        """Measure the grid layout component's preferred size.

        Args:
            console: The console context for measurement.

        Returns:
            Measure object with width and height for the layout.
        """
        logger.log(5, f"Measuring grid: {self.component_name}")  # Use level 5 for TRACE

        if not self.children:
            return Measure(0, 0)

        # Determine grid dimensions
        num_columns = self._calculate_columns()
        num_rows = self._calculate_rows(len(self.children), num_columns)

        # Calculate cell sizes
        cell_width, cell_height = self._calculate_cell_sizes(num_columns, num_rows)

        # Calculate total dimensions
        total_width = num_columns * cell_width + (num_columns - 1) * self.column_gap
        total_height = num_rows * cell_height + (num_rows - 1) * self.row_gap

        return Measure(total_width, total_height)


__all__ = ["Grid", "GridRenderable"]
