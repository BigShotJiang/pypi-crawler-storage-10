"""Columns layout component."""

from __future__ import annotations

from dataclasses import dataclass
from typing import TYPE_CHECKING

from ...core.console import Console, Measure
from ...utils.logging import get_logger
from ..base import ContainerBase, ContainerRenderable

if TYPE_CHECKING:
    from ...style.subsystem import StylingContext

logger = get_logger(__name__)


class Columns(ContainerBase):
    """Columns layout component that arranges children in multiple columns."""

    def __init__(self, columns: int = 2, gap: int = 1, **kwargs: object) -> None:
        """Initialize the columns layout.

        Args:
            columns: Number of columns to arrange children in.
            gap: Spacing between columns in characters.
            **kwargs: Additional keyword arguments passed to parent.
        """
        super().__init__(**kwargs)
        self.columns = max(1, columns)  # Ensure at least 1 column
        self.gap = max(0, gap)  # Ensure non-negative gap

    @property
    def component_name(self) -> str:
        """Return the component name for styling purposes."""
        return "columns"

    def to_renderable(self, styling_context: StylingContext | None = None) -> ColumnsRenderable:
        """Convert this columns layout to a renderable component.

        Args:
            styling_context: The styling context for this component.

        Returns:
            A ColumnsRenderable instance.
        """
        from ...style.subsystem import StylingContext

        context = styling_context or StylingContext(component_name=self.component_name)
        renderable = ColumnsRenderable(
            component_name=self.component_name,
            styling_context=context,
            columns=self.columns,
            gap=self.gap,
        )

        # Add children to renderable
        for child in self.children:
            renderable.add_child(child.to_renderable(context))

        return renderable


@dataclass(slots=True)
class ColumnsRenderable(ContainerRenderable):
    """Renderable columns layout component."""

    columns: int = 2
    gap: int = 1

    def render(self, console: Console) -> str | list[str] | None:
        """Render the columns layout and all its children.

        Args:
            console: The console to render to.

        Returns:
            The rendered layout as a list of strings.
        """
        logger.log(5, f"Rendering columns: {self.component_name}")  # Use level 5 for TRACE

        # Get resolved style for styling
        _ = self.get_resolved_style(console)

        if not self.children:
            return []

        # Apply column layout logic
        return self._render_columns()

    def _render_columns(self) -> list[str]:
        """Render children arranged in columns.

        Returns:
            List of strings representing the column layout.
        """
        if not self.children:
            return []

        # Get console from the render method context
        console = Console()  # Create a console instance for rendering

        # Calculate column width
        total_width = 80  # Assume terminal width
        total_gap_width = self.gap * (self.columns - 1)
        column_width = max(1, (total_width - total_gap_width) // self.columns)

        # Get content from each child
        column_contents: list[list[str]] = [[] for _ in range(self.columns)]

        # Distribute children across columns
        for i, child in enumerate(self.children):
            column_index = i % self.columns
            child_output = child.render(console)

            if child_output is None:
                continue
            elif isinstance(child_output, str):
                column_contents[column_index].append(child_output)
            elif isinstance(child_output, list):
                column_contents[column_index].extend(child_output)

        # Combine columns with gaps
        result_lines: list[str] = []
        max_lines = max(len(col) for col in column_contents) if column_contents else 0

        for line_idx in range(max_lines):
            line_parts: list[str] = []

            for col_idx, col_content in enumerate(column_contents):
                if line_idx < len(col_content):
                    # Pad/truncate to column width
                    line_part = col_content[line_idx][:column_width].ljust(column_width)
                else:
                    line_part = " " * column_width

                line_parts.append(line_part)

                # Add gap between columns (except after last column)
                if col_idx < self.columns - 1:
                    line_parts.append(" " * self.gap)

            result_lines.append("".join(line_parts).rstrip())

        return result_lines

    def measure(self, console: Console) -> Measure:
        """Measure the columns layout component's preferred size.

        Args:
            console: The console context for measurement.

        Returns:
            Measure object with width and height for the layout.
        """
        logger.log(5, f"Measuring columns: {self.component_name}")  # Use level 5 for TRACE

        if not self.children:
            return Measure(0, 0)

        # Calculate total width
        total_width = 80  # Assume terminal width
        total_gap_width = self.gap * (self.columns - 1)
        column_width = max(1, (total_width - total_gap_width) // self.columns)
        actual_width = self.columns * column_width + total_gap_width

        # Calculate total height (tallest column)
        max_height = 0
        items_per_column = (len(self.children) + self.columns - 1) // self.columns

        for col_start in range(0, len(self.children), items_per_column):
            col_end = min(col_start + items_per_column, len(self.children))
            col_height = 0

            for child in self.children[col_start:col_end]:
                child_measure = child.measure(console)
                col_height += child_measure.height

            max_height = max(max_height, col_height)

        return Measure(actual_width, max_height)


__all__ = ["Columns", "ColumnsRenderable"]
