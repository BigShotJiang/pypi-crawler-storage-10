"""Backward-compatible import for layout base classes."""

from __future__ import annotations

from ..base import LayoutBase

__all__ = ["LayoutBase"]