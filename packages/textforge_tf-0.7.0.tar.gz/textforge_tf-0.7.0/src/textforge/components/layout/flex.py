"""Flex layout component."""

from __future__ import annotations

from dataclasses import dataclass
from typing import TYPE_CHECKING, Literal

from ...core.console import Console, Measure
from ...utils.logging import get_logger
from ..base import ContainerBase, ContainerRenderable

if TYPE_CHECKING:
    from ...style.subsystem import StylingContext

logger = get_logger(__name__)

FlexDirection = Literal["row", "column"]
JustifyContent = Literal["start", "center", "end", "space-between", "space-around", "space-evenly"]
AlignItems = Literal["start", "center", "end", "stretch"]


class Flex(ContainerBase):
    """Flex layout component that arranges children using flexbox principles."""

    def __init__(
        self,
        direction: FlexDirection = "row",
        justify: JustifyContent = "start",
        align: AlignItems = "stretch",
        gap: int = 0,
        wrap: bool = False,
        **kwargs: object,
    ) -> None:
        """Initialize the flex layout.

        Args:
            direction: Direction of the flex layout ("row" or "column").
            justify: How to justify content along the main axis.
            align: How to align items along the cross axis.
            gap: Spacing between flex items.
            wrap: Whether items should wrap to new lines.
            **kwargs: Additional keyword arguments passed to parent.
        """
        super().__init__(**kwargs)
        self.direction = direction
        self.justify = justify
        self.align = align
        self.gap = max(0, gap)
        self.wrap = wrap

    @property
    def component_name(self) -> str:
        """Return the component name for styling purposes."""
        return "flex"

    def to_renderable(self, styling_context: StylingContext | None = None) -> FlexRenderable:
        """Convert this flex layout to a renderable component.

        Args:
            styling_context: The styling context for this component.

        Returns:
            A FlexRenderable instance.
        """
        from ...style.subsystem import StylingContext

        context = styling_context or StylingContext(component_name=self.component_name)
        renderable = FlexRenderable(
            component_name=self.component_name,
            styling_context=context,
            direction=self.direction,
            justify=self.justify,
            align=self.align,
            gap=self.gap,
            wrap=self.wrap,
        )

        # Add children to renderable
        for child in self.children:
            renderable.add_child(child.to_renderable(context))

        return renderable


@dataclass(slots=True)
class FlexRenderable(ContainerRenderable):
    """Renderable flex layout component."""

    direction: FlexDirection = "row"
    justify: JustifyContent = "start"
    align: AlignItems = "stretch"
    gap: int = 0
    wrap: bool = False

    def render(self, console: Console) -> str | list[str] | None:
        """Render the flex layout and all its children.

        Args:
            console: The console to render to.

        Returns:
            The rendered layout as a list of strings.
        """
        logger.log(5, f"Rendering flex: {self.component_name}")  # Use level 5 for TRACE

        # Get resolved style for styling
        _ = self.get_resolved_style(console)

        if not self.children:
            return []

        # For now, implement a simple row layout
        # A full flexbox implementation would be much more complex
        return self._render_simple_flex()

    def _render_simple_flex(self) -> list[str]:
        """Render children in a simple flex layout.

        Returns:
            List of strings representing the flex layout.
        """
        if not self.children:
            return []

        # Get console from the render method context
        console = Console()  # Create a console instance for rendering

        if self.direction == "column":
            # Stack children vertically
            result_lines: list[str] = []
            for child in self.children:
                child_output = child.render(console)
                if child_output is None:
                    continue
                elif isinstance(child_output, str):
                    result_lines.append(child_output)
                elif isinstance(child_output, list):
                    result_lines.extend(child_output)

                # Add gap between items
                if self.gap > 0:
                    result_lines.append("")

            # Remove trailing empty line if gap was added
            if result_lines and result_lines[-1] == "":
                result_lines.pop()

            return result_lines
        else:
            # Simple row layout - concatenate horizontally with gaps
            result_parts: list[str] = []
            for i, child in enumerate(self.children):
                child_output = child.render(console)
                if child_output is None:
                    continue

                # Get first line of child output
                if isinstance(child_output, str):
                    child_line = child_output
                elif isinstance(child_output, list) and child_output:
                    child_line = child_output[0]
                else:
                    continue

                result_parts.append(child_line)

                # Add gap between items (except after last)
                if i < len(self.children) - 1 and self.gap > 0:
                    result_parts.append(" " * self.gap)

            return ["".join(result_parts)]

    def measure(self, console: Console) -> Measure:
        """Measure the flex layout component's preferred size.

        Args:
            console: The console context for measurement.

        Returns:
            Measure object with width and height for the layout.
        """
        logger.log(5, f"Measuring flex: {self.component_name}")  # Use level 5 for TRACE

        if not self.children:
            return Measure(0, 0)

        if self.direction == "column":
            # Stack vertically
            total_width = 0
            total_height = 0

            for child in self.children:
                child_measure = child.measure(console)
                total_width = max(total_width, child_measure.width)
                total_height += child_measure.height

            # Add gaps
            if self.children:
                total_height += self.gap * (len(self.children) - 1)

            return Measure(total_width, total_height)
        else:
            # Arrange horizontally
            total_width = 0
            max_height = 0

            for child in self.children:
                child_measure = child.measure(console)
                total_width += child_measure.width
                max_height = max(max_height, child_measure.height)

            # Add gaps
            if self.children:
                total_width += self.gap * (len(self.children) - 1)

            return Measure(total_width, max_height)


__all__ = ["Flex", "FlexRenderable"]
