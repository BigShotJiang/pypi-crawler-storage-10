"""Backward-compatible import for status base classes."""

from __future__ import annotations

from ..base import StatusBase

__all__ = ["StatusBase"]