"""Progress bar component for displaying completion status."""

from __future__ import annotations

from typing import TYPE_CHECKING

from ...core.console import Console, Measure
from ...renderers.gui.types import GuiNode
from ...utils.logging import get_logger
from ..base import RenderableComponent, StatusBase

if TYPE_CHECKING:
    from ...style.subsystem import StylingContext

logger = get_logger(__name__)


class ProgressBar(StatusBase):
    """A progress bar component that displays completion percentage.

    The progress bar shows a visual representation of progress from 0% to 100%.
    """

    def __init__(self, progress: float = 0.0, width: int = 20, show_percentage: bool = True, **kwargs: object) -> None:
        """Initialize the progress bar component.

        Args:
            progress: Current progress as a float between 0.0 and 1.0.
            width: Width of the progress bar in characters.
            show_percentage: Whether to display the percentage text.
            **kwargs: Additional keyword arguments passed to parent.
        """
        super().__init__(**kwargs)
        self.progress = max(0.0, min(1.0, progress))  # Clamp to [0, 1]
        self.width = max(1, width)
        self.show_percentage = show_percentage

    @property
    def component_name(self) -> str:
        """Return the component name for styling purposes."""
        return "progress_bar"

    def set_progress(self, progress: float) -> None:
        """Update the progress value.

        Args:
            progress: New progress value between 0.0 and 1.0.
        """
        self.progress = max(0.0, min(1.0, progress))

    def to_renderable(self, styling_context: StylingContext | None = None) -> ProgressBarRenderable:
        """Convert this progress bar to a renderable component.

        Args:
            styling_context: The styling context for this component.

        Returns:
            A renderable progress bar component instance.
        """
        from ...style.subsystem import StylingContext

        context = styling_context or StylingContext(component_name=self.component_name)
        return ProgressBarRenderable(
            component_name=self.component_name,
            styling_context=context,
            progress=self.progress,
            width=self.width,
            show_percentage=self.show_percentage,
        )


class ProgressBarRenderable(RenderableComponent):
    """Renderable progress bar component."""

    def __init__(
        self,
        component_name: str,
        styling_context: StylingContext,
        progress: float,
        width: int,
        show_percentage: bool,
    ) -> None:
        """Initialize the renderable progress bar.

        Args:
            component_name: The component name.
            styling_context: The styling context.
            progress: Current progress value.
            width: Bar width in characters.
            show_percentage: Whether to show percentage.
        """
        super().__init__(component_name, styling_context)
        self.progress = progress
        self.width = width
        self.show_percentage = show_percentage

    def render(self, console: Console) -> str | list[str] | None:
        """Render the progress bar.

        Args:
            console: The console to render to.

        Returns:
            The rendered progress bar as a string.
        """
        logger.log(5, f"Rendering progress bar: {self.component_name}")  # Use level 5 for TRACE

        # Get resolved style for styling
        _ = self.get_resolved_style(console)

        filled_width = int(self.progress * self.width)
        bar = "█" * filled_width + "░" * (self.width - filled_width)

        if self.show_percentage:
            percentage = f"{self.progress * 100:.1f}%"
            display_text = f"[{bar}] {percentage}"
        else:
            display_text = f"[{bar}]"

        return display_text

    def measure(self, console: Console) -> Measure:
        """Measure the progress bar's preferred size.

        Args:
            console: The console context for measurement.

        Returns:
            Measure object with width and height for the progress bar.
        """
        logger.log(5, f"Measuring progress bar: {self.component_name}")  # Use level 5 for TRACE

        if self.show_percentage:
            text_width = self.width + 2 + 6  # [bar] + space + 100.0%
        else:
            text_width = self.width + 2  # [bar]

        return Measure(text_width, 1)

    def to_node(self, console: Console) -> GuiNode:
        """Convert the progress bar into a GUI node.

        Args:
            console: Console context used for style resolution.

        Returns:
            GuiNode: Node populated with progress metadata for GUI rendering.
        """

        node = super().to_node(console)
        node.state["clamp"] = True
        percentage_text = f"{self.progress * 100:.1f}%"
        node.children.append(GuiNode("progress_fill", text=percentage_text))
        if self.show_percentage:
            node.children.append(GuiNode("progress_label", text=percentage_text))
        return node


__all__ = ["ProgressBar", "ProgressBarRenderable"]
