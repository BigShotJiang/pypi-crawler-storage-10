"""Gauge component for displaying values within a range."""

from __future__ import annotations

from typing import TYPE_CHECKING

from ...core.console import Console, Measure
from ...utils.logging import get_logger
from ..base import RenderableComponent, StatusBase

if TYPE_CHECKING:
    from ...style.subsystem import StylingContext

logger = get_logger(__name__)


class Gauge(StatusBase):
    """A gauge component that displays a value within a specified range.

    The gauge shows a visual representation of a value between minimum and maximum,
    similar to a progress bar but with customizable range and labels.
    """

    def __init__(
        self,
        value: float = 0.0,
        min_value: float = 0.0,
        max_value: float = 100.0,
        width: int = 20,
        show_value: bool = True,
        label: str = "",
        **kwargs: object,
    ) -> None:
        """Initialize the gauge component.

        Args:
            value: Current value to display.
            min_value: Minimum value of the range.
            max_value: Maximum value of the range.
            width: Width of the gauge bar in characters.
            show_value: Whether to display the numeric value.
            label: Optional label text to display.
            **kwargs: Additional keyword arguments passed to parent.
        """
        super().__init__(**kwargs)
        if min_value >= max_value:
            raise ValueError("min_value must be less than max_value")

        self.value = max(min_value, min(max_value, value))
        self.min_value = min_value
        self.max_value = max_value
        self.width = max(1, width)
        self.show_value = show_value
        self.label = label

    @property
    def component_name(self) -> str:
        """Return the component name for styling purposes."""
        return "gauge"

    def set_value(self, value: float) -> None:
        """Update the gauge value.

        Args:
            value: New value to set, clamped to the valid range.
        """
        self.value = max(self.min_value, min(self.max_value, value))

    def get_percentage(self) -> float:
        """Get the current value as a percentage (0.0 to 1.0).

        Returns:
            The percentage value.
        """
        return (self.value - self.min_value) / (self.max_value - self.min_value)

    def to_renderable(self, styling_context: StylingContext | None = None) -> GaugeRenderable:
        """Convert this gauge to a renderable component.

        Args:
            styling_context: The styling context for this component.

        Returns:
            A renderable gauge component instance.
        """
        from ...style.subsystem import StylingContext

        context = styling_context or StylingContext(component_name=self.component_name)
        return GaugeRenderable(
            component_name=self.component_name,
            styling_context=context,
            value=self.value,
            min_value=self.min_value,
            max_value=self.max_value,
            width=self.width,
            show_value=self.show_value,
            label=self.label,
        )


class GaugeRenderable(RenderableComponent):
    """Renderable gauge component."""

    def __init__(
        self,
        component_name: str,
        styling_context: StylingContext,
        value: float,
        min_value: float,
        max_value: float,
        width: int,
        show_value: bool,
        label: str,
    ) -> None:
        """Initialize the renderable gauge.

        Args:
            component_name: The component name.
            styling_context: The styling context.
            value: Current value.
            min_value: Minimum value.
            max_value: Maximum value.
            width: Bar width in characters.
            show_value: Whether to show the numeric value.
            label: Label text.
        """
        super().__init__(component_name, styling_context)
        self.value = value
        self.min_value = min_value
        self.max_value = max_value
        self.width = width
        self.show_value = show_value
        self.label = label

    def render(self, console: Console) -> str | list[str] | None:
        """Render the gauge.

        Args:
            console: The console to render to.

        Returns:
            The rendered gauge as a string.
        """
        logger.log(5, f"Rendering gauge: {self.component_name}")  # Use level 5 for TRACE

        # Get resolved style for styling
        _ = self.get_resolved_style(console)

        percentage = (self.value - self.min_value) / (self.max_value - self.min_value)
        filled_width = int(percentage * self.width)
        bar = "█" * filled_width + "░" * (self.width - filled_width)

        parts: list[str] = []
        if self.label:
            parts.append(f"{self.label}: ")
        parts.append(f"[{bar}]")
        if self.show_value:
            parts.append(f" {self.value:.1f}")

        display_text = "".join(parts)
        return display_text

    def measure(self, console: Console) -> Measure:
        """Measure the gauge's preferred size.

        Args:
            console: The console context for measurement.

        Returns:
            Measure object with width and height for the gauge.
        """
        logger.log(5, f"Measuring gauge: {self.component_name}")  # Use level 5 for TRACE

        label_width = len(self.label) + 2 if self.label else 0  # label:
        bar_width = self.width + 2  # [bar]
        value_width = 6 if self.show_value else 0  # space + 100.0

        text_width = label_width + bar_width + value_width
        return Measure(text_width, 1)


__all__ = ["Gauge", "GaugeRenderable"]
