"""Spinner component for displaying loading states."""

from __future__ import annotations

import time
from typing import TYPE_CHECKING

from ...core.console import Console, Measure
from ...utils.logging import get_logger
from ..base import RenderableComponent, StatusBase

if TYPE_CHECKING:
    from ...style.subsystem import StylingContext

logger = get_logger(__name__)


class Spinner(StatusBase):
    """A spinner component that displays an animated loading indicator.

    The spinner cycles through different characters to show ongoing activity.
    """

    SPINNER_CHARS = ["⠋", "⠙", "⠹", "⠸", "⠼", "⠴", "⠦", "⠧", "⠇", "⠏"]

    def __init__(self, text: str = "Loading...", speed: float = 0.1, **kwargs: object) -> None:
        """Initialize the spinner component.

        Args:
            text: Text to display alongside the spinner.
            speed: Animation speed in seconds per frame.
            **kwargs: Additional keyword arguments passed to parent.
        """
        super().__init__(**kwargs)
        self.text = text
        self.speed = speed
        self._start_time = time.perf_counter()

    @property
    def component_name(self) -> str:
        """Return the component name for styling purposes."""
        return "spinner"

    def to_renderable(self, styling_context: StylingContext | None = None) -> SpinnerRenderable:
        """Convert this spinner to a renderable component.

        Args:
            styling_context: The styling context for this component.

        Returns:
            A renderable spinner component instance.
        """
        from ...style.subsystem import StylingContext

        context = styling_context or StylingContext(component_name=self.component_name)
        return SpinnerRenderable(
            component_name=self.component_name,
            styling_context=context,
            text=self.text,
            speed=self.speed,
            start_time=self._start_time,
        )


class SpinnerRenderable(RenderableComponent):
    """Renderable spinner component with animation state."""

    def __init__(
        self,
        component_name: str,
        styling_context: StylingContext,
        text: str,
        speed: float,
        start_time: float,
    ) -> None:
        """Initialize the renderable spinner.

        Args:
            component_name: The component name.
            styling_context: The styling context.
            text: Text to display.
            speed: Animation speed.
            start_time: Animation start time.
        """
        super().__init__(component_name, styling_context)
        self.text = text
        self.speed = speed
        self.start_time = start_time

    def render(self, console: Console) -> str | list[str] | None:
        """Render the spinner with current animation frame.

        Args:
            console: The console to render to.

        Returns:
            The rendered spinner as a string.
        """
        logger.log(5, f"Rendering spinner: {self.component_name}")  # Use level 5 for TRACE

        # Get resolved style for styling
        _ = self.get_resolved_style(console)

        current_time = time.perf_counter()
        elapsed = current_time - self.start_time
        frame_index = int(elapsed / self.speed) % len(Spinner.SPINNER_CHARS)
        spinner_char = Spinner.SPINNER_CHARS[frame_index]

        display_text = f"{spinner_char} {self.text}"
        return display_text

    def measure(self, console: Console) -> Measure:
        """Measure the spinner's preferred size.

        Args:
            console: The console context for measurement.

        Returns:
            Measure object with width and height for the spinner.
        """
        logger.log(5, f"Measuring spinner: {self.component_name}")  # Use level 5 for TRACE

        text_width = len(f"⠋ {self.text}")  # Use widest spinner char for measurement
        return Measure(text_width, 1)


__all__ = ["Spinner", "SpinnerRenderable"]
