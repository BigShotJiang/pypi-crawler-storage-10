"""Text component for displaying text content."""

from __future__ import annotations

from typing import TYPE_CHECKING

from ..core.console import Console, Measure
from .base import Component, RenderableComponent

if TYPE_CHECKING:
    from ..renderers.gui.types import GuiNode
    from ..style.subsystem import StylingContext


class Text(Component):
    """A component for displaying text content."""

    def __init__(self, content: str, **kwargs: object) -> None:
        """Initialize the text component.

        Args:
            content: The text content to display.
            **kwargs: Additional keyword arguments passed to parent class.
        """
        super().__init__(**kwargs)
        self.content = content

    @property
    def component_name(self) -> str:
        """Return the component name for styling purposes."""
        return "text"

    def to_renderable(self, styling_context: StylingContext | None = None) -> TextRenderable:
        """Convert this component to a renderable text component.

        Args:
            styling_context: Optional styling context for this component.

        Returns:
            A TextRenderable instance.
        """
        from ..style.subsystem import StylingContext

        context = styling_context or StylingContext(component_name=self.component_name)
        return TextRenderable(
            component_name=self.component_name,
            styling_context=context,
            content=self.content,
        )


class TextRenderable(RenderableComponent):
    """Renderable text component."""

    def __init__(self, component_name: str, styling_context: StylingContext | None, content: str) -> None:
        """Initialize the renderable text component.

        Args:
            component_name: The name of the component.
            styling_context: The styling context.
            content: The text content to render.
        """
        super().__init__(component_name, styling_context)
        self.content = content

    def render(self, console: Console) -> str | list[str] | None:
        """Render the text content to output.

        Args:
            console: The console context for rendering.

        Returns:
            The rendered text content as a string or list of strings.
        """
        # Get resolved style for future styling (currently not used)
        _ = self.get_resolved_style(console)

        # Handle multi-line text
        if "\n" in self.content:
            return self.content.split("\n")
        else:
            return self.content

    def measure(self, console: Console) -> Measure:
        """Measure the text component's dimensions.

        Args:
            console: The console context for measurement.

        Returns:
            Measure object with width and height for the text.
        """
        lines = self.content.split("\n")
        width = max(len(line) for line in lines) if lines else 0
        height = len(lines)

        return Measure(width, height)

    def to_node(self, console: Console) -> GuiNode:
        """Convert the text component into a GUI node.

        Args:
            console: Console context used for style resolution.

        Returns:
            GuiNode: Node populated with text content for GUI rendering.
        """

        node = super().to_node(console)
        node.text = self.content
        return node


__all__ = ["Text", "TextRenderable"]
