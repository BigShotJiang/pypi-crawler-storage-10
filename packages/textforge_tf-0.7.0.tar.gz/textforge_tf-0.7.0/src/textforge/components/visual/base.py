"""Backward-compatible import for visual base classes."""

from __future__ import annotations

from ..base import VisualBase

__all__ = ["VisualBase"]