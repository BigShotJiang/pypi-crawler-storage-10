"""Image component for displaying visual images."""

from __future__ import annotations

from typing import TYPE_CHECKING

from ...core.console import Console, Measure
from ...utils.logging import get_logger
from ..base import RenderableComponent, VisualBase

if TYPE_CHECKING:
    from ...style.subsystem import StylingContext

logger = get_logger(__name__)


class Image(VisualBase):
    """Component for displaying images.

    The Image component supports various image formats and provides
    scaling, positioning, and styling capabilities for visual content.
    """

    def __init__(self, src: str, alt: str = "", width: int | None = None, height: int | None = None, **kwargs: object) -> None:
        """Initialize an Image component.

        Args:
            src: Path or URL to the image source.
            alt: Alternative text for accessibility.
            width: Optional width constraint.
            height: Optional height constraint.
            **kwargs: Additional keyword arguments passed to parent.
        """
        super().__init__(**kwargs)
        self.src = src
        self.alt = alt
        self.width = width
        self.height = height

    @property
    def component_name(self) -> str:
        """Return the component name for styling purposes."""
        return "image"

    def to_renderable(self, styling_context: StylingContext | None = None) -> ImageRenderable:
        """Convert this image to a renderable component.

        Args:
            styling_context: Optional styling context for this component.

        Returns:
            An ImageRenderable instance.
        """
        from ...style.subsystem import StylingContext

        context = styling_context or StylingContext(component_name=self.component_name)
        return ImageRenderable(
            component_name=self.component_name,
            styling_context=context,
            src=self.src,
            alt=self.alt,
            width=self.width,
            height=self.height,
        )


class ImageRenderable(RenderableComponent):
    """Renderable image component."""

    def __init__(
        self,
        component_name: str,
        styling_context: StylingContext,
        src: str,
        alt: str,
        width: int | None,
        height: int | None,
    ) -> None:
        """Initialize the renderable image component.

        Args:
            component_name: The component name.
            styling_context: The styling context.
            src: Image source.
            alt: Alt text.
            width: Image width.
            height: Image height.
        """
        super().__init__(component_name, styling_context)
        self.src = src
        self.alt = alt
        self.width = width
        self.height = height

    def render(self, console: Console) -> str | list[str] | None:
        """Render the image component.

        Args:
            console: The console to render to.

        Returns:
            The rendered image as a placeholder string.
        """
        logger.log(5, f"Rendering image: {self.component_name}")  # Use level 5 for TRACE

        # Get resolved style for styling
        _ = self.get_resolved_style(console)

        # For now, render as ASCII placeholder
        img_width = self.width or 20
        img_height = self.height or 10

        lines: list[str] = []
        lines.append("┌" + "─" * (img_width - 2) + "┐")

        for _ in range(img_height - 2):
            lines.append("│" + "█" * (img_width - 2) + "│")

        lines.append("└" + "─" * (img_width - 2) + "┘")

        # Add alt text if present
        if self.alt:
            lines.append(f"[{self.alt}]")

        return lines

    def measure(self, console: Console) -> Measure:
        """Measure the image component's preferred size.

        Args:
            console: The console context for measurement.

        Returns:
            Measure object with width and height for the image.
        """
        logger.log(5, f"Measuring image: {self.component_name}")  # Use level 5 for TRACE

        # Default image size if not specified
        img_width = self.width or 22  # Account for borders
        img_height = self.height or 12  # Account for borders and alt text

        # Add space for alt text
        if self.alt:
            img_height += 1

        return Measure(img_width, img_height)


__all__ = ["Image", "ImageRenderable"]
