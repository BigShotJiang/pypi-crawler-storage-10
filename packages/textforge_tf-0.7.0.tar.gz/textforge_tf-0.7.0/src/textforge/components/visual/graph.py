"""Graph component for displaying data visualizations."""

from __future__ import annotations

from typing import TYPE_CHECKING, Any

from ...core.console import Console, Measure
from ...utils.logging import get_logger
from ..base import RenderableComponent, VisualBase

if TYPE_CHECKING:
    from ...style.subsystem import StylingContext

logger = get_logger(__name__)


class Graph(VisualBase):
    """Component for displaying data visualizations and charts.

    The Graph component supports various chart types like line graphs,
    bar charts, pie charts, and scatter plots for data visualization.
    """

    def __init__(
        self,
        data: list[dict[str, Any]] | dict[str, Any],
        graph_type: str = "line",
        width: int | None = None,
        height: int | None = None,
        title: str = "",
        **kwargs: object,
    ) -> None:
        """Initialize a Graph component.

        Args:
            data: Graph data as list of points or structured data.
            graph_type: Type of graph ('line', 'bar', 'pie', 'scatter').
            width: Optional width constraint.
            height: Optional height constraint.
            title: Optional graph title.
            **kwargs: Additional keyword arguments passed to parent.
        """
        super().__init__(**kwargs)
        self.data = data
        self.graph_type = graph_type
        self.width = width
        self.height = height
        self.title = title

    @property
    def component_name(self) -> str:
        """Return the component name for styling purposes."""
        return "graph"

    def to_renderable(self, styling_context: StylingContext | None = None) -> GraphRenderable:
        """Convert this graph to a renderable component.

        Args:
            styling_context: Optional styling context for this component.

        Returns:
            A GraphRenderable instance.
        """
        from ...style.subsystem import StylingContext

        context = styling_context or StylingContext(component_name=self.component_name)
        return GraphRenderable(
            component_name=self.component_name,
            styling_context=context,
            data=self.data,
            graph_type=self.graph_type,
            width=self.width,
            height=self.height,
            title=self.title,
        )


class GraphRenderable(RenderableComponent):
    """Renderable graph component."""

    def __init__(
        self,
        component_name: str,
        styling_context: StylingContext,
        data: list[dict[str, Any]] | dict[str, Any],
        graph_type: str,
        width: int | None,
        height: int | None,
        title: str,
    ) -> None:
        """Initialize the renderable graph component.

        Args:
            component_name: The component name.
            styling_context: The styling context.
            data: Graph data.
            graph_type: Type of graph.
            width: Graph width.
            height: Graph height.
            title: Graph title.
        """
        super().__init__(component_name, styling_context)
        self.data = data
        self.graph_type = graph_type
        self.width = width
        self.height = height
        self.title = title

    def render(self, console: Console) -> str | list[str] | None:
        """Render the graph component.

        Args:
            console: The console to render to.

        Returns:
            The rendered graph as a list of strings.
        """
        logger.log(5, f"Rendering graph: {self.component_name}")  # Use level 5 for TRACE

        # Get resolved style for styling
        _ = self.get_resolved_style(console)

        # Simple graph rendering
        lines: list[str] = []

        # Add title if present
        if self.title:
            lines.append(f"┌─ {self.title} ─" + "─" * 50 + "┐")
        else:
            lines.append("┌" + "─" * 60 + "┐")

        # Graph area (placeholder)
        graph_height = self.height or 10
        graph_width = self.width or 60

        for _ in range(graph_height):
            lines.append("│" + " " * graph_width + "│")

        lines.append("└" + "─" * graph_width + "┘")

        # Add data info
        if isinstance(self.data, list) and self.data:
            lines.append(f"Data points: {len(self.data)}")
        elif isinstance(self.data, dict):
            lines.append(f"Graph type: {self.graph_type}")
        else:
            lines.append("No data")

        return lines

    def measure(self, console: Console) -> Measure:
        """Measure the graph component's preferred size.

        Args:
            console: The console context for measurement.

        Returns:
            Measure object with width and height for the graph.
        """
        logger.log(5, f"Measuring graph: {self.component_name}")  # Use level 5 for TRACE

        graph_width = self.width or 62  # Account for borders
        graph_height = self.height or 15  # Account for borders and title

        # Add space for title and data info
        if self.title:
            graph_height += 1
        graph_height += 1  # Data info line

        return Measure(graph_width, graph_height)


__all__ = ["Graph", "GraphRenderable"]
