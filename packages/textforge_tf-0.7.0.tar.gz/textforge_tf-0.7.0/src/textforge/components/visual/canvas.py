"""Canvas component for custom drawing and graphics."""

from __future__ import annotations

from typing import TYPE_CHECKING, Any

from ...core.console import Console, Measure
from ...utils.logging import get_logger
from ..base import RenderableComponent, VisualBase

if TYPE_CHECKING:
    from collections.abc import Callable

    from ...style.subsystem import StylingContext

logger = get_logger(__name__)


class Canvas(VisualBase):
    """Component for custom drawing and graphics rendering.

    The Canvas component provides a drawing surface where custom graphics
    can be rendered using a drawing API. It's useful for charts, diagrams,
    and custom visual elements.
    """

    def __init__(self, width: int, height: int, draw_function: Callable[[], None] | None = None, **kwargs: object) -> None:
        """Initialize a Canvas component.

        Args:
            width: Canvas width in pixels/cells.
            height: Canvas height in pixels/cells.
            draw_function: Optional function to draw on the canvas.
            **kwargs: Additional keyword arguments passed to parent.
        """
        super().__init__(**kwargs)
        self.width = width
        self.height = height
        self.draw_function = draw_function

    @property
    def component_name(self) -> str:
        """Return the component name for styling purposes."""
        return "canvas"

    def to_renderable(self, styling_context: StylingContext | None = None) -> CanvasRenderable:
        """Convert this canvas to a renderable component.

        Args:
            styling_context: The styling context for this component.

        Returns:
            A CanvasRenderable instance.
        """
        from ...style.subsystem import StylingContext

        context = styling_context or StylingContext(component_name=self.component_name)
        renderable = CanvasRenderable(
            component_name=self.component_name,
            styling_context=context,
            width=self.width,
            height=self.height,
            draw_function=self.draw_function,
        )

        # Execute draw function to populate commands
        if renderable.draw_function:
            renderable.draw_function()

        return renderable


class CanvasRenderable(RenderableComponent):
    """Renderable canvas component."""

    def __init__(
        self,
        component_name: str,
        styling_context: StylingContext,
        width: int,
        height: int,
        draw_function: Callable[[], None] | None,
    ) -> None:
        """Initialize the renderable canvas component.

        Args:
            component_name: The component name.
            styling_context: The styling context.
            width: Canvas width.
            height: Canvas height.
            draw_function: Optional draw function.
        """
        super().__init__(component_name, styling_context)
        self.width = width
        self.height = height
        self.draw_function = draw_function
        self._drawing_commands: list[dict[str, Any]] = []

    def draw_line(self, x1: int, y1: int, x2: int, y2: int, color: str = "white") -> None:
        """Draw a line on the canvas.

        Args:
            x1: Starting X coordinate.
            y1: Starting Y coordinate.
            x2: Ending X coordinate.
            y2: Ending Y coordinate.
            color: Line color.
        """
        self._drawing_commands.append({"type": "line", "x1": x1, "y1": y1, "x2": x2, "y2": y2, "color": color})

    def draw_rect(self, x: int, y: int, width: int, height: int, color: str = "white", filled: bool = False) -> None:
        """Draw a rectangle on the canvas.

        Args:
            x: X coordinate of top-left corner.
            y: Y coordinate of top-left corner.
            width: Rectangle width.
            height: Rectangle height.
            color: Rectangle color.
            filled: Whether to fill the rectangle.
        """
        self._drawing_commands.append({"type": "rect", "x": x, "y": y, "width": width, "height": height, "color": color, "filled": filled})

    def draw_circle(self, x: int, y: int, radius: int, color: str = "white", filled: bool = False) -> None:
        """Draw a circle on the canvas.

        Args:
            x: X coordinate of center.
            y: Y coordinate of center.
            radius: Circle radius.
            color: Circle color.
            filled: Whether to fill the circle.
        """
        self._drawing_commands.append({"type": "circle", "x": x, "y": y, "radius": radius, "color": color, "filled": filled})

    def render(self, console: Console) -> str | list[str] | None:
        """Render the canvas component.

        Args:
            console: The console to render to.

        Returns:
            The rendered canvas as a list of strings.
        """
        logger.log(5, f"Rendering canvas: {self.component_name}")  # Use level 5 for TRACE

        # Get resolved style for styling
        _ = self.get_resolved_style(console)

        # Create empty canvas
        canvas_lines: list[str] = []
        for _ in range(self.height):
            canvas_lines.append(" " * self.width)

        # Execute drawing commands
        for command in self._drawing_commands:
            self._execute_draw_command(canvas_lines, command)

        # Add border
        bordered_lines: list[str] = []
        bordered_lines.append("┌" + "─" * self.width + "┐")
        for line in canvas_lines:
            bordered_lines.append("│" + line + "│")
        bordered_lines.append("└" + "─" * self.width + "┘")

        return bordered_lines

    def _execute_draw_command(self, canvas_lines: list[str], command: dict[str, Any]) -> None:
        """Execute a single drawing command.

        Args:
            canvas_lines: The canvas lines to modify.
            command: The drawing command to execute.
        """
        cmd_type = command["type"]

        if cmd_type == "line":
            self._draw_line(canvas_lines, command)
        elif cmd_type == "rect":
            self._draw_rect(canvas_lines, command)
        elif cmd_type == "circle":
            self._draw_circle(canvas_lines, command)

    def _draw_line(self, canvas_lines: list[str], command: dict[str, Any]) -> None:
        """Draw a line on the canvas."""
        x1, y1, x2, y2 = command["x1"], command["y1"], command["x2"], command["y2"]

        # Simple line drawing (Bresenham's algorithm would be better)
        if abs(x2 - x1) > abs(y2 - y1):
            # Horizontal-ish line
            for x in range(min(x1, x2), max(x1, x2) + 1):
                y = y1 + (y2 - y1) * (x - x1) // (x2 - x1) if x2 != x1 else y1
                if 0 <= x < self.width and 0 <= y < self.height:
                    canvas_lines[y] = canvas_lines[y][:x] + "█" + canvas_lines[y][x+1:]
        else:
            # Vertical-ish line
            for y in range(min(y1, y2), max(y1, y2) + 1):
                x = x1 + (x2 - x1) * (y - y1) // (y2 - y1) if y2 != y1 else x1
                if 0 <= x < self.width and 0 <= y < self.height:
                    canvas_lines[y] = canvas_lines[y][:x] + "█" + canvas_lines[y][x+1:]

    def _draw_rect(self, canvas_lines: list[str], command: dict[str, Any]) -> None:
        """Draw a rectangle on the canvas."""
        x, y, width, height = command["x"], command["y"], command["width"], command["height"]
        filled = command.get("filled", False)

        for dy in range(height):
            for dx in range(width):
                if filled or dy == 0 or dy == height - 1 or dx == 0 or dx == width - 1:
                    px, py = x + dx, y + dy
                    if 0 <= px < self.width and 0 <= py < self.height:
                        canvas_lines[py] = canvas_lines[py][:px] + "█" + canvas_lines[py][px+1:]

    def _draw_circle(self, canvas_lines: list[str], command: dict[str, Any]) -> None:
        """Draw a circle on the canvas."""
        x, y, radius = command["x"], command["y"], command["radius"]
        filled = command.get("filled", False)

        for dy in range(-radius, radius + 1):
            for dx in range(-radius, radius + 1):
                if filled:
                    dist_sq = dx * dx + dy * dy
                    if dist_sq <= radius * radius:
                        px, py = x + dx, y + dy
                        if 0 <= px < self.width and 0 <= py < self.height:
                            canvas_lines[py] = canvas_lines[py][:px] + "█" + canvas_lines[py][px+1:]
                else:
                    # Outline only
                    dist = (dx * dx + dy * dy) ** 0.5
                    if abs(dist - radius) < 1:
                        px, py = x + dx, y + dy
                        if 0 <= px < self.width and 0 <= py < self.height:
                            canvas_lines[py] = canvas_lines[py][:px] + "█" + canvas_lines[py][px+1:]

    def measure(self, console: Console) -> Measure:
        """Measure the canvas component's preferred size.

        Args:
            console: The console context for measurement.

        Returns:
            Measure object with width and height for the canvas.
        """
        logger.log(5, f"Measuring canvas: {self.component_name}")  # Use level 5 for TRACE

        # Account for borders
        width = self.width + 2
        height = self.height + 2

        return Measure(width, height)


__all__ = ["Canvas", "CanvasRenderable"]
