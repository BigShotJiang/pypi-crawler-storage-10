"""Button interactive component."""

from __future__ import annotations

from typing import TYPE_CHECKING, Any

from ...core.console import Console, Measure
from ..base import RenderableComponent
from .base import InteractiveBase

if TYPE_CHECKING:
    from collections.abc import Callable

    from ...renderers.gui.types import GuiNode
    from ...style.subsystem import StylingContext


class Button(InteractiveBase):
    """An interactive button component with event handling capabilities."""

    def __init__(self, label: str, on_click: Callable[[Any], None] | None = None, **kwargs: object) -> None:
        """Initialize the button component.

        Args:
            label: The button label text.
            on_click: Optional callback function for click events.
            **kwargs: Additional keyword arguments passed to the parent class.
        """
        # Store the label and callback
        self.label = label
        self._on_click = on_click

        # Initialize the parent class
        super().__init__(**kwargs)

    @property
    def component_name(self) -> str:
        """Return the component name for styling purposes."""
        return "button"

    def to_renderable(self, styling_context: StylingContext | None = None) -> ButtonRenderable:
        """Convert this button to a renderable button.

        Args:
            styling_context: The styling context for this component.

        Returns:
            A ButtonRenderable instance.
        """
        from ...style.subsystem import StylingContext

        context = styling_context or StylingContext(component_name=self.component_name)
        return ButtonRenderable(
            component_name=self.component_name,
            styling_context=context,
            label=self.label,
            on_click=self._on_click,
        )

    def handle_click(self, event_data: object | None = None) -> None:
        """Handle a click event by calling the on_click callback if provided.

        Args:
            event_data: Optional event data.
        """
        super().handle_click(event_data)
        if self._on_click:
            try:
                self._on_click(event_data)
            except Exception as e:
                # Log error but don't crash
                from ...utils.logging import get_logger

                logger = get_logger(__name__)
                logger.error(f"Error in button click handler: {e}")


class ButtonRenderable(RenderableComponent):
    """Renderable button interactive component with event handling."""

    def __init__(self, component_name: str, styling_context: StylingContext, label: str, on_click: Callable[[Any], None] | None) -> None:
        """Initialize the renderable button component.

        Args:
            component_name: The name of the component.
            styling_context: The styling context.
            label: The button label.
            on_click: Optional click callback.
        """
        super().__init__(component_name, styling_context)
        self.label = label
        self.on_click = on_click

    def render(self, console: Console) -> str | list[str] | None:
        """Render the button component with states (normal/hover/pressed).

        Args:
            console: The console to render to.

        Returns:
            The rendered button as a string.
        """
        # Get resolved style for button appearance
        resolved_style = self.get_resolved_style(console)

        # Determine button style based on state
        # For now, use normal state - interactive state management would be handled by event system
        button_style = getattr(resolved_style, "button_style", "normal")

        # Create button with brackets and label
        button_text = f"[ {self.label} ]"
        return button_text

    def measure(self, console: Console) -> Measure:
        """Measure the button component's preferred size.

        Args:
            console: The console context for measurement.

        Returns:
            Measure object with width and height for the button.
        """
        # Button width includes brackets and spaces
        width = len(self.label) + 4  # [ space label space ]
        height = 1  # Single line button
        return Measure(width, height)

    def handle_click(self, event_data: object | None = None) -> None:
        """Handle a click event by calling the callback.

        Args:
            event_data: Optional event data.
        """
        if self.on_click:
            try:
                self.on_click(event_data)
            except Exception as e:
                # Log error but don't crash
                from ...utils.logging import get_logger

                logger = get_logger(__name__)
                logger.error(f"Error in button click handler: {e}")

    def to_node(self, console: Console) -> GuiNode:
        """Convert the button component into a GUI node.

        Args:
            console: Console context used for style resolution.

        Returns:
            GuiNode: Node populated with button label and interaction state.
        """

        node = super().to_node(console)
        node.text = self.label
        node.state["interactive"] = True
        return node
