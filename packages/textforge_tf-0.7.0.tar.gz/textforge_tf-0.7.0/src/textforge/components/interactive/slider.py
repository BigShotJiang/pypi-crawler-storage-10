"""Slider interactive component."""

from __future__ import annotations

from typing import TYPE_CHECKING

from ...core.console import Console, Measure
from ...utils.logging import get_logger
from ..base import InteractiveBase, RenderableComponent

if TYPE_CHECKING:
    from collections.abc import Callable

    from ...style.subsystem import StylingContext

logger = get_logger(__name__)


class Slider(InteractiveBase):
    """An interactive slider component with event handling capabilities."""

    def __init__(
        self,
        min_value: float = 0.0,
        max_value: float = 100.0,
        value: float = 0.0,
        step: float = 1.0,
        on_change: Callable[[float], None] | None = None,
        **kwargs: object,
    ) -> None:
        """Initialize the slider component.

        Args:
            min_value: Minimum value for the slider.
            max_value: Maximum value for the slider.
            value: Current value of the slider.
            step: Step increment for the slider.
            on_change: Optional callback function for value changes.
            **kwargs: Additional keyword arguments passed to the parent class.
        """
        super().__init__(**kwargs)
        self.min_value = min_value
        self.max_value = max_value
        self.value = max(min_value, min(max_value, value))  # Clamp initial value
        self.step = step
        self.on_change = on_change

    @property
    def component_name(self) -> str:
        """Return the component name for styling purposes."""
        return "slider"

    def to_renderable(self, styling_context: StylingContext | None = None) -> SliderRenderable:
        """Convert this slider to a renderable slider.

        Args:
            styling_context: The styling context for this component.

        Returns:
            A SliderRenderable instance.
        """
        from ...style.subsystem import StylingContext

        context = styling_context or StylingContext(component_name=self.component_name)
        return SliderRenderable(
            component_name=self.component_name,
            styling_context=context,
            min_value=self.min_value,
            max_value=self.max_value,
            value=self.value,
            step=self.step,
            on_change=self.on_change,
        )

    def set_value(self, new_value: float) -> None:
        """Set the slider value, clamping it to the valid range.

        Args:
            new_value: The new value to set.
        """
        clamped_value = max(self.min_value, min(self.max_value, new_value))
        if clamped_value != self.value:
            self.value = clamped_value
            if self.on_change:
                try:
                    self.on_change(clamped_value)
                except Exception as e:
                    logger.error(f"Error in slider change handler: {e}")

    def increment(self) -> None:
        """Increment the slider value by one step."""
        self.set_value(self.value + self.step)

    def decrement(self) -> None:
        """Decrement the slider value by one step."""
        self.set_value(self.value - self.step)


class SliderRenderable(RenderableComponent):
    """Renderable slider interactive component with event handling."""

    def __init__(
        self,
        component_name: str,
        styling_context: StylingContext,
        min_value: float,
        max_value: float,
        value: float,
        step: float,
        on_change: Callable[[float], None] | None,
    ) -> None:
        """Initialize the renderable slider component.

        Args:
            component_name: The name of the component.
            styling_context: The styling context.
            min_value: Minimum value.
            max_value: Maximum value.
            value: Current value.
            step: Step increment.
            on_change: Optional change callback.
        """
        super().__init__(component_name, styling_context)
        self.min_value = min_value
        self.max_value = max_value
        self.value = value
        self.step = step
        self.on_change = on_change

    def render(self, console: Console) -> str | list[str] | None:
        """Render the slider component with handle and track rendering.

        Args:
            console: The console to render to.

        Returns:
            The rendered slider as a string.
        """
        logger.log(5, f"Rendering slider: {self.component_name}")  # Use level 5 for TRACE

        # Get resolved style for styling
        _ = self.get_resolved_style(console)

        # Calculate handle position based on value
        if self.max_value > self.min_value:
            ratio = (self.value - self.min_value) / (self.max_value - self.min_value)
            handle_pos = int(ratio * 38)  # Fixed track width
        else:
            handle_pos = 0

        # Create track with handle
        track = "[" + "─" * 38 + "]"
        if handle_pos < 38:
            track_list = list(track)
            track_list[handle_pos + 1] = "●"  # Handle symbol
            track = "".join(track_list)

        # Add value display
        value_display = f" {self.value:.1f}"
        slider_line = track + value_display

        return slider_line

    def measure(self, console: Console) -> Measure:
        """Measure the slider component's preferred size.

        Args:
            console: The console context for measurement.

        Returns:
            Measure object with width and height for the slider.
        """
        logger.log(5, f"Measuring slider: {self.component_name}")  # Use level 5 for TRACE

        width = 45  # [track] + space + value
        height = 1  # Single line slider
        return Measure(width, height)

    def set_value(self, new_value: float) -> None:
        """Set the slider value, clamping it to the valid range.

        Args:
            new_value: The new value to set.
        """
        clamped_value = max(self.min_value, min(self.max_value, new_value))
        if clamped_value != self.value:
            self.value = clamped_value
            if self.on_change:
                try:
                    self.on_change(clamped_value)
                except Exception as e:
                    logger.error(f"Error in slider change handler: {e}")

    def increment(self) -> None:
        """Increment the slider value by one step."""
        self.set_value(self.value + self.step)

    def decrement(self) -> None:
        """Decrement the slider value by one step."""
        self.set_value(self.value - self.step)


__all__ = ["Slider", "SliderRenderable"]
