"""Checkbox interactive component."""

from __future__ import annotations

from typing import TYPE_CHECKING

from ...core.console import Console, Measure
from ...utils.logging import get_logger
from ..base import InteractiveBase, RenderableComponent

if TYPE_CHECKING:
    from collections.abc import Callable

    from ...style.subsystem import StylingContext

logger = get_logger(__name__)


class Checkbox(InteractiveBase):
    """An interactive checkbox component with event handling capabilities."""

    def __init__(self, label: str, checked: bool = False, on_change: Callable[[bool], None] | None = None, **kwargs: object) -> None:
        """Initialize the checkbox component.

        Args:
            label: The checkbox label text.
            checked: Initial checked state.
            on_change: Optional callback function for state changes.
            **kwargs: Additional keyword arguments passed to the parent class.
        """
        super().__init__(**kwargs)
        self.label = label
        self.checked = checked
        self.on_change = on_change

    @property
    def component_name(self) -> str:
        """Return the component name for styling purposes."""
        return "checkbox"

    def to_renderable(self, styling_context: StylingContext | None = None) -> CheckboxRenderable:
        """Convert this checkbox to a renderable checkbox.

        Args:
            styling_context: The styling context for this component.

        Returns:
            A CheckboxRenderable instance.
        """
        from ...style.subsystem import StylingContext

        context = styling_context or StylingContext(component_name=self.component_name)
        return CheckboxRenderable(
            component_name=self.component_name,
            styling_context=context,
            label=self.label,
            checked=self.checked,
            on_change=self.on_change,
        )

    def toggle(self) -> None:
        """Toggle the checked state of the checkbox."""
        self.checked = not self.checked
        if self.on_change:
            try:
                self.on_change(self.checked)
            except Exception as e:
                logger.error(f"Error in checkbox change handler: {e}")

    def handle_click(self, event_data: object | None = None) -> None:
        """Handle a click event by toggling the checkbox state.

        Args:
            event_data: Optional event data.
        """
        self.toggle()


class CheckboxRenderable(RenderableComponent):
    """Renderable checkbox interactive component with event handling."""

    def __init__(
        self,
        component_name: str,
        styling_context: StylingContext,
        label: str,
        checked: bool,
        on_change: Callable[[bool], None] | None,
    ) -> None:
        """Initialize the renderable checkbox component.

        Args:
            component_name: The name of the component.
            styling_context: The styling context.
            label: The checkbox label.
            checked: Current checked state.
            on_change: Optional change callback.
        """
        super().__init__(component_name, styling_context)
        self.label = label
        self.checked = checked
        self.on_change = on_change

    def render(self, console: Console) -> str | list[str] | None:
        """Render the checkbox component with checkmark rendering.

        Args:
            console: The console to render to.

        Returns:
            The rendered checkbox as a string.
        """
        logger.log(5, f"Rendering checkbox: {self.component_name}")  # Use level 5 for TRACE

        # Get resolved style for styling
        _ = self.get_resolved_style(console)

        # Render checkbox with checkmark if checked
        checkmark = "☑" if self.checked else "☐"
        checkbox_text = f"{checkmark} {self.label}"
        return checkbox_text

    def measure(self, console: Console) -> Measure:
        """Measure the checkbox component's preferred size.

        Args:
            console: The console context for measurement.

        Returns:
            Measure object with width and height for the checkbox.
        """
        logger.log(5, f"Measuring checkbox: {self.component_name}")  # Use level 5 for TRACE

        # Checkbox width includes checkmark, space, and label
        width = len(self.label) + 4  # checkmark + space + label
        height = 1  # Single line checkbox
        return Measure(width, height)

    def toggle(self) -> None:
        """Toggle the checked state of the checkbox."""
        self.checked = not self.checked
        if self.on_change:
            try:
                self.on_change(self.checked)
            except Exception as e:
                logger.error(f"Error in checkbox change handler: {e}")

    def handle_click(self, event_data: object | None = None) -> None:
        """Handle a click event by toggling the checkbox state.

        Args:
            event_data: Optional event data.
        """
        self.toggle()


__all__ = ["Checkbox", "CheckboxRenderable"]
