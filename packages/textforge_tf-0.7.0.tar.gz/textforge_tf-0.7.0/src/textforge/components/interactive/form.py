"""Form interactive component."""

from __future__ import annotations

from typing import TYPE_CHECKING, Any

from ...core.console import Console, Measure
from ...utils.logging import get_logger
from ..base import ContainerBase, ContainerRenderable

if TYPE_CHECKING:
    from collections.abc import Callable

    from ...style.subsystem import StylingContext

logger = get_logger(__name__)


class Form(ContainerBase):
    """An interactive form component that can contain form fields with event handling capabilities."""

    def __init__(self, on_submit: Callable[[dict[str, Any]], None] | None = None, **kwargs: object) -> None:
        """Initialize the form component.

        Args:
            on_submit: Optional callback function for form submission.
            **kwargs: Additional keyword arguments passed to the parent class.
        """
        super().__init__(**kwargs)
        self.on_submit = on_submit

    @property
    def component_name(self) -> str:
        """Return the component name for styling purposes."""
        return "form"

    def to_renderable(self, styling_context: StylingContext | None = None) -> FormRenderable:
        """Convert this form to a renderable form.

        Args:
            styling_context: The styling context for this component.

        Returns:
            A FormRenderable instance.
        """
        from ...style.subsystem import StylingContext

        context = styling_context or StylingContext(component_name=self.component_name)
        renderable = FormRenderable(
            component_name=self.component_name,
            styling_context=context,
            on_submit=self.on_submit,
        )

        # Add children to renderable
        for child in self.children:
            renderable.add_child(child.to_renderable(context))

        return renderable

    def submit(self) -> None:
        """Submit the form, collecting data from all child components."""
        form_data = self._collect_form_data()
        if self.on_submit:
            try:
                self.on_submit(form_data)
            except Exception as e:
                logger.error(f"Error in form submit handler: {e}")

    def _collect_form_data(self) -> dict[str, Any]:
        """Collect form data from all child components.

        Returns:
            A dictionary of form field names to their values.
        """
        form_data: dict[str, Any] = {}
        for child in self.children:
            if hasattr(child, "name") and hasattr(child, "value"):
                form_data[child.name] = child.value
        return form_data


class FormRenderable(ContainerRenderable):
    """Renderable form interactive component with event handling."""

    def __init__(
        self,
        component_name: str,
        styling_context: StylingContext,
        on_submit: Callable[[dict[str, Any]], None] | None,
    ) -> None:
        """Initialize the renderable form component.

        Args:
            component_name: The name of the component.
            styling_context: The styling context.
            on_submit: Optional submit callback.
        """
        super().__init__(component_name, styling_context)
        self.on_submit = on_submit

    def render(self, console: Console) -> str | list[str] | None:
        """Render the form component with field management and validation.

        Args:
            console: The console to render to.

        Returns:
            The rendered form as a list of strings.
        """
        logger.log(5, f"Rendering form: {self.component_name}")  # Use level 5 for TRACE

        # Get resolved style for styling
        _ = self.get_resolved_style(console)

        if not self.children:
            return []

        # Render each child component and collect their output
        form_lines: list[str] = []
        for child in self.children:
            child_output = child.render(console)
            if child_output is None:
                continue
            elif isinstance(child_output, str):
                form_lines.append(child_output)
            elif isinstance(child_output, list):
                form_lines.extend(child_output)

        # Add submit instruction
        if self.children:
            form_lines.append("Press Enter to submit form")

        return form_lines

    def measure(self, console: Console) -> Measure:
        """Measure the form component's preferred size.

        Args:
            console: The console context for measurement.

        Returns:
            Measure object with width and height for the form.
        """
        logger.log(5, f"Measuring form: {self.component_name}")  # Use level 5 for TRACE

        if not self.children:
            return Measure(0, 0)

        total_height = 0
        max_width = 0

        for child in self.children:
            child_measure = child.measure(console)
            max_width = max(max_width, child_measure.width)
            total_height += child_measure.height

        # Add submit instruction
        if self.children:
            total_height += 1
            max_width = max(max_width, 23)  # "Press Enter to submit form"

        return Measure(max_width, total_height)

    def submit(self) -> None:
        """Submit the form, collecting data from all child components."""
        form_data = self._collect_form_data()
        if self.on_submit:
            try:
                self.on_submit(form_data)
            except Exception as e:
                logger.error(f"Error in form submit handler: {e}")

    def _collect_form_data(self) -> dict[str, Any]:
        """Collect form data from all child components.

        Returns:
            A dictionary of form field names to their values.
        """
        form_data: dict[str, Any] = {}
        for child in self.children:
            if hasattr(child, "name") and hasattr(child, "value"):
                form_data[child.name] = child.value
        return form_data


__all__ = ["Form", "FormRenderable"]
