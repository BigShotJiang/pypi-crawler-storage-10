"""Backward-compatible import for interactive base classes."""

from __future__ import annotations

from ..base import InteractiveBase

__all__ = ["InteractiveBase"]