"""Foundational component abstractions for Textforge."""

from __future__ import annotations

import logging
import weakref
from abc import ABC, abstractmethod
from dataclasses import dataclass, field
from functools import wraps
from threading import RLock
from typing import TYPE_CHECKING, Any

from ..core.console import Console, Measure
from ..core.layout import tfs_to_layout_style
from ..renderers.base import RenderableBase
from ..renderers.gui.types import GuiNode
from ..style.subsystem import StylingContext, get_styling_subsystem
from ..utils.logging import get_logger

if TYPE_CHECKING:
    from collections.abc import Iterable, Sequence

    from ..core.layout.engine import LayoutStyle
    from ..style.tfs.tfs_cascade import ResolvedStyle

TRACE_LOG_LEVEL = 5
logging.addLevelName(TRACE_LOG_LEVEL, "TRACE")

_LOGGER = get_logger("textforge.components", level=logging.INFO)


class ComponentError(Exception):
    """Base exception raised for component subsystem failures."""


class InvalidComponentPropertyError(ComponentError):
    """Raised when a component property value is not accepted."""


class ComponentNotFoundError(ComponentError):
    """Raised when a component cannot be located for an operation."""


class ComponentValidationError(ComponentError):
    """Raised when component validation rules fail."""


class Component(ABC):
    """Abstract base class for all logical components."""

    _creation_lock = RLock()

    def __init__(self, *args: object, children: Sequence[Component] | None = None, **kwargs: object) -> None:
        del args, kwargs
        # Initialize per-instance state lock and emit creation log
        self._state_lock = RLock()
        with self._creation_lock:
            _LOGGER.debug("Creating %s", self.__class__.__name__)
        self.validate_props()

    @property
    def logger(self) -> logging.Logger:
        """Return a component specific logger.

        Returns:
            logging.Logger: Logger scoped to the concrete component.
        """

        return get_logger(f"textforge.components.{self.__class__.__name__.lower()}")

    @property
    @abstractmethod
    def component_name(self) -> str:
        """Return the canonical component name used for styling."""

    @abstractmethod
    def to_renderable(self, styling_context: StylingContext | None = None) -> RenderableComponent:
        """Convert this logical component into a renderable counterpart.

        Args:
            styling_context: Optional styling context override.

        Returns:
            RenderableComponent: Renderable representation for rendering pipelines.
        """

    def validate_props(self) -> None:
        """Validate component properties.

        Returns:
            None
        """

        return None

    def fail_validation(self, message: str) -> None:
        """Log a validation failure and raise :class:`ComponentValidationError`.

        Args:
            message: Explanation of the validation failure.

        Raises:
            ComponentValidationError: Always raised to signal invalid configuration.

        Returns:
            None
        """

        self.logger.warning("Validation failed for %s: %s", self.component_name, message)
        raise ComponentValidationError(message)


def _wrap_render_method(cls: type[RenderableComponent], name: str, lock_attr: str) -> None:
    method = cls.__dict__.get(name)
    if method is None:
        return
    if "_textforge_wrapped" in getattr(method, "__dict__", {}):
        return

    @wraps(method)
    def wrapper(self: RenderableComponent, *args: object, **kwargs: object) -> object:
        lock: RLock = getattr(self, lock_attr)
        with lock:
            _LOGGER.log(TRACE_LOG_LEVEL, "%s %s", name.capitalize(), self.component_name)
            return method(self, *args, **kwargs)

    wrapper.__dict__["_textforge_wrapped"] = True
    setattr(cls, name, wrapper)


@dataclass(slots=True)
class RenderableComponent(RenderableBase, ABC):
    """Base class for renderable components that integrate with styling."""

    component_name: str
    styling_context: StylingContext | None = None
    _resolved_style: ResolvedStyle | None = field(default=None, init=False, repr=False)
    _render_lock: RLock = field(default_factory=RLock, init=False, repr=False)
    _measure_lock: RLock = field(default_factory=RLock, init=False, repr=False)
    _style_lock: RLock = field(default_factory=RLock, init=False, repr=False)

    def __init_subclass__(cls, **kwargs: object) -> None:
        super().__init_subclass__(**kwargs)
        if cls is RenderableComponent:
            return
        _wrap_render_method(cls, "render", "_render_lock")
        _wrap_render_method(cls, "measure", "_measure_lock")

    def get_resolved_style(self, console: Console | None = None) -> ResolvedStyle:
        """Return the cached or newly resolved TFS style for the component.

        Args:
            console: Optional console context (accepted for signature compatibility; not used).

        Returns:
            ResolvedStyle: Cached or freshly resolved style instance.
        """

        del console
        with self._style_lock:
            if self._resolved_style is not None:
                return self._resolved_style
            subsystem = get_styling_subsystem()
            context = self.styling_context or StylingContext(component_name=self.component_name)
            self._resolved_style = subsystem.resolve_style(context)
            return self._resolved_style

    def invalidate_cached_style(self) -> None:
        """Clear any cached style so the next access performs resolution.

        Returns:
            None
        """

        with self._style_lock:
            self._resolved_style = None

    def iter_children(self) -> tuple[RenderableComponent, ...]:
        """Return a snapshot of child renderables.

        For leaf components (components with no children), this returns an empty tuple.
        Container components should override this method to return their actual children.

        Returns:
            tuple[RenderableComponent, ...]: Copy of current child renderables.
        """
        return ()

    def get_layout_style(self) -> LayoutStyle:
        """Get the layout style by converting resolved TFS style.

        Returns:
            LayoutStyle: Layout style for this component.
        """
        resolved_style = self.get_resolved_style()
        from ..core.layout.tfs_converter import tfs_to_layout_style
        return tfs_to_layout_style(resolved_style)

    def _build_layout_properties(self, resolved_style: ResolvedStyle) -> dict[str, object]:
        """Extract layout-relevant properties from a resolved style.

        Args:
            resolved_style: Fully resolved TFS style.

        Returns:
            dict[str, object]: Mapping of layout property names to values.
        """

        candidates: dict[str, object] = {
            "display": resolved_style.display,
            "position": resolved_style.position,
            "width": resolved_style.width,
            "height": resolved_style.height,
            "min-width": resolved_style.min_width,
            "min-height": resolved_style.min_height,
            "max-width": resolved_style.max_width,
            "max-height": resolved_style.max_height,
            "flex-grow": resolved_style.flex_grow,
            "flex-shrink": resolved_style.flex_shrink,
            "flex-basis": resolved_style.flex_basis,
            "justify": resolved_style.justify_content,
            "align": resolved_style.align_items,
            "top": resolved_style.top,
            "right": resolved_style.right,
            "bottom": resolved_style.bottom,
            "left": resolved_style.left,
            "grid-template-columns": resolved_style.grid_template_columns,
            "grid-template-rows": resolved_style.grid_template_rows,
            "grid-gap": resolved_style.grid_gap,
            "grid-column-gap": resolved_style.grid_column_gap,
            "grid-row-gap": resolved_style.grid_row_gap,
        }

        layout_props: dict[str, object] = {}
        for key, value in candidates.items():
            if value is None:
                continue
            if isinstance(value, (int, float, str)):
                layout_props[key] = value
            else:
                layout_props[key] = str(value)
        return layout_props

    def to_node(self, console: Console) -> GuiNode:
        """Convert this renderable into a GUI node representation.

        Args:
            console: Console context used for style resolution.

        Returns:
            GuiNode: GUI node containing style, layout, and child metadata.
        """

        resolved_style = self.get_resolved_style(console)
        layout_style: LayoutStyle | None = tfs_to_layout_style(resolved_style)
        node = GuiNode(
            component_name=self.component_name,
            style=resolved_style,
            layout_style=layout_style,
        )
        node.metadata["renderable"] = weakref.ref(self)
        handle_click = getattr(self, "handle_click", None)
        if callable(handle_click):
            node.metadata.setdefault("on_click", handle_click)
            node.metadata["interactive"] = True
        self._populate_gui_node(node, console)
        for child in self.iter_children():
            child_node = child.to_node(console)
            child_node.metadata["parent"] = weakref.ref(node)
            node.children.append(child_node)
        return node

    def _populate_gui_node(self, node: GuiNode, console: Console) -> None:
        """Populate component-specific GUI metadata on the node.

        Args:
            node: GuiNode that should receive additional data.
            console: Console context used for conversion.

        Returns:
            None
        """

        del node, console

    @abstractmethod
    def render(self, console: Console) -> str | Iterable[str] | None:
        """Render the component using the provided console.

        Args:
            console: Console abstraction used for rendering.

        Returns:
            str | Iterable[str] | None: Rendered output suitable for downstream consumers.
        """

    @abstractmethod
    def measure(self, console: Console) -> Measure:
        """Return the measured size for the component.

        Args:
            console: Console abstraction used for measurement.

        Returns:
            Measure: Width and height measurement in terminal cells.
        """


@dataclass(slots=True)
class ContainerRenderable(RenderableComponent):
    """Renderable container that manages child renderables."""

    children: list[RenderableComponent] = field(default_factory=list)
    _children_lock: RLock = field(default_factory=RLock, init=False, repr=False)

    def iter_children(self) -> tuple[RenderableComponent, ...]:
        """Return a snapshot of child renderables.

        Returns:
            tuple[RenderableComponent, ...]: Copy of current child renderables.
        """

        with self._children_lock:
            return tuple(self.children)

    def add_child(self, child: RenderableComponent) -> None:
        """Append a child renderable to this container.

        Args:
            child: Renderable component to append.

        Returns:
            None
        """

        with self._children_lock:
            self.children.append(child)
            _LOGGER.debug("Added child to %s", self.component_name)

    def remove_child(self, child: RenderableComponent) -> None:
        """Remove a specific child or raise :class:`ComponentNotFoundError`.

        Args:
            child: Renderable component to remove.

        Raises:
            ComponentNotFoundError: If the child does not exist in the container.

        Returns:
            None
        """

        with self._children_lock:
            try:
                self.children.remove(child)
            except ValueError as exc:
                raise ComponentNotFoundError(
                    f"Child not found in container '{self.component_name}'"
                ) from exc

    def clear(self) -> None:
        """Remove all child renderables.

        Returns:
            None
        """

        with self._children_lock:
            self.children.clear()

    def render(self, console: Console) -> str | Iterable[str] | None:
        """Render child components sequentially and collect their output.

        Args:
            console: Console abstraction used for rendering.

        Returns:
            RenderableOutput: Aggregated child output as a list of strings.
        """

        lines: list[str] = []
        for child in self.iter_children():
            rendered = child.render(console)
            if rendered is None:
                continue
            if isinstance(rendered, str):
                lines.append(rendered)
            else:
                lines.extend(rendered)
        return lines

    def measure(self, console: Console) -> Measure:
        """Return the combined measurement of all child components.

        Args:
            console: Console abstraction used for measurement.

        Returns:
            Measure: Aggregate bounding box for all children.
        """

        width: int = 0
        height: int = 0
        for child in self.iter_children():
            measure = child.measure(console)
            width = max(width, measure.width)
            height += measure.height
        return Measure(width, height)


class ContainerBase(Component, ABC):
    """Logical base class for components that aggregate children."""

    def __init__(self, *args: object, children: Sequence[Component] | None = None, **kwargs: object) -> None:
        """Initialise the container base.

        Args:
            *args: Positional arguments forwarded to :class:`Component`.
            children: Child components to initialize with.
            **kwargs: Keyword arguments forwarded to :class:`Component`.

        Returns:
            None
        """

        children_arg = children
        super().__init__(*args, **kwargs)
        if children_arg is None:
            self._children = []
        else:
            self._children = list(children_arg)
        self._children_lock = RLock()

    def iter_children(self) -> tuple[Component, ...]:
        """Return a snapshot of child components.

        Returns:
            tuple[Component, ...]: Copy of current logical children.
        """

        with self._children_lock:
            return tuple(self._children)

    def add_child(self, child: Component) -> None:
        """Append a child component to this container.

        Args:
            child: Component to append.

        Returns:
            None
        """

        with self._children_lock:
            self._children.append(child)
            self.logger.debug("Added child to %s", self.component_name)

    def remove_child(self, child: Component) -> None:
        """Remove the specified child component.

        Args:
            child: Component to remove.

        Raises:
            ComponentNotFoundError: If the child is not present.

        Returns:
            None
        """

        with self._children_lock:
            try:
                self._children.remove(child)
                self.logger.debug("Removed child from %s", self.component_name)
            except ValueError as exc:
                raise ComponentNotFoundError(
                    f"Child not present in container '{self.component_name}'"
                ) from exc

    @property
    def children(self) -> list[Component]:
        """Expose the underlying child list for compatibility.

        Returns:
            list[Component]: Live list of child components.
        """

        return self._children

    @children.setter
    def children(self, value: Iterable[Component]) -> None:
        """Replace the child collection with the supplied iterable.

        Args:
            value: Iterable of components to become the new children.

        Returns:
            None
        """

        with self._children_lock:
            self._children = list(value)

    def to_renderable(self, styling_context: StylingContext | None = None) -> ContainerRenderable:
        """Convert the container into a :class:`ContainerRenderable`.

        Args:
            styling_context: Optional styling context override.

        Returns:
            ContainerRenderable: Renderable representation containing child renderables.
        """

        context = styling_context or StylingContext(component_name=self.component_name)
        renderable = ContainerRenderable(component_name=self.component_name, styling_context=context)
        for child in self.iter_children():
            renderable.add_child(child.to_renderable(context))
        return renderable


class DecorativeBase(Component, ABC):
    """Base class for decorative components."""

    def __init__(self, *args: object, children: Sequence[Component] | None = None, **kwargs: object) -> None:
        """Initialise the decorative component base.

        Args:
            *args: Positional arguments forwarded to :class:`Component`.
            children: Child components to initialize with.
            **kwargs: Keyword arguments forwarded to :class:`Component`.

        Returns:
            None
        """

        children_arg = children
        super().__init__(*args, **kwargs)
        if children_arg is None:
            self._children = []
        else:
            self._children = list(children_arg)
        self._children_lock = RLock()

    def iter_children(self) -> tuple[Component, ...]:
        """Return a snapshot of child components.

        Returns:
            tuple[Component, ...]: Copy of current logical children.
        """

        with self._children_lock:
            return tuple(self._children)

    def add_child(self, child: Component) -> None:
        """Append a child component to this decorative component.

        Args:
            child: Component to append.

        Returns:
            None
        """

        with self._children_lock:
            self._children.append(child)
            self.logger.debug("Added child to %s", self.component_name)

    def remove_child(self, child: Component) -> None:
        """Remove the specified child component.

        Args:
            child: Component to remove.

        Raises:
            ComponentNotFoundError: If the child is not present.

        Returns:
            None
        """

        with self._children_lock:
            try:
                self._children.remove(child)
                self.logger.debug("Removed child from %s", self.component_name)
            except ValueError as exc:
                raise ComponentNotFoundError(
                    f"Child not present in decorative '{self.component_name}'"
                ) from exc

    @property
    def children(self) -> list[Component]:
        """Expose the underlying child list.

        Returns:
            list[Component]: Live list of child components.
        """

        return self._children

    @children.setter
    def children(self, value: Iterable[Component]) -> None:
        """Replace the child collection with the supplied iterable.

        Args:
            value: Iterable of components to become the new children.

        Returns:
            None
        """

        with self._children_lock:
            self._children = list(value)

    def to_renderable(self, styling_context: StylingContext | None = None) -> ContainerRenderable:
        """Convert into a :class:`ContainerRenderable` wrapping child renderables.

        Args:
            styling_context: Optional styling context override.

        Returns:
            ContainerRenderable: Renderable representation containing child renderables.
        """

        context = styling_context or StylingContext(component_name=self.component_name)
        renderable = ContainerRenderable(component_name=self.component_name, styling_context=context)
        for child in self.iter_children():
            renderable.add_child(child.to_renderable(context))
        return renderable


class InteractiveBase(Component, ABC):
    """Base class for interactive components."""

    def __init__(self, *args: object, children: Sequence[Component] | None = None, **kwargs: object) -> None:
        """Initialise the interactive component base.

        Args:
            *args: Positional arguments forwarded to :class:`Component`.
            children: Child components to initialize with.
            **kwargs: Keyword arguments forwarded to :class:`Component`.

        Returns:
            None
        """

        children_arg = children
        super().__init__(*args, **kwargs)
        if children_arg is None:
            self._children = []
        else:
            self._children = list(children_arg)
        self._children_lock = RLock()

    def iter_children(self) -> tuple[Component, ...]:
        """Return a snapshot of child components.

        Returns:
            tuple[Component, ...]: Copy of current logical children.
        """

        with self._children_lock:
            return tuple(self._children)

    def add_child(self, child: Component) -> None:
        """Append a child component to this interactive component.

        Args:
            child: Component to append.

        Returns:
            None
        """

        with self._children_lock:
            self._children.append(child)
            self.logger.debug("Added child to %s", self.component_name)

    def remove_child(self, child: Component) -> None:
        """Remove the specified child component.

        Args:
            child: Component to remove.

        Raises:
            ComponentNotFoundError: If the child is not present.

        Returns:
            None
        """

        with self._children_lock:
            try:
                self._children.remove(child)
                self.logger.debug("Removed child from %s", self.component_name)
            except ValueError as exc:
                raise ComponentNotFoundError(
                    f"Child not present in interactive '{self.component_name}'"
                ) from exc

    @property
    def children(self) -> list[Component]:
        """Expose the underlying child list.

        Returns:
            list[Component]: Live list of child components.
        """

        return self._children

    @children.setter
    def children(self, value: Iterable[Component]) -> None:
        """Replace the child collection with the supplied iterable.

        Args:
            value: Iterable of components to become the new children.

        Returns:
            None
        """

        with self._children_lock:
            self._children = list(value)

    def to_renderable(self, styling_context: StylingContext | None = None) -> ContainerRenderable:
        """Convert into a :class:`ContainerRenderable` wrapping child renderables.

        Args:
            styling_context: Optional styling context override.

        Returns:
            ContainerRenderable: Renderable representation containing child renderables.
        """

        context = styling_context or StylingContext(component_name=self.component_name)
        renderable = ContainerRenderable(component_name=self.component_name, styling_context=context)
        for child in self.iter_children():
            renderable.add_child(child.to_renderable(context))
        return renderable


class LayoutBase(Component, ABC):
    """Base class for layout components."""

    def __init__(self, *args: object, children: Sequence[Component] | None = None, **kwargs: object) -> None:
        """Initialise the layout component base.

        Args:
            *args: Positional arguments forwarded to :class:`Component`.
            children: Child components to initialize with.
            **kwargs: Keyword arguments forwarded to :class:`Component`.

        Returns:
            None
        """

        children_arg = children
        super().__init__(*args, **kwargs)
        if children_arg is None:
            self._children = []
        else:
            self._children = list(children_arg)
        self._children_lock = RLock()

    def iter_children(self) -> tuple[Component, ...]:
        """Return a snapshot of child components.

        Returns:
            tuple[Component, ...]: Copy of current logical children.
        """

        with self._children_lock:
            return tuple(self._children)

    def add_child(self, child: Component) -> None:
        """Append a child component to this layout component.

        Args:
            child: Component to append.

        Returns:
            None
        """

        with self._children_lock:
            self._children.append(child)
            self.logger.debug("Added child to %s", self.component_name)

    def remove_child(self, child: Component) -> None:
        """Remove the specified child component.

        Args:
            child: Component to remove.

        Raises:
            ComponentNotFoundError: If the child is not present.

        Returns:
            None
        """

        with self._children_lock:
            try:
                self._children.remove(child)
                self.logger.debug("Removed child from %s", self.component_name)
            except ValueError as exc:
                raise ComponentNotFoundError(
                    f"Child not present in layout '{self.component_name}'"
                ) from exc

    @property
    def children(self) -> list[Component]:
        """Expose the underlying child list.

        Returns:
            list[Component]: Live list of child components.
        """

        return self._children

    @children.setter
    def children(self, value: Iterable[Component]) -> None:
        """Replace the child collection with the supplied iterable.

        Args:
            value: Iterable of components to become the new children.

        Returns:
            None
        """

        with self._children_lock:
            self._children = list(value)

    def to_renderable(self, styling_context: StylingContext | None = None) -> ContainerRenderable:
        """Convert into a :class:`ContainerRenderable` wrapping child renderables.

        Args:
            styling_context: Optional styling context override.

        Returns:
            ContainerRenderable: Renderable representation containing child renderables.
        """

        context = styling_context or StylingContext(component_name=self.component_name)
        renderable = ContainerRenderable(component_name=self.component_name, styling_context=context)
        for child in self.iter_children():
            renderable.add_child(child.to_renderable(context))
        return renderable


class TypographyBase(Component, ABC):
    """Base class for typography components."""

    def __init__(self, *args: object, children: Sequence[Component] | None = None, **kwargs: object) -> None:
        """Initialise the typography component base.

        Args:
            *args: Positional arguments forwarded to :class:`Component`.
            children: Child components to initialize with.
            **kwargs: Keyword arguments forwarded to :class:`Component`.

        Returns:
            None
        """

        children_arg = children
        super().__init__(*args, **kwargs)
        if children_arg is None:
            self._children = []
        else:
            self._children = list(children_arg)
        self._children_lock = RLock()

    def iter_children(self) -> tuple[Component, ...]:
        """Return a snapshot of child components.

        Returns:
            tuple[Component, ...]: Copy of current logical children.
        """

        with self._children_lock:
            return tuple(self._children)

    def add_child(self, child: Component) -> None:
        """Append a child component to this typography component.

        Args:
            child: Component to append.

        Returns:
            None
        """

        with self._children_lock:
            self._children.append(child)
            self.logger.debug("Added child to %s", self.component_name)

    def remove_child(self, child: Component) -> None:
        """Remove the specified child component.

        Args:
            child: Component to remove.

        Raises:
            ComponentNotFoundError: If the child is not present.

        Returns:
            None
        """

        with self._children_lock:
            try:
                self._children.remove(child)
                self.logger.debug("Removed child from %s", self.component_name)
            except ValueError as exc:
                raise ComponentNotFoundError(
                    f"Child not present in typography '{self.component_name}'"
                ) from exc

    @property
    def children(self) -> list[Component]:
        """Expose the underlying child list.

        Returns:
            list[Component]: Live list of child components.
        """

        return self._children

    @children.setter
    def children(self, value: Iterable[Component]) -> None:
        """Replace the child collection with the supplied iterable.

        Args:
            value: Iterable of components to become the new children.

        Returns:
            None
        """

        with self._children_lock:
            self._children = list(value)

    def to_renderable(self, styling_context: StylingContext | None = None) -> ContainerRenderable:
        """Convert into a :class:`ContainerRenderable` wrapping child renderables.

        Args:
            styling_context: Optional styling context override.

        Returns:
            ContainerRenderable: Renderable representation containing child renderables.
        """

        context = styling_context or StylingContext(component_name=self.component_name)
        renderable = ContainerRenderable(component_name=self.component_name, styling_context=context)
        for child in self.iter_children():
            renderable.add_child(child.to_renderable(context))
        return renderable


class DataBase(Component, ABC):
    """Base class for data display components."""

    def __init__(self, *args: object, children: Sequence[Component] | None = None, **kwargs: object) -> None:
        """Initialise the data component base.

        Args:
            *args: Positional arguments forwarded to :class:`Component`.
            children: Child components to initialize with.
            **kwargs: Keyword arguments forwarded to :class:`Component`.

        Returns:
            None
        """

        children_arg = children
        super().__init__(*args, **kwargs)
        if children_arg is None:
            self._children = []
        else:
            self._children = list(children_arg)
        self._children_lock = RLock()

    def iter_children(self) -> tuple[Component, ...]:
        """Return a snapshot of child components.

        Returns:
            tuple[Component, ...]: Copy of current logical children.
        """

        with self._children_lock:
            return tuple(self._children)

    def add_child(self, child: Component) -> None:
        """Append a child component to this data component.

        Args:
            child: Component to append.

        Returns:
            None
        """

        with self._children_lock:
            self._children.append(child)
            self.logger.debug("Added child to %s", self.component_name)

    def remove_child(self, child: Component) -> None:
        """Remove the specified child component.

        Args:
            child: Component to remove.

        Raises:
            ComponentNotFoundError: If the child is not present.

        Returns:
            None
        """

        with self._children_lock:
            try:
                self._children.remove(child)
                self.logger.debug("Removed child from %s", self.component_name)
            except ValueError as exc:
                raise ComponentNotFoundError(
                    f"Child not present in data '{self.component_name}'"
                ) from exc

    @property
    def children(self) -> list[Component]:
        """Expose the underlying child list.

        Returns:
            list[Component]: Live list of child components.
        """

        return self._children

    @children.setter
    def children(self, value: Iterable[Component]) -> None:
        """Replace the child collection with the supplied iterable.

        Args:
            value: Iterable of components to become the new children.

        Returns:
            None
        """

        with self._children_lock:
            self._children = list(value)

    def to_renderable(self, styling_context: StylingContext | None = None) -> ContainerRenderable:
        """Convert into a :class:`ContainerRenderable` wrapping child renderables.

        Args:
            styling_context: Optional styling context override.

        Returns:
            ContainerRenderable: Renderable representation containing child renderables.
        """

        context = styling_context or StylingContext(component_name=self.component_name)
        renderable = ContainerRenderable(component_name=self.component_name, styling_context=context)
        for child in self.iter_children():
            renderable.add_child(child.to_renderable(context))
        return renderable


class StatusBase(Component, ABC):
    """Base class for status display components."""

    def __init__(self, *args: object, children: Sequence[Component] | None = None, **kwargs: object) -> None:
        """Initialise the status component base.

        Args:
            *args: Positional arguments forwarded to :class:`Component`.
            children: Child components to initialize with.
            **kwargs: Keyword arguments forwarded to :class:`Component`.

        Returns:
            None
        """

        children_arg = children
        super().__init__(*args, **kwargs)
        if children_arg is None:
            self._children = []
        else:
            self._children = list(children_arg)
        self._children_lock = RLock()

    def iter_children(self) -> tuple[Component, ...]:
        """Return a snapshot of child components.

        Returns:
            tuple[Component, ...]: Copy of current logical children.
        """

        with self._children_lock:
            return tuple(self._children)

    def add_child(self, child: Component) -> None:
        """Append a child component to this status component.

        Args:
            child: Component to append.

        Returns:
            None
        """

        with self._children_lock:
            self._children.append(child)
            self.logger.debug("Added child to %s", self.component_name)

    def remove_child(self, child: Component) -> None:
        """Remove the specified child component.

        Args:
            child: Component to remove.

        Raises:
            ComponentNotFoundError: If the child is not present.

        Returns:
            None
        """

        with self._children_lock:
            try:
                self._children.remove(child)
                self.logger.debug("Removed child from %s", self.component_name)
            except ValueError as exc:
                raise ComponentNotFoundError(
                    f"Child not present in status '{self.component_name}'"
                ) from exc

    @property
    def children(self) -> list[Component]:
        """Expose the underlying child list.

        Returns:
            list[Component]: Live list of child components.
        """

        return self._children

    @children.setter
    def children(self, value: Iterable[Component]) -> None:
        """Replace the child collection with the supplied iterable.

        Args:
            value: Iterable of components to become the new children.

        Returns:
            None
        """

        with self._children_lock:
            self._children = list(value)

    def to_renderable(self, styling_context: StylingContext | None = None) -> ContainerRenderable:
        """Convert into a :class:`ContainerRenderable` wrapping child renderables.

        Args:
            styling_context: Optional styling context override.

        Returns:
            ContainerRenderable: Renderable representation containing child renderables.
        """

        context = styling_context or StylingContext(component_name=self.component_name)
        renderable = ContainerRenderable(component_name=self.component_name, styling_context=context)
        for child in self.iter_children():
            renderable.add_child(child.to_renderable(context))
        return renderable


class NavigationBase(Component, ABC):
    """Base class for navigation components."""

    def __init__(self, *args: object, children: Sequence[Component] | None = None, **kwargs: object) -> None:
        """Initialise the navigation component base.

        Args:
            *args: Positional arguments forwarded to :class:`Component`.
            children: Child components to initialize with.
            **kwargs: Keyword arguments forwarded to :class:`Component`.

        Returns:
            None
        """

        children_arg = children
        super().__init__(*args, **kwargs)
        if children_arg is None:
            self._children = []
        else:
            self._children = list(children_arg)
        self._children_lock = RLock()

    def iter_children(self) -> tuple[Component, ...]:
        """Return a snapshot of child components.

        Returns:
            tuple[Component, ...]: Copy of current logical children.
        """

        with self._children_lock:
            return tuple(self._children)

    def add_child(self, child: Component) -> None:
        """Append a child component to this navigation component.

        Args:
            child: Component to append.

        Returns:
            None
        """

        with self._children_lock:
            self._children.append(child)
            self.logger.debug("Added child to %s", self.component_name)

    def remove_child(self, child: Component) -> None:
        """Remove the specified child component.

        Args:
            child: Component to remove.

        Raises:
            ComponentNotFoundError: If the child is not present.

        Returns:
            None
        """

        with self._children_lock:
            try:
                self._children.remove(child)
                self.logger.debug("Removed child from %s", self.component_name)
            except ValueError as exc:
                raise ComponentNotFoundError(
                    f"Child not present in navigation '{self.component_name}'"
                ) from exc

    @property
    def children(self) -> list[Component]:
        """Expose the underlying child list.

        Returns:
            list[Component]: Live list of child components.
        """

        return self._children

    @children.setter
    def children(self, value: Iterable[Component]) -> None:
        """Replace the child collection with the supplied iterable.

        Args:
            value: Iterable of components to become the new children.

        Returns:
            None
        """

        with self._children_lock:
            self._children = list(value)

    def to_renderable(self, styling_context: StylingContext | None = None) -> ContainerRenderable:
        """Convert into a :class:`ContainerRenderable` wrapping child renderables.

        Args:
            styling_context: Optional styling context override.

        Returns:
            ContainerRenderable: Renderable representation containing child renderables.
        """

        context = styling_context or StylingContext(component_name=self.component_name)
        renderable = ContainerRenderable(component_name=self.component_name, styling_context=context)
        for child in self.iter_children():
            renderable.add_child(child.to_renderable(context))
        return renderable


class VisualBase(Component, ABC):
    """Base class for visual components."""

    def __init__(self, *args: object, children: Sequence[Component] | None = None, **kwargs: object) -> None:
        """Initialise the visual component base.

        Args:
            *args: Positional arguments forwarded to :class:`Component`.
            children: Child components to initialize with.
            **kwargs: Keyword arguments forwarded to :class:`Component`.

        Returns:
            None
        """

        children_arg = children
        super().__init__(*args, **kwargs)
        if children_arg is None:
            self._children = []
        else:
            self._children = list(children_arg)
        self._children_lock = RLock()

    def iter_children(self) -> tuple[Component, ...]:
        """Return a snapshot of child components.

        Returns:
            tuple[Component, ...]: Copy of current logical children.
        """

        with self._children_lock:
            return tuple(self._children)

    def add_child(self, child: Component) -> None:
        """Append a child component to this visual component.

        Args:
            child: Component to append.

        Returns:
            None
        """

        with self._children_lock:
            self._children.append(child)
            self.logger.debug("Added child to %s", self.component_name)

    def remove_child(self, child: Component) -> None:
        """Remove the specified child component.

        Args:
            child: Component to remove.

        Raises:
            ComponentNotFoundError: If the child is not present.

        Returns:
            None
        """

        with self._children_lock:
            try:
                self._children.remove(child)
                self.logger.debug("Removed child from %s", self.component_name)
            except ValueError as exc:
                raise ComponentNotFoundError(
                    f"Child not present in visual '{self.component_name}'"
                ) from exc

    @property
    def children(self) -> list[Component]:
        """Expose the underlying child list.

        Returns:
            list[Component]: Live list of child components.
        """

        return self._children

    @children.setter
    def children(self, value: Iterable[Component]) -> None:
        """Replace the child collection with the supplied iterable.

        Args:
            value: Iterable of components to become the new children.

        Returns:
            None
        """

        with self._children_lock:
            self._children = list(value)

    def to_renderable(self, styling_context: StylingContext | None = None) -> ContainerRenderable:
        """Convert into a :class:`ContainerRenderable` wrapping child renderables.

        Args:
            styling_context: Optional styling context override.

        Returns:
            ContainerRenderable: Renderable representation containing child renderables.
        """

        context = styling_context or StylingContext(component_name=self.component_name)
        renderable = ContainerRenderable(component_name=self.component_name, styling_context=context)
        for child in self.iter_children():
            renderable.add_child(child.to_renderable(context))
        return renderable


class FeedbackBase(Component, ABC):
    """Base class for feedback components."""

    def __init__(self, *args: object, children: Sequence[Component] | None = None, **kwargs: object) -> None:
        """Initialise the feedback component base.

        Args:
            *args: Positional arguments forwarded to :class:`Component`.
            children: Child components to initialize with.
            **kwargs: Keyword arguments forwarded to :class:`Component`.

        Returns:
            None
        """

        children_arg = children
        super().__init__(*args, **kwargs)
        if children_arg is None:
            self._children = []
        else:
            self._children = list(children_arg)
        self._children_lock = RLock()

    def iter_children(self) -> tuple[Component, ...]:
        """Return a snapshot of child components.

        Returns:
            tuple[Component, ...]: Copy of current logical children.
        """

        with self._children_lock:
            return tuple(self._children)

    def add_child(self, child: Component) -> None:
        """Append a child component to this feedback component.

        Args:
            child: Component to append.

        Returns:
            None
        """

        with self._children_lock:
            self._children.append(child)
            self.logger.debug("Added child to %s", self.component_name)

    def remove_child(self, child: Component) -> None:
        """Remove the specified child component.

        Args:
            child: Component to remove.

        Raises:
            ComponentNotFoundError: If the child is not present.

        Returns:
            None
        """

        with self._children_lock:
            try:
                self._children.remove(child)
                self.logger.debug("Removed child from %s", self.component_name)
            except ValueError as exc:
                raise ComponentNotFoundError(
                    f"Child not present in feedback '{self.component_name}'"
                ) from exc

    @property
    def children(self) -> list[Component]:
        """Expose the underlying child list.

        Returns:
            list[Component]: Live list of child components.
        """

        return self._children

    @children.setter
    def children(self, value: Iterable[Component]) -> None:
        """Replace the child collection with the supplied iterable.

        Args:
            value: Iterable of components to become the new children.

        Returns:
            None
        """

        with self._children_lock:
            self._children = list(value)

    def to_renderable(self, styling_context: StylingContext | None = None) -> ContainerRenderable:
        """Convert into a :class:`ContainerRenderable` wrapping child renderables.

        Args:
            styling_context: Optional styling context override.

        Returns:
            ContainerRenderable: Renderable representation containing child renderables.
        """

        context = styling_context or StylingContext(component_name=self.component_name)
        renderable = ContainerRenderable(component_name=self.component_name, styling_context=context)
        for child in self.iter_children():
            renderable.add_child(child.to_renderable(context))
        return renderable


def box(text: str, **kwargs: object) -> RenderableComponent:
    """Return a renderable box component containing the provided text.

    Args:
        text: Text content to include inside the box component.
        **kwargs: Additional keyword arguments forwarded to :class:`Box`.

    Returns:
        RenderableComponent: Renderable box ready for the rendering pipeline.
    """

    helper_logger = get_logger("textforge.components.helpers")
    helper_logger.debug("Creating box helper (length=%d)", len(text))
    from .containers.box import Box  # Local import to avoid circular dependency
    from .text import Text

    component = Box(children=[Text(text)], **kwargs)
    return component.to_renderable()


def text(content: str, **kwargs: object) -> RenderableComponent:
    """Return a renderable text component with the provided content.

    Args:
        content: Text content to display.
        **kwargs: Additional keyword arguments forwarded to :class:`Text`.

    Returns:
        RenderableComponent: Renderable text ready for the rendering pipeline.
    """
    from .text import Text

    component = Text(content=content, **kwargs)
    return component.to_renderable()


def panel(content: str | Sequence[dict[str, object]], children: Sequence[Component] | None = None, **kwargs: object) -> RenderableComponent:
    """Return a renderable panel configured with the supplied content.

    Args:
        content: Panel title string or list of dictionaries describing children.
        children: Child components to include in the panel.
        **kwargs: Additional keyword arguments forwarded to :class:`Panel`.

    Returns:
        RenderableComponent: Renderable panel ready for rendering.

    Raises:
        InvalidComponentPropertyError: If ``content`` is not a supported structure.
    """

    helper_logger = get_logger("textforge.components.helpers")
    helper_logger.debug("Creating panel helper with content type %s", type(content).__name__)
    panel_kwargs: dict[str, Any] = {k: v for k, v in kwargs.items() if k not in ("title",)}
    from .containers.panel import Panel
    from .text import Text

    component = Panel(children=children, **panel_kwargs)

    if isinstance(content, str):
        title_value: str = str(content)
        component.title = title_value
    else:
        # Treat as a sequence describing children; validate structure
        children_components: list[Component] = []
        try:
            for item in content:
                # Duck-typed mapping check to extract 'content'
                value_obj = item.get("content", str(item)) if hasattr(item, "get") else str(item)
                text_value = str(value_obj)
                children_components.append(Text(text_value))
        except TypeError as exc:  # Not iterable
            raise InvalidComponentPropertyError(
                "Panel content must be a string or list of dictionaries with 'content' keys."
            ) from exc
        children_seq: Sequence[Component] = tuple(children_components)
        component.children = children_seq
    return component.to_renderable()


__all__ = [
    "Component",
    "RenderableComponent",
    "ContainerRenderable",
    "ContainerBase",
    "DecorativeBase",
    "InteractiveBase",
    "LayoutBase",
    "TypographyBase",
    "DataBase",
    "StatusBase",
    "NavigationBase",
    "VisualBase",
    "FeedbackBase",
    "ComponentError",
    "InvalidComponentPropertyError",
    "ComponentNotFoundError",
    "ComponentValidationError",
    "box",
    "panel",
]
