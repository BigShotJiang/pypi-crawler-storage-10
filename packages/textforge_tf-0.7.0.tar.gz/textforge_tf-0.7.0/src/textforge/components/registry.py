"""Component registry and extensibility system.

This module provides the infrastructure for registering custom components,
renderers, and other extensible parts of the Textforge component system.
"""

from __future__ import annotations

import threading
from typing import TYPE_CHECKING, Any

from ..utils.logging import get_logger

if TYPE_CHECKING:
    from collections.abc import Callable

    from .base import Component
    from .types import ComponentFactory

logger = get_logger(__name__)


class ComponentRegistry:
    """Registry for custom components with thread-safe operations."""

    def __init__(self) -> None:
        self._components: dict[str, ComponentFactory] = {}
        self._renderers: dict[str, Callable[..., Any]] = {}
        self._layouts: dict[str, Callable[..., Any]] = {}
        self._lock = threading.RLock()

    def register_component(self, name: str, component_factory: ComponentFactory) -> None:
        """Register a custom component factory.

        Args:
            name: The name to register the component under.
            component_factory: A callable that creates component instances.

        Raises:
            ValueError: If a component with the same name is already registered.
        """
        with self._lock:
            if name in self._components:
                raise ValueError(f"Component '{name}' is already registered")
            self._components[name] = component_factory
            logger.debug(f"Registered custom component: {name}")

    def get_component(self, name: str) -> ComponentFactory | None:
        """Get a registered component factory by name.

        Args:
            name: The name of the component to retrieve.

        Returns:
            The component factory if registered, None otherwise.
        """
        with self._lock:
            return self._components.get(name)

    def list_components(self) -> list[str]:
        """List all registered component names.

        Returns:
            A list of registered component names.
        """
        with self._lock:
            return list(self._components.keys())

    def register_renderer(self, name: str, renderer_factory: Callable[..., Any]) -> None:
        """Register a custom renderer.

        Args:
            name: The name to register the renderer under.
            renderer_factory: A callable that creates renderer instances.

        Raises:
            ValueError: If a renderer with the same name is already registered.
        """
        with self._lock:
            if name in self._renderers:
                raise ValueError(f"Renderer '{name}' is already registered")
            self._renderers[name] = renderer_factory
            logger.debug(f"Registered custom renderer: {name}")

    def get_renderer(self, name: str) -> Callable[..., Any] | None:
        """Get a registered renderer factory by name.

        Args:
            name: The name of the renderer to retrieve.

        Returns:
            The renderer factory if registered, None otherwise.
        """
        with self._lock:
            return self._renderers.get(name)

    def register_layout(self, name: str, layout_factory: Callable[..., Any]) -> None:
        """Register a custom layout algorithm.

        Args:
            name: The name to register the layout under.
            layout_factory: A callable that creates layout instances.

        Raises:
            ValueError: If a layout with the same name is already registered.
        """
        with self._lock:
            if name in self._layouts:
                raise ValueError(f"Layout '{name}' is already registered")
            self._layouts[name] = layout_factory
            logger.debug(f"Registered custom layout: {name}")

    def get_layout(self, name: str) -> Callable[..., Any] | None:
        """Get a registered layout factory by name.

        Args:
            name: The name of the layout to retrieve.

        Returns:
            The layout factory if registered, None otherwise.
        """
        with self._lock:
            return self._layouts.get(name)


# Global registry instance
_component_registry = ComponentRegistry()


def get_component_registry() -> ComponentRegistry:
    """Get the global component registry instance.

    Returns:
        The global ComponentRegistry instance.
    """
    return _component_registry


def register_component(name: str, component_factory: ComponentFactory) -> None:
    """Register a custom component factory globally.

    Args:
        name: The name to register the component under.
        component_factory: A callable that creates component instances.
    """
    _component_registry.register_component(name, component_factory)


def get_registered_component(name: str) -> ComponentFactory | None:
    """Get a globally registered component factory.

    Args:
        name: The name of the component to retrieve.

    Returns:
        The component factory if registered, None otherwise.
    """
    return _component_registry.get_component(name)


def create_component(name: str, *args: object, **kwargs: object) -> Component:
    """Create a component instance by name.

    Args:
        name: The name of the component to create.
        *args: Positional arguments to pass to the component factory.
        **kwargs: Keyword arguments to pass to the component factory.

    Returns:
        A new component instance.

    Raises:
        ValueError: If no component with the given name is registered.
    """
    factory = _component_registry.get_component(name)
    if factory is None:
        raise ValueError(f"No component registered with name '{name}'")
    return factory(*args, **kwargs)
