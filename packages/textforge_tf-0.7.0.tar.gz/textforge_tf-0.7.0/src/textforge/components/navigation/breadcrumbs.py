"""Breadcrumbs navigation component."""

from __future__ import annotations

from typing import TYPE_CHECKING

from ...core.console import Console, Measure
from ...utils.logging import get_logger
from ..base import NavigationBase, RenderableComponent

if TYPE_CHECKING:
    from ...style.subsystem import StylingContext
    from .base import NavigationItem

logger = get_logger(__name__)


class Breadcrumbs(NavigationBase):
    """Breadcrumbs navigation component for displaying hierarchical navigation paths."""

    def __init__(
        self,
        items: list[NavigationItem] | None = None,
        separator: str = " › ",
        **kwargs: object,
    ) -> None:
        """Initialize the breadcrumbs component.

        Args:
            items: List of navigation items representing the breadcrumb path.
            separator: The separator character between breadcrumb items.
            **kwargs: Additional keyword arguments passed to parent.
        """
        super().__init__(**kwargs)
        self.items = items or []
        self.separator = separator

    @property
    def component_name(self) -> str:
        """Return the component name for styling purposes."""
        return "breadcrumbs"

    def to_renderable(self, styling_context: StylingContext | None = None) -> BreadcrumbsRenderable:
        """Convert this breadcrumbs component to a renderable component.

        Args:
            styling_context: The styling context for this component.

        Returns:
            A renderable breadcrumbs component.
        """
        from ...style.subsystem import StylingContext

        context = styling_context or StylingContext(component_name=self.component_name)
        return BreadcrumbsRenderable(
            component_name=self.component_name,
            styling_context=context,
            items=self.items,
            separator=self.separator,
        )


class BreadcrumbsRenderable(RenderableComponent):
    """Renderable breadcrumbs component."""

    def __init__(
        self,
        component_name: str,
        styling_context: StylingContext,
        items: list[NavigationItem],
        separator: str,
    ) -> None:
        """Initialize the renderable breadcrumbs.

        Args:
            component_name: The component name.
            styling_context: The styling context.
            items: The navigation items representing the path.
            separator: The separator between items.
        """
        super().__init__(component_name, styling_context)
        self.items = items
        self.separator = separator

    def render(self, console: Console) -> str | list[str] | None:
        """Render the breadcrumbs component.

        Args:
            console: The console to render to.

        Returns:
            The rendered breadcrumbs as a string.
        """
        logger.log(5, f"Rendering breadcrumbs: {self.component_name}")  # Use level 5 for TRACE

        # Get resolved style for styling
        _ = self.get_resolved_style(console)

        if not self.items:
            return ""

        # Build breadcrumb trail
        breadcrumb_parts: list[str] = []
        for i, item in enumerate(self.items):
            # Style current/last item differently
            if i == len(self.items) - 1:
                breadcrumb_parts.append(f"[{item.label}]")  # Current page
            else:
                breadcrumb_parts.append(item.label)

        return self.separator.join(breadcrumb_parts)

    def measure(self, console: Console) -> Measure:
        """Measure the breadcrumbs' preferred size.

        Args:
            console: The console context for measurement.

        Returns:
            Measure object with width and height for the breadcrumbs.
        """
        logger.log(5, f"Measuring breadcrumbs: {self.component_name}")  # Use level 5 for TRACE

        if not self.items:
            return Measure(0, 0)

        # Calculate total width
        total_width = 0
        for i, item in enumerate(self.items):
            if i == len(self.items) - 1:
                total_width += len(item.label) + 2  # brackets
            else:
                total_width += len(item.label)

            # Add separator width (except after last item)
            if i < len(self.items) - 1:
                total_width += len(self.separator)

        height = 1
        return Measure(total_width, height)


__all__ = ["Breadcrumbs", "BreadcrumbsRenderable"]
