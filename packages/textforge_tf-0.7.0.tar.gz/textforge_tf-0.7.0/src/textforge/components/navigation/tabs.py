"""Tabs navigation component."""

from __future__ import annotations

from typing import TYPE_CHECKING

from ...core.console import Console, Measure
from ...utils.logging import get_logger
from ..base import NavigationBase, RenderableComponent

if TYPE_CHECKING:
    from ...style.subsystem import StylingContext
    from .base import NavigationItem

logger = get_logger(__name__)


class Tabs(NavigationBase):
    """Tabs navigation component for displaying tabbed navigation items."""

    def __init__(
        self,
        items: list[NavigationItem] | None = None,
        active_tab: str | None = None,
        **kwargs: object,
    ) -> None:
        """Initialize the tabs component.

        Args:
            items: List of navigation items.
            active_tab: The value of the currently active tab.
            **kwargs: Additional keyword arguments passed to parent.
        """
        super().__init__(**kwargs)
        self.items = items or []
        self.active_tab = active_tab

    @property
    def component_name(self) -> str:
        """Return the component name for styling purposes."""
        return "tabs"

    def to_renderable(self, styling_context: StylingContext | None = None) -> TabsRenderable:
        """Convert this tabs component to a renderable component.

        Args:
            styling_context: The styling context for this component.

        Returns:
            A renderable tabs component.
        """
        from ...style.subsystem import StylingContext

        context = styling_context or StylingContext(component_name=self.component_name)
        return TabsRenderable(
            component_name=self.component_name,
            styling_context=context,
            items=self.items,
            active_tab=self.active_tab,
        )


class TabsRenderable(RenderableComponent):
    """Renderable tabs component."""

    def __init__(
        self,
        component_name: str,
        styling_context: StylingContext,
        items: list[NavigationItem],
        active_tab: str | None,
    ) -> None:
        """Initialize the renderable tabs.

        Args:
            component_name: The component name.
            styling_context: The styling context.
            items: The navigation items.
            active_tab: The currently active tab value.
        """
        super().__init__(component_name, styling_context)
        self.items = items
        self.active_tab = active_tab

    def render(self, console: Console) -> str | list[str] | None:
        """Render the tabs component.

        Args:
            console: The console to render to.

        Returns:
            The rendered tabs as a list of strings.
        """
        logger.log(5, f"Rendering tabs: {self.component_name}")  # Use level 5 for TRACE

        # Get resolved style for styling
        _ = self.get_resolved_style(console)

        if not self.items:
            return []

        # Render tab headers
        tab_lines: list[str] = []

        # First line: tab labels with separators
        tab_header = ""
        for i, item in enumerate(self.items):
            is_active = (self.active_tab and item.label == self.active_tab) or (not self.active_tab and i == 0)
            prefix = "[" if is_active else " "
            suffix = "]" if is_active else " "
            tab_header += f"{prefix}{item.label}{suffix}"

            # Add separator between tabs (except after last)
            if i < len(self.items) - 1:
                tab_header += " │ "

        tab_lines.append(tab_header)

        # Optional: Add underline for active tab
        if self.active_tab:
            underline = ""
            for i, item in enumerate(self.items):
                is_active = item.label == self.active_tab
                tab_width = len(item.label) + 2  # brackets
                underline += "─" * tab_width if is_active else " " * tab_width

                if i < len(self.items) - 1:
                    underline += "─┼─" if is_active else " │ "
            tab_lines.append(underline)

        return tab_lines

    def measure(self, console: Console) -> Measure:
        """Measure the tabs' preferred size.

        Args:
            console: The console context for measurement.

        Returns:
            Measure object with width and height for the tabs.
        """
        logger.log(5, f"Measuring tabs: {self.component_name}")  # Use level 5 for TRACE

        if not self.items:
            return Measure(0, 0)

        # Calculate total width
        total_width = 0
        for i, item in enumerate(self.items):
            total_width += len(item.label) + 2  # brackets
            if i < len(self.items) - 1:
                total_width += 3  # separator

        height = 2 if self.active_tab else 1  # header + optional underline
        return Measure(total_width, height)


__all__ = ["Tabs", "TabsRenderable"]
