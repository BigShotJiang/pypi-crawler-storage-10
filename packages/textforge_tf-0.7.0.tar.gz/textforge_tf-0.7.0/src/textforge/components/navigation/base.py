"""Navigation base classes and types."""

from __future__ import annotations

from dataclasses import dataclass
from typing import TYPE_CHECKING, Any

from ..base import NavigationBase

if TYPE_CHECKING:
    from collections.abc import Callable

__all__ = ["NavigationBase", "NavigationItem"]


@dataclass
class NavigationItem:
    """Represents a navigation item in menus, tabs, and breadcrumbs."""

    label: str
    """The display text for the navigation item."""

    href: str | None = None
    """Optional URL or route for navigation."""

    active: bool = False
    """Whether this navigation item is currently active/selected."""

    disabled: bool = False
    """Whether this navigation item is disabled."""

    icon: str | None = None
    """Optional icon identifier."""

    children: list[NavigationItem] | None = None
    """Optional child navigation items for hierarchical menus."""

    data: dict[str, Any] | None = None
    """Optional additional data associated with the item."""

    on_click: Callable[[NavigationItem], None] | None = None
    """Optional callback when the item is clicked."""