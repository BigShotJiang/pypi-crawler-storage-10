"""Menu navigation component."""

from __future__ import annotations

from typing import TYPE_CHECKING

from ...core.console import Console, Measure
from ...utils.logging import get_logger
from ..base import NavigationBase, RenderableComponent

if TYPE_CHECKING:
    from ...style.subsystem import StylingContext
    from .base import NavigationItem

logger = get_logger(__name__)


class Menu(NavigationBase):
    """Menu navigation component for displaying hierarchical navigation items."""

    def __init__(self, items: list[NavigationItem] | None = None, **kwargs: object) -> None:
        """Initialize the menu component.

        Args:
            items: List of navigation items for the menu.
            **kwargs: Additional keyword arguments passed to parent.
        """
        super().__init__(**kwargs)
        self.items = items or []

    @property
    def component_name(self) -> str:
        """Return the component name for styling purposes."""
        return "menu"

    def to_renderable(self, styling_context: StylingContext | None = None) -> MenuRenderable:
        """Convert this menu to a renderable component.

        Args:
            styling_context: The styling context for this component.

        Returns:
            A renderable menu component.
        """
        from ...style.subsystem import StylingContext

        context = styling_context or StylingContext(component_name=self.component_name)
        return MenuRenderable(
            component_name=self.component_name,
            styling_context=context,
            items=self.items,
        )


class MenuRenderable(RenderableComponent):
    """Renderable menu component."""

    def __init__(
        self,
        component_name: str,
        styling_context: StylingContext,
        items: list[NavigationItem],
    ) -> None:
        """Initialize the renderable menu.

        Args:
            component_name: The component name.
            styling_context: The styling context.
            items: The navigation items.
        """
        super().__init__(component_name, styling_context)
        self.items = items

    def render(self, console: Console) -> str | list[str] | None:
        """Render the menu component.

        Args:
            console: The console to render to.

        Returns:
            The rendered menu as a list of strings.
        """
        logger.log(5, f"Rendering menu: {self.component_name}")  # Use level 5 for TRACE

        # Get resolved style for styling
        _ = self.get_resolved_style(console)

        if not self.items:
            return []

        # Simple menu rendering
        lines: list[str] = []
        for i, item in enumerate(self.items):
            prefix = "▶ " if item.active else "  "
            line = f"{prefix}{item.label}"
            lines.append(line)

            # Render children if present
            if item.children:
                for child in item.children:
                    child_prefix = "  └─ " if item.active else "    "
                    child_line = f"{child_prefix}{child.label}"
                    lines.append(child_line)

        return lines

    def measure(self, console: Console) -> Measure:
        """Measure the menu's preferred size.

        Args:
            console: The console context for measurement.

        Returns:
            Measure object with width and height for the menu.
        """
        logger.log(5, f"Measuring menu: {self.component_name}")  # Use level 5 for TRACE

        if not self.items:
            return Measure(0, 0)

        max_width = 0
        total_height = 0

        for item in self.items:
            # Measure main item
            item_width = len(item.label) + 4  # prefix + label
            max_width = max(max_width, item_width)
            total_height += 1

            # Measure children
            if item.children:
                for child in item.children:
                    child_width = len(child.label) + 8  # indent + label
                    max_width = max(max_width, child_width)
                    total_height += 1

        return Measure(max_width, total_height)


__all__ = ["Menu", "MenuRenderable"]
