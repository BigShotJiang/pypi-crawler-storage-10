"""Status and progress components."""

from __future__ import annotations

from dataclasses import dataclass
from typing import TYPE_CHECKING, Any, Literal

from ..core import Console, Measure
from ..core.text.symbols import Symbols
from ..renderers.base import RenderableBase
from ..renderers.gui.types import GuiNode
from ..style import get_style_engine
from ..style.colors import Color

if TYPE_CHECKING:
    from ..core.console import RenderableLike

__all__ = [
    "ProgressBar",
    "StatusBar",
    "SegmentedBar",
    "Spinner",
    "Meter",
    "progress_bar",
    "status_bar",
    "segmented_bar",
    "spinner",
    "meter",
    "Thermometer",
    "Compass",
    "GaugeDial",
    "WeatherIndicator",
    "thermometer",
    "compass",
    "gauge_dial",
    "weather_indicator",
]


class ProgressBar:
    """Build progress bars for stats, loading, etc."""

    @staticmethod
    def render(
        current: int | float,
        maximum: int | float,
        width: int = 40,
        label: str = "",
        show_percentage: bool = True,
        show_numbers: bool = True,
        filled_char: str = "#",
        empty_char: str = "-",
        color: str | None = None,
        bracket_style: Literal["square", "round", "angle", "pipe", "none"] = "square",
        indeterminate: bool = False,
        frame: int = 0,
        blank_lines_before: int = 0,
        blank_lines_after: int = 0,
    ) -> str:
        """
        Render a progress bar.

        Args:
            current: Current value
            maximum: Maximum value
            width: Width of the bar (excluding label and numbers)
            label: Label text before the bar
            show_percentage: Show percentage after bar
            show_numbers: Show current/max numbers
            filled_char: Character for filled portion
            empty_char: Character for empty portion
            color: Bar color
            bracket_style: Style of brackets around bar
            blank_lines_before: Blank lines before bar
            blank_lines_after: Blank lines after bar
        """
        out: list[str] = []
        for _ in range(blank_lines_before):
            out.append("")

        if indeterminate:
            # Moving window within the bar
            window = max(1, width // 5)
            start = frame % (width + window)
            bar_chars = [empty_char] * width
            for i in range(window):
                pos = start - i
                if 0 <= pos < width:
                    bar_chars[pos] = filled_char
            bar = "".join(bar_chars)
            percentage = 0.0
        else:
            # Calculate percentage
            percentage = (current / maximum * 100.0) if maximum > 0 else 0.0
            filled_width = int(width * current / maximum) if maximum > 0 else 0
            filled_width = max(0, min(width, filled_width))

            # Build bar
            filled = filled_char * filled_width
            empty = empty_char * (width - filled_width)
            bar = filled + empty

        # Apply color
        if color:
            bar_color = Color.get_color(color)
            bar = bar_color + bar + Color.RESET

        # Apply brackets
        brackets = {
            "square": ("[", "]"),
            "round": ("(", ")"),
            "angle": ("<", ">"),
            "pipe": ("|", "|"),
            "none": ("", ""),
        }
        left, right = brackets.get(bracket_style, ("[", "]"))

        # Build output
        output = f"{label + ' ' if label else ''}{left}{bar}{right}"

        if show_percentage and not indeterminate:
            output += f" {percentage:.0f}%"

        if show_numbers and not indeterminate:
            output += f" ({current}/{maximum})"

        out.append(output)

        for _ in range(blank_lines_after):
            out.append("")
        return "\n".join(out)


def progress_bar(
    current: int | float,
    maximum: int | float,
    width: int = 40,
    label: str = "",
    show_percentage: bool = True,
    show_numbers: bool = True,
    filled_char: str = "#",
    empty_char: str = "-",
    color: str | None = None,
    bracket_style: Literal["square", "round", "angle", "pipe", "none"] = "square",
) -> _ProgressBarRenderable:
    """Return a renderable progress bar."""
    return _ProgressBarRenderable(
        current=current,
        maximum=maximum,
        width=width,
        label=label,
        show_percentage=show_percentage,
        show_numbers=show_numbers,
        filled_char=filled_char,
        empty_char=empty_char,
        color=color,
        bracket_style=bracket_style,
    )


def status_bar(
    stats: list[dict[str, Any]],
    width: int = 80,
    bar_width: int = 20,
    layout: Literal["horizontal", "vertical"] = "horizontal",
    show_icons: bool = True,
) -> _StatusBarRenderable:
    """Return a renderable status bar."""
    return _StatusBarRenderable(
        stats=stats,
        width=width,
        bar_width=bar_width,
        layout=layout,
        show_icons=show_icons,
    )


def segmented_bar(
    segments: list[tuple[str, int | float, str]],
    width: int = 60,
    show_values: bool = True,
    show_labels: bool = True,
    separator: str = "|",
) -> _SegmentedBarRenderable:
    """Return a renderable segmented bar."""
    return _SegmentedBarRenderable(
        segments=segments,
        width=width,
        show_values=show_values,
        show_labels=show_labels,
        separator=separator,
    )


def spinner(
    text: str = "Loading",
    frame: int = 0,
    style: str = "dots",
    color: str = "cyan",
) -> _SpinnerRenderable:
    """Return a renderable spinner."""
    return _SpinnerRenderable(
        text=text,
        frame=frame,
        style=style,
        color=color,
    )


def meter(
    value: float,
    min_val: float = 0.0,
    max_val: float = 100.0,
    width: int = 50,
    label: str = "",
    thresholds: dict[float, str] | None = None,
    show_value: bool = True,
) -> _MeterRenderable:
    """Return a renderable meter."""
    return _MeterRenderable(
        value=value,
        min_val=min_val,
        max_val=max_val,
        width=width,
        label=label,
        thresholds=thresholds,
        show_value=show_value,
    )


class StatusBar:
    """Build status bars for HP, MP, XP, etc."""

    @staticmethod
    def render(
        stats: list[dict[str, Any]],
        width: int = 80,
        bar_width: int = 20,
        layout: Literal["horizontal", "vertical"] = "horizontal",
        show_icons: bool = True,
        live_update: bool = False,
        frames: int = 0,
        fps: float = 8.0,
        blank_lines_before: int = 0,
        blank_lines_after: int = 0,
    ) -> str:
        """
        Render status bars for multiple stats.

        Args:
            stats: List of stat dictionaries with keys: label, current, max, color, icon
            width: Total width for horizontal layout
            bar_width: Width of each bar
            layout: Layout direction
            show_icons: Show icons before labels
            blank_lines_before: Blank lines before status bar
            blank_lines_after: Blank lines after status bar

        Example:
            StatusBar.render([
                {"label": "HP", "current": 75, "max": 100, "color": "red", "icon": "<3"},
                {"label": "MP", "current": 50, "max": 80, "color": "blue", "icon": "^"},
                {"label": "XP", "current": 300, "max": 500, "color": "gold", "icon": "*"}
            ])
        """
        out: list[str] = []
        for _ in range(blank_lines_before):
            out.append("")

        def _render_once(frame: int = 0) -> str:
            from io import StringIO

            buf = StringIO()
            import sys as _sys

            old = _sys.stdout
            try:
                _sys.stdout = buf
                for stat in stats:
                    label = stat.get("label", "")
                    current = stat.get("current", 0)
                    maximum = stat.get("max", 100)
                    color = stat.get("color", "white")
                    icon = stat.get("icon", "")

                    # Build label
                    if show_icons and icon:
                        display_label = f"{icon} {label}"
                    else:
                        display_label = label

                    # Animate indeterminate if max==0
                    indeterminate = maximum == 0
                    ProgressBar.render(
                        current=current,
                        maximum=maximum if maximum else 100,
                        width=bar_width,
                        label=display_label,
                        show_percentage=not indeterminate,
                        show_numbers=not indeterminate,
                        color=color,
                        bracket_style="square",
                        indeterminate=indeterminate,
                        frame=frame,
                    )
            finally:
                _sys.stdout = old
            return buf.getvalue().rstrip("\n")

        if live_update:
            console = Console()
            with console.live() as live:
                if frames <= 0:
                    frames = 40
                for f in range(frames):
                    live.update(_render_once(f))
                    import time as _t

                    _t.sleep(1.0 / max(1.0, fps))
        else:
            out.append(_render_once())

        for _ in range(blank_lines_after):
            out.append("")
        return "\n".join(out)


class Spinner:
    """Build loading spinners and indicators."""

    SPINNER_STYLES = {
        "dots": [".", "o", "O", "o"],
        "line": ["-", "\\", "|", "/"],
        "arrow": ["<", "^", ">", "v"],
        "box": ["[ ]", "[=]", "[#]", "[=]"],
        "circle": ["( )", "(o)", "(O)", "(o)"],
        "bouncing": ["*", ".", " ", "."],
    }

    @staticmethod
    def render(text: str = "Loading", frame: int = 0, style: str = "dots", color: str = "cyan") -> str:
        """
        Get a single frame of a spinner (for animation loops).

        Args:
            text: Loading text
            frame: Current frame number
            style: Spinner style
            color: Spinner color

        Returns:
            Formatted spinner string
        """
        frames = Spinner.SPINNER_STYLES.get(style, Spinner.SPINNER_STYLES["dots"])
        spinner_char = frames[frame % len(frames)]

        spinner_color = Color.get_color(color)
        return f"{spinner_color}{spinner_char}{Color.RESET} {text}..."


class SegmentedBar:
    """Build segmented progress bars (health with segments)."""

    @staticmethod
    def render(
        current: int,
        maximum: int,
        segments: int = 10,
        width: int = 40,
        label: str = "",
        color: str = "green",
        segment_char: str = "#",
        separator: str = " ",
        blank_lines_before: int = 0,
        blank_lines_after: int = 0,
    ) -> str:
        """
        Render a segmented progress bar.

        Args:
            current: Current value
            maximum: Maximum value
            segments: Number of segments
            width: Total bar width
            label: Label text
            color: Bar color
            segment_char: Character for segments
            separator: Separator between segments
            blank_lines_before: Blank lines before bar
            blank_lines_after: Blank lines after bar
        """
        out: list[str] = []
        for _ in range(blank_lines_before):
            out.append("")

        bar_color = Color.get_color(color)

        # Calculate segment width
        sep_total = len(separator) * (segments - 1)
        seg_width = (width - sep_total) // segments

        # Calculate filled segments
        filled_segments = int((current / maximum) * segments) if maximum > 0 else 0

        # Build bar
        bar_parts: list[str] = []
        for i in range(segments):
            if i < filled_segments:
                bar_parts.append(bar_color + segment_char * seg_width + Color.RESET)
            else:
                bar_parts.append(Symbols.BAR_EMPTY() * seg_width)

        bar = separator.join(bar_parts)

        # Output
        if label:
            out.append(f"{label}: [{bar}] {current}/{maximum}")
        else:
            out.append(f"[{bar}] {current}/{maximum}")

        for _ in range(blank_lines_after):
            out.append("")
        return "\n".join(out)


class Meter:
    """Build meter/gauge displays."""

    @staticmethod
    def render(
        value: float,
        min_val: float = 0.0,
        max_val: float = 100.0,
        width: int = 50,
        label: str = "",
        thresholds: dict[float, str] | None = None,
        show_value: bool = True,
        blank_lines_before: int = 0,
        blank_lines_after: int = 0,
    ) -> str:
        """
        Render a meter/gauge.

        Args:
            value: Current value
            min_val: Minimum value
            max_val: Maximum value
            width: Meter width
            label: Meter label
            thresholds: Dict of threshold:color pairs
            show_value: Show numeric value
            blank_lines_before: Blank lines before meter
            blank_lines_after: Blank lines after meter
        """
        out: list[str] = []
        for _ in range(blank_lines_before):
            out.append("")

        # Default thresholds
        if thresholds is None:
            thresholds = {0.0: "red", 0.3: "yellow", 0.7: "green"}

        # Calculate percentage
        percentage = (value - min_val) / (max_val - min_val) if max_val > min_val else 0
        percentage = max(0.0, min(1.0, percentage))

        # Determine color based on thresholds; coerce keys to float
        color = "white"
        try:
            th_items = [(float(k), v) for k, v in thresholds.items()]
        except Exception:
            th_items = [(k, v) for k, v in thresholds.items()]
        for threshold, threshold_color in sorted(th_items, key=lambda kv: kv[0]):
            if percentage >= float(threshold):
                color = threshold_color

        # Build meter
        filled = int(width * percentage)
        meter_color = Color.get_color(color)

        bar = meter_color + Symbols.BAR_FILLED() * filled + Symbols.BAR_EMPTY() * (width - filled) + Color.RESET

        # Output
        if label:
            value_str = f" {value:.1f}" if show_value else ""
            out.append(f"{label}: [{bar}]{value_str}")
        else:
            value_str = f" {value:.1f}" if show_value else ""
            out.append(f"[{bar}]{value_str}")

        for _ in range(blank_lines_after):
            out.append("")
        return "\n".join(out)


class Thermometer:
    """Vertical thermometer widget."""

    @staticmethod
    def render(
        value: float,
        *,
        min_val: float = 0.0,
        max_val: float = 100.0,
        height: int = 10,
        color: str = "red",
        label: str | None = None,
    ) -> str:
        out: list[str] = []
        pct = 0.0 if max_val <= min_val else (value - min_val) / (max_val - min_val)
        pct = max(0.0, min(1.0, pct))
        filled = int(round(pct * height))
        col = Color.get_color(color)
        out.append("  ___ ")
        for row in range(height, 0, -1):
            if row <= filled:
                bar = col + "|#|" + Color.RESET
            else:
                bar = "| |"
            out.append(f"  {bar}")
        out.append("  ---")
        if label:
            out.append(f"{label}: {value:.1f}")
        return "\n".join(out)


class Compass:
    """Cardinal compass with direction indicator."""

    @staticmethod
    def render(direction: float | str = 0.0, color: str = "cyan") -> str:
        if isinstance(direction, str):
            mapping = {"N": 0.0, "E": 90.0, "S": 180.0, "W": 270.0}
            deg = mapping.get(direction.upper(), 0.0)
        else:
            deg = float(direction)
        deg = deg % 360.0
        col = Color.get_color(color)
        lines: list[str] = []
        lines.append("   N")
        lines.append(" W + E")
        lines.append("   S")
        if deg < 45 or deg >= 315:
            arrow = "^"
        elif deg < 135:
            arrow = ">"
        elif deg < 225:
            arrow = "v"
        else:
            arrow = "<"
        lines.append(col + f"  {arrow} {deg:.0f} deg" + Color.RESET)
        return "\n".join(lines)


class GaugeDial:
    """Horizontal gauge with pointer."""

    @staticmethod
    def render(
        value: float,
        *,
        min_val: float = 0.0,
        max_val: float = 100.0,
        width: int = 20,
        color: str = "accent",
        label: str | None = None,
    ) -> str:
        pct = 0.0 if max_val <= min_val else (value - min_val) / (max_val - min_val)
        pct = max(0.0, min(1.0, pct))
        pos = int(pct * (width - 1))
        col = Color.get_color(color)
        scale = "|" + "-" * (width - 2) + "|"
        pointer = " " * pos + "^"
        lines = [col + scale + Color.RESET, pointer]
        if label:
            lines.append(f"{label}: {value:.1f}")
        return "\n".join(lines)


class WeatherIndicator:
    """Simple weather indicator with icon."""

    @staticmethod
    def render(condition: str, temperature_c: float | None = None) -> str:
        cond = condition.lower()
        icon = {
            "sunny": "(sun)",
            "clear": "(sun)",
            "cloudy": "(cloud)",
            "rain": "(rain)",
            "snow": "(snow)",
            "storm": "(storm)",
            "fog": "(fog)",
        }.get(cond, "(weather)")
        text = f"{icon} {condition.title()}"
        if temperature_c is not None:
            text += f" {temperature_c:.1f} degC"
        return text


@dataclass(slots=True)
class _ThermoRenderable(RenderableBase):
    """Renderable wrapper for Thermometer.render that returns strings."""

    value: float
    min_val: float = 0.0
    max_val: float = 100.0
    height: int = 10
    color: str = "red"
    label: str | None = None

    def render(self, console: Console) -> str:
        return Thermometer.render(
            self.value,
            min_val=self.min_val,
            max_val=self.max_val,
            height=self.height,
            color=self.color,
            label=self.label,
        )

    def measure(self, console: Console) -> Measure:
        return Measure.from_text(self.render(console))

    def to_node(self, console: Console) -> GuiNode:
        node = GuiNode("thermometer")
        # Calculate fill percentage
        percentage = (self.value - self.min_val) / (self.max_val - self.min_val)
        node.children.append(GuiNode("thermometer_fill", text=f"{percentage:.1%}"))
        if self.label:
            node.children.append(GuiNode("thermometer_label", text=self.label))
        return node


def thermometer(
    value: float,
    *,
    min_val: float = 0.0,
    max_val: float = 100.0,
    height: int = 10,
    color: str = "red",
    label: str | None = None,
) -> RenderableLike:
    return _ThermoRenderable(
        value=value,
        min_val=min_val,
        max_val=max_val,
        height=height,
        color=color,
        label=label,
    )


def compass(
    heading: float | str = 0.0,
    color: str = "cyan",
) -> _CompassRenderable:
    """Return a renderable compass."""
    return _CompassRenderable(
        heading=heading,
        color=color,
    )


def gauge_dial(
    value: float,
    min_val: float = 0.0,
    max_val: float = 100.0,
    width: int = 20,
    color: str = "accent",
    label: str | None = None,
) -> _GaugeDialRenderable:
    """Return a renderable gauge dial."""
    return _GaugeDialRenderable(
        value=value,
        min_val=min_val,
        max_val=max_val,
        width=width,
        color=color,
        label=label,
    )


def weather_indicator(
    condition: str,
    temperature_c: float | None = None,
) -> _WeatherIndicatorRenderable:
    """Return a renderable weather indicator."""
    return _WeatherIndicatorRenderable(
        condition=condition,
        temperature_c=temperature_c,
    )


# Renderable classes for GUI support
@dataclass(slots=True)
class _ProgressBarRenderable(RenderableBase):
    """Renderable wrapper for ProgressBar.render that returns strings."""

    current: int | float
    maximum: int | float
    width: int = 40
    label: str = ""
    show_percentage: bool = True
    show_numbers: bool = True
    filled_char: str = "#"
    empty_char: str = "-"
    color: str | None = None
    bracket_style: Literal["square", "round", "angle", "pipe", "none"] = "square"

    def render(self, console: object) -> str:
        return ProgressBar.render(
            self.current,
            self.maximum,
            width=self.width,
            label=self.label,
            show_percentage=self.show_percentage,
            show_numbers=self.show_numbers,
            filled_char=self.filled_char,
            empty_char=self.empty_char,
            color=self.color,
            bracket_style=self.bracket_style,
        )

    def to_node(self, console: object) -> GuiNode:
        node = GuiNode("progress_bar")
        percentage = (self.current / self.maximum) if self.maximum > 0 else 0
        node.children.append(GuiNode("progress_fill", text=f"{percentage:.1%}"))
        if self.label:
            node.children.append(GuiNode("progress_label", text=self.label))
        return node


@dataclass(slots=True)
class _StatusBarRenderable(RenderableBase):
    """Renderable wrapper for StatusBar.render that returns strings."""

    stats: list[dict[str, Any]]
    width: int = 80
    bar_width: int = 20
    layout: Literal["horizontal", "vertical"] = "horizontal"
    show_icons: bool = True

    def render(self, console: object) -> str:
        return StatusBar.render(
            self.stats,
            width=self.width,
            bar_width=self.bar_width,
            layout=self.layout,
            show_icons=self.show_icons,
            blank_lines_before=0,
            blank_lines_after=0,
        )

    def to_node(self, console: object) -> GuiNode:
        node = GuiNode("status_bar")
        for stat in self.stats:
            item_node = GuiNode("status_item")
            if "label" in stat:
                item_node.children.append(GuiNode("status_label", text=str(stat["label"])))
            if "value" in stat:
                item_node.children.append(GuiNode("status_value", text=str(stat["value"])))
            node.children.append(item_node)
        return node


@dataclass(slots=True)
class _SegmentedBarRenderable(RenderableBase):
    """Renderable wrapper for SegmentedBar.render that returns strings."""

    segments: list[tuple[str, int | float, str]]
    width: int = 60
    show_values: bool = True
    show_labels: bool = True
    separator: str = "|"

    def render(self, console: object) -> str:
        """Render multiple segments as a combined bar."""
        if not self.segments:
            return ""

        out: list[str] = []

        # Calculate total value for proportional sizing
        total_value = sum(value for _, value, _ in self.segments)

        # Build segments
        bar_parts: list[str] = []
        labels: list[str] = []
        values: list[str] = []

        for label, value, color in self.segments:
            if total_value > 0:
                # Calculate segment width proportionally
                segment_width = int((value / total_value) * self.width)
            else:
                segment_width = self.width // len(self.segments)

            # Ensure minimum width of 1
            segment_width = max(1, segment_width)

            # Create colored segment
            bar_color = Color.get_color(color)
            segment = bar_color + "█" * segment_width + Color.RESET
            bar_parts.append(segment)

            if self.show_labels:
                labels.append(label)
            if self.show_values:
                values.append(str(int(value)))

        # Combine segments with separator
        bar = self.separator.join(bar_parts)

        # Add labels and values if requested
        if self.show_labels and labels:
            out.append(" ".join(labels))
        out.append(bar)
        if self.show_values and values:
            out.append(" ".join(values))

        return "\n".join(out)

    def to_node(self, console: object) -> GuiNode:
        # Resolve TFS styles for this component
        engine = get_style_engine()
        resolved_style = engine.resolve(node={"component_name": "segmented_bar"}, state={}, caps=None)

        node = GuiNode("segmented_bar", style=resolved_style)
        for label, value, _ in self.segments:
            segment_node = GuiNode("segment", text=f"{label}: {value}")
            node.children.append(segment_node)
        return node


@dataclass(slots=True)
class _SpinnerRenderable(RenderableBase):
    """Renderable wrapper for Spinner.render that returns strings."""

    frame: int = 0
    style: str = "dots"
    color: str = "cyan"
    text: str = ""

    def render(self, console: object) -> str:
        return Spinner.render(
            text=self.text,
            frame=self.frame,
            style=self.style,
            color=self.color,
        )

    def to_node(self, console: object) -> GuiNode:
        node = GuiNode("spinner")
        node.children.append(GuiNode("spinner_icon", text="⟳"))
        if self.text:
            node.children.append(GuiNode("spinner_text", text=self.text))
        return node


@dataclass(slots=True)
class _MeterRenderable(RenderableBase):
    """Renderable wrapper for Meter.render that returns strings."""

    value: float
    min_val: float = 0.0
    max_val: float = 100.0
    width: int = 50
    label: str = ""
    thresholds: dict[float, str] | None = None
    show_value: bool = True

    def render(self, console: object) -> str:
        return Meter.render(
            self.value,
            min_val=self.min_val,
            max_val=self.max_val,
            width=self.width,
            label=self.label,
            thresholds=self.thresholds,
            show_value=self.show_value,
            blank_lines_before=0,
            blank_lines_after=0,
        )

    def to_node(self, console: object) -> GuiNode:
        node = GuiNode("meter")
        percentage = (self.value - self.min_val) / (self.max_val - self.min_val)
        node.children.append(GuiNode("meter_fill", text=f"{percentage:.1%}"))
        if self.label:
            node.children.append(GuiNode("meter_label", text=self.label))
        return node


@dataclass(slots=True)
class _CompassRenderable(RenderableBase):
    """Renderable wrapper for Compass.render that returns strings."""

    heading: float | str = 0.0
    color: str = "cyan"

    def render(self, console: object) -> str:
        return Compass.render(
            self.heading,
            color=self.color,
        )

    def to_node(self, console: object) -> GuiNode:
        node = GuiNode("compass")
        node.children.append(GuiNode("compass_heading", text=f"{self.heading}°"))
        return node


@dataclass(slots=True)
class _GaugeDialRenderable(RenderableBase):
    """Renderable wrapper for GaugeDial.render that returns strings."""

    value: float
    min_val: float = 0.0
    max_val: float = 100.0
    width: int = 20
    color: str = "accent"
    label: str | None = None

    def render(self, console: object) -> str:
        return GaugeDial.render(
            self.value,
            min_val=self.min_val,
            max_val=self.max_val,
            width=self.width,
            color=self.color,
            label=self.label,
        )

    def to_node(self, console: object) -> GuiNode:
        node = GuiNode("gauge_dial")
        percentage = (self.value - self.min_val) / (self.max_val - self.min_val)
        node.children.append(GuiNode("gauge_needle", text=f"{percentage:.1%}"))
        if self.label:
            node.children.append(GuiNode("gauge_label", text=self.label))
        return node


@dataclass(slots=True)
class _WeatherIndicatorRenderable(RenderableBase):
    """Renderable wrapper for WeatherIndicator.render that returns strings."""

    condition: str
    temperature_c: float | None = None

    def render(self, console: object) -> str:
        return WeatherIndicator.render(
            self.condition,
            temperature_c=self.temperature_c,
        )

    def to_node(self, console: object) -> GuiNode:
        node = GuiNode("weather_indicator")
        node.children.append(GuiNode("weather_condition", text=self.condition))
        if self.temperature_c is not None:
            node.children.append(GuiNode("weather_temperature", text=f"{self.temperature_c:.1f}°C"))
        return node
