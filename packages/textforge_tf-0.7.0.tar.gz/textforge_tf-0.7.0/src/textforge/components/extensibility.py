"""Component extensibility patterns and examples.

This module provides patterns and examples for creating custom components
through inheritance and composition, as described in the Textforge
architecture.
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import TYPE_CHECKING

from ..core.console import Measure
from ..utils.logging import get_logger
from .base import Component, ContainerRenderable, RenderableComponent
from .containers.base import ContainerBase
from .registry import register_component

if TYPE_CHECKING:
    from collections.abc import Callable

    from ..core.console import Console
    from ..style.subsystem import StylingContext

logger = get_logger(__name__)


# Example 1: Inheritance Pattern - Custom Card Component
class CustomCard(ContainerBase):
    """Example custom card component using inheritance pattern.

    This demonstrates the inheritance pattern for creating custom components
    with specialized behavior while inheriting from base classes.
    """

    def __init__(
        self,
        title: str,
        content: Component | None = None,
        actions: list[Component] | None = None,
        variant: str = "default",
        **kwargs: object
    ) -> None:
        """Initialize the custom card.

        Args:
            title: Card title text.
            content: Main content component.
            actions: Action components (buttons, etc.).
            variant: Visual variant ("default", "elevated", "outlined").
            **kwargs: Additional arguments passed to parent.
        """
        super().__init__(**kwargs)
        self.title = title
        self.content = content
        self.actions = actions or []
        self.variant = variant

    @property
    def component_name(self) -> str:
        """Return the component name for styling purposes."""
        return f"custom-card-{self.variant}"

    def to_renderable(self, styling_context: StylingContext | None = None) -> CustomCardRenderable:
        """Convert this card to a renderable card.

        Args:
            styling_context: The styling context for this component.

        Returns:
            A CustomCardRenderable instance.
        """
        from ..style.subsystem import StylingContext

        context = styling_context or StylingContext(component_name=self.component_name)
        renderable = CustomCardRenderable(
            component_name=self.component_name,
            styling_context=context,
            title=self.title,
            variant=self.variant
        )

        # Add title component
        from .text import Text
        title_comp = Text(self.title, style="card-title")
        renderable.title_component = title_comp.to_renderable(context)

        # Add content
        if self.content:
            renderable.content_component = self.content.to_renderable(context)

        # Add actions
        for action in self.actions:
            renderable.add_action(action.to_renderable(context))

        # Add children from parent
        for child in self.children:
            renderable.add_child(child.to_renderable(context))

        return renderable


@dataclass(slots=True)
class CustomCardRenderable(ContainerRenderable):
    """Renderable custom card component."""

    title: str = ""
    title_component: RenderableComponent | None = None
    content_component: RenderableComponent | None = None
    actions: list[RenderableComponent] | None = None
    variant: str = "default"

    def __post_init__(self) -> None:
        if self.actions is None:
            self.actions = []

    def add_action(self, action: RenderableComponent) -> None:
        """Add an action component."""
        self.actions.append(action)

    def render(self, console: Console) -> str | list[str] | None:
        """Render the custom card.

        Args:
            console: The console to render to.

        Returns:
            The rendered output.
        """
        logger.log(5, f"Rendering custom card: {self.component_name}")

        # Get resolved style
        _ = self.get_resolved_style(console)

        rendered_parts: list[str] = []

        # Render title
        if self.title_component:
            title_output = self.title_component.render(console)
            if title_output:
                rendered_parts.append(str(title_output))

        # Render content
        if self.content_component:
            content_output = self.content_component.render(console)
            if content_output:
                rendered_parts.append(str(content_output))

        # Render children
        for child in self.children:
            child_output = child.render(console)
            if child_output:
                rendered_parts.append(str(child_output))

        # Render actions
        if self.actions:
            action_outputs: list[str] = []
            for action in self.actions:
                action_output = action.render(console)
                if action_output:
                    action_outputs.append(str(action_output))
            if action_outputs:
                rendered_parts.append(" ".join(action_outputs))

        return "\n".join(rendered_parts)

    def measure(self, console: Console) -> Measure:
        """Measure the custom card's dimensions.

        Args:
            console: The console context for measurement.

        Returns:
            Measure object with width and height.
        """
        logger.log(5, f"Measuring custom card: {self.component_name}")

        total_height = 0
        max_width = 0

        # Measure title
        if self.title_component:
            title_measure = self.title_component.measure(console)
            max_width = max(max_width, title_measure.width)
            total_height += title_measure.height

        # Measure content
        if self.content_component:
            content_measure = self.content_component.measure(console)
            max_width = max(max_width, content_measure.width)
            total_height += content_measure.height

        # Measure children
        for child in self.children:
            child_measure = child.measure(console)
            max_width = max(max_width, child_measure.width)
            total_height += child_measure.height

        # Measure actions
        if self.actions:
            action_width = 0
            action_height = 0
            for action in self.actions:
                action_measure = action.measure(console)
                action_width += action_measure.width + 1  # Add space between actions
                action_height = max(action_height, action_measure.height)
            max_width = max(max_width, action_width)
            total_height += action_height

        # Add spacing
        num_sections = sum([
            1 if self.title_component else 0,
            1 if self.content_component else 0,
            1 if self.children else 0,
            1 if self.actions else 0
        ])
        if num_sections > 1:
            total_height += num_sections - 1  # Add line breaks between sections

        return Measure(max_width, total_height)


# Example 2: Composition Pattern - Dashboard Panel
def DashboardPanel(
    title: str,
    metrics: list[tuple[str, str]],
    status: str = "normal",
    **kwargs: object
) -> CustomCard:
    """Create a dashboard panel using composition pattern.

    This demonstrates the composition pattern where complex components
    are built by composing simpler components together.

    Args:
        title: Panel title.
        metrics: List of (label, value) metric tuples.
        status: Status indicator ("normal", "warning", "error").
        **kwargs: Additional arguments.

    Returns:
        A composed dashboard panel component.
    """
    from .containers import Box
    from .text import Text

    # Create metric components
    metric_components: list[Component] = []
    for label, value in metrics:
        metric_box = Box(
            direction="horizontal",
            children=[
                Text(f"{label}: ", style="metric-label"),
                Text(value, style="metric-value")
            ]
        )
        metric_components.append(metric_box)

    # Create status indicator
    status_colors = {
        "normal": "status-normal",
        "warning": "status-warning",
        "error": "status-error"
    }
    status_component = Text(f"[{status.upper()}]", style=status_colors.get(status, "status-normal"))

    # Compose the panel using CustomCard
    return CustomCard(
        title=title,
        content=Box(
            direction="vertical",
            children=metric_components
        ),
        actions=[status_component],
        variant="dashboard",
        **kwargs
    )


# Example 3: Factory Function Pattern - Themed Components
def create_themed_button(
    text: str,
    theme_variant: str,
    **kwargs: object
) -> Component:
    """Create a themed button using factory pattern.

    Args:
        text: Button text.
        theme_variant: Theme variant ("primary", "secondary", "danger").
        **kwargs: Additional button arguments.

    Returns:
        A themed button component.
    """
    from .interactive import Button

    # Map theme variants to style classes
    style_map = {
        "primary": "button-primary",
        "secondary": "button-secondary",
        "danger": "button-danger"
    }

    style_class = style_map.get(theme_variant, "button-primary")

    return Button(text, style=style_class, **kwargs)


# Example 4: Plugin-based Custom Component
def register_custom_components() -> None:
    """Register custom components with the component registry.

    This demonstrates how to register custom components for global use.
    """
    # Register the custom card
    register_component("CustomCard", CustomCard)

    # Register the dashboard panel factory
    register_component("DashboardPanel", DashboardPanel)

    # Register themed button factory
    register_component("ThemedButton", create_themed_button)

    logger.debug("Registered custom components")


# Example 5: Mixin Pattern for Component Extensions
class ClickableMixin:
    """Mixin to add click handling to components."""

    def __init__(self, on_click: object = None, **kwargs: object) -> None:
        self.on_click = on_click
        super().__init__(**kwargs)

    def handle_click(self, event: object) -> None:
        """Handle click events."""
        if self.on_click:
            self.on_click(event)


class HoverableMixin:
    """Mixin to add hover effects to components."""

    def __init__(self, on_hover: object = None, **kwargs: object) -> None:
        self.on_hover = on_hover
        super().__init__(**kwargs)

    def handle_hover(self, event: object) -> None:
        """Handle hover events."""
        if self.on_hover:
            self.on_hover(event)


# Example usage of mixins
class InteractiveCard(CustomCard, ClickableMixin, HoverableMixin):
    """Card component with interactive capabilities using mixins."""

    def __init__(self, on_click: Callable[[], None] | None = None, on_hover: Callable[[], None] | None = None, **kwargs: object) -> None:
        # Initialize mixins first, then parent classes
        ClickableMixin.__init__(self, on_click=on_click)
        HoverableMixin.__init__(self, on_hover=on_hover)
        CustomCard.__init__(self, **kwargs)


# Export the custom components
__all__ = [
    "CustomCard",
    "CustomCardRenderable",
    "DashboardPanel",
    "create_themed_button",
    "InteractiveCard",
    "ClickableMixin",
    "HoverableMixin",
    "register_custom_components",
]
