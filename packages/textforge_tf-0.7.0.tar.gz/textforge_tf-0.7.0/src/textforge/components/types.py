"""Type definitions and protocols for the component subsystem."""

from __future__ import annotations

from collections.abc import Callable, Sequence
from typing import TYPE_CHECKING, Protocol, runtime_checkable

if TYPE_CHECKING:
    from ..core.console import Console, Measure
    from ..renderers.gui.types import GuiNode
    from ..style.subsystem import StylingContext
    from ..style.tfs.tfs_cascade import ResolvedStyle

RenderableOutput = str | Sequence[str] | None


@runtime_checkable
class RenderableComponentProtocol(Protocol):
    """Protocol describing renderable component capabilities."""

    component_name: str
    styling_context: StylingContext | None

    def get_resolved_style(self) -> ResolvedStyle:
        """Return the resolved style for this component.

        Returns:
            ResolvedStyle: Fully resolved TFS style.
        """

        ...

    def invalidate_cached_style(self) -> None:
        """Invalidate any cached style.

        Returns:
            None
        """

        ...

    def render(self, console: Console) -> RenderableOutput:
        """Render using the provided console abstraction.

        Args:
            console: Console to render against.

        Returns:
            RenderableOutput: Rendered content for downstream processing.
        """

        ...

    def measure(self, console: Console) -> Measure:
        """Measure component dimensions with respect to a console.

        Args:
            console: Console to use for measurement.

        Returns:
            Measure: Width and height measurement.
        """

        ...

    def to_node(self, console: Console) -> GuiNode:
        """Convert the component into a GUI node representation.

        Args:
            console: Console context provided for compatibility.

        Returns:
            GuiNode: GUI representation including layout metadata.
        """

        ...


@runtime_checkable
class ComponentProtocol(Protocol):
    """Protocol describing logical component behaviour."""

    @property
    def component_name(self) -> str:
        """Return the canonical component name.

        Returns:
            str: Name used for styling resolution.
        """

        ...

    def to_renderable(self, styling_context: StylingContext | None = None) -> RenderableComponentProtocol:
        """Convert the logical component into its renderable counterpart.

        Args:
            styling_context: Optional override styling context.

        Returns:
            RenderableComponentProtocol: Renderable component matching this definition.
        """

        ...


ComponentFactory = Callable[..., ComponentProtocol]

ComponentChildren = Sequence[ComponentProtocol]
RenderableChildren = Sequence[RenderableComponentProtocol]
ComponentProps = dict[str, object]
StyleProps = dict[str, object]

__all__ = [
    "ComponentFactory",
    "ComponentProtocol",
    "RenderableComponentProtocol",
    "ComponentChildren",
    "RenderableChildren",
    "ComponentProps",
    "RenderableOutput",
    "StyleProps",
]
