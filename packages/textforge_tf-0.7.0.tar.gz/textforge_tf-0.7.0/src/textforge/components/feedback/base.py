"""Backward-compatible import for feedback base classes."""

from __future__ import annotations

from ..base import FeedbackBase

__all__ = ["FeedbackBase"]