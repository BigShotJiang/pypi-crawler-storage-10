"""Alert component for displaying important notifications."""

from __future__ import annotations

from typing import TYPE_CHECKING, Literal

from ...core.console import Console, Measure
from ...utils.logging import get_logger
from ..base import ComponentError, RenderableComponent
from .base import FeedbackBase

if TYPE_CHECKING:
    from ...style.subsystem import StylingContext

logger = get_logger(__name__)


class Alert(FeedbackBase):
    """Alert component for displaying important notifications with different severity levels."""

    def __init__(
        self,
        message: str,
        severity: Literal["info", "warning", "error", "success"] = "info",
        title: str | None = None,
        dismissible: bool = False,
        **kwargs: object,
    ) -> None:
        """Initialize an Alert component.

        Args:
            message: The alert message text.
            severity: The severity level of the alert.
            title: Optional title for the alert.
            dismissible: Whether the alert can be dismissed by the user.
            **kwargs: Additional keyword arguments passed to parent.
        """
        super().__init__(**kwargs)
        self.message = message
        self.severity = severity
        self.title = title
        self.dismissible = dismissible

    @property
    def component_name(self) -> str:
        """Return the component name for styling purposes."""
        return "alert"

    def to_renderable(self, styling_context: StylingContext | None = None) -> AlertRenderable:
        """Convert this alert to a renderable component.

        Args:
            styling_context: The styling context for this component.

        Returns:
            A renderable alert component instance.
        """
        from ...style.subsystem import StylingContext

        context = styling_context or StylingContext(component_name=self.component_name)
        return AlertRenderable(
            component_name=self.component_name,
            styling_context=context,
            message=self.message,
            severity=self.severity,
            title=self.title,
            dismissible=self.dismissible,
        )

    def dismiss(self) -> None:
        """Dismiss the alert if it is dismissible.

        Raises:
            ComponentError: If the alert is not dismissible.
        """
        if not self.dismissible:
            raise ComponentError("Alert is not dismissible")
        # Implementation for dismissal logic would go here
        # This is a placeholder for actual dismissal behavior


class AlertRenderable(RenderableComponent):
    """Renderable alert component."""

    def __init__(
        self,
        component_name: str,
        styling_context: StylingContext,
        message: str,
        severity: str,
        title: str | None,
        dismissible: bool,
    ) -> None:
        """Initialize the renderable alert component.

        Args:
            component_name: The name of the component.
            styling_context: The styling context.
            message: The alert message.
            severity: The severity level.
            title: Optional title.
            dismissible: Whether dismissible.
        """
        super().__init__(component_name, styling_context)
        self.message = message
        self.severity = severity
        self.title = title
        self.dismissible = dismissible

    def render(self, console: Console) -> str | list[str] | None:
        """Render the alert component.

        Args:
            console: The console to render to.

        Returns:
            The rendered alert as a string.
        """
        logger.log(5, f"Rendering alert: {self.component_name}")  # Use level 5 for TRACE

        # Get resolved style for styling
        _ = self.get_resolved_style(console)

        lines: list[str] = []

        # Add title if present
        if self.title:
            lines.append(f"[{self.severity.upper()}] {self.title}")

        # Add message
        lines.append(self.message)

        # Add dismiss hint if dismissible
        if self.dismissible:
            lines.append("(Press X to dismiss)")

        return "\n".join(lines)

    def measure(self, console: Console) -> Measure:
        """Measure the alert component's preferred size.

        Args:
            console: The console context for measurement.

        Returns:
            Measure object with width and height for the alert.
        """
        logger.log(5, f"Measuring alert: {self.component_name}")  # Use level 5 for TRACE

        width = max(len(self.message), len(self.title) if self.title else 0)
        height = 1  # message
        if self.title:
            height += 1
        if self.dismissible:
            height += 1

        return Measure(width, height)


def alert(
    message: str,
    severity: Literal["info", "warning", "error", "success"] = "info",
    title: str | None = None,
    dismissible: bool = False,
) -> Alert:
    """Create an alert component.

    Args:
        message: The alert message text.
        severity: The severity level of the alert.
        title: Optional title for the alert.
        dismissible: Whether the alert can be dismissed by the user.

    Returns:
        A new Alert component instance.
    """
    return Alert(
        message=message,
        severity=severity,
        title=title,
        dismissible=dismissible,
    )


__all__ = ["Alert", "AlertRenderable", "alert"]
