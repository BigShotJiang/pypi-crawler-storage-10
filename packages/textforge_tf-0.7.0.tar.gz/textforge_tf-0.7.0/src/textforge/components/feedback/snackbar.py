"""Snackbar component for brief notifications."""

from __future__ import annotations

from typing import TYPE_CHECKING, Literal

from ...core.console import Console, Measure
from ...utils.logging import get_logger
from ..base import RenderableComponent
from .base import FeedbackBase

if TYPE_CHECKING:
    from ...style.subsystem import StylingContext

logger = get_logger(__name__)


class Snackbar(FeedbackBase):
    """Snackbar component for displaying brief, one-line notifications."""

    def __init__(
        self,
        message: str,
        tone: Literal["info", "success", "warning", "error"] = "info",
        width: int = 80,
        align: Literal["left", "center", "right"] = "center",
        border_style: str = "single",
        **kwargs: object,
    ) -> None:
        """Initialize a Snackbar component.

        Args:
            message: The snackbar message text.
            tone: The tone/severity of the snackbar.
            width: The width of the snackbar in characters.
            align: Text alignment within the snackbar.
            border_style: The border style for the snackbar.
            **kwargs: Additional keyword arguments passed to parent.
        """
        super().__init__(**kwargs)
        self.message = message
        self.tone = tone
        self.width = width
        self.align = align
        self.border_style = border_style

    @property
    def component_name(self) -> str:
        """Return the component name for styling purposes."""
        return "snackbar"

    def to_renderable(self, styling_context: StylingContext | None = None) -> SnackbarRenderable:
        """Convert this snackbar to a renderable component.

        Args:
            styling_context: The styling context for this component.

        Returns:
            A renderable snackbar component instance.
        """
        from ...style.subsystem import StylingContext

        context = styling_context or StylingContext(component_name=self.component_name)
        return SnackbarRenderable(
            component_name=self.component_name,
            styling_context=context,
            message=self.message,
            tone=self.tone,
            width=self.width,
            align=self.align,
            border_style=self.border_style,
        )


class SnackbarRenderable(RenderableComponent):
    """Renderable snackbar component."""

    def __init__(
        self,
        component_name: str,
        styling_context: StylingContext,
        message: str,
        tone: str,
        width: int,
        align: str,
        border_style: str,
    ) -> None:
        """Initialize the renderable snackbar component.

        Args:
            component_name: The name of the component.
            styling_context: The styling context.
            message: The snackbar message.
            tone: The tone/severity.
            width: Snackbar width.
            align: Text alignment.
            border_style: Border style.
        """
        super().__init__(component_name, styling_context)
        self.message = message
        self.tone = tone
        self.width = width
        self.align = align
        self.border_style = border_style

    def render(self, console: Console) -> str | list[str] | None:
        """Render the snackbar component.

        Args:
            console: The console to render to.

        Returns:
            The rendered snackbar as a string.
        """
        logger.log(5, f"Rendering snackbar: {self.component_name}")  # Use level 5 for TRACE

        # Get resolved style for styling
        _ = self.get_resolved_style(console)

        # Simple snackbar rendering
        if self.align == "center":
            text = self.message.center(self.width)
        elif self.align == "right":
            text = self.message.rjust(self.width)
        else:  # left
            text = self.message.ljust(self.width)

        return f"[{self.tone.upper()}] {text[:self.width]}"

    def measure(self, console: Console) -> Measure:
        """Measure the snackbar component's preferred size.

        Args:
            console: The console context for measurement.

        Returns:
            Measure object with width and height for the snackbar.
        """
        logger.log(5, f"Measuring snackbar: {self.component_name}")  # Use level 5 for TRACE

        width = self.width
        height = 1

        return Measure(width, height)


def snackbar(
    message: str,
    tone: Literal["info", "success", "warning", "error"] = "info",
    width: int = 80,
    align: Literal["left", "center", "right"] = "center",
    border_style: str = "single",
) -> Snackbar:
    """Create a snackbar component.

    Args:
        message: The snackbar message text.
        tone: The tone/severity of the snackbar.
        width: The width of the snackbar in characters.
        align: Text alignment within the snackbar.
        border_style: The border style for the snackbar.

    Returns:
        A new Snackbar component instance.
    """
    return Snackbar(
        message=message,
        tone=tone,
        width=width,
        align=align,
        border_style=border_style,
    )


__all__ = ["Snackbar", "SnackbarRenderable", "snackbar"]
