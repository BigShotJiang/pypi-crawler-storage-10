"""Toast component for transient notifications."""

from __future__ import annotations

import time
from typing import TYPE_CHECKING, Literal

from ...core.console import Console, Measure
from ...utils.logging import get_logger
from ..base import RenderableComponent
from .base import FeedbackBase

if TYPE_CHECKING:
    from ...style.subsystem import StylingContext

logger = get_logger(__name__)


class Toast(FeedbackBase):
    """Toast component for displaying transient notifications."""

    def __init__(
        self,
        message: str,
        tone: Literal["info", "success", "warning", "error"] = "info",
        duration: float | None = 4.0,
        width: int = 60,
        border_style: str = "rounded",
        **kwargs: object,
    ) -> None:
        """Initialize a Toast component.

        Args:
            message: The toast message text.
            tone: The tone/severity of the toast.
            duration: How long to display the toast in seconds, or None for indefinite.
            width: The width of the toast in characters.
            border_style: The border style for the toast.
            **kwargs: Additional keyword arguments passed to parent.
        """
        super().__init__(**kwargs)
        self.message = message
        self.tone = tone
        self.duration = duration
        self.width = width
        self.border_style = border_style
        self.created_at = time.monotonic()

    @property
    def component_name(self) -> str:
        """Return the component name for styling purposes."""
        return "toast"

    def to_renderable(self, styling_context: StylingContext | None = None) -> ToastRenderable:
        """Convert this toast to a renderable component.

        Args:
            styling_context: The styling context for this component.

        Returns:
            A renderable toast component instance.
        """
        from ...style.subsystem import StylingContext

        context = styling_context or StylingContext(component_name=self.component_name)
        return ToastRenderable(
            component_name=self.component_name,
            styling_context=context,
            message=self.message,
            tone=self.tone,
            duration=self.duration,
            width=self.width,
            border_style=self.border_style,
            created_at=self.created_at,
        )

    def is_expired(self) -> bool:
        """Check if the toast has expired.

        Returns:
            True if the toast has expired, False otherwise.
        """
        if self.duration is None:
            return False
        return time.monotonic() - self.created_at >= self.duration


class ToastRenderable(RenderableComponent):
    """Renderable toast component."""

    def __init__(
        self,
        component_name: str,
        styling_context: StylingContext,
        message: str,
        tone: str,
        duration: float | None,
        width: int,
        border_style: str,
        created_at: float,
    ) -> None:
        """Initialize the renderable toast component.

        Args:
            component_name: The name of the component.
            styling_context: The styling context.
            message: The toast message.
            tone: The tone/severity.
            duration: Display duration.
            width: Toast width.
            border_style: Border style.
            created_at: Creation timestamp.
        """
        super().__init__(component_name, styling_context)
        self.message = message
        self.tone = tone
        self.duration = duration
        self.width = width
        self.border_style = border_style
        self.created_at = created_at

    def render(self, console: Console) -> str | list[str] | None:
        """Render the toast component.

        Args:
            console: The console to render to.

        Returns:
            The rendered toast as a string.
        """
        logger.log(5, f"Rendering toast: {self.component_name}")  # Use level 5 for TRACE

        # Get resolved style for styling
        _ = self.get_resolved_style(console)

        # Simple toast rendering
        lines: list[str] = []
        lines.append(f"[{self.tone.upper()}] {self.message}")

        # Add duration indicator if applicable
        if self.duration:
            elapsed = time.monotonic() - self.created_at
            remaining = max(0, self.duration - elapsed)
            if remaining > 0:
                progress = int((remaining / self.duration) * 20)
                bar = "█" * progress + "░" * (20 - progress)
                lines.append(f"[{bar}] {remaining:.1f}s")

        return "\n".join(lines)

    def measure(self, console: Console) -> Measure:
        """Measure the toast component's preferred size.

        Args:
            console: The console context for measurement.

        Returns:
            Measure object with width and height for the toast.
        """
        logger.log(5, f"Measuring toast: {self.component_name}")  # Use level 5 for TRACE

        width = max(self.width, len(self.message) + 10)
        height = 1
        if self.duration:
            height += 1  # progress bar

        return Measure(width, height)


def toast(
    message: str,
    tone: Literal["info", "success", "warning", "error"] = "info",
    duration: float | None = 4.0,
    width: int = 60,
    border_style: str = "rounded",
) -> Toast:
    """Create a toast component.

    Args:
        message: The toast message text.
        tone: The tone/severity of the toast.
        duration: How long to display the toast in seconds, or None for indefinite.
        width: The width of the toast in characters.
        border_style: The border style for the toast.

    Returns:
        A new Toast component instance.
    """
    return Toast(
        message=message,
        tone=tone,
        duration=duration,
        width=width,
        border_style=border_style,
    )


__all__ = ["Toast", "ToastRenderable", "toast"]
