"""Decorative components such as dividers and banners."""

from __future__ import annotations

# Renderable classes for GUI support
from dataclasses import dataclass
from typing import Literal

from ..core.text.symbols import Symbols
from ..renderers.base import RenderableBase
from ..renderers.gui.types import GuiNode
from ..style import get_style_engine
from ..style.colors import Color

__all__ = [
    "Divider",
    "Banner",
    "Timeline",
    "Tooltip",
    "AsciiArt",
    "divider",
    "banner",
    "timeline",
    "tooltip",
    "ascii_art",
]


class Divider:
    """Build horizontal dividers and separators."""

    @staticmethod
    def render(
        width: int = 80,
        style: Literal["solid", "double", "dashed", "dotted", "heavy", "wave", "decorative"] = "solid",
        text: str = "",
        text_position: Literal["left", "center", "right"] = "center",
        color: str | None = None,
        blank_lines_before: int = 0,
        blank_lines_after: int = 0,
    ) -> str:
        """
        Render a horizontal divider.

        Args:
            width: Total width of divider
            style: Style of divider line
            text: Optional text in the divider
            text_position: Position of text
            color: Divider color
            blank_lines_before: Blank lines before divider
            blank_lines_after: Blank lines after divider
        """
        lines: list[str] = []
        for _ in range(blank_lines_before):
            lines.append("")

        # Define line characters
        chars = {
            "solid": "─",
            "double": "═",
            "dashed": "┄",
            "dotted": "·",
            "heavy": "━",
            "wave": "~",
            "decorative": "═══",
        }
        char = chars.get(style, "─")

        # Build divider
        if text:
            text_with_spaces = f" {text} "
            text_len = len(text_with_spaces)

            if text_position == "left":
                line = text_with_spaces + char * (width - text_len)
            elif text_position == "right":
                line = char * (width - text_len) + text_with_spaces
            else:  # center
                left_width = (width - text_len) // 2
                right_width = width - text_len - left_width
                line = char * left_width + text_with_spaces + char * right_width
        else:
            line = char * width

        # Apply color
        if color:
            line_color = Color.get_color(color)
            line = line_color + line + Color.RESET

        lines.append(line)

        for _ in range(blank_lines_after):
            lines.append("")
        return "\n".join(lines)


def divider(
    width: int = 80,
    style: Literal["solid", "double", "dashed", "dotted", "heavy", "wave", "decorative"] = "solid",
    text: str = "",
    text_position: Literal["left", "center", "right"] = "center",
    color: str | None = None,
    blank_lines_before: int = 0,
    blank_lines_after: int = 0,
) -> _DividerRenderable:
    """Return a renderable divider component."""
    return _DividerRenderable(
        width=width,
        style=style,
        text=text,
        text_position=text_position,
        color=color,
        blank_lines_before=blank_lines_before,
        blank_lines_after=blank_lines_after,
    )


def banner(
    text: str,
    width: int = 80,
    style: Literal["simple", "block", "double"] = "simple",
    color: str | None = None,
    blank_lines_before: int = 1,
    blank_lines_after: int = 1,
) -> _BannerRenderable:
    """Return a renderable banner component."""
    return _BannerRenderable(
        text=text,
        width=width,
        style=style,
        color=color,
        blank_lines_before=blank_lines_before,
        blank_lines_after=blank_lines_after,
    )


def tooltip(
    text: str,
    width: int = 40,
    color: str | None = None,
    border_style: str = "rounded",
    arrow: Literal["up", "down", "left", "right"] = "up",
) -> _TooltipRenderable:
    """Return a renderable tooltip."""
    return _TooltipRenderable(
        text=text,
        width=width,
        color=color,
        border_style=border_style,
        arrow=arrow,
    )


def timeline(
    events: list[dict[str, str]],
    width: int = 80,
    marker_color: str = "green",
    title_color: str = "bold",
    time_color: str = "dim",
    show_times: bool = True,
) -> _TimelineRenderable:
    """Return a renderable timeline."""
    return _TimelineRenderable(
        events=events,
        width=width,
        marker_color=marker_color,
        title_color=title_color,
        time_color=time_color,
        show_times=show_times,
    )


def ascii_art(
    text: str,
    font: str = "tiny",
    color: str | None = None,
) -> _AsciiArtRenderable:
    """Return a renderable ASCII art block."""
    return _AsciiArtRenderable(
        text=text,
        font=font,
        color=color,
    )


class Banner:
    """Create large decorative text banners."""

    @staticmethod
    def render(
        text: str,
        style: Literal["simple", "block", "double"] = "simple",
        width: int = 80,
        color: str | None = None,
        blank_lines_before: int = 1,
        blank_lines_after: int = 1,
    ) -> str:
        """
        Render a decorative banner.

        Args:
            text: Banner text
            style: Banner style
            width: Banner width
            color: Text color
            blank_lines_before: Blank lines before banner
            blank_lines_after: Blank lines after banner
        """
        out: list[str] = []
        for _ in range(blank_lines_before):
            out.append("")

        text_color = Color.get_color(color) if color else ""

        if style == "block":
            # Block style with filled background
            border = "█" * width
            padding = "█" + " " * (width - 2) + "█"
            text_centered = text.center(width - 2)
            text_line = "█" + text_color + text_centered + Color.RESET + "█"

            out.append(border)
            out.append(padding)
            out.append(text_line)
            out.append(padding)
            out.append(border)

        elif style == "double":
            # Double line border
            top = "╔" + "═" * (width - 2) + "╗"
            padding = "║" + " " * (width - 2) + "║"
            text_centered = text.center(width - 2)
            text_line = "║" + text_color + text_centered + Color.RESET + "║"
            bottom = "╚" + "═" * (width - 2) + "╝"

            out.append(top)
            out.append(padding)
            out.append(text_line)
            out.append(padding)
            out.append(bottom)

        else:  # simple
            # Simple with decorative characters
            border = "=" * width
            text_centered = text.center(width)
            if color:
                text_centered = text_color + text_centered + Color.RESET

            out.append(border)
            out.append(text_centered)
            out.append(border)

        for _ in range(blank_lines_after):
            out.append("")
        return "\n".join(out)


class Tooltip:
    """Render a tooltip-like box with small arrow indicator."""

    @staticmethod
    def render(
        text: str,
        width: int = 40,
        color: str | None = None,
        border_style: str = "rounded",
        arrow: Literal["up", "down", "left", "right"] = "up",
        blank_lines_before: int = 0,
        blank_lines_after: int = 0,
        ascii_mode: bool | None = None,
    ) -> str:
        out: list[str] = []
        for _ in range(blank_lines_before):
            out.append("")

        _ = Symbols.get_symbols(border_style, ascii_mode)
        col = Color.get_color(color) if color else ""
        reset = Color.RESET if color else ""

        # Arrow line
        arrow_map = {"up": "▲", "down": "▼", "left": "◀", "right": "▶"}
        arrow_char = arrow_map.get(arrow, "▲")
        out.append(" " * ((width // 2) - 1) + arrow_char)

        # Boxed text
        out.extend(Divider.render(width=width, style="dashed").splitlines())
        lines = [text]
        for line in lines:
            visible = len(line)
            pad = max(0, width - visible)
            out.append(col + line + reset + " " * pad)
        out.extend(Divider.render(width=width, style="dashed").splitlines())

        for _ in range(blank_lines_after):
            out.append("")
        return "\n".join(out)


class Timeline:
    """Render a vertical timeline of events with markers and timestamps."""

    @staticmethod
    def render(
        events: list[dict[str, str]],
        width: int = 80,
        marker_color: str = "accent",
        text_color: str | None = None,
        title_color: str | None = None,
        time_color: str | None = None,
        show_times: bool = True,
    ) -> str:
        out: list[str] = []
        mcol = Color.get_color(marker_color)
        title_col = Color.get_color(title_color) if title_color else (Color.get_color(text_color) if text_color else "")
        time_col = Color.get_color(time_color) if time_color else Color.DIM
        title_reset = Color.RESET if title_color or text_color else ""
        time_reset = Color.RESET

        for i, ev in enumerate(events):
            ts = ev.get("time", "")
            title = ev.get("title", "")
            desc = ev.get("desc", "")
            connector = "│" if i < len(events) - 1 else " "
            marker = f"{mcol}●{Color.RESET}"

            time_part = f" {time_col}{ts}{time_reset}" if show_times and ts else ""
            out.append(f"{connector} {marker} {title_col}{title}{title_reset}{time_part}")

            if desc:
                out.append(f"{connector}    {desc}")
        return "\n".join(out)


class AsciiArt:
    """Render ASCII art banners from text using simple fonts.

    For now, supports two built-in simple fonts without external deps.
    """

    FONTS = {
        "tiny": {
            "A": [" /\\ ", "/--\\", "\\__/"],
            "B": ["|__]", "|__]"],
        },
        "block": {},
    }

    @staticmethod
    def render(text: str, font: str = "tiny", color: str | None = None) -> str:
        col = Color.get_color(color) if color else ""
        reset = Color.RESET if color else ""
        # Extremely small demo font: fallback to plain text if missing
        lines: list[str] = ["", "", ""]
        font_map = AsciiArt.FONTS.get(font, {})
        for ch in text.upper():
            glyph = font_map.get(ch)
            if not glyph:
                # Fallback: append the char to the middle line
                lines[1] += ch + " "
                continue
            for i, row in enumerate(glyph):
                if i >= len(lines):
                    lines.append("")
                lines[i] += row + "  "
        return "\n".join(col + line.rstrip() + reset for line in lines)


@dataclass(slots=True)
class _DividerRenderable(RenderableBase):
    """Renderable wrapper for Divider.render that returns strings."""

    width: int = 80
    style: Literal["solid", "double", "dashed", "dotted", "heavy", "wave", "decorative"] = "solid"
    text: str = ""
    text_position: Literal["left", "center", "right"] = "center"
    color: str | None = None
    blank_lines_before: int = 0
    blank_lines_after: int = 0

    def render(self, console: object) -> str:
        return Divider.render(
            width=self.width,
            style=self.style,
            text=self.text,
            text_position=self.text_position,
            color=self.color,
            blank_lines_before=self.blank_lines_before,
            blank_lines_after=self.blank_lines_after,
        )

    def to_node(self, console: object) -> GuiNode:
        # Resolve TFS styles for this component
        engine = get_style_engine()
        node_dict = {"component_name": "Divider"}
        resolved_style = engine.resolve(node=node_dict, state={}, caps=None)

        node = GuiNode("divider", text=self.text, style=resolved_style)
        return node


@dataclass(slots=True)
class _BannerRenderable(RenderableBase):
    """Renderable wrapper for Banner.render that returns strings."""

    text: str
    width: int = 80
    style: Literal["simple", "block", "double"] = "simple"
    color: str | None = None
    blank_lines_before: int = 1
    blank_lines_after: int = 1

    def render(self, console: object) -> str:
        return Banner.render(
            text=self.text,
            width=self.width,
            style=self.style,
            color=self.color,
            blank_lines_before=self.blank_lines_before,
            blank_lines_after=self.blank_lines_after,
        )

    def to_node(self, console: object) -> GuiNode:
        # Resolve TFS styles for this component
        engine = get_style_engine()
        node_dict = {"component_name": "Banner"}
        resolved_style = engine.resolve(node=node_dict, state={}, caps=None)

        node = GuiNode("banner", text=self.text, style=resolved_style)
        return node


@dataclass(slots=True)
class _TooltipRenderable(RenderableBase):
    """Renderable wrapper for Tooltip.render that returns strings."""

    text: str
    width: int = 40
    color: str | None = None
    border_style: str = "rounded"
    arrow: Literal["up", "down", "left", "right"] = "up"

    def render(self, console: object) -> str:
        return Tooltip.render(
            text=self.text,
            width=self.width,
            color=self.color,
            border_style=self.border_style,
            arrow=self.arrow,
            blank_lines_before=0,
            blank_lines_after=0,
            ascii_mode=None,
        )

    def to_node(self, console: object) -> GuiNode:
        # Resolve TFS styles for this component
        engine = get_style_engine()
        node_dict = {"component_name": "Tooltip"}
        resolved_style = engine.resolve(node=node_dict, state={}, caps=None)

        node = GuiNode("tooltip", style=resolved_style)
        node.children.append(GuiNode("text", text=self.text))
        return node


@dataclass(slots=True)
class _TimelineRenderable(RenderableBase):
    """Renderable wrapper for Timeline.render that returns strings."""

    events: list[dict[str, str]]
    width: int = 80
    marker_color: str = "green"
    title_color: str = "bold"
    time_color: str = "dim"
    show_times: bool = True

    def render(self, console: object) -> str:
        return Timeline.render(
            events=self.events,
            width=self.width,
            marker_color=self.marker_color,
            title_color=self.title_color,
            time_color=self.time_color,
            show_times=self.show_times,
        )

    def to_node(self, console: object) -> GuiNode:
        # Resolve TFS styles for this component
        engine = get_style_engine()
        node_dict = {"component_name": "Timeline"}
        resolved_style = engine.resolve(node=node_dict, state={}, caps=None)

        node = GuiNode("timeline", style=resolved_style)
        for event in self.events:
            event_node = GuiNode("timeline_event")
            if "title" in event:
                event_node.children.append(GuiNode("title", text=event["title"]))
            if "time" in event:
                event_node.children.append(GuiNode("time", text=event["time"]))
            if "desc" in event:
                event_node.children.append(GuiNode("description", text=event["desc"]))
            node.children.append(event_node)
        return node


@dataclass(slots=True)
class _AsciiArtRenderable(RenderableBase):
    """Renderable wrapper for AsciiArt.render that returns strings."""

    text: str
    font: str = "tiny"
    color: str | None = None

    def render(self, console: object) -> str:
        return AsciiArt.render(
            text=self.text,
            font=self.font,
            color=self.color,
        )

    def to_node(self, console: object) -> GuiNode:
        # Resolve TFS styles for this component
        engine = get_style_engine()
        node_dict = {"component_name": "AsciiArt"}
        resolved_style = engine.resolve(node=node_dict, state={}, caps=None)

        node = GuiNode("ascii_art", text=self.text, style=resolved_style)
        return node
