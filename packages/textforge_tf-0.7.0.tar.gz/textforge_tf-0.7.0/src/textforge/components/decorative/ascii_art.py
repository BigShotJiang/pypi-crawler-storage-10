"""ASCII art decorative component."""

from __future__ import annotations

from typing import TYPE_CHECKING

from ...core.console import Console, Measure
from ...utils.logging import get_logger
from ..base import DecorativeBase, RenderableComponent

if TYPE_CHECKING:
    from ...style.subsystem import StylingContext

logger = get_logger(__name__)


class ASCIIArt(DecorativeBase):
    """A decorative component for displaying ASCII art."""

    def __init__(self, art: str, align: str = "left", **kwargs: object) -> None:
        """Initialize the ASCII art component.

        Args:
            art: The ASCII art string to display.
            align: Text alignment ("left", "center", "right").
            **kwargs: Additional keyword arguments passed to parent.
        """
        super().__init__(**kwargs)
        self.art = art
        self.align = align

    @property
    def component_name(self) -> str:
        """Return the component name for styling purposes."""
        return "ascii_art"

    def to_renderable(self, styling_context: StylingContext | None = None) -> ASCIIArtRenderable:
        """Convert this ASCII art to a renderable ASCII art.

        Args:
            styling_context: The styling context for this component.

        Returns:
            An ASCIIArtRenderable instance.
        """
        from ...style.subsystem import StylingContext

        context = styling_context or StylingContext(component_name=self.component_name)
        return ASCIIArtRenderable(
            component_name=self.component_name,
            styling_context=context,
            art=self.art,
            align=self.align,
        )


class ASCIIArtRenderable(RenderableComponent):
    """Renderable ASCII art decorative component."""

    def __init__(self, component_name: str, styling_context: StylingContext, art: str, align: str = "left") -> None:
        """Initialize the renderable ASCII art component.

        Args:
            component_name: The name of the component.
            styling_context: The styling context.
            art: The ASCII art string.
            align: Text alignment.
        """
        super().__init__(component_name, styling_context)
        self.art = art
        self.align = align

    def render(self, console: Console) -> str | list[str] | None:
        """Render the ASCII art component with proper formatting.

        Args:
            console: The console to render to.

        Returns:
            The rendered ASCII art as a string.
        """
        logger.log(5, f"Rendering ASCII art: {self.component_name}")  # Use level 5 for TRACE

        # Get resolved style for styling
        _ = self.get_resolved_style(console)

        lines = self.art.splitlines()
        return lines

    def measure(self, console: Console) -> Measure:
        """Measure the ASCII art component's preferred size.

        Args:
            console: The console context for measurement.

        Returns:
            Measure object with width and height for the ASCII art.
        """
        logger.log(5, f"Measuring ASCII art: {self.component_name}")  # Use level 5 for TRACE

        lines = self.art.splitlines()
        width = max(len(line) for line in lines) if lines else 0
        height = len(lines)
        return Measure(width, height)


__all__ = ["ASCIIArt", "ASCIIArtRenderable"]
