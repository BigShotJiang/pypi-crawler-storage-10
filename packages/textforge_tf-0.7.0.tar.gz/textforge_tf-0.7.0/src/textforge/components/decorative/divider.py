"""Divider decorative component."""

from __future__ import annotations

from dataclasses import dataclass
from typing import TYPE_CHECKING

from ...core.console import Console, Measure
from ...utils.logging import get_logger
from ..base import DecorativeBase, RenderableComponent

if TYPE_CHECKING:
    from ...style.subsystem import StylingContext

logger = get_logger(__name__)


class Divider(DecorativeBase):
    """A decorative divider component for separating content sections."""

    def __init__(self, style: str = "solid", length: int | None = None, **kwargs: object) -> None:
        """Initialize the divider component.

        Args:
            style: The divider style (e.g., "solid", "dashed", "dotted").
            length: Optional fixed length for the divider.
            **kwargs: Additional keyword arguments passed to parent.
        """
        super().__init__(**kwargs)
        self.style = style
        self.length = length

    @property
    def component_name(self) -> str:
        """Return the component name for styling purposes."""
        return "divider"

    def to_renderable(self, styling_context: StylingContext | None = None) -> DividerRenderable:
        """Convert this divider to a renderable divider.

        Args:
            styling_context: The styling context for this component.

        Returns:
            A DividerRenderable instance.
        """
        from ...style.subsystem import StylingContext

        context = styling_context or StylingContext(component_name=self.component_name)
        return DividerRenderable(
            component_name=self.component_name,
            styling_context=context,
            style=self.style,
            length=self.length,
        )


@dataclass(slots=True)
class DividerRenderable(RenderableComponent):
    """Renderable divider decorative component."""

    style: str = "solid"
    length: int | None = None

    def render(self, console: Console) -> str | list[str] | None:
        """Render the divider component with horizontal/vertical divider lines and styles.

        Args:
            console: The console to render to.

        Returns:
            The rendered divider as a string.
        """
        logger.log(5, f"Rendering divider: {self.component_name}")  # Use level 5 for TRACE

        # Get resolved style for styling
        _ = self.get_resolved_style(console)

        # Get terminal width from console
        width = 80  # Default width

        # Use specified length or full width
        divider_width = self.length if self.length is not None else width

        # Create divider based on style
        if self.style == "dashed":
            line_char = "-"
        elif self.style == "dotted":
            line_char = "."
        elif self.style == "double":
            line_char = "="
        else:  # solid or default
            line_char = "─"

        divider_line = line_char * divider_width
        return divider_line

    def measure(self, console: Console) -> Measure:
        """Measure the divider component's preferred size.

        Args:
            console: The console context for measurement.

        Returns:
            Measure object with width and height for the divider.
        """
        logger.log(5, f"Measuring divider: {self.component_name}")  # Use level 5 for TRACE

        # Use specified length or default width
        width = self.length if self.length is not None else 80
        height = 1  # Dividers are typically 1 character high

        return Measure(width, height)


__all__ = ["Divider", "DividerRenderable"]
