"""Backward-compatible import for decorative base classes."""

from __future__ import annotations

from ..base import DecorativeBase

__all__ = ["DecorativeBase"]