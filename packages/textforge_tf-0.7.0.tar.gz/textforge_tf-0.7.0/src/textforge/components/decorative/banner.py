"""Banner decorative component."""

from __future__ import annotations

from typing import TYPE_CHECKING

from ...core.console import Console, Measure
from ...utils.logging import get_logger
from ..base import DecorativeBase, RenderableComponent

if TYPE_CHECKING:
    from ...style.subsystem import StylingContext

logger = get_logger(__name__)


class Banner(DecorativeBase):
    """A decorative banner component for displaying prominent text or graphics."""

    def __init__(self, content: str, style: str = "default", **kwargs: object) -> None:
        """Initialize the banner component.

        Args:
            content: The banner content to display.
            style: The banner style (e.g., "default", "success", "warning", "error").
            **kwargs: Additional keyword arguments passed to parent.
        """
        super().__init__(**kwargs)
        self.content = content
        self.style = style

    @property
    def component_name(self) -> str:
        """Return the component name for styling purposes."""
        return "banner"

    def to_renderable(self, styling_context: StylingContext | None = None) -> BannerRenderable:
        """Convert this banner to a renderable banner.

        Args:
            styling_context: The styling context for this component.

        Returns:
            A BannerRenderable instance.
        """
        from ...style.subsystem import StylingContext

        context = styling_context or StylingContext(component_name=self.component_name)
        return BannerRenderable(
            component_name=self.component_name,
            styling_context=context,
            content=self.content,
            style=self.style,
        )


class BannerRenderable(RenderableComponent):
    """Renderable banner decorative component."""

    def __init__(self, component_name: str, styling_context: StylingContext, content: str, style: str = "default") -> None:
        """Initialize the renderable banner component.

        Args:
            component_name: The name of the component.
            styling_context: The styling context.
            content: The banner content.
            style: The banner style.
        """
        super().__init__(component_name, styling_context)
        self.content = content
        self.style = style

    def render(self, console: Console) -> str | list[str] | None:
        """Render the banner component with styled text and centering/alignment.

        Args:
            console: The console to render to.

        Returns:
            The rendered banner as a string.
        """
        logger.log(5, f"Rendering banner: {self.component_name}")  # Use level 5 for TRACE

        # Get resolved style for styling
        _ = self.get_resolved_style(console)

        # Create centered banner text
        width = 80  # Default terminal width
        padding = max(0, (width - len(self.content)) // 2)
        banner_line = " " * padding + self.content

        # Add top and bottom borders
        border = "=" * width
        banner = f"{border}\n{banner_line}\n{border}"

        return banner

    def measure(self, console: Console) -> Measure:
        """Measure the banner component's preferred size.

        Args:
            console: The console context for measurement.

        Returns:
            Measure object with width and height for the banner.
        """
        logger.log(5, f"Measuring banner: {self.component_name}")  # Use level 5 for TRACE

        width = 80  # Default terminal width
        height = 3  # Banner height is always 3 lines (top border, content, bottom border)
        return Measure(width, height)


__all__ = ["Banner", "BannerRenderable"]
