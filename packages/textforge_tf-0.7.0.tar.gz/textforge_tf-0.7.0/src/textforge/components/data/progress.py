"""Progress component for displaying progress indicators."""

from __future__ import annotations

from dataclasses import dataclass
from typing import TYPE_CHECKING

from ...core.console import Console, Measure
from ...utils.logging import get_logger
from ..base import DataBase, RenderableComponent

if TYPE_CHECKING:
    from ...style.subsystem import StylingContext

logger = get_logger(__name__)


@dataclass
class ProgressData:
    """Data structure for progress component."""

    value: float  # Current progress value (0.0 to 1.0)
    label: str | None = None
    show_percentage: bool = True

    def __post_init__(self) -> None:
        """Validate progress data."""
        if not (0.0 <= self.value <= 1.0):
            raise ValueError("Progress value must be between 0.0 and 1.0")


class Progress(DataBase):
    """Progress component for displaying progress indicators."""

    def __init__(self, data: ProgressData, **kwargs: object) -> None:
        """Initialize the progress component.

        Args:
            data: The progress data to display.
            **kwargs: Additional keyword arguments.
        """
        super().__init__(**kwargs)
        self.data = data

    @property
    def component_name(self) -> str:
        """Return the component name for styling purposes."""
        return "progress"

    def to_renderable(self, styling_context: StylingContext | None = None) -> ProgressRenderable:
        """Convert this component to a renderable progress bar.

        Args:
            styling_context: The styling context for this component.

        Returns:
            A ProgressRenderable instance.
        """
        from ...style.subsystem import StylingContext

        context = styling_context or StylingContext(component_name=self.component_name)
        return ProgressRenderable(
            component_name=self.component_name,
            styling_context=context,
            data=self.data,
        )


class ProgressRenderable(RenderableComponent):
    """Renderable progress component."""

    def __init__(self, component_name: str, styling_context: StylingContext, data: ProgressData) -> None:
        """Initialize the renderable progress component.

        Args:
            component_name: The name of the component.
            styling_context: The styling context.
            data: The progress data.
        """
        super().__init__(component_name, styling_context)
        self.data = data

    def render(self, console: Console) -> str | list[str] | None:
        """Render the progress bar.

        Args:
            console: The console to render to.

        Returns:
            The rendered progress bar as a string.
        """
        logger.log(5, f"Rendering progress: {self.component_name}")  # Use level 5 for TRACE

        # Get resolved style for styling
        _ = self.get_resolved_style(console)

        # Calculate progress bar dimensions
        bar_width = 38  # Fixed width for now
        filled_width = int(self.data.value * bar_width)

        # Create progress bar
        background = "░" * bar_width
        filled = "█" * filled_width
        bar = filled + background[filled_width:]

        # Add borders
        progress_bar = f"[{bar}]"

        # Add label/percentage
        if self.data.show_percentage:
            percentage = f"{int(self.data.value * 100)}%"
            return f"{progress_bar} {percentage}"
        elif self.data.label:
            return f"{progress_bar} {self.data.label}"
        else:
            return progress_bar

    def measure(self, console: Console) -> Measure:
        """Measure the progress bar's preferred size.

        Args:
            console: The console context for measurement.

        Returns:
            Measure object with width and height for the progress bar.
        """
        logger.log(5, f"Measuring progress: {self.component_name}")  # Use level 5 for TRACE

        # Calculate width
        width = 40  # [bar] + space + percentage/label
        if self.data.label:
            width += len(self.data.label) + 1
        elif self.data.show_percentage:
            width += 4  # "100%" + space

        height = 1

        return Measure(width, height)


__all__ = ["Progress", "ProgressRenderable", "ProgressData"]
