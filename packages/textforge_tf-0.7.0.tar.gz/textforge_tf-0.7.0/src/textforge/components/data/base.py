"""Backward-compatible import for data base classes."""

from __future__ import annotations

from ..base import DataBase

__all__ = ["DataBase"]