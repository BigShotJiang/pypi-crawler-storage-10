"""Table component for displaying tabular data."""

from __future__ import annotations

from dataclasses import dataclass
from typing import TYPE_CHECKING, Any

from ...core.console import Console, Measure
from ...utils.logging import get_logger
from ..base import DataBase, RenderableComponent

if TYPE_CHECKING:
    from ...style.subsystem import StylingContext

logger = get_logger(__name__)


@dataclass
class TableData:
    """Data structure for table component."""

    headers: list[str]
    rows: list[list[Any]]
    column_widths: list[int] | None = None

    def __post_init__(self) -> None:
        """Validate table data."""
        if not self.headers:
            raise ValueError("Table must have at least one header")

        if self.rows and len(self.headers) != len(self.rows[0]):
            raise ValueError("All rows must have the same number of columns as headers")

        if self.column_widths and len(self.column_widths) != len(self.headers):
            raise ValueError("Column widths must match number of headers")


class Table(DataBase):
    """Table component for displaying tabular data."""

    def __init__(self, data: TableData, **kwargs: object) -> None:
        """Initialize the table component.

        Args:
            data: The table data to display.
            **kwargs: Additional keyword arguments.
        """
        super().__init__(**kwargs)
        self.data = data

    @property
    def component_name(self) -> str:
        """Return the component name for styling purposes."""
        return "table"

    def to_renderable(self, styling_context: StylingContext | None = None) -> TableRenderable:
        """Convert this component to a renderable table.

        Args:
            styling_context: The styling context for this component.

        Returns:
            A TableRenderable instance.
        """
        from ...style.subsystem import StylingContext

        context = styling_context or StylingContext(component_name=self.component_name)
        return TableRenderable(
            component_name=self.component_name,
            styling_context=context,
            data=self.data,
        )


class TableRenderable(RenderableComponent):
    """Renderable table component."""

    def __init__(self, component_name: str, styling_context: StylingContext, data: TableData) -> None:
        """Initialize the renderable table component.

        Args:
            component_name: The name of the component.
            styling_context: The styling context.
            data: The table data.
        """
        super().__init__(component_name, styling_context)
        self.data = data

    def render(self, console: Console) -> str | list[str] | None:
        """Render the table.

        Args:
            console: The console to render to.

        Returns:
            The rendered table as a list of strings.
        """
        logger.log(5, f"Rendering table: {self.component_name}")  # Use level 5 for TRACE

        # Get resolved style for styling
        _ = self.get_resolved_style(console)

        if not self.data.headers:
            return []

        lines: list[str] = []

        # Calculate column widths
        if self.data.column_widths:
            col_widths = self.data.column_widths
        else:
            # Auto-calculate column widths
            col_widths: list[int] = []
            for i, header in enumerate(self.data.headers):
                max_width = len(header)
                for row in self.data.rows:
                    if i < len(row):
                        max_width = max(max_width, len(str(row[i])))
                col_widths.append(max_width + 2)  # Add padding

        # Render headers
        header_parts: list[str] = []
        for i, header in enumerate(self.data.headers):
            header_parts.append(header.ljust(col_widths[i]))
        lines.append("".join(header_parts).rstrip())

        # Render separator
        separator_parts: list[str] = []
        for width in col_widths:
            separator_parts.append("-" * width)
        lines.append("".join(separator_parts).rstrip())

        # Render rows
        for row in self.data.rows:
            row_parts: list[str] = []
            for i, cell in enumerate(row):
                if i < len(col_widths):
                    row_parts.append(str(cell).ljust(col_widths[i]))
            lines.append("".join(row_parts).rstrip())

        return lines

    def measure(self, console: Console) -> Measure:
        """Measure the table's preferred size.

        Args:
            console: The console context for measurement.

        Returns:
            Measure object with width and height for the table.
        """
        logger.log(5, f"Measuring table: {self.component_name}")  # Use level 5 for TRACE

        if not self.data.headers:
            return Measure(0, 0)

        # Calculate column widths
        if self.data.column_widths:
            total_width = sum(self.data.column_widths)
        else:
            # Auto-calculate column widths
            col_widths: list[int] = []
            for i, header in enumerate(self.data.headers):
                max_width = len(header)
                for row in self.data.rows:
                    if i < len(row):
                        max_width = max(max_width, len(str(row[i])))
                col_widths.append(max_width + 2)  # Add padding
            total_width = sum(col_widths)

        # Height = headers (1) + separator (1) + rows
        height = 2 + len(self.data.rows)

        return Measure(total_width, height)


__all__ = ["Table", "TableRenderable", "TableData"]
