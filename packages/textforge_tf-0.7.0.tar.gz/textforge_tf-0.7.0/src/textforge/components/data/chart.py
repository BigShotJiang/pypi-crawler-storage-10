"""Chart component for displaying data visualizations."""

from __future__ import annotations

from dataclasses import dataclass
from typing import TYPE_CHECKING

from ...core.console import Console, Measure
from ...utils.logging import get_logger
from ..base import DataBase, RenderableComponent

if TYPE_CHECKING:
    from ...style.subsystem import StylingContext

logger = get_logger(__name__)


@dataclass
class ChartData:
    """Data structure for chart component."""

    labels: list[str]
    datasets: list[ChartDataset]

    def __post_init__(self) -> None:
        """Validate chart data."""
        if not self.labels:
            raise ValueError("Chart must have at least one label")

        if not self.datasets:
            raise ValueError("Chart must have at least one dataset")


@dataclass
class ChartDataset:
    """Data structure for a single chart dataset."""

    label: str
    data: list[float | int]
    color: str | None = None


class Chart(DataBase):
    """Chart component for displaying data visualizations."""

    def __init__(self, data: ChartData, chart_type: str = "bar", **kwargs: object) -> None:
        """Initialize the chart component.

        Args:
            data: The chart data to display.
            chart_type: Type of chart (bar, line, pie, etc.).
            **kwargs: Additional keyword arguments.
        """
        super().__init__(**kwargs)
        self.data = data
        self.chart_type = chart_type

    @property
    def component_name(self) -> str:
        """Return the component name for styling purposes."""
        return "chart"

    def to_renderable(self, styling_context: StylingContext | None = None) -> ChartRenderable:
        """Convert this component to a renderable chart.

        Args:
            styling_context: The styling context for this component.

        Returns:
            A ChartRenderable instance.
        """
        from ...style.subsystem import StylingContext

        context = styling_context or StylingContext(component_name=self.component_name)
        return ChartRenderable(
            component_name=self.component_name,
            styling_context=context,
            data=self.data,
        )


class ChartRenderable(RenderableComponent):
    """Renderable chart component."""

    def __init__(self, component_name: str, styling_context: StylingContext, data: ChartData) -> None:
        """Initialize the renderable chart component.

        Args:
            component_name: The name of the component.
            styling_context: The styling context.
            data: The chart data.
        """
        super().__init__(component_name, styling_context)
        self.data = data

    def render(self, console: Console) -> str | list[str] | None:
        """Render the chart.

        Args:
            console: The console to render to.

        Returns:
            The rendered chart as a list of strings.
        """
        logger.log(5, f"Rendering chart: {self.component_name}")  # Use level 5 for TRACE

        # Get resolved style for styling
        _ = self.get_resolved_style(console)

        if not self.data.datasets:
            return []

        # Simple bar chart implementation
        return self._render_bar_chart()

    def _render_bar_chart(self) -> list[str]:
        """Render a bar chart.

        Returns:
            List of strings representing the chart.
        """
        if not self.data.datasets:
            return []

        dataset = self.data.datasets[0]  # Use first dataset for now
        if isinstance(dataset, dict):
            data = dataset.get('data', [])
        else:
            data = dataset.data
        max_value = max(data) if data else 1

        chart_width = 60  # Fixed width for now
        chart_height = 10  # Fixed height for now

        lines: list[str] = []

        # Create empty chart area
        for _ in range(chart_height):
            lines.append(" " * chart_width)

        # Draw bars
        bar_width = chart_width // len(data) if data else 1

        for i, value in enumerate(data):
            bar_height = int((value / max_value) * chart_height) if max_value > 0 else 0
            bar_x = i * bar_width

            # Draw bar from bottom up
            for h in range(bar_height):
                y = chart_height - 1 - h
                for w in range(min(bar_width - 1, chart_width - bar_x)):
                    if bar_x + w < chart_width:
                        lines[y] = lines[y][:bar_x + w] + "█" + lines[y][bar_x + w + 1:]

        # Add labels at bottom
        label_line = ""
        for i, label in enumerate(self.data.labels):
            if i < len(data):
                label_x = i * bar_width + (bar_width // 2) - len(label) // 2
                if label_x >= 0 and label_x + len(label) <= chart_width:
                    # Insert label
                    while len(label_line) < label_x:
                        label_line += " "
                    if len(label_line) == label_x:
                        label_line += label
                    else:
                        # Overlay label
                        for j, char in enumerate(label):
                            if label_x + j < len(label_line):
                                label_line = label_line[:label_x + j] + char + label_line[label_x + j + 1:]
                            else:
                                label_line += char

        lines.append(label_line[:chart_width])

        return lines

    def measure(self, console: Console) -> Measure:
        """Measure the chart's preferred size.

        Args:
            console: The console context for measurement.

        Returns:
            Measure object with width and height for the chart.
        """
        logger.log(5, f"Measuring chart: {self.component_name}")  # Use level 5 for TRACE

        # Default size for chart
        width = 60
        height = 12  # Chart + labels

        return Measure(width, height)


__all__ = ["Chart", "ChartRenderable", "ChartData", "ChartDataset"]
