"""Container-style components (boxes, cards, panels, dialogs)."""

from __future__ import annotations

from abc import ABC, abstractmethod
from dataclasses import dataclass
from typing import TYPE_CHECKING, Any, Literal

from ..core import Console, Measure
from ..core.text.symbols import Symbols
from ..core.text_engine import visible_width as _vw
from ..renderers.base import RenderableBase
from ..renderers.gui.types import GuiNode
from ..style.colors import Color
from ..utils import get_visible_length, wrap_text
from ..utils.input import read_key

if TYPE_CHECKING:
    from collections.abc import Mapping, Sequence


# TODO: Move these to a shared location when component architecture is finalized
@dataclass(slots=True, frozen=True)
class StylingContext:
    """Context information for style resolution."""

    component_name: str
    state: Mapping[str, bool] | None = None
    theme_overrides: Mapping[str, str] | None = None
    caps: Any = None

    def __post_init__(self) -> None:
        if self.state is None:
            object.__setattr__(self, "state", {})


class Component(ABC):
    """Abstract base class for all components in the component subsystem.

    Components are pure data structures that describe UI elements.
    They do not perform rendering directly - instead they return
    renderable objects that can be processed by the rendering pipeline.
    """

    @property
    @abstractmethod
    def component_name(self) -> str:
        """Return the component name for styling purposes."""
        ...

    @abstractmethod
    def to_renderable(self, styling_context: StylingContext | None = None) -> RenderableComponent:
        """Convert this component to a renderable object.

        Args:
            styling_context: Optional styling context for pre-computed styles.

        Returns:
            A renderable component ready for the rendering pipeline.
        """
        ...


class RenderableComponent(RenderableBase):
    """Base class for renderable components that can be processed by the rendering pipeline.

    This class extends RenderableBase and adds styling context support.
    """

    def __init__(self, component_name: str, styling_context: StylingContext | None = None) -> None:
        """Initialize the renderable component.

        Args:
            component_name: Name of the component for styling.
            styling_context: Optional pre-computed styling context.
        """
        self._component_name = component_name
        self._styling_context = styling_context
        self._resolved_style = None

    @property
    def component_name(self) -> str:
        """Return the component name."""
        return self._component_name

    @property
    def styling_context(self) -> StylingContext | None:
        """Return the styling context."""
        return self._styling_context

    def get_resolved_style(self, console: Console) -> object:
        """Get the resolved style for this component.

        Args:
            console: The console instance for style resolution.

        Returns:
            The resolved style object.
        """
        if self._resolved_style is not None:
            return self._resolved_style

        # Resolve style using the styling subsystem
        from ..style.subsystem import StylingSubsystem

        subsystem = StylingSubsystem()
        context = self._styling_context or StylingContext(component_name=self._component_name)
        self._resolved_style = subsystem.resolve_style(context)
        return self._resolved_style

    @abstractmethod
    def render(self, console: Console) -> str | list[str] | None:
        """Render this component to a string or list of strings.

        Args:
            console: The console instance to render with.

        Returns:
            The rendered output as a string, list of strings, or None.
        """
        ...

    @abstractmethod
    def measure(self, console: Console) -> Measure:
        """Measure the dimensions of this component.

        Args:
            console: The console instance to measure with.

        Returns:
            The measured dimensions.
        """
        ...

    def to_node(self, console: Console) -> GuiNode:
        """Convert this component to a GUI node for GUI rendering.

        Args:
            console: The console instance.

        Returns:
            A GUI node representation.
        """
        # Get resolved style
        resolved_style = self.get_resolved_style(console)

        # Convert TFS style to LayoutStyle for layout computation
        from ..core.layout import tfs_to_layout_style

        layout_style = tfs_to_layout_style(resolved_style)

        # Create the base node
        node = GuiNode(self._component_name, style=resolved_style, layout_style=layout_style)

        # Subclasses should override to add children
        return node


__all__ = [
    "Box",
    "Panel",
    "ScrollablePanel",
    "Card",
    "Dialog",
    "box",
    "panel",
    "scrollable_panel",
    "card",
    "dialog",
]


class _BorderMixin:
    """Shared helpers for drawing framed boxes."""

    @staticmethod
    def top_line(symbols: dict[str, str], width: int) -> str:
        return symbols["top_left"] + symbols["horizontal"] * (width - 2) + symbols["top_right"]

    @staticmethod
    def bottom_line(symbols: dict[str, str], width: int) -> str:
        return symbols["bottom_left"] + symbols["horizontal"] * (width - 2) + symbols["bottom_right"]

    @staticmethod
    def empty_line(symbols: dict[str, str], width: int) -> str:
        return symbols["vertical"] + " " * (width - 2) + symbols["vertical"]


class Box(Component):
    """Box component for displaying text in a bordered container.

    A component that renders text within a styled border with configurable
    padding, alignment, and visual effects.
    """

    def __init__(self, text: str, **kwargs: object) -> None:
        self.text = text
        self.width = kwargs.get("width", 80)
        self.color = kwargs.get("color", None)
        self.symbol_style = kwargs.get("symbol_style", "box")
        self.border_thickness = kwargs.get("border_thickness", 1)
        self.padding = kwargs.get("padding", 1)
        self.margin_left = kwargs.get("margin_left", 0)
        self.bg_color = kwargs.get("bg_color", None)
        self.shadow = kwargs.get("shadow", False)
        self.blank_lines_before = kwargs.get("blank_lines_before", 0)
        self.blank_lines_after = kwargs.get("blank_lines_after", 0)
        self.align = kwargs.get("align", "center")
        self.ascii_mode = kwargs.get("ascii_mode", None)

    @property
    def component_name(self) -> str:
        """Return the component name for styling purposes."""
        return "Box"

    def to_renderable(self, styling_context: StylingContext | None = None) -> RenderableComponent:
        """Convert this component to a renderable object.

        Args:
            styling_context: Optional styling context for pre-computed styles.

        Returns:
            A renderable component ready for the rendering pipeline.
        """
        context = styling_context or StylingContext(component_name=self.component_name)
        return BoxRenderable(
            text=self.text,
            width=self.width,
            color=self.color,
            symbol_style=self.symbol_style,
            border_thickness=self.border_thickness,
            padding=self.padding,
            margin_left=self.margin_left,
            bg_color=self.bg_color,
            shadow=self.shadow,
            blank_lines_before=self.blank_lines_before,
            blank_lines_after=self.blank_lines_after,
            align=self.align,
            ascii_mode=self.ascii_mode,
            styling_context=context,
        )


@dataclass(slots=True)
class BoxRenderable(RenderableComponent):
    """Renderable wrapper for Box component."""

    text: str
    width: int = 80
    color: str | None = None
    symbol_style: str = "box"
    border_thickness: int = 1
    padding: int = 1
    margin_left: int = 0
    bg_color: str | None = None
    shadow: bool = False
    blank_lines_before: int = 0
    blank_lines_after: int = 0
    align: Literal["left", "center", "right"] = "center"
    ascii_mode: bool | None = None

    def render(self, console: Console) -> str:
        """Render this component to a string.

        Args:
            console: The console instance to render with.

        Returns:
            The rendered output as a string.
        """
        text_color = Color.get_color(self.color)
        bg = Color.get_bg_color(self.bg_color) if self.bg_color else ""
        symbols = Symbols.get_symbols(self.symbol_style, self.ascii_mode)

        # Collect output lines
        output_lines: list[str] = []

        # Responsive width detection
        if self.width <= 0:
            max_line = 0
            for ln in wrap_text(self.text, 10**6):
                max_line = max(max_line, _vw(Color.apply_inline_markup(ln)))
            inner = max_line + self.padding * 2
            width = max(4, inner + 2)
        else:
            width = self.width

        for _ in range(self.blank_lines_before):
            output_lines.append("")

        # Top border (support thickness)
        for _ in range(max(1, self.border_thickness)):
            output_lines.append((" " * self.margin_left) + _BorderMixin.top_line(symbols, width))

        # Padding lines
        for _ in range(self.padding):
            line = symbols["vertical"] + (bg + " " * (width - 2) + (Color.RESET if bg else "")) + symbols["vertical"]
            output_lines.append((" " * self.margin_left) + line)

        # Content
        inner_width = width - 2  # exclude borders
        content_width = inner_width - (self.padding * 2)
        text_lines = wrap_text(self.text, content_width)
        for line in text_lines:
            colored_line = Color.apply_inline_markup(line)
            if self.color:
                colored_line = text_color + colored_line + Color.RESET
            visible_len = get_visible_length(colored_line)

            if self.align == "left":
                left_spaces = 0
            elif self.align == "right":
                left_spaces = max(0, content_width - visible_len)
            else:  # center
                left_spaces = max(0, (content_width - visible_len) // 2)
            right_spaces = max(0, content_width - visible_len - left_spaces)

            inner = (
                symbols["vertical"]
                + (" " * self.padding)
                + (bg or "")
                + (" " * left_spaces)
                + colored_line
                + (" " * right_spaces)
                + (Color.RESET if bg else "")
                + (" " * self.padding)
                + symbols["vertical"]
            )
            output_lines.append((" " * self.margin_left) + inner)

        # Padding lines
        for _ in range(self.padding):
            line = symbols["vertical"] + (bg + " " * (width - 2) + (Color.RESET if bg else "")) + symbols["vertical"]
            output_lines.append((" " * self.margin_left) + line)

        # Bottom border (support thickness)
        for _ in range(max(1, self.border_thickness)):
            output_lines.append((" " * self.margin_left) + _BorderMixin.bottom_line(symbols, width))

        # Shadow effect: a simple offset dark fill to the right and bottom
        if self.shadow:
            shade_char = "░"
            # Right shadow strip
            output_lines.append((" " * (self.margin_left + width)) + shade_char)
            # Bottom shadow line
            output_lines.append((" " * (self.margin_left + 1)) + shade_char * (width))

        for _ in range(self.blank_lines_after):
            output_lines.append("")

        return "\n".join(output_lines)

    def measure(self, console: Console) -> Measure:
        """Measure the dimensions of this component.

        Args:
            console: The console instance to measure with.

        Returns:
            The measured dimensions.
        """
        rendered = self.render(console)
        return Measure.from_text(rendered)


def box(text: str, **kwargs: object) -> RenderableComponent:
    """Create a renderable box component.

    Args:
        text: Text content (supports inline markup).
        **kwargs: Additional styling and layout options.

    Returns:
        A renderable box component.
    """
    component = Box(text, **kwargs)
    return component.to_renderable()


class Panel(Component):
    """Panel component for displaying multi-section content.

    A component that renders multiple sections of content within a bordered
    container, with optional section titles and separators.
    """

    def __init__(self, content: str | list[dict[str, Any]], **kwargs: object) -> None:
        self.content = content
        self.title = kwargs.get("title", "")
        self.width = kwargs.get("width", 80)
        self.border_style = kwargs.get("border_style", "box")
        self.blank_lines_before = kwargs.get("blank_lines_before", 0)
        self.blank_lines_after = kwargs.get("blank_lines_after", 0)
        self.ascii_mode = kwargs.get("ascii_mode", None)

    @property
    def component_name(self) -> str:
        """Return the component name for styling purposes."""
        return "Panel"

    def to_renderable(self, styling_context: StylingContext | None = None) -> RenderableComponent:
        """Convert this component to a renderable object.

        Args:
            styling_context: Optional styling context for pre-computed styles.

        Returns:
            A renderable component ready for the rendering pipeline.
        """
        context = styling_context or StylingContext(component_name=self.component_name)
        if isinstance(self.content, str):
            sections = [{"title": self.title, "content": self.content.split("\n")} if self.title else {"content": self.content.split("\n")}]
        else:
            sections = self.content
        return PanelRenderable(
            sections=sections,
            width=self.width,
            border_style=self.border_style,
            blank_lines_before=self.blank_lines_before,
            blank_lines_after=self.blank_lines_after,
            ascii_mode=self.ascii_mode,
            styling_context=context,
        )


@dataclass(slots=True)
class PanelRenderable(RenderableComponent):
    """Renderable wrapper for Panel component."""

    sections: list[dict[str, Any]]
    width: int = 80
    border_style: str = "box"
    blank_lines_before: int = 0
    blank_lines_after: int = 0
    ascii_mode: bool | None = None

    def render(self, console: Console) -> str:
        """Render this component to a string.

        Args:
            console: The console instance to render with.

        Returns:
            The rendered output as a string.
        """
        out: list[str] = []
        for _ in range(self.blank_lines_before):
            out.append("")

        symbols = Symbols.get_symbols(self.border_style, self.ascii_mode)

        # Top border
        out.append(_BorderMixin.top_line(symbols, self.width))

        for i, section in enumerate(self.sections):
            section_title = section.get("title", "")
            section_content = section.get("content", [])

            # Section title
            if section_title:
                title_colored = Color.apply_inline_markup(section_title)
                visible_len = get_visible_length(title_colored)
                padding_needed = self.width - 4 - visible_len
                title_line = symbols["vertical"] + " " + Color.BOLD + title_colored + Color.RESET + " " * padding_needed + " " + symbols["vertical"]
                out.append(title_line)

            # Section content
            if isinstance(section_content, list):
                for line in section_content:
                    line_colored = Color.apply_inline_markup(str(line))
                    visible_len = get_visible_length(line_colored)
                    padding_needed = self.width - 4 - visible_len
                    content_line = symbols["vertical"] + " " + line_colored + " " * padding_needed + " " + symbols["vertical"]
                    out.append(content_line)
            else:
                line_colored = Color.apply_inline_markup(str(section_content))
                visible_len = get_visible_length(line_colored)
                padding_needed = self.width - 4 - visible_len
                content_line = symbols["vertical"] + " " + line_colored + " " * padding_needed + " " + symbols["vertical"]
                out.append(content_line)

            # Separator between sections
            if i < len(self.sections) - 1:
                separator = symbols["t_right"] + symbols["horizontal"] * (self.width - 2) + symbols["t_left"]
                out.append(separator)

        # Bottom border
        out.append(_BorderMixin.bottom_line(symbols, self.width))

        for _ in range(self.blank_lines_after):
            out.append("")
        return "\n".join(out)

    def measure(self, console: Console) -> Measure:
        """Measure the dimensions of this component.

        Args:
            console: The console instance to measure with.

        Returns:
            The measured dimensions.
        """
        rendered = self.render(console)
        return Measure.from_text(rendered)


def panel(content: str | list[dict[str, Any]], **kwargs: object) -> RenderableComponent:
    """Create a renderable panel component.

    Args:
        content: Content as a string or list of section dictionaries.
        **kwargs: Additional styling and layout options.

    Returns:
        A renderable panel component.
    """
    component = Panel(content, **kwargs)
    return component.to_renderable()


@dataclass(slots=True)
class ScrollablePanel(Component):
    """Scrollable panel component for displaying large content.

    A component that renders content within a scrollable viewport with
    optional title and footer showing scroll position.
    """

    content: Sequence[str] | str
    width: int = 80
    height: int = 10
    offset: int = 0
    title: str | None = None
    footer: bool = True
    border_style: str = "box"
    blank_lines_before: int = 0
    blank_lines_after: int = 0
    ascii_mode: bool | None = None

    @property
    def component_name(self) -> str:
        """Return the component name for styling purposes."""
        return "ScrollablePanel"

    def to_renderable(self, styling_context: StylingContext | None = None) -> RenderableComponent:
        """Convert this component to a renderable object.

        Args:
            styling_context: Optional styling context for pre-computed styles.

        Returns:
            A renderable component ready for the rendering pipeline.
        """
        context = styling_context or StylingContext(component_name=self.component_name)
        return ScrollablePanelRenderable(
            content=self.content,
            width=self.width,
            height=self.height,
            offset=self.offset,
            title=self.title,
            footer=self.footer,
            border_style=self.border_style,
            blank_lines_before=self.blank_lines_before,
            blank_lines_after=self.blank_lines_after,
            ascii_mode=self.ascii_mode,
            styling_context=context,
        )


@dataclass(slots=True)
class ScrollablePanelRenderable(RenderableComponent):
    """Renderable wrapper for ScrollablePanel component."""

    content: Sequence[str] | str
    width: int = 80
    height: int = 10
    offset: int = 0
    title: str | None = None
    footer: bool = True
    border_style: str = "box"
    blank_lines_before: int = 0
    blank_lines_after: int = 0
    ascii_mode: bool | None = None

    def render(self, console: Console) -> str:
        """Render this component to a string.

        Args:
            console: The console instance to render with.

        Returns:
            The rendered output as a string.
        """
        out: list[str] = []
        for _ in range(self.blank_lines_before):
            out.append("")

        if isinstance(self.content, str):
            lines = self.content.splitlines()
        else:
            lines = [str(line) for line in self.content]

        total = len(lines)
        if total == 0:
            lines = [""]
            total = 1

        max_offset = max(0, total - self.height)
        offset = max(0, min(self.offset, max_offset))

        symbols = Symbols.get_symbols(self.border_style, self.ascii_mode)
        inner_width = max(4, self.width - 2)

        # Header
        top_border = symbols["top_left"] + symbols["horizontal"] * inner_width + symbols["top_right"]
        out.append(top_border)
        if self.title:
            title_text = Color.apply_inline_markup(self.title)
            visible_len = get_visible_length(title_text)
            padding = max(0, inner_width - visible_len)
            line = symbols["vertical"] + title_text + " " * padding + symbols["vertical"]
            out.append(line)
            out.append(symbols["t_right"] + symbols["horizontal"] * inner_width + symbols["t_left"])

        # Content window
        visible = lines[offset : offset + self.height]
        for i in range(self.height):
            line = visible[i] if i < len(visible) else ""
            colored = Color.apply_inline_markup(line)
            visible_len = get_visible_length(colored)
            padding = max(0, inner_width - visible_len)
            out.append(symbols["vertical"] + colored + " " * padding + symbols["vertical"])

        if self.footer:
            info = f"{offset + 1}-{min(offset + self.height, total)} / {total}"
            info_colored = Color.DIM + info + Color.RESET
            padding = max(0, inner_width - get_visible_length(info))
            out.append(symbols["t_right"] + symbols["horizontal"] * inner_width + symbols["t_left"])
            out.append(symbols["vertical"] + info_colored + " " * padding + symbols["vertical"])

        bottom_border = symbols["bottom_left"] + symbols["horizontal"] * inner_width + symbols["bottom_right"]
        out.append(bottom_border)

        for _ in range(self.blank_lines_after):
            out.append("")
        return "\n".join(out)

    def measure(self, console: Console) -> Measure:
        """Measure the dimensions of this component.

        Args:
            console: The console instance to measure with.

        Returns:
            The measured dimensions.
        """
        rendered = self.render(console)
        return Measure.from_text(rendered)


def scrollable_panel(
    content: Sequence[str] | str,
    width: int = 80,
    height: int = 10,
    offset: int = 0,
    title: str | None = None,
    footer: bool = True,
    border_style: str = "box",
    blank_lines_before: int = 0,
    blank_lines_after: int = 0,
    ascii_mode: bool | None = None,
) -> RenderableComponent:
    """Create a renderable scrollable panel component.

    Args:
        content: Content as a sequence of strings or a single string.
        width: Panel width.
        height: Number of content rows to display.
        offset: Starting scroll offset.
        title: Optional title shown in header.
        footer: Show a footer with viewport information.
        border_style: Border style.
        blank_lines_before: Blank lines before panel.
        blank_lines_after: Blank lines after panel.
        ascii_mode: Force ASCII symbols (True), Unicode (False), or auto-detect (None).

    Returns:
        A renderable scrollable panel component.
    """
    component = ScrollablePanel(
        content=content,
        width=width,
        height=height,
        offset=offset,
        title=title,
        footer=footer,
        border_style=border_style,
        blank_lines_before=blank_lines_before,
        blank_lines_after=blank_lines_after,
        ascii_mode=ascii_mode,
    )
    return component.to_renderable()


@dataclass(slots=True)
class Card(Component):
    """Card component for displaying structured information.

    A component that renders information in a card format with a title
    and structured content (key-value pairs or list items).
    """

    title: str
    content: dict[str, Any] | list[str]
    width: int = 60
    title_color: str = "gold"
    border_style: str = "double"
    padding: int = 1
    blank_lines_before: int = 0
    blank_lines_after: int = 0
    ascii_mode: bool | None = None

    @property
    def component_name(self) -> str:
        """Return the component name for styling purposes."""
        return "Card"

    def to_renderable(self, styling_context: StylingContext | None = None) -> RenderableComponent:
        """Convert this component to a renderable object.

        Args:
            styling_context: Optional styling context for pre-computed styles.

        Returns:
            A renderable component ready for the rendering pipeline.
        """
        context = styling_context or StylingContext(component_name=self.component_name)
        return CardRenderable(
            title=self.title,
            content=self.content,
            width=self.width,
            title_color=self.title_color,
            border_style=self.border_style,
            padding=self.padding,
            blank_lines_before=self.blank_lines_before,
            blank_lines_after=self.blank_lines_after,
            ascii_mode=self.ascii_mode,
            styling_context=context,
        )


@dataclass(slots=True)
class CardRenderable(RenderableComponent):
    """Renderable wrapper for Card component."""

    title: str
    content: dict[str, Any] | list[str]
    width: int = 60
    title_color: str = "gold"
    border_style: str = "double"
    padding: int = 1
    blank_lines_before: int = 0
    blank_lines_after: int = 0
    ascii_mode: bool | None = None

    def render(self, console: Console) -> str:
        """Render this component to a string.

        Args:
            console: The console instance to render with.

        Returns:
            The rendered output as a string.
        """
        out: list[str] = []
        for _ in range(self.blank_lines_before):
            out.append("")

        symbols = Symbols.get_symbols(self.border_style, self.ascii_mode)
        tcolor = Color.get_color(self.title_color)

        # Top border
        top = symbols["top_left"] + symbols["horizontal"] * (self.width - 2) + symbols["top_right"]
        out.append(top)

        # Padding
        for _ in range(self.padding):
            out.append(symbols["vertical"] + " " * (self.width - 2) + symbols["vertical"])

        # Title
        title_text = self.title.center(self.width - 4)
        title_line = symbols["vertical"] + " " + tcolor + title_text + Color.RESET + " " + symbols["vertical"]
        out.append(title_line)

        # Separator
        separator = symbols["t_right"] + symbols["horizontal"] * (self.width - 2) + symbols["t_left"]
        out.append(separator)

        # Content - compact rendering for CLI
        if isinstance(self.content, dict):
            # For dict content, render as compact key: value pairs
            for key, value in self.content.items():
                key_colored = Color.apply_inline_markup(str(key))
                value_colored = Color.apply_inline_markup(str(value))
                line = f"{key_colored}: {value_colored}"
                visible_len = get_visible_length(line)
                padding_needed = self.width - 4 - visible_len
                content_line = symbols["vertical"] + " " + line + " " * padding_needed + " " + symbols["vertical"]
                out.append(content_line)
        else:
            # For list content, render as compact single lines
            for line in self.content:
                line_colored = Color.apply_inline_markup(str(line))
                visible_len = get_visible_length(line_colored)
                padding_needed = self.width - 4 - visible_len
                content_line = symbols["vertical"] + " " + line_colored + " " * padding_needed + " " + symbols["vertical"]
                out.append(content_line)

        # Padding
        for _ in range(self.padding):
            out.append(symbols["vertical"] + " " * (self.width - 2) + symbols["vertical"])

        # Bottom border
        bottom = symbols["bottom_left"] + symbols["horizontal"] * (self.width - 2) + symbols["bottom_right"]
        out.append(bottom)

        for _ in range(self.blank_lines_after):
            out.append("")
        return "\n".join(out)

    def measure(self, console: Console) -> Measure:
        """Measure the dimensions of this component.

        Args:
            console: The console instance to measure with.

        Returns:
            The measured dimensions.
        """
        rendered = self.render(console)
        return Measure.from_text(rendered)


def card(
    title: str,
    content: dict[str, Any] | list[str],
    width: int = 60,
    title_color: str = "gold",
    border_style: str = "double",
    padding: int = 1,
    blank_lines_before: int = 0,
    blank_lines_after: int = 0,
    ascii_mode: bool | None = None,
) -> RenderableComponent:
    """Create a renderable card component.

    Args:
        title: Card title.
        content: Dictionary of key-value pairs or list of lines.
        width: Card width.
        title_color: Title text color.
        border_style: Border style.
        padding: Internal padding.
        blank_lines_before: Blank lines before card.
        blank_lines_after: Blank lines after card.
        ascii_mode: Force ASCII symbols (True), Unicode (False), or auto-detect (None).

    Returns:
        A renderable card component.
    """
    component = Card(
        title=title,
        content=content,
        width=width,
        title_color=title_color,
        border_style=border_style,
        padding=padding,
        blank_lines_before=blank_lines_before,
        blank_lines_after=blank_lines_after,
        ascii_mode=ascii_mode,
    )
    return component.to_renderable()


@dataclass(slots=True)
class Dialog(Component):
    """Dialog component for displaying modal messages and prompts.

    A component that renders modal dialogs with titles, messages, and
    optional buttons for user interaction.
    """

    title: str
    message: str
    buttons: list[str] | None = None
    selected_button: int = 0
    width: int = 60
    dialog_type: Literal["info", "warning", "error", "success", "question"] = "info"
    blank_lines_before: int = 1
    blank_lines_after: int = 1
    ascii_mode: bool | None = None

    @property
    def component_name(self) -> str:
        """Return the component name for styling purposes."""
        return "Dialog"

    def to_renderable(self, styling_context: StylingContext | None = None) -> RenderableComponent:
        """Convert this component to a renderable object.

        Args:
            styling_context: Optional styling context for pre-computed styles.

        Returns:
            A renderable component ready for the rendering pipeline.
        """
        context = styling_context or StylingContext(component_name=self.component_name)
        return DialogRenderable(
            title=self.title,
            message=self.message,
            buttons=self.buttons,
            selected_button=self.selected_button,
            width=self.width,
            dialog_type=self.dialog_type,
            blank_lines_before=self.blank_lines_before,
            blank_lines_after=self.blank_lines_after,
            ascii_mode=self.ascii_mode,
            styling_context=context,
        )


@dataclass(slots=True)
class DialogRenderable(RenderableComponent):
    """Renderable wrapper for Dialog component."""

    title: str
    message: str
    buttons: list[str] | None = None
    selected_button: int = 0
    width: int = 60
    dialog_type: Literal["info", "warning", "error", "success", "question"] = "info"
    blank_lines_before: int = 1
    blank_lines_after: int = 1
    ascii_mode: bool | None = None

    def render(self, console: Console) -> str:
        """Render this component to a string.

        Args:
            console: The console instance to render with.

        Returns:
            The rendered output as a string.
        """
        if self.buttons is None:
            buttons = ["OK"]
        else:
            buttons = self.buttons

        out: list[str] = []
        for _ in range(self.blank_lines_before):
            out.append("")

        # Type-specific settings
        type_settings = {
            "info": {"icon": "ℹ", "color": "cyan"},
            "warning": {"icon": "⚠", "color": "yellow"},
            "error": {"icon": "✗", "color": "red"},
            "success": {"icon": "✓", "color": "green"},
            "question": {"icon": "?", "color": "blue"},
        }

        settings = type_settings.get(self.dialog_type, type_settings["info"])
        icon = settings["icon"]
        title_color = Color.get_color(settings["color"])

        symbols = Symbols.get_symbols("double", self.ascii_mode)

        # Top border
        out.append(_BorderMixin.top_line(symbols, self.width))

        # Title with icon
        title_text = f"{icon} {self.title}"
        title_centered = title_text.center(self.width - 4)
        title_line = symbols["vertical"] + " " + title_color + title_centered + Color.RESET + " " + symbols["vertical"]
        out.append(title_line)

        # Separator
        separator = symbols["t_right"] + symbols["horizontal"] * (self.width - 2) + symbols["t_left"]
        out.append(separator)

        # Message
        message_lines = wrap_text(self.message, self.width - 6)
        for line in message_lines:
            colored = Color.apply_inline_markup(line)
            visible_len = get_visible_length(colored)
            padding_needed = max(0, self.width - 4 - visible_len)
            message_line = symbols["vertical"] + " " + colored + " " * padding_needed + " " + symbols["vertical"]
            out.append(message_line)

        # Spacing before buttons
        out.append(symbols["vertical"] + " " * (self.width - 2) + symbols["vertical"])

        # Buttons
        button_str = "  ".join(f"{Color.BOLD}[{btn}]{Color.RESET}" if i == self.selected_button else f"[{btn}]" for i, btn in enumerate(buttons))
        button_visible = sum(len(btn) + 2 for btn in buttons) + (len(buttons) - 1) * 2
        button_padding = (self.width - 4 - button_visible) // 2
        button_line = symbols["vertical"] + " " + " " * button_padding + button_str + " " * (self.width - 4 - button_visible - button_padding) + " " + symbols["vertical"]
        out.append(button_line)

        # Bottom border
        out.append(_BorderMixin.bottom_line(symbols, self.width))

        for _ in range(self.blank_lines_after):
            out.append("")
        return "\n".join(out)

    def measure(self, console: Console) -> Measure:
        """Measure the dimensions of this component.

        Args:
            console: The console instance to measure with.

        Returns:
            The measured dimensions.
        """
        rendered = self.render(console)
        return Measure.from_text(rendered)


def dialog(
    title: str,
    message: str,
    buttons: list[str] | None = None,
    selected_button: int = 0,
    width: int = 60,
    dialog_type: Literal["info", "warning", "error", "success", "question"] = "info",
    blank_lines_before: int = 1,
    blank_lines_after: int = 1,
    ascii_mode: bool | None = None,
) -> RenderableComponent:
    """Create a renderable dialog component.

    Args:
        title: Dialog title.
        message: Dialog message.
        buttons: List of button labels.
        selected_button: Index of selected button.
        width: Dialog width.
        dialog_type: Type of dialog (affects icon/color).
        blank_lines_before: Blank lines before dialog.
        blank_lines_after: Blank lines after dialog.
        ascii_mode: Force ASCII symbols (True), Unicode (False), or auto-detect (None).

    Returns:
        A renderable dialog component.
    """
    component = Dialog(
        title=title,
        message=message,
        buttons=buttons,
        selected_button=selected_button,
        width=width,
        dialog_type=dialog_type,
        blank_lines_before=blank_lines_before,
        blank_lines_after=blank_lines_after,
        ascii_mode=ascii_mode,
    )
    return component.to_renderable()


class CardRenderableLegacy:
    """Build info cards for items, characters, etc."""

    @staticmethod
    def render(
        title: str,
        content: dict[str, Any] | list[str],
        width: int = 60,
        title_color: str = "gold",
        border_style: str = "double",
        padding: int = 1,
        blank_lines_before: int = 0,
        blank_lines_after: int = 0,
        ascii_mode: bool | None = None,
    ) -> str:
        """
        Render an information card.

        Args:
            title: Card title
            content: Dictionary of key-value pairs or list of lines
            width: Card width
            title_color: Title text color
            border_style: Border style
            padding: Internal padding
            blank_lines_before: Blank lines before card
            blank_lines_after: Blank lines after card
            ascii_mode: Force ASCII symbols (True), Unicode (False), or auto-detect (None)
        """
        out: list[str] = []
        for _ in range(blank_lines_before):
            out.append("")

        symbols = Symbols.get_symbols(border_style, ascii_mode)
        tcolor = Color.get_color(title_color)

        # Top border
        top = symbols["top_left"] + symbols["horizontal"] * (width - 2) + symbols["top_right"]
        out.append(top)

        # Padding
        for _ in range(padding):
            out.append(symbols["vertical"] + " " * (width - 2) + symbols["vertical"])

        # Title
        title_text = title.center(width - 4)
        title_line = symbols["vertical"] + " " + tcolor + title_text + Color.RESET + " " + symbols["vertical"]
        out.append(title_line)

        # Separator
        separator = symbols["t_right"] + symbols["horizontal"] * (width - 2) + symbols["t_left"]
        out.append(separator)

        # Content - compact rendering for CLI
        if isinstance(content, dict):
            # For dict content, render as compact key: value pairs
            for key, value in content.items():
                key_colored = Color.apply_inline_markup(str(key))
                value_colored = Color.apply_inline_markup(str(value))
                line = f"{key_colored}: {value_colored}"
                visible_len = get_visible_length(line)
                padding_needed = width - 4 - visible_len
                content_line = symbols["vertical"] + " " + line + " " * padding_needed + " " + symbols["vertical"]
                out.append(content_line)
        else:
            # For list content, render as compact single lines
            for line in content:
                line_colored = Color.apply_inline_markup(str(line))
                visible_len = get_visible_length(line_colored)
                padding_needed = width - 4 - visible_len
                content_line = symbols["vertical"] + " " + line_colored + " " * padding_needed + " " + symbols["vertical"]
                out.append(content_line)

        # Padding
        for _ in range(padding):
            out.append(symbols["vertical"] + " " * (width - 2) + symbols["vertical"])

        # Bottom border
        bottom = symbols["bottom_left"] + symbols["horizontal"] * (width - 2) + symbols["bottom_right"]
        out.append(bottom)

        for _ in range(blank_lines_after):
            out.append("")
        return "\n".join(out)


class PanelRenderableLegacy(_BorderMixin):
    """Build multi-section panels."""

    @staticmethod
    def render(
        sections: list[dict[str, Any]],
        width: int = 80,
        border_style: str = "box",
        blank_lines_before: int = 0,
        blank_lines_after: int = 0,
        ascii_mode: bool | None = None,
    ) -> str:
        """
        Render a panel with multiple sections.

        Args:
            sections: List of section dicts with 'title' and 'content'
            width: Panel width
            border_style: Border style
            blank_lines_before: Blank lines before panel
            blank_lines_after: Blank lines after panel
            ascii_mode: Force ASCII symbols (True), Unicode (False), or auto-detect (None)

        Example:
            Panel.render([
                {"title": "Player", "content": ["HP: 100", "MP: 50"]},
                {"title": "Enemy", "content": ["HP: 75", "MP: 30"]}
            ])
        """
        out: list[str] = []
        for _ in range(blank_lines_before):
            out.append("")

        symbols = Symbols.get_symbols(border_style, ascii_mode)

        # Top border
        out.append(_BorderMixin.top_line(symbols, width))

        for i, section in enumerate(sections):
            section_title = section.get("title", "")
            section_content = section.get("content", [])

            # Section title
            if section_title:
                title_colored = Color.apply_inline_markup(section_title)
                visible_len = get_visible_length(title_colored)
                padding_needed = width - 4 - visible_len
                title_line = symbols["vertical"] + " " + Color.BOLD + title_colored + Color.RESET + " " * padding_needed + " " + symbols["vertical"]
                out.append(title_line)

            # Section content
            if isinstance(section_content, list):
                for line in section_content:
                    line_colored = Color.apply_inline_markup(str(line))
                    visible_len = get_visible_length(line_colored)
                    padding_needed = width - 4 - visible_len
                    content_line = symbols["vertical"] + " " + line_colored + " " * padding_needed + " " + symbols["vertical"]
                    out.append(content_line)
            else:
                line_colored = Color.apply_inline_markup(str(section_content))
                visible_len = get_visible_length(line_colored)
                padding_needed = width - 4 - visible_len
                content_line = symbols["vertical"] + " " + line_colored + " " * padding_needed + " " + symbols["vertical"]
                out.append(content_line)

            # Separator between sections
            if i < len(sections) - 1:
                separator = symbols["t_right"] + symbols["horizontal"] * (width - 2) + symbols["t_left"]
                out.append(separator)

        # Bottom border
        out.append(_BorderMixin.bottom_line(symbols, width))

        for _ in range(blank_lines_after):
            out.append("")
        return "\n".join(out)


class ScrollablePanelRenderableLegacy:
    """Scrollable panel with optional interactive navigation."""

    @staticmethod
    def render(
        content: Sequence[str] | str,
        width: int = 80,
        height: int = 10,
        offset: int = 0,
        title: str | None = None,
        footer: bool = True,
        border_style: str = "box",
        blank_lines_before: int = 0,
        blank_lines_after: int = 0,
        ascii_mode: bool | None = None,
    ) -> str:
        """
        Render a scrolling window over multi-line content.

        Args:
            content: Iterable of lines or a single string.
            width: Panel width.
            height: Number of content rows to display.
            offset: Starting scroll offset.
            title: Optional title shown in header.
            footer: Show a footer with viewport information.
            border_style: Border style key from Symbols.
            ascii_mode: Force ASCII symbols (True), Unicode (False), or auto-detect (None)
        """
        out: list[str] = []
        for _ in range(blank_lines_before):
            out.append("")

        if isinstance(content, str):
            lines = content.splitlines()
        else:
            lines = [str(line) for line in content]

        total = len(lines)
        if total == 0:
            lines = [""]
            total = 1

        max_offset = max(0, total - height)
        offset = max(0, min(offset, max_offset))

        symbols = Symbols.get_symbols(border_style, ascii_mode)
        inner_width = max(4, width - 2)

        # Header
        top_border = symbols["top_left"] + symbols["horizontal"] * inner_width + symbols["top_right"]
        out.append(top_border)
        if title:
            title_text = Color.apply_inline_markup(title)
            visible_len = get_visible_length(title_text)
            padding = max(0, inner_width - visible_len)
            line = symbols["vertical"] + title_text + " " * padding + symbols["vertical"]
            out.append(line)
            out.append(symbols["t_right"] + symbols["horizontal"] * inner_width + symbols["t_left"])

        # Content window
        visible = lines[offset : offset + height]
        for i in range(height):
            line = visible[i] if i < len(visible) else ""
            colored = Color.apply_inline_markup(line)
            visible_len = get_visible_length(colored)
            padding = max(0, inner_width - visible_len)
            out.append(symbols["vertical"] + colored + " " * padding + symbols["vertical"])

        if footer:
            info = f"{offset + 1}-{min(offset + height, total)} / {total}"
            info_colored = Color.DIM + info + Color.RESET
            padding = max(0, inner_width - get_visible_length(info))
            out.append(symbols["t_right"] + symbols["horizontal"] * inner_width + symbols["t_left"])
            out.append(symbols["vertical"] + info_colored + " " * padding + symbols["vertical"])

        bottom_border = symbols["bottom_left"] + symbols["horizontal"] * inner_width + symbols["bottom_right"]
        out.append(bottom_border)

        for _ in range(blank_lines_after):
            out.append("")
        return "\n".join(out)

    @staticmethod
    def interactive(
        content: Sequence[str] | str,
        width: int = 80,
        height: int = 10,
        title: str | None = None,
        border_style: str = "box",
        instructions: bool = True,
        *,
        timeout: float = 0.2,
    ) -> None:
        """
        Interactive scrolling session using arrow keys / PgUp / PgDn / home / end.

        Press q or ESC to exit the session.
        """
        if isinstance(content, str):
            lines = content.splitlines()
        else:
            lines = [str(line) for line in content]

        offset = 0
        total = len(lines)
        max_offset = max(0, total - height)

        def _clamp(val: int) -> int:
            return max(0, min(max_offset, val))

        try:
            while True:
                print("\x1b[2J\x1b[H", end="")
                ScrollablePanelRenderableLegacy.render(
                    lines,
                    width=width,
                    height=height,
                    offset=offset,
                    title=title,
                    border_style=border_style,
                )
                if instructions:
                    print("Use ↑/↓, PgUp/PgDn, Home/End to scroll. q to quit.")
                key = read_key(timeout=timeout)
                if not key:
                    continue
                if key in {"q", "escape"}:
                    break
                if key in {"up", "k"}:
                    offset = _clamp(offset - 1)
                elif key in {"down", "j"}:
                    offset = _clamp(offset + 1)
                elif key == "page_up":
                    offset = _clamp(offset - height)
                elif key == "page_down":
                    offset = _clamp(offset + height)
                elif key == "home":
                    offset = 0
                elif key == "end":
                    offset = max_offset
        finally:
            print("\x1b[2J\x1b[H", end="")


class DialogRenderableLegacy(_BorderMixin):
    """Build dialog boxes and modals."""

    @staticmethod
    def render(
        title: str,
        message: str,
        buttons: list[str] | None = None,
        selected_button: int = 0,
        width: int = 60,
        dialog_type: Literal["info", "warning", "error", "success", "question"] = "info",
        blank_lines_before: int = 1,
        blank_lines_after: int = 1,
        ascii_mode: bool | None = None,
    ) -> str:
        """
        Render a dialog box.

        Args:
            title: Dialog title
            message: Dialog message
            buttons: List of button labels
            selected_button: Index of selected button
            width: Dialog width
            dialog_type: Type of dialog (affects icon/color)
            blank_lines_before: Blank lines before dialog
            blank_lines_after: Blank lines after dialog
            ascii_mode: Force ASCII symbols (True), Unicode (False), or auto-detect (None)
        """
        if buttons is None:
            buttons = ["OK"]

        out: list[str] = []
        for _ in range(blank_lines_before):
            out.append("")

        # Type-specific settings
        type_settings = {
            "info": {"icon": "ℹ", "color": "cyan"},
            "warning": {"icon": "⚠", "color": "yellow"},
            "error": {"icon": "✗", "color": "red"},
            "success": {"icon": "✓", "color": "green"},
            "question": {"icon": "?", "color": "blue"},
        }

        settings = type_settings.get(dialog_type, type_settings["info"])
        icon = settings["icon"]
        title_color = Color.get_color(settings["color"])

        symbols = Symbols.get_symbols("double", ascii_mode)

        # Top border
        out.append(_BorderMixin.top_line(symbols, width))

        # Title with icon
        title_text = f"{icon} {title}"
        title_centered = title_text.center(width - 4)
        title_line = symbols["vertical"] + " " + title_color + title_centered + Color.RESET + " " + symbols["vertical"]
        out.append(title_line)

        # Separator
        separator = symbols["t_right"] + symbols["horizontal"] * (width - 2) + symbols["t_left"]
        out.append(separator)

        # Message
        message_lines = wrap_text(message, width - 6)
        for line in message_lines:
            colored = Color.apply_inline_markup(line)
            visible_len = get_visible_length(colored)
            padding_needed = max(0, width - 4 - visible_len)
            message_line = symbols["vertical"] + " " + colored + " " * padding_needed + " " + symbols["vertical"]
            out.append(message_line)

        # Spacing before buttons
        out.append(symbols["vertical"] + " " * (width - 2) + symbols["vertical"])

        # Buttons
        button_str = "  ".join(f"{Color.BOLD}[{btn}]{Color.RESET}" if i == selected_button else f"[{btn}]" for i, btn in enumerate(buttons))
        button_visible = sum(len(btn) + 2 for btn in buttons) + (len(buttons) - 1) * 2
        button_padding = (width - 4 - button_visible) // 2
        button_line = symbols["vertical"] + " " + " " * button_padding + button_str + " " * (width - 4 - button_visible - button_padding) + " " + symbols["vertical"]
        out.append(button_line)

        # Bottom border
        out.append(_BorderMixin.bottom_line(symbols, width))

        for _ in range(blank_lines_after):
            out.append("")
        return "\n".join(out)
