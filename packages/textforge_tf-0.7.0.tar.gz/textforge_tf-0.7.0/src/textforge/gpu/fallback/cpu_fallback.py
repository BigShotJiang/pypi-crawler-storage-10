"""CPU fallback implementation for GPU acceleration."""
from __future__ import annotations

import threading

from ...utils.logging import get_logger
from ..types import Geometry, GPUBackend, Shader

logger = get_logger(__name__)

class CPUFallback(GPUBackend):
    """CPU-based fallback implementation when GPU acceleration is unavailable.

    Provides software rasterization and shader emulation for systems without
    GPU acceleration support.
    """

    def __init__(self) -> None:
        self._shaders: dict[str, Shader] = {}
        self._software_rasterizer = SoftwareRasterizer()
        self._lock = threading.RLock()

    def is_available(self) -> bool:
        """CPU fallback is always available as a last resort."""
        return True

    def create_shader(self, name: str, vertex_src: str, fragment_src: str) -> Shader:
        """Create a shader with CPU emulation.

        Args:
            name: Unique name for the shader.
            vertex_src: Vertex shader source code (GLSL).
            fragment_src: Fragment shader source code (GLSL).

        Returns:
            Shader instance with CPU emulation.

        Raises:
            ShaderCompilationError: If shader creation fails.
        """
        from ..types import Shader, ShaderCompilationError

        with self._lock:
            try:
                shader = Shader(name, vertex_src, fragment_src)
                # In CPU fallback, we emulate shader compilation via Shader API
                shader.compile(self)
                self._shaders[name] = shader
                logger.debug(f"Created CPU fallback shader: {name}")
                return shader
            except Exception as e:
                logger.error(f"CPU shader emulation failed for {name}: {e}")
                raise ShaderCompilationError(f"CPU shader emulation failed: {e}") from e

    def render_geometry(self, geometry: Geometry, shader: Shader) -> None:
        """Render geometry using CPU-based software rendering.

        Args:
            geometry: The geometry data to render.
            shader: The shader to use for rendering.
        """
        from ..core import logger

        with self._lock:
            try:
                # Use software rasterizer to emulate GPU rendering
                self._software_rasterizer.render(geometry, shader)
                logger.debug(f"CPU fallback rendered geometry with {geometry.vertex_count} vertices")
            except Exception as e:
                logger.error(f"CPU rendering failed: {e}")
                raise


class SoftwareRasterizer:
    """Software-based rasterization for CPU fallback.

    Implements basic rasterization algorithms including line drawing,
    triangle filling, and shader emulation.
    """

    def __init__(self, width: int = 800, height: int = 600) -> None:
        self._width = width
        self._height = height
        self._framebuffer: list[list[tuple[int, int, int, int]]] = []
        self._depth_buffer: list[list[float]] = []
        self._clear_color = (0, 0, 0, 255)
        self._lock = threading.RLock()
        self._initialize_buffers()

    def _initialize_buffers(self) -> None:
        """Initialize the framebuffer and depth buffer."""
        with self._lock:
            self._framebuffer = [[(0, 0, 0, 255) for _ in range(self._width)] for _ in range(self._height)]
            self._depth_buffer = [[float("inf") for _ in range(self._width)] for _ in range(self._height)]

    def render(self, geometry: Geometry, shader: Shader) -> None:
        """Perform software rendering of geometry.

        Args:
            geometry: The geometry to render.
            shader: The shader to emulate.
        """
        with self._lock:
            # Process vertices through vertex shader emulation
            transformed_vertices = self._process_vertices(geometry, shader)

            # Render primitives
            if geometry.indices:
                # Indexed rendering
                self._render_indexed_triangles(transformed_vertices, geometry.indices, shader)
            else:
                # Direct vertex rendering (assuming triangles)
                self._render_triangles(transformed_vertices, shader)

    def _process_vertices(self, geometry: Geometry, shader: Shader) -> list[list[float]]:
        """Process vertices through vertex shader emulation.

        Args:
            geometry: The input geometry.
            shader: The shader to emulate.

        Returns:
            List of transformed vertices.
        """
        transformed: list[list[float]] = []

        # Group vertices by 5 floats (x, y, z, u, v)
        for i in range(0, len(geometry.vertices), 5):
            vertex = geometry.vertices[i : i + 5]
            if len(vertex) == 5:
                # Emulate vertex shader transformation
                # For now, pass through unchanged
                transformed.append(vertex)

        return transformed

    def _render_indexed_triangles(self, vertices: list[list[float]], indices: list[int], shader: Shader) -> None:
        """Render indexed triangles.

        Args:
            vertices: List of vertex data.
            indices: List of vertex indices.
            shader: The shader to emulate.
        """
        # Process triangles from indices
        for i in range(0, len(indices), 3):
            if i + 2 < len(indices):
                idx1, idx2, idx3 = indices[i], indices[i + 1], indices[i + 2]
                if idx1 < len(vertices) and idx2 < len(vertices) and idx3 < len(vertices):
                    v1 = vertices[idx1]
                    v2 = vertices[idx2]
                    v3 = vertices[idx3]
                    self._rasterize_triangle(v1, v2, v3, shader)

    def _render_triangles(self, vertices: list[list[float]], shader: Shader) -> None:
        """Render triangles directly from vertices.

        Args:
            vertices: List of vertex data.
            shader: The shader to emulate.
        """
        # Process triangles (every 3 vertices)
        for i in range(0, len(vertices), 3):
            if i + 2 < len(vertices):
                v1 = vertices[i]
                v2 = vertices[i + 1]
                v3 = vertices[i + 2]
                self._rasterize_triangle(v1, v2, v3, shader)

    def _rasterize_triangle(self, v1: list[float], v2: list[float], v3: list[float], shader: Shader) -> None:
        """Rasterize a single triangle.

        Args:
            v1, v2, v3: Triangle vertices (x, y, z, u, v).
            shader: The shader to emulate for fragment processing.
        """
        # Convert to screen coordinates (simple viewport transform)
        screen_v1 = self._to_screen_coords(v1)
        screen_v2 = self._to_screen_coords(v2)
        screen_v3 = self._to_screen_coords(v3)

        # Calculate triangle bounding box
        min_x = max(0, int(min(screen_v1[0], screen_v2[0], screen_v3[0])))
        max_x = min(self._width - 1, int(max(screen_v1[0], screen_v2[0], screen_v3[0])))
        min_y = max(0, int(min(screen_v1[1], screen_v2[1], screen_v3[1])))
        max_y = min(self._height - 1, int(max(screen_v1[1], screen_v2[1], screen_v3[1])))

        # Rasterize pixels inside triangle
        for y in range(min_y, max_y + 1):
            for x in range(min_x, max_x + 1):
                # Check if pixel is inside triangle
                if self._point_in_triangle(x, y, screen_v1, screen_v2, screen_v3):
                    # Calculate barycentric coordinates for interpolation
                    bary = self._barycentric_coords(x, y, screen_v1, screen_v2, screen_v3)

                    # Interpolate depth
                    depth = bary[0] * v1[2] + bary[1] * v2[2] + bary[2] * v3[2]

                    # Depth test
                    if depth < self._depth_buffer[y][x]:
                        self._depth_buffer[y][x] = depth

                        # Interpolate texture coordinates
                        u = bary[0] * v1[3] + bary[1] * v2[3] + bary[2] * v3[3]
                        v_coord = bary[0] * v1[4] + bary[1] * v2[4] + bary[2] * v3[4]

                        # Emulate fragment shader
                        color = self._emulate_fragment_shader(shader, u, v_coord)

                        # Write to framebuffer
                        self._framebuffer[y][x] = color

    def _to_screen_coords(self, vertex: list[float]) -> tuple[float, float, float, float, float]:
        """Convert vertex to screen coordinates (pixel space).

        Args:
            vertex: Vertex data (x, y, z, u, v) in pixel space where
                (0, 0) is top-left of the viewport.

        Returns:
            Screen space coordinates (x, y, z, u, v) in pixels.
        """
        x, y, z, u, v = vertex

        # Clamp to viewport bounds
        screen_x = max(0.0, min(float(self._width - 1), float(x)))
        screen_y = max(0.0, min(float(self._height - 1), float(y)))

        return (screen_x, screen_y, z, u, v)

    def _point_in_triangle(self, px: int, py: int, v1: tuple[float, float, float, float, float], v2: tuple[float, float, float, float, float], v3: tuple[float, float, float, float, float]) -> bool:
        """Check if a point is inside a triangle using barycentric coordinates.

        Args:
            px, py: Point coordinates.
            v1, v2, v3: Triangle vertices.

        Returns:
            True if point is inside triangle.
        """

        def sign(p1: tuple[float, float, float, float, float], p2: tuple[float, float, float, float, float], p3: tuple[float, float, float, float, float]) -> float:
            return (p1[0] - p3[0]) * (p2[1] - p3[1]) - (p2[0] - p3[0]) * (p1[1] - p3[1])

        d1 = sign(v1, v2, v3)
        d2 = sign(v2, v3, v1)
        d3 = sign(v3, v1, v2)

        has_neg = (d1 < 0) or (d2 < 0) or (d3 < 0)
        has_pos = (d1 > 0) or (d2 > 0) or (d3 > 0)

        return not (has_neg and has_pos)

    def _barycentric_coords(
        self, px: int, py: int, v1: tuple[float, float, float, float, float], v2: tuple[float, float, float, float, float], v3: tuple[float, float, float, float, float]
    ) -> tuple[float, float, float]:
        """Calculate barycentric coordinates.

        Args:
            px, py: Point coordinates.
            v1, v2, v3: Triangle vertices.

        Returns:
            Barycentric coordinates (w1, w2, w3).
        """
        # Calculate areas
        area = self._triangle_area(v1, v2, v3)
        if area == 0:
            return (1.0, 0.0, 0.0)

        w1 = self._triangle_area((px, py, 0.0, 0.0, 0.0), v2, v3) / area
        w2 = self._triangle_area(v1, (px, py, 0.0, 0.0, 0.0), v3) / area
        w3 = self._triangle_area(v1, v2, (px, py, 0.0, 0.0, 0.0)) / area

        return (w1, w2, w3)

    def _triangle_area(self, v1: tuple[float, float, float, float, float], v2: tuple[float, float, float, float, float], v3: tuple[float, float, float, float, float]) -> float:
        """Calculate triangle area using cross product.

        Args:
            v1, v2, v3: Triangle vertices.

        Returns:
            Triangle area.
        """
        return abs((v2[0] - v1[0]) * (v3[1] - v1[1]) - (v3[0] - v1[0]) * (v2[1] - v1[1])) * 0.5

    def _emulate_fragment_shader(self, shader: Shader, u: float, v: float) -> tuple[int, int, int, int]:
        """Emulate fragment shader execution.

        Args:
            shader: The shader to emulate.
            u, v: Texture coordinates.

        Returns:
            RGBA color tuple.
        """
        # Simple fragment shader emulation
        # For now, return a solid color based on texture coordinates
        r = int((u * 0.5 + 0.5) * 255)
        g = int((v * 0.5 + 0.5) * 255)
        b = 128
        a = 255

        return (r, g, b, a)

    def clear(self, color: tuple[int, int, int, int] | None = None) -> None:
        """Clear the framebuffer and depth buffer.

        Args:
            color: Clear color (r, g, b, a). If None, uses current clear color.
        """
        with self._lock:
            if color is None:
                color = self._clear_color

            for y in range(self._height):
                for x in range(self._width):
                    self._framebuffer[y][x] = color
                    self._depth_buffer[y][x] = float("inf")

    def set_clear_color(self, color: tuple[int, int, int, int]) -> None:
        """Set the clear color.

        Args:
            color: Clear color (r, g, b, a).
        """
        self._clear_color = color

    def get_framebuffer(self) -> list[list[tuple[int, int, int, int]]]:
        """Get the current framebuffer contents.

        Returns:
            Copy of the framebuffer.
        """
        with self._lock:
            return [row[:] for row in self._framebuffer]

    def resize(self, width: int, height: int) -> None:
        """Resize the framebuffer.

        Args:
            width: New width.
            height: New height.
        """
        with self._lock:
            self._width = width
            self._height = height
            self._initialize_buffers()
