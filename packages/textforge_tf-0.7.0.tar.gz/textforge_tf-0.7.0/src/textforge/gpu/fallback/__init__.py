"""CPU fallback implementation for GPU acceleration."""

from .cpu_fallback import CPUFallback

__all__ = [
    "CPUFallback",
]
