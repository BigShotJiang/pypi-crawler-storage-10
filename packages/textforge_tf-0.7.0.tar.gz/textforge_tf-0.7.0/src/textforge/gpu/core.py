"""Core GPU acceleration functionality for Textforge."""

from __future__ import annotations

import platform
import threading
from abc import ABC, abstractmethod
from typing import TYPE_CHECKING

from ..utils.logging import get_logger
from .fallback.cpu_fallback import CPUFallback
from .types import Geometry, GPUBackend, Shader

if TYPE_CHECKING:
    from ..components.base import RenderableComponent

logger = get_logger(__name__)


class GPUBuffer(ABC):
    """Abstract base class for GPU buffer objects."""

    def __init__(self, data: list[float] | list[int], usage: str) -> None:
        """Initialize GPU buffer with data.

        Args:
            data: The buffer data as floats or ints.
            usage: Buffer usage pattern ('static', 'dynamic', etc.).
        """
        self._data = data
        self._usage = usage
        self._buffer_id: int | None = None

    @property
    def data(self) -> list[float] | list[int]:
        """Get the buffer data."""
        return self._data

    @property
    def usage(self) -> str:
        """Get the buffer usage pattern."""
        return self._usage

    @abstractmethod
    def bind(self) -> None:
        """Bind the buffer for GPU operations."""
        pass

    @abstractmethod
    def unbind(self) -> None:
        """Unbind the buffer."""
        pass

    def update_data(self, data: list[float] | list[int]) -> None:
        """Update buffer data in memory.

        Args:
            data: New data to store in the buffer.

        Notes:
            Subclasses should call this first, then push to GPU as needed.
        """
        self._data = data


class GPUManager:
    """Manages GPU acceleration with automatic backend detection and fallback."""

    def __init__(self) -> None:
        self._backend: GPUBackend | None = None
        self._fallback = CPUFallback()
        self._lock = threading.RLock()
        self._shaders: dict[str, Shader] = {}
        self._initialized = False
        self._default_shader_sources: tuple[str, str] | None = None

    def _ensure_backend(self) -> GPUBackend | None:
        """Ensure a backend has been detected and return it.

        Returns:
            GPUBackend | None: Detected backend or ``None`` when unavailable.
        """
        if not self._initialized:
            self._backend = self._detect_backend()
            self._initialized = True
        return self._backend

    def _detect_backend(self) -> GPUBackend | None:
        """Detect the best available GPU backend for the current platform.

        Returns:
            The best available GPU backend instance, or None if none available.
        """
        system = platform.system()

        if system == "Windows":
            # Prefer DirectX on Windows, then OpenGL as backup, then Vulkan
            try:
                from .backends.directx import DirectXBackend

                backend = DirectXBackend()
                if backend.is_available():
                    logger.debug("Selected DirectX backend for Windows")
                    return backend
            except (ImportError, Exception) as e:
                logger.debug(f"DirectX backend not available: {e}")

            try:
                from .backends.opengl import OpenGLBackend

                backend = OpenGLBackend()
                if backend.is_available():
                    logger.debug("Selected OpenGL backend for Windows")
                    return backend
            except (ImportError, Exception) as e:
                logger.debug(f"OpenGL backend not available: {e}")

            try:
                from .backends.vulkan import VulkanBackend

                backend = VulkanBackend()
                if backend.is_available():
                    logger.debug("Selected Vulkan backend for Windows")
                    return backend
            except (ImportError, Exception) as e:
                logger.debug(f"Vulkan backend not available: {e}")

        elif system == "Darwin":  # macOS
            # Prefer Metal on macOS, then OpenGL, then Vulkan
            try:
                from .backends.metal import MetalBackend

                backend = MetalBackend()
                if backend.is_available():
                    logger.debug("Selected Metal backend for macOS")
                    return backend
            except ImportError:
                logger.debug("Metal backend not available (import failed)")

            try:
                from .backends.opengl import OpenGLBackend

                backend = OpenGLBackend()
                if backend.is_available():
                    logger.debug("Selected OpenGL backend for macOS")
                    return backend
            except (ImportError, Exception) as e:
                logger.debug(f"OpenGL backend not available: {e}")

            try:
                from .backends.vulkan import VulkanBackend

                backend = VulkanBackend()
                if backend.is_available():
                    logger.debug("Selected Vulkan backend for macOS")
                    return backend
            except (ImportError, Exception) as e:
                logger.debug(f"Vulkan backend not available: {e}")

        else:  # Linux and other Unix-like systems
            # Prefer Vulkan on Linux, then OpenGL
            try:
                from .backends.vulkan import VulkanBackend

                backend = VulkanBackend()
                if backend.is_available():
                    logger.debug("Selected Vulkan backend for Linux/Unix")
                    return backend
            except (ImportError, Exception) as e:
                logger.debug(f"Vulkan backend not available: {e}")

            try:
                from .backends.opengl import OpenGLBackend

                backend = OpenGLBackend()
                if backend.is_available():
                    logger.debug("Selected OpenGL backend for Linux/Unix")
                    return backend
            except (ImportError, Exception) as e:
                logger.debug(f"OpenGL backend not available: {e}")

        logger.debug("No GPU backend available")
        return None

    def is_available(self) -> bool:
        """Check if GPU acceleration is available."""
        with self._lock:
            return self._ensure_backend() is not None

    def create_shader(self, name: str, vertex_src: str, fragment_src: str) -> Shader:
        """Create and compile a shader program.

        Args:
            name: Unique name for the shader.
            vertex_src: Vertex shader source code.
            fragment_src: Fragment shader source code.

        Returns:
            Compiled Shader instance.

        Raises:
            GPUBackendNotAvailableError: If no GPU backend is available.
        """
        with self._lock:
            existing = self._shaders.get(name)
            if existing is not None:
                return existing

            backend = self._ensure_backend()
            if backend is None:
                return self._fallback.create_shader(name, vertex_src, fragment_src)

            try:
                shader = backend.create_shader(name, vertex_src, fragment_src)
                self._shaders[name] = shader
                logger.debug(f"Successfully created GPU shader: {name}")
                return shader
            except Exception as e:
                logger.warning(f"GPU shader creation failed for {name}: {e}, falling back to CPU")
                return self._fallback.create_shader(name, vertex_src, fragment_src)

    def get_default_shader_sources(self) -> tuple[str, str]:
        """Return backend-appropriate default shader sources.

        Returns:
            Tuple of (vertex_source, fragment_source) strings.
        """
        with self._lock:
            if self._default_shader_sources is not None:
                return self._default_shader_sources

            sources: tuple[str, str] | None = None
            backend = self._ensure_backend()

            if backend is not None and backend.__class__.__name__ == "DirectXBackend":
                try:
                    from .shaders.hlsl import load_pixel_shader_hlsl, load_vertex_shader_hlsl

                    sources = (load_vertex_shader_hlsl(), load_pixel_shader_hlsl())
                except Exception:
                    sources = None

            if sources is None:
                from .shaders.fragment import load_fragment_shader as _f
                from .shaders.vertex import load_vertex_shader as _v

                sources = (_v(), _f())

            self._default_shader_sources = sources
            return sources

    def render_geometry(self, geometry: Geometry, shader: Shader) -> None:
        """Render geometry using GPU acceleration or CPU fallback.

        Args:
            geometry: The geometry data to render.
            shader: The shader to use for rendering.
        """
        with self._lock:
            backend = self._ensure_backend()
            if backend is None:
                self._fallback.render_geometry(geometry, shader)
                return

            try:
                shader.bind()
                backend.render_geometry(geometry, shader)
                logger.debug(f"Successfully rendered geometry with {geometry.vertex_count} vertices using GPU")
            except Exception as e:
                logger.warning(f"GPU rendering failed: {e}, falling back to CPU")
                self._fallback.render_geometry(geometry, shader)


## CPU fallback is implemented in `.fallback.cpu_fallback` and imported above.

_GPU_MANAGER_SINGLETON: GPUManager | None = None
_GPU_MANAGER_LOCK = threading.Lock()


def get_gpu_manager() -> GPUManager:
    """Return the process-wide GPU manager singleton.

    Returns:
        GPUManager: Shared manager instance reused across render calls.
    """
    global _GPU_MANAGER_SINGLETON
    with _GPU_MANAGER_LOCK:
        if _GPU_MANAGER_SINGLETON is None:
            _GPU_MANAGER_SINGLETON = GPUManager()
        return _GPU_MANAGER_SINGLETON


def render_with_gpu_acceleration(component: RenderableComponent, target_surface: object) -> None:
    """Render a component using GPU acceleration when available.

    Args:
        component (RenderableComponent): Component to render.
        target_surface (object): Backend-specific surface or context receiving rendering output.
    """
    gpu_manager = get_gpu_manager()

    if gpu_manager.is_available():
        # Convert component to GPU geometry
        geometry = component_to_gpu_geometry(component)

        # Use appropriate shader per backend
        vs_src, fs_src = gpu_manager.get_default_shader_sources()
        shader = gpu_manager.create_shader("default_component", vs_src, fs_src)

        # Render with GPU acceleration
        gpu_manager.render_geometry(geometry, shader)
        logger.debug("Rendered component with GPU acceleration")
    else:
        # Fall back to CPU rendering
        cpu_render(component, target_surface)
        logger.debug("Rendered component with CPU fallback")


def component_to_gpu_geometry(component: RenderableComponent) -> Geometry:
    """Convert a component to GPU geometry.

    Args:
        component: The renderable component to convert.

    Returns:
        Geometry data suitable for GPU rendering.
    """
    # Get component dimensions from measurement
    from ..core.console import Console

    console = Console()

    # Try to measure component, fallback to default size if not supported
    try:
        measure = component.measure(console)
        width = float(measure.width)
        height = float(measure.height)
    except AttributeError:
        # Component doesn't support measurement, use default dimensions
        logger.debug(f"Component {type(component).__name__} doesn't support measurement, using defaults")
        width = 100.0  # Default width
        height = 20.0  # Default height

    # Create quad vertices (x, y, z, u, v)
    vertices = [
        # Bottom-left
        0.0,
        0.0,
        0.0,
        0.0,
        0.0,
        # Bottom-right
        width,
        0.0,
        0.0,
        1.0,
        0.0,
        # Top-right
        width,
        height,
        0.0,
        1.0,
        1.0,
        # Top-left
        0.0,
        height,
        0.0,
        0.0,
        1.0,
    ]

    # Triangle indices for quad
    indices = [0, 1, 2, 2, 3, 0]

    return Geometry(vertices=vertices, indices=indices, vertex_count=4, index_count=6)


def cpu_render(component: RenderableComponent, target_surface: object) -> None:
    """CPU-based rendering fallback.

    Args:
        component (RenderableComponent): Component to render using software path.
        target_surface (object): Render target for CPU fallback.
    """
    # Placeholder implementation - would perform software rendering
    logger.debug("Performing CPU-based rendering")


def load_vertex_shader() -> str:
    """Deprecated. Use GPUManager.get_default_shader_sources instead."""
    from .shaders.vertex import load_vertex_shader as _load
    return _load()


def load_fragment_shader() -> str:
    """Deprecated. Use GPUManager.get_default_shader_sources instead."""
    from .shaders.fragment import load_fragment_shader as _load
    return _load()
