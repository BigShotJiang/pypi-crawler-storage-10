"""GPU acceleration subsystem for Textforge."""

from .core import GPUManager, render_with_gpu_acceleration
from .fallback.cpu_fallback import CPUFallback
from .types import Shader

__all__ = [
    "GPUManager",
    "Shader",
    "CPUFallback",
    "render_with_gpu_acceleration",
]
