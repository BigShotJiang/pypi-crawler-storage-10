"""Cube texture implementation."""

from __future__ import annotations

from .texture import Texture


class TextureCube(Texture):
    """Cube texture for GPU rendering (skyboxes, environment mapping).

    Uses OpenGL when available; otherwise stores data CPU-side.
    """

    def __init__(
        self,
        size: int,
        data: list[bytes | bytearray | memoryview | list[int] | None] | None = None,
        format: str = "rgba8",
    ) -> None:
        """Initialize cube texture.

        Args:
            size: Width/height of each cube face in pixels.
            data: List of 6 faces' pixel data, or None per face.
            format: Pixel format string, e.g. 'rgba8'.
        """
        super().__init__(size, size, format)  # Cube textures are square
        self.size = size
        if data is not None and len(data) != 6:
            raise ValueError("Cube texture requires data for 6 faces")
        self._data: list[bytes | bytearray | memoryview | list[int] | None] = data or [None] * 6
        self._create_gpu_texture_if_available()

    def _create_gpu_texture_if_available(self) -> None:
        """Create GL cubemap texture if OpenGL is available and context is current."""
        try:
            import importlib

            gl = importlib.import_module("OpenGL.GL")

            self._texture_id = gl.glGenTextures(1)
            gl.glBindTexture(gl.GL_TEXTURE_CUBE_MAP, self._texture_id)

            # Default parameters
            gl.glTexParameteri(gl.GL_TEXTURE_CUBE_MAP, gl.GL_TEXTURE_MIN_FILTER, gl.GL_LINEAR)
            gl.glTexParameteri(gl.GL_TEXTURE_CUBE_MAP, gl.GL_TEXTURE_MAG_FILTER, gl.GL_LINEAR)
            gl.glTexParameteri(gl.GL_TEXTURE_CUBE_MAP, gl.GL_TEXTURE_WRAP_S, gl.GL_CLAMP_TO_EDGE)
            gl.glTexParameteri(gl.GL_TEXTURE_CUBE_MAP, gl.GL_TEXTURE_WRAP_T, gl.GL_CLAMP_TO_EDGE)
            gl.glTexParameteri(gl.GL_TEXTURE_CUBE_MAP, gl.GL_TEXTURE_WRAP_R, gl.GL_CLAMP_TO_EDGE)

            internal_format, pixel_format, pixel_type = _gl_format_for(self.format)
            targets = [
                gl.GL_TEXTURE_CUBE_MAP_POSITIVE_X,
                gl.GL_TEXTURE_CUBE_MAP_NEGATIVE_X,
                gl.GL_TEXTURE_CUBE_MAP_POSITIVE_Y,
                gl.GL_TEXTURE_CUBE_MAP_NEGATIVE_Y,
                gl.GL_TEXTURE_CUBE_MAP_POSITIVE_Z,
                gl.GL_TEXTURE_CUBE_MAP_NEGATIVE_Z,
            ]
            for face, target in enumerate(targets):
                face_data = self._data[face]
                gl.glTexImage2D(
                    target,
                    0,
                    internal_format,
                    self.width,
                    self.height,
                    0,
                    pixel_format,
                    pixel_type,
                    face_data,
                )

            gl.glBindTexture(gl.GL_TEXTURE_CUBE_MAP, 0)
        except Exception:
            self._texture_id = None

    def bind(self, slot: int = 0) -> None:
        """Bind cube texture to texture slot."""
        try:
            import importlib

            gl = importlib.import_module("OpenGL.GL")
            gl.glActiveTexture(gl.GL_TEXTURE0 + int(slot))
            gl.glBindTexture(gl.GL_TEXTURE_CUBE_MAP, int(self._texture_id) if self._texture_id is not None else 0)
        except Exception:
            return

    def unbind(self) -> None:
        """Unbind cube texture."""
        try:
            import importlib

            gl = importlib.import_module("OpenGL.GL")
            gl.glBindTexture(gl.GL_TEXTURE_CUBE_MAP, 0)
        except Exception:
            return

    def update_data(self, data: list[bytes | bytearray | memoryview | list[int] | None]) -> None:
        """Update texture data for all faces."""
        if len(data) != 6:
            raise ValueError("Cube texture requires data for 6 faces")
        self._data = data
        try:
            import importlib

            gl = importlib.import_module("OpenGL.GL")
            if self._texture_id is None:
                self._create_gpu_texture_if_available()
            if self._texture_id is not None:
                gl.glBindTexture(gl.GL_TEXTURE_CUBE_MAP, self._texture_id)
                _, pixel_format, pixel_type = _gl_format_for(self.format)
                targets = [
                    gl.GL_TEXTURE_CUBE_MAP_POSITIVE_X,
                    gl.GL_TEXTURE_CUBE_MAP_NEGATIVE_X,
                    gl.GL_TEXTURE_CUBE_MAP_POSITIVE_Y,
                    gl.GL_TEXTURE_CUBE_MAP_NEGATIVE_Y,
                    gl.GL_TEXTURE_CUBE_MAP_POSITIVE_Z,
                    gl.GL_TEXTURE_CUBE_MAP_NEGATIVE_Z,
                ]
                for face, target in enumerate(targets):
                    gl.glTexSubImage2D(
                        target,
                        0,
                        0,
                        0,
                        self.width,
                        self.height,
                        pixel_format,
                        pixel_type,
                        self._data[face],
                    )
                gl.glBindTexture(gl.GL_TEXTURE_CUBE_MAP, 0)
        except Exception:
            return

    def update_face(self, face_index: int, data: bytes | bytearray | memoryview | list[int]) -> None:
        """Update data for a specific face."""
        if not 0 <= face_index < 6:
            raise ValueError("Face index must be between 0 and 5")
        self._data[face_index] = data
        try:
            import importlib

            gl = importlib.import_module("OpenGL.GL")
            if self._texture_id is None:
                self._create_gpu_texture_if_available()
            if self._texture_id is not None:
                targets = [
                    gl.GL_TEXTURE_CUBE_MAP_POSITIVE_X,
                    gl.GL_TEXTURE_CUBE_MAP_NEGATIVE_X,
                    gl.GL_TEXTURE_CUBE_MAP_POSITIVE_Y,
                    gl.GL_TEXTURE_CUBE_MAP_NEGATIVE_Y,
                    gl.GL_TEXTURE_CUBE_MAP_POSITIVE_Z,
                    gl.GL_TEXTURE_CUBE_MAP_NEGATIVE_Z,
                ]
                gl.glBindTexture(gl.GL_TEXTURE_CUBE_MAP, self._texture_id)
                _, pixel_format, pixel_type = _gl_format_for(self.format)
                gl.glTexSubImage2D(
                    targets[face_index],
                    0,
                    0,
                    0,
                    self.width,
                    self.height,
                    pixel_format,
                    pixel_type,
                    data,
                )
                gl.glBindTexture(gl.GL_TEXTURE_CUBE_MAP, 0)
        except Exception:
            return

    @property
    def texture_id(self) -> object:
        """Get the GPU texture identifier."""
        return self._texture_id


def _gl_format_for(fmt: str) -> tuple[int, int, int]:
    """Map format string to OpenGL constants for cubemaps.

    Args:
        fmt: Format like 'rgba8'.

    Returns:
        Tuple of (internal_format, pixel_format, pixel_type).
    """
    import importlib

    gl = importlib.import_module("OpenGL.GL")
    fmt_l = fmt.lower()
    if fmt_l == "rgba8":
        return (gl.GL_RGBA8, gl.GL_RGBA, gl.GL_UNSIGNED_BYTE)
    if fmt_l == "rgb8":
        return (gl.GL_RGB8, gl.GL_RGB, gl.GL_UNSIGNED_BYTE)
    return (gl.GL_RGBA8, gl.GL_RGBA, gl.GL_UNSIGNED_BYTE)
