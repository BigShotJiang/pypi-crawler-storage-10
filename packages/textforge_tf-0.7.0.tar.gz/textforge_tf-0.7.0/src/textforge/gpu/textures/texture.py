"""Base GPU texture class."""

from abc import ABC, abstractmethod
from typing import Any


class Texture(ABC):
    """Abstract base class for GPU textures."""

    def __init__(self, width: int, height: int, format: str = "rgba8") -> None:
        """Initialize texture with dimensions and format."""
        self.width = width
        self.height = height
        self.format = format
        self._texture_id: Any = None

    @abstractmethod
    def bind(self, slot: int = 0) -> None:
        """Bind texture to a texture slot."""
        pass

    @abstractmethod
    def unbind(self) -> None:
        """Unbind texture."""
        pass

    @abstractmethod
    def update_data(self, data: object) -> None:
        """Update texture data."""
        pass

    @property
    @abstractmethod
    def texture_id(self) -> object:
        """Get the GPU texture identifier."""
        return self._texture_id
