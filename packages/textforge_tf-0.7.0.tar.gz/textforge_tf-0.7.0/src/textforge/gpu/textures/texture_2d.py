"""2D texture implementation."""

from __future__ import annotations

from .texture import Texture


class Texture2D(Texture):
    """2D texture for GPU rendering with optional OpenGL acceleration.

    Falls back to CPU-side data storage when GPU APIs are unavailable.
    """

    def __init__(
        self,
        width: int,
        height: int,
        data: bytes | bytearray | memoryview | list[int] | None = None,
        format: str = "rgba8",
    ) -> None:
        """Initialize 2D texture.

        Args:
            width: Texture width in pixels.
            height: Texture height in pixels.
            data: Initial pixel data (row-major, tightly packed), RGBA unless noted.
            format: Format string, e.g. 'rgba8', 'rgb8'.
        """
        super().__init__(width, height, format)
        self._data: bytes | bytearray | memoryview | list[int] | None = data
        self._create_gpu_texture_if_available()

    def _create_gpu_texture_if_available(self) -> None:
        """Create GL texture if OpenGL is available and a context is current."""
        try:
            import importlib

            gl = importlib.import_module("OpenGL.GL")

            # Generate and bind texture
            self._texture_id = gl.glGenTextures(1)
            gl.glBindTexture(gl.GL_TEXTURE_2D, self._texture_id)

            # Default parameters
            gl.glTexParameteri(gl.GL_TEXTURE_2D, gl.GL_TEXTURE_MIN_FILTER, gl.GL_LINEAR)
            gl.glTexParameteri(gl.GL_TEXTURE_2D, gl.GL_TEXTURE_MAG_FILTER, gl.GL_LINEAR)
            gl.glTexParameteri(gl.GL_TEXTURE_2D, gl.GL_TEXTURE_WRAP_S, gl.GL_CLAMP_TO_EDGE)
            gl.glTexParameteri(gl.GL_TEXTURE_2D, gl.GL_TEXTURE_WRAP_T, gl.GL_CLAMP_TO_EDGE)

            # Upload initial data if provided
            if self._data is not None:
                _internal_format, pixel_format, pixel_type = _gl_format_for(self.format)
                gl.glTexImage2D(
                    gl.GL_TEXTURE_2D,
                    0,
                    _internal_format,
                    self.width,
                    self.height,
                    0,
                    pixel_format,
                    pixel_type,
                    self._data,
                )
            else:
                # Allocate empty texture
                internal_format, pixel_format, pixel_type = _gl_format_for(self.format)
                gl.glTexImage2D(
                    gl.GL_TEXTURE_2D,
                    0,
                    internal_format,
                    self.width,
                    self.height,
                    0,
                    pixel_format,
                    pixel_type,
                    None,
                )

            gl.glBindTexture(gl.GL_TEXTURE_2D, 0)
        except Exception:
            # No OpenGL available or no context; remain CPU-side only
            self._texture_id = None

    def bind(self, slot: int = 0) -> None:
        """Bind 2D texture to texture slot."""
        try:
            import importlib

            gl = importlib.import_module("OpenGL.GL")
            gl.glActiveTexture(gl.GL_TEXTURE0 + int(slot))
            gl.glBindTexture(gl.GL_TEXTURE_2D, int(self._texture_id) if self._texture_id is not None else 0)
        except Exception:
            # CPU fallback - no-op
            return

    def unbind(self) -> None:
        """Unbind 2D texture."""
        try:
            import importlib

            gl = importlib.import_module("OpenGL.GL")
            gl.glBindTexture(gl.GL_TEXTURE_2D, 0)
        except Exception:
            return

    def update_data(self, data: bytes | bytearray | memoryview | list[int]) -> None:
        """Update texture data.

        Args:
            data: Pixel data matching the texture format and size.
        """
        self._data = data
        try:
            import importlib

            gl = importlib.import_module("OpenGL.GL")
            if self._texture_id is None:
                # Try to create texture now if context became available
                self._create_gpu_texture_if_available()
            if self._texture_id is not None:
                gl.glBindTexture(gl.GL_TEXTURE_2D, self._texture_id)
                _internal_format, pixel_format, pixel_type = _gl_format_for(self.format)
                gl.glTexSubImage2D(
                    gl.GL_TEXTURE_2D,
                    0,
                    0,
                    0,
                    self.width,
                    self.height,
                    pixel_format,
                    pixel_type,
                    data,
                )
                gl.glBindTexture(gl.GL_TEXTURE_2D, 0)
        except Exception:
            # CPU fallback - keep data only
            return

    @property
    def texture_id(self) -> object:
        """Get the GPU texture identifier."""
        return self._texture_id


def _gl_format_for(fmt: str) -> tuple[int, int, int]:
    """Map format string to OpenGL constants.

    Args:
        fmt: Format like 'rgba8', 'rgb8'.

    Returns:
        Tuple of (internal_format, pixel_format, pixel_type).
    """
    import importlib

    gl = importlib.import_module("OpenGL.GL")
    fmt_l = fmt.lower()
    if fmt_l == "rgba8":
        return (gl.GL_RGBA8, gl.GL_RGBA, gl.GL_UNSIGNED_BYTE)
    if fmt_l == "rgb8":
        return (gl.GL_RGB8, gl.GL_RGB, gl.GL_UNSIGNED_BYTE)
    # Default to RGBA8
    return (gl.GL_RGBA8, gl.GL_RGBA, gl.GL_UNSIGNED_BYTE)
