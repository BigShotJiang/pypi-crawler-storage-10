"""Fragment shader loading and management."""


def load_fragment_shader() -> str:
    """Load the default fragment shader source."""
    return """#version 330 core
out vec4 FragColor;

in vec2 TexCoord;

uniform sampler2D texture1;
uniform vec4 color;

void main() {
    vec4 texColor = texture(texture1, TexCoord);
    FragColor = texColor * color;
}
"""
