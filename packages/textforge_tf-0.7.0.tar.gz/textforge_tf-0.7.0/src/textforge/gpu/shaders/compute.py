"""Compute shader loading and management."""


def load_compute_shader() -> str:
    """Load the default compute shader source."""
    return """#version 430 core
layout (local_size_x = 16, local_size_y = 16) in;

layout(rgba32f, binding = 0) uniform image2D inputImage;
layout(rgba32f, binding = 1) uniform image2D outputImage;

uniform float time;
uniform vec2 resolution;

void main() {
    ivec2 texelCoord = ivec2(gl_GlobalInvocationID.xy);
    vec4 color = imageLoad(inputImage, texelCoord);

    // Simple compute shader effect - add time-based modulation
    float modulation = sin(time + texelCoord.x * 0.01 + texelCoord.y * 0.01) * 0.1 + 0.9;
    color.rgb *= modulation;

    imageStore(outputImage, texelCoord, color);
}
"""
