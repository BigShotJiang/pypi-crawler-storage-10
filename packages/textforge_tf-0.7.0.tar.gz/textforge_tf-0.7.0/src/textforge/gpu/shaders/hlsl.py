"""Default HLSL shaders for DirectX backends.

Provides vertex/pixel/compute shaders suitable for UI rendering with
position (float3) and texcoord (float2) inputs. The vertex shader assumes
coordinates are already in clip-space (NDC). If you supply pixel-space
coordinates, convert them to NDC on CPU before upload, or pass an ortho
matrix via a constant buffer and adapt these shaders as needed.
"""

from __future__ import annotations


def load_vertex_shader_hlsl() -> str:
    """Return a default HLSL vertex shader source.

    The shader takes POSITION (float3) and TEXCOORD0 (float2) and forwards
    them to the pixel shader. The input position is interpreted as clip-space.

    Returns:
        HLSL source for a vertex shader.
    """

    return (
        """
cbuffer ColorBuffer : register(b0)
{
    float4 color;
};

struct VSInput {
    float3 aPos : POSITION;
    float2 aTexCoord : TEXCOORD0;
};

struct VSOutput {
    float4 Pos : SV_POSITION;
    float2 TexCoord : TEXCOORD0;
};

VSOutput mainVS(VSInput input)
{
    VSOutput o;
    o.Pos = float4(input.aPos, 1.0);
    o.TexCoord = input.aTexCoord;
    return o;
}
"""
    ).strip()


def load_pixel_shader_hlsl() -> str:
    """Return a default HLSL pixel shader source.

    The shader samples a bound texture and multiplies by a uniform color.
    If no texture is bound, set the sampler to a 1x1 white texture.

    Returns:
        HLSL source for a pixel shader.
    """

    return (
        """
cbuffer ColorBuffer : register(b0)
{
    float4 color;
};

Texture2D texture1 : register(t0);
SamplerState sampler1 : register(s0);

struct PSInput {
    float4 Pos : SV_POSITION;
    float2 TexCoord : TEXCOORD0;
};

float4 mainPS(PSInput input) : SV_TARGET
{
    float4 tex = texture1.Sample(sampler1, input.TexCoord);
    return tex * color;
}
"""
    ).strip()


def load_compute_shader_hlsl() -> str:
    """Return a default HLSL compute shader source.

    A simple pass-through compute effect that modulates color by time.

    Returns:
        HLSL source for a compute shader.
    """

    return (
        """
cbuffer TimeBuffer : register(b0)
{
    float time;
    float2 resolution;
    float pad;
};

Texture2D<float4> inputImage : register(t0);
RWTexture2D<float4> outputImage : register(u0);

[numthreads(16,16,1)]
void mainCS(uint3 DTid : SV_DispatchThreadID)
{
    float2 coord = float2(DTid.xy) / resolution;
    float4 color = inputImage.Load(int3(DTid.xy, 0));
    float modulation = sin(time + coord.x * 0.01 + coord.y * 0.01) * 0.1 + 0.9;
    color.rgb *= modulation;
    outputImage[DTid.xy] = color;
}
"""
    ).strip()


