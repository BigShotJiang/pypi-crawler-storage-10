"""Shader management for GPU acceleration."""

from .compute import load_compute_shader
from .fragment import load_fragment_shader
from .vertex import load_vertex_shader

__all__ = [
    "load_vertex_shader",
    "load_fragment_shader",
    "load_compute_shader",
]
