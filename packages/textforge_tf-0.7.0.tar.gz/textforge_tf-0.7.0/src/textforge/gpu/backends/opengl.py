"""OpenGL GPU backend for fallback support."""

import threading
from typing import Any

from ...utils.logging import get_logger
from ..types import Geometry, GPUBackend, GPUBackendNotAvailableError, Shader, ShaderCompilationError

logger = get_logger(__name__)


class OpenGLBackend(GPUBackend):
    """OpenGL GPU backend implementation for fallback support.

    Provides OpenGL 3.3+ support for hardware-accelerated rendering across all platforms.
    """

    def __init__(self) -> None:
        self._initialized = False
        self._context: Any = None
        self._lock = threading.RLock()
        self._shaders: dict[str, int] = {}
        self._programs: dict[str, int] = {}
        self._vbos: dict[str, int] = {}
        self._ibos: dict[str, int] = {}
        self._vaos: dict[str, int] = {}

    def is_available(self) -> bool:
        """Check if OpenGL is available on this system.

        Returns:
            True if OpenGL 3.3+ is available, False otherwise.
        """
        try:
            import importlib.util

            return importlib.util.find_spec("OpenGL.GL") is not None
        except Exception:
            return False

    def create_shader(self, name: str, vertex_src: str, fragment_src: str) -> Shader:
        """Create and compile a shader using OpenGL.

        Args:
            name: Unique name for the shader.
            vertex_src: Vertex shader source code (GLSL).
            fragment_src: Fragment shader source code (GLSL).

        Returns:
            Compiled Shader instance.

        Raises:
            GPUBackendNotAvailableError: If OpenGL is not available.
            ShaderCompilationError: If shader compilation fails.
        """
        with self._lock:
            if not self.is_available():
                raise GPUBackendNotAvailableError("OpenGL backend not available")

            self._ensure_initialized()

            try:
                import importlib
                gl = importlib.import_module("OpenGL.GL")

                # Create vertex shader
                vertex_shader = gl.glCreateShader(gl.GL_VERTEX_SHADER)
                gl.glShaderSource(vertex_shader, vertex_src)
                gl.glCompileShader(vertex_shader)

                # Check vertex shader compilation
                if not gl.glGetShaderiv(vertex_shader, gl.GL_COMPILE_STATUS):
                    error = gl.glGetShaderInfoLog(vertex_shader)
                    gl.glDeleteShader(vertex_shader)
                    raise ShaderCompilationError(f"Vertex shader compilation failed: {error}")

                # Create fragment shader
                fragment_shader = gl.glCreateShader(gl.GL_FRAGMENT_SHADER)
                gl.glShaderSource(fragment_shader, fragment_src)
                gl.glCompileShader(fragment_shader)

                # Check fragment shader compilation
                if not gl.glGetShaderiv(fragment_shader, gl.GL_COMPILE_STATUS):
                    error = gl.glGetShaderInfoLog(fragment_shader)
                    gl.glDeleteShader(vertex_shader)
                    gl.glDeleteShader(fragment_shader)
                    raise ShaderCompilationError(f"Fragment shader compilation failed: {error}")

                # Create and link program
                program = gl.glCreateProgram()
                gl.glAttachShader(program, vertex_shader)
                gl.glAttachShader(program, fragment_shader)
                gl.glLinkProgram(program)

                # Check program linking
                if not gl.glGetProgramiv(program, gl.GL_LINK_STATUS):
                    error = gl.glGetProgramInfoLog(program)
                    gl.glDeleteProgram(program)
                    gl.glDeleteShader(vertex_shader)
                    gl.glDeleteShader(fragment_shader)
                    raise ShaderCompilationError(f"Shader program linking failed: {error}")

                # Clean up shaders (they're linked into the program now)
                gl.glDetachShader(program, vertex_shader)
                gl.glDetachShader(program, fragment_shader)
                gl.glDeleteShader(vertex_shader)
                gl.glDeleteShader(fragment_shader)

                # Store program
                self._programs[name] = program

                shader = Shader(name, vertex_src, fragment_src)
                shader.compile(self)

                logger.debug(f"Successfully compiled OpenGL shader: {name}")
                return shader

            except Exception as e:
                logger.error(f"OpenGL shader compilation failed for {name}: {e}")
                raise ShaderCompilationError(f"OpenGL shader compilation failed: {e}") from e

    def render_geometry(self, geometry: Geometry, shader: Shader) -> None:
        """Render geometry using OpenGL.

        Args:
            geometry: The geometry data to render.
            shader: The shader to use for rendering.

        Raises:
            GPUBackendNotAvailableError: If OpenGL is not available.
        """
        with self._lock:
            if not self.is_available():
                raise GPUBackendNotAvailableError("OpenGL backend not available")

            # Try OpenGL rendering, fall back to CPU if no context
            try:
                self._ensure_initialized()

                import ctypes
                import importlib
                gl = importlib.import_module("OpenGL.GL")
                arrays = importlib.import_module("OpenGL.arrays")

                # Get or create VAO for this shader/geometry combination
                vao_key = f"{shader.name}_geometry"
                if vao_key not in self._vaos:
                    vao_id = gl.glGenVertexArrays(1)
                    self._vaos[vao_key] = vao_id

                    gl.glBindVertexArray(vao_id)

                    # Create and setup VBO for vertex data
                    vbo_id = gl.glGenBuffers(1)
                    self._vbos[f"{vao_key}_vertices"] = vbo_id

                    gl.glBindBuffer(gl.GL_ARRAY_BUFFER, vbo_id)
                    vertex_data = arrays.GLfloatArray(geometry.vertices)
                    gl.glBufferData(gl.GL_ARRAY_BUFFER, vertex_data, gl.GL_STATIC_DRAW)

                    # Set up vertex attributes
                    # Position attribute (location 0) - first 3 floats
                    gl.glEnableVertexAttribArray(0)
                    gl.glVertexAttribPointer(0, 3, gl.GL_FLOAT, gl.GL_FALSE, 5 * 4, None)

                    # Texture coordinate attribute (location 1) - next 2 floats
                    gl.glEnableVertexAttribArray(1)
                    gl.glVertexAttribPointer(1, 2, gl.GL_FLOAT, gl.GL_FALSE, 5 * 4, ctypes.c_void_p(3 * 4))

                    # Create and setup IBO for index data if present
                    if geometry.indices:
                        ibo_id = gl.glGenBuffers(1)
                        self._ibos[f"{vao_key}_indices"] = ibo_id

                        gl.glBindBuffer(gl.GL_ELEMENT_ARRAY_BUFFER, ibo_id)
                        index_data = arrays.GLuintArray(geometry.indices)
                        gl.glBufferData(gl.GL_ELEMENT_ARRAY_BUFFER, index_data, gl.GL_STATIC_DRAW)

                    gl.glBindVertexArray(0)
                else:
                    gl.glBindVertexArray(self._vaos[vao_key])

                # Use the shader program
                program = self._programs.get(shader.name)
                if program is None:
                    raise ShaderCompilationError(f"No program found for shader {shader.name}")
                gl.glUseProgram(program)

                # Set viewport (should be configurable)
                gl.glViewport(0, 0, 800, 600)
                gl.glClearColor(0.0, 0.0, 0.0, 1.0)
                gl.glClear(gl.GL_COLOR_BUFFER_BIT)
                gl.glClear(gl.GL_DEPTH_BUFFER_BIT)

                # Render geometry
                if geometry.indices:
                    gl.glDrawElements(gl.GL_TRIANGLES, geometry.index_count, gl.GL_UNSIGNED_INT, None)
                else:
                    gl.glDrawArrays(gl.GL_TRIANGLES, 0, geometry.vertex_count)

                # Clean up state
                gl.glBindVertexArray(0)
                gl.glUseProgram(0)

                logger.debug(f"Rendered geometry with {geometry.vertex_count} vertices using OpenGL")

            except Exception as e:
                logger.warning(f"OpenGL rendering failed: {e}, falling back to CPU")
                # Fall back to CPU rendering
                from ..fallback.cpu_fallback import CPUFallback
                cpu_fallback = CPUFallback()
                cpu_fallback.render_geometry(geometry, shader)

    def _ensure_initialized(self) -> None:
        """Ensure OpenGL context is initialized.

        Raises:
            GPUBackendNotAvailableError: If OpenGL initialization fails.
        """
        if not self._initialized:
            try:
                import importlib
                gl = importlib.import_module("OpenGL.GL")

                # Verify a current context exists by probing version string first
                version_bytes = gl.glGetString(gl.GL_VERSION)
                if not version_bytes:
                    raise RuntimeError("No current OpenGL context")
                version = version_bytes.decode("utf-8", errors="ignore")

                # Enable necessary OpenGL features
                gl.glEnable(gl.GL_DEPTH_TEST)
                gl.glEnable(gl.GL_BLEND)
                gl.glBlendFunc(gl.GL_SRC_ALPHA, gl.GL_ONE_MINUS_SRC_ALPHA)

                logger.debug(f"Initialized OpenGL {version}")
                self._initialized = True

            except Exception as e:
                logger.error(f"Failed to initialize OpenGL context: {e}")
                raise GPUBackendNotAvailableError(f"Failed to initialize OpenGL context: {e}") from e

    def cleanup(self) -> None:
        """Clean up OpenGL resources."""
        with self._lock:
            try:
                import importlib
                gl = importlib.import_module("OpenGL.GL")

                # Delete programs
                for program_id in self._programs.values():
                    gl.glDeleteProgram(program_id)
                self._programs.clear()

                # Delete VAOs
                for vao_id in self._vaos.values():
                    gl.glDeleteVertexArrays(1, [vao_id])
                self._vaos.clear()

                # Delete VBOs
                for vbo_id in self._vbos.values():
                    gl.glDeleteBuffers(1, [vbo_id])
                self._vbos.clear()

                # Delete IBOs
                for ibo_id in self._ibos.values():
                    gl.glDeleteBuffers(1, [ibo_id])
                self._ibos.clear()

                logger.debug("OpenGL backend cleaned up")
                self._initialized = False

            except Exception as e:
                logger.error(f"Error during OpenGL cleanup: {e}")
                # Don't re-raise during cleanup
