"""Metal GPU backend for macOS."""

import platform
from typing import Any

from ...utils.logging import get_logger
from ..types import Geometry, GPUBackend, GPUBackendNotAvailableError, Shader, ShaderCompilationError

logger = get_logger(__name__)


class MetalBackend(GPUBackend):
    """Metal GPU backend implementation for macOS.

    Provides Metal API support for hardware-accelerated rendering on macOS platforms.
    """

    def __init__(self) -> None:
        self._initialized = False
        self._device: Any = None
        self._command_queue: Any = None
        self._library: Any = None
        self._shaders: dict[str, Any] = {}
        self._vertex_buffers: dict[str, Any] = {}
        self._index_buffers: dict[str, Any] = {}

    def is_available(self) -> bool:
        """Check if Metal is available on this system.

        Returns:
            True if Metal is available, False otherwise.
        """
        if platform.system() != "Darwin":
            return False

        try:
            import importlib.util

            # Require PyObjC bridge (objc) and Metal bindings to be present
            if not importlib.util.find_spec("objc"):
                return False
            # Metal module name via PyObjC is typically 'Metal'
            if not importlib.util.find_spec("Metal"):
                return False
            return True
        except Exception:
            return False

    def create_shader(self, name: str, vertex_src: str, fragment_src: str) -> Shader:
        """Create and compile a shader using Metal.

        Args:
            name: Unique name for the shader.
            vertex_src: Vertex shader source code (MSL).
            fragment_src: Fragment shader source code (MSL).

        Returns:
            Compiled Shader instance.

        Raises:
            GPUBackendNotAvailableError: If Metal is not available.
            ShaderCompilationError: If shader compilation fails.
        """
        if not self.is_available():
            raise GPUBackendNotAvailableError("Metal backend not available")

        self._ensure_initialized()

        try:
            # Create vertex function
            vertex_function = self._compile_vertex_function(vertex_src)
            # Create fragment function
            fragment_function = self._compile_fragment_function(fragment_src)

            # Store shader functions
            self._shaders[name] = {"vertex": vertex_function, "fragment": fragment_function}

            shader = Shader(name, vertex_src, fragment_src)
            shader.compile(self)

            logger.debug(f"Successfully compiled Metal shader: {name}")
            return shader

        except Exception as e:
            logger.error(f"Metal shader compilation failed for {name}: {e}")
            raise ShaderCompilationError(f"Metal shader compilation failed: {e}") from e

    def render_geometry(self, geometry: Geometry, shader: Shader) -> None:
        """Render geometry using Metal.

        Args:
            geometry: The geometry data to render.
            shader: The shader to use for rendering.

        Raises:
            GPUBackendNotAvailableError: If Metal is not available.
        """
        if not self.is_available():
            raise GPUBackendNotAvailableError("Metal backend not available")

        self._ensure_initialized()

        try:
            # Create command buffer
            command_buffer = self._command_queue.commandBuffer()

            # Create render command encoder
            render_pass_descriptor = self._create_render_pass_descriptor()
            render_encoder = command_buffer.renderCommandEncoderWithDescriptor_(render_pass_descriptor)

            # Set shaders
            shader_program = self._shaders.get(shader.name)
            if shader_program:
                render_encoder.setVertexFunction_(shader_program["vertex"])
                render_encoder.setFragmentFunction_(shader_program["fragment"])

            # Set up vertex buffer
            vertex_buffer = self._create_vertex_buffer(geometry.vertices)
            render_encoder.setVertexBuffer_offset_atIndex_(vertex_buffer, 0, 0)

            # Set up index buffer if present
            if geometry.indices:
                index_buffer = self._create_index_buffer(geometry.indices)
                render_encoder.drawIndexedPrimitives_indexCount_indexType_indexBuffer_indexBufferOffset_(
                    3,  # MTLPrimitiveTypeTriangle
                    geometry.index_count,
                    0,  # MTLIndexTypeUInt32
                    index_buffer,
                    0,
                )
            else:
                render_encoder.drawPrimitives_vertexStart_vertexCount_(
                    3,  # MTLPrimitiveTypeTriangle
                    0,
                    geometry.vertex_count,
                )

            # End encoding
            render_encoder.endEncoding()

            # Commit command buffer
            command_buffer.commit()
            command_buffer.waitUntilCompleted()

            logger.debug(f"Rendered geometry with {geometry.vertex_count} vertices using Metal")

        except Exception as e:
            logger.error(f"Metal rendering failed: {e}")
            raise

    def _ensure_initialized(self) -> None:
        """Ensure Metal device and command queue are initialized.

        Raises:
            GPUBackendNotAvailableError: If Metal initialization fails.
        """
        if not self._initialized:
            try:
                # Initialize Metal device and command queue
                # In production, this would use Metal APIs
                # For now, this is a placeholder implementation
                logger.debug("Initializing Metal backend")
                self._initialized = True

            except Exception as e:
                logger.error(f"Failed to initialize Metal: {e}")
                raise GPUBackendNotAvailableError(f"Metal initialization failed: {e}") from e

    def _compile_vertex_function(self, source: str) -> object:
        """Compile a vertex function from MSL source.

        Args:
            source: MSL vertex function source code.

        Returns:
            Compiled vertex function object.
        """
        # Placeholder - in real implementation would compile MSL
        return None

    def _compile_fragment_function(self, source: str) -> object:
        """Compile a fragment function from MSL source.

        Args:
            source: MSL fragment function source code.

        Returns:
            Compiled fragment function object.
        """
        # Placeholder - in real implementation would compile MSL
        return None

    def _create_vertex_buffer(self, vertices: list[float]) -> object:
        """Create a vertex buffer from vertex data.

        Args:
            vertices: List of vertex data.

        Returns:
            Metal vertex buffer object.
        """
        # Placeholder - in real implementation would create MTLBuffer
        return None

    def _create_index_buffer(self, indices: list[int]) -> object:
        """Create an index buffer from index data.

        Args:
            indices: List of index data.

        Returns:
            Metal index buffer object.
        """
        # Placeholder - in real implementation would create MTLBuffer
        return None

    def _create_render_pass_descriptor(self) -> object:
        """Create a render pass descriptor.

        Returns:
            Metal render pass descriptor object.
        """
        # Placeholder - in real implementation would create MTLRenderPassDescriptor
        return None

    def cleanup(self) -> None:
        """Clean up Metal resources."""
        if self._initialized:
            try:
                # Release Metal resources
                self._shaders.clear()
                self._vertex_buffers.clear()
                self._index_buffers.clear()
                # Release device, command queue, library, etc.
                logger.debug("Metal backend cleaned up")
            except Exception as e:
                logger.error(f"Error during Metal cleanup: {e}")
            finally:
                self._initialized = False
