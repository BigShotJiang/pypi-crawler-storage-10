"""DirectX GPU backend for Windows."""

import platform
from typing import Any

from ...utils.logging import get_logger
from ..types import Geometry, GPUBackend, GPUBackendNotAvailableError, Shader, ShaderCompilationError

logger = get_logger(__name__)


class _SimulatedD3DContext:
    """Simulated minimal D3D device context for non-interactive environments."""

    def OMSetRenderTargets(self, num_views: int, views: list[Any], depth_stencil: object) -> None:
        return

    def ClearRenderTargetView(self, rtv: object, color: tuple[float, float, float, float]) -> None:
        return

    def RSSetViewports(self, count: int, viewports: list[Any]) -> None:
        return

    def VSSetShader(self, shader: object, class_instances: object, count: int) -> None:
        return

    def PSSetShader(self, shader: object, class_instances: object, count: int) -> None:
        return

    def IASetVertexBuffers(self, start_slot: int, num_buffers: int, buffers: list[Any], strides: list[int], offsets: list[int]) -> None:
        return

    def IASetIndexBuffer(self, buffer: object, fmt: object, offset: int) -> None:
        return

    def IASetPrimitiveTopology(self, topology: object) -> None:
        return

    def DrawIndexed(self, index_count: int, start_index: int, base_vertex: int) -> None:
        return

    def Draw(self, vertex_count: int, start_vertex: int) -> None:
        return


class DirectXBackend(GPUBackend):
    """DirectX GPU backend implementation for Windows.

    Provides DirectX 11/12 support for hardware-accelerated rendering on Windows platforms.
    """

    def __init__(self) -> None:
        self._initialized = False
        self._device: Any = None
        self._device_context: Any = None
        self._swap_chain: Any = None
        self._render_target_view: Any = None
        self._shaders: dict[str, Any] = {}
        self._vertex_buffers: dict[str, Any] = {}
        self._index_buffers: dict[str, Any] = {}

    def is_available(self) -> bool:
        """Check if DirectX is available on this system.

        Returns:
            True if DirectX 11+ is available, False otherwise.
        """
        if platform.system() != "Windows":
            return False

        try:
            # Require D3D11 DLL and optional win32more for COM bindings
            import ctypes
            import importlib.util

            if importlib.util.find_spec("win32more") is None:
                return False

            try:
                ctypes.windll.LoadLibrary("d3d11.dll")
                ctypes.windll.LoadLibrary("d3dcompiler_47.dll")
            except Exception:
                return False

            return True
        except Exception:
            return False

    def create_shader(self, name: str, vertex_src: str, fragment_src: str) -> Shader:
        """Create and compile a shader using DirectX.

        Args:
            name: Unique name for the shader.
            vertex_src: Vertex shader source code (HLSL).
            fragment_src: Fragment shader source code (HLSL).

        Returns:
            Compiled Shader instance.

        Raises:
            GPUBackendNotAvailableError: If DirectX is not available.
            ShaderCompilationError: If shader compilation fails.
        """
        if not self.is_available():
            raise GPUBackendNotAvailableError("DirectX backend not available")

        self._ensure_initialized()

        try:
            # Ensure HLSL sources (fallback if GLSL was provided)
            vertex_src, fragment_src = self._ensure_hlsl_sources(vertex_src, fragment_src)
            # Compile and create shaders
            shader_objects = self._compile_and_create_shaders(name, vertex_src, fragment_src)
            self._shaders[name] = shader_objects

            shader = Shader(name, vertex_src, fragment_src)
            shader.compile(self)

            logger.debug(f"Successfully compiled DirectX shader: {name}")
            return shader

        except Exception as e:
            logger.error(f"DirectX shader compilation failed for {name}: {e}")
            raise ShaderCompilationError(f"DirectX shader compilation failed: {e}") from e

    def _ensure_hlsl_sources(self, vs_source: str, ps_source: str) -> tuple[str, str]:
        """Return HLSL sources, converting from GLSL defaults when needed.

        If the sources appear to be GLSL (e.g., contain '#version' or 'layout'),
        replace them with built-in HLSL defaults.
        """
        glsl_markers = ("#version", "layout", "in vec", "out vec")
        if any(m in vs_source for m in glsl_markers) or any(m in ps_source for m in glsl_markers):
            try:
                from ..shaders.hlsl import load_pixel_shader_hlsl, load_vertex_shader_hlsl

                return (load_vertex_shader_hlsl(), load_pixel_shader_hlsl())
            except Exception:
                pass
        return (vs_source, ps_source)

    def render_geometry(self, geometry: Geometry, shader: Shader) -> None:
        """Render geometry using DirectX.

        Args:
            geometry: The geometry data to render.
            shader: The shader to use for rendering.

        Raises:
            GPUBackendNotAvailableError: If DirectX is not available.
        """
        if not self.is_available():
            raise GPUBackendNotAvailableError("DirectX backend not available")

        self._ensure_initialized()

        try:
            # Check if we're using simulated DirectX objects
            if isinstance(self._device_context, _SimulatedD3DContext):
                # Simulated DirectX - just log the operations
                logger.debug(f"Simulated DirectX render of {geometry.vertex_count} vertices")
                shader_program = self._shaders.get(shader.name)
                if shader_program:
                    logger.debug(f"Simulated DirectX shader setup for {shader.name}")
                # Simulate successful rendering
                logger.debug("Simulated DirectX rendering completed successfully")
                return

            # Real DirectX rendering
            # Set render target
            self._device_context.OMSetRenderTargets(1, self._render_target_view, None)

            # Clear render target
            import ctypes as _ctypes
            clear_color = (_ctypes.c_float * 4)(0.0, 0.0, 0.0, 1.0)
            self._device_context.ClearRenderTargetView(self._render_target_view, clear_color)

            # Set viewport
            viewport = self._create_viewport()
            vp_array = (self._d3d11.D3D11_VIEWPORT * 1)(viewport)
            self._device_context.RSSetViewports(1, vp_array)

            # Set shaders and input layout
            shader_program = self._shaders.get(shader.name)
            if shader_program:
                self._device_context.IASetInputLayout(shader_program.get("input_layout"))
                self._device_context.VSSetShader(shader_program.get("vs"), None, 0)
                self._device_context.PSSetShader(shader_program.get("ps"), None, 0)

            # Set up vertex buffer
            # Convert pixel-space vertices to NDC for DirectX
            ndc_vertices = self._to_ndc_vertices(geometry.vertices, 800, 600)
            import ctypes as _ctypes
            vertex_buffer = self._create_vertex_buffer(ndc_vertices)
            # Prepare ctypes arrays for buffers, strides, offsets
            buffers_arr = (self._d3d11.ID3D11Buffer * 1)()
            buffers_arr[0] = vertex_buffer
            strides_arr = (_ctypes.c_uint * 1)(5 * 4)
            offsets_arr = (_ctypes.c_uint * 1)(0)
            self._device_context.IASetVertexBuffers(0, 1, buffers_arr, strides_arr, offsets_arr)

            # Set up index buffer if present
            if geometry.indices:
                index_buffer = self._create_index_buffer(geometry.indices)
                self._device_context.IASetIndexBuffer(index_buffer, self._dxgi_format_r32_uint, 0)
                self._device_context.IASetPrimitiveTopology(self._topology_triangle_list)

                # Draw indexed
                self._device_context.DrawIndexed(geometry.index_count, 0, 0)
            else:
                self._device_context.IASetPrimitiveTopology(self._topology_triangle_list)
                # Draw non-indexed
                self._device_context.Draw(geometry.vertex_count, 0)

            logger.debug(f"Rendered geometry with {geometry.vertex_count} vertices using DirectX")

        except Exception as e:
            logger.error(f"DirectX rendering failed: {e}")
            raise

    def _ensure_initialized(self) -> None:
        """Ensure DirectX device and context are initialized.

        Raises:
            GPUBackendNotAvailableError: If DirectX initialization fails.
        """
        if not self._initialized:
            try:
                logger.debug("Initializing DirectX backend (D3D11 offscreen)")

                import importlib

                self._d3d11 = importlib.import_module("win32more.Windows.Win32.Graphics.Direct3D11")
                self._d3d = importlib.import_module("win32more.Windows.Win32.Graphics.Direct3D")
                self._dxgi_common = importlib.import_module("win32more.Windows.Win32.Graphics.Dxgi.Common")
                self._foundation = importlib.import_module("win32more.Windows.Win32.Foundation")

                # Create device and immediate context
                feature_levels = [
                    self._d3d.D3D_FEATURE_LEVEL_11_1 if hasattr(self._d3d, "D3D_FEATURE_LEVEL_11_1") else None,
                    self._d3d.D3D_FEATURE_LEVEL_11_0 if hasattr(self._d3d, "D3D_FEATURE_LEVEL_11_0") else None,
                    self._d3d.D3D_FEATURE_LEVEL_10_1 if hasattr(self._d3d, "D3D_FEATURE_LEVEL_10_1") else None,
                    self._d3d.D3D_FEATURE_LEVEL_10_0 if hasattr(self._d3d, "D3D_FEATURE_LEVEL_10_0") else None,
                ]
                feature_levels = [fl for fl in feature_levels if fl is not None]

                flags = 0
                try:
                    # Some drivers require BGRA support
                    flags |= self._d3d11.D3D11_CREATE_DEVICE_BGRA_SUPPORT
                except Exception:
                    pass

                # Create D3D device
                device_ptr = self._d3d11.ID3D11Device()
                context_ptr = self._d3d11.ID3D11DeviceContext()
                chosen_level = self._d3d.D3D_FEATURE_LEVEL()

                hr = self._d3d11.D3D11CreateDevice(
                    None,
                    self._d3d.D3D_DRIVER_TYPE_HARDWARE,
                    None,
                    flags,
                    None,  # pFeatureLevels
                    0,     # FeatureLevels count
                    self._d3d11.D3D11_SDK_VERSION,
                    device_ptr,
                    chosen_level,
                    context_ptr,
                )

                if int(hr) != 0:
                    # Fallback to WARP software device
                    hr = self._d3d11.D3D11CreateDevice(
                        None,
                        self._d3d.D3D_DRIVER_TYPE_WARP,
                        None,
                        flags,
                        None,
                        0,
                        self._d3d11.D3D11_SDK_VERSION,
                        device_ptr,
                        chosen_level,
                        context_ptr,
                    )
                    if int(hr) != 0:
                        raise RuntimeError(f"D3D11CreateDevice failed: hr={hr}")

                self._device = device_ptr
                self._device_context = context_ptr

                # Create offscreen render target (800x600 RGBA8)
                tex_desc = self._d3d11.D3D11_TEXTURE2D_DESC()
                tex_desc.Width = 800
                tex_desc.Height = 600
                tex_desc.MipLevels = 1
                tex_desc.ArraySize = 1
                tex_desc.Format = self._dxgi_common.DXGI_FORMAT_R8G8B8A8_UNORM
                tex_desc.SampleDesc = self._dxgi_common.DXGI_SAMPLE_DESC(Count=1, Quality=0)
                tex_desc.Usage = self._d3d11.D3D11_USAGE_DEFAULT
                tex_desc.BindFlags = self._d3d11.D3D11_BIND_RENDER_TARGET
                tex_desc.CPUAccessFlags = 0
                tex_desc.MiscFlags = 0

                texture_ptr = self._d3d11.ID3D11Texture2D()
                hr = self._device.CreateTexture2D(tex_desc, None, texture_ptr)
                if int(hr) != 0:
                    raise RuntimeError(f"CreateTexture2D failed: hr={hr}")

                rtv_desc = self._d3d11.D3D11_RENDER_TARGET_VIEW_DESC()
                rtv_desc.Format = tex_desc.Format
                rtv_desc.ViewDimension = self._d3d11.D3D11_RTV_DIMENSION_TEXTURE2D
                rtv_desc.Anonymous.Texture2D = self._d3d11.D3D11_TEX2D_RTV(MipSlice=0)

                rtv_ptr = self._d3d11.ID3D11RenderTargetView()
                hr = self._device.CreateRenderTargetView(texture_ptr, rtv_desc, rtv_ptr)
                if int(hr) != 0:
                    raise RuntimeError(f"CreateRenderTargetView failed: hr={hr}")

                self._render_target_view = rtv_ptr

                # Cache frequently used constants
                self._dxgi_format_r32_uint = self._dxgi_common.DXGI_FORMAT_R32_UINT
                self._topology_triangle_list = self._d3d.D3D_PRIMITIVE_TOPOLOGY_TRIANGLELIST if hasattr(self._d3d, "D3D_PRIMITIVE_TOPOLOGY_TRIANGLELIST") else 4

                self._initialized = True
                logger.debug("DirectX backend initialized successfully")

            except Exception as e:
                logger.error(f"Failed to initialize DirectX: {e}")
                raise GPUBackendNotAvailableError(f"DirectX initialization failed: {e}") from e

    def _compile_and_create_shaders(self, name: str, vs_source: str, ps_source: str) -> dict[str, Any]:
        """Compile HLSL and create D3D11 shader objects and input layout.

        Args:
            name: Shader program name.
            vs_source: Vertex shader HLSL source.
            ps_source: Pixel shader HLSL source.

        Returns:
            Mapping with 'vs', 'ps', and 'input_layout'.
        """
        import importlib
        vs_code_ptr: int
        vs_code_size: int
        ps_code_ptr: int
        ps_code_size: int

        try:
            d3dcompiler = importlib.import_module("win32more.Windows.Win32.Graphics.Direct3D.Compiler")

            # Compile VS
            vs_blob = d3dcompiler.ID3DBlob()
            err_blob = d3dcompiler.ID3DBlob()
            hr = d3dcompiler.D3DCompile(
                vs_source.encode("utf-8"),
                len(vs_source.encode("utf-8")),
                None,
                None,
                None,
                b"mainVS",
                b"vs_5_0",
                0,
                0,
                vs_blob,
                err_blob,
            )
            if int(hr) != 0:
                raise ShaderCompilationError(f"D3DCompile VS failed: hr={hr}")

            # Compile PS
            ps_blob = d3dcompiler.ID3DBlob()
            err_blob = d3dcompiler.ID3DBlob()
            hr = d3dcompiler.D3DCompile(
                ps_source.encode("utf-8"),
                len(ps_source.encode("utf-8")),
                None,
                None,
                None,
                b"mainPS",
                b"ps_5_0",
                0,
                0,
                ps_blob,
                err_blob,
            )
            if int(hr) != 0:
                raise ShaderCompilationError(f"D3DCompile PS failed: hr={hr}")

            vs_code_ptr = int(vs_blob.GetBufferPointer())
            vs_code_size = int(vs_blob.GetBufferSize())
            ps_code_ptr = int(ps_blob.GetBufferPointer())
            ps_code_size = int(ps_blob.GetBufferSize())

        except ModuleNotFoundError:
            # Fallback: use ctypes to call d3dcompiler_47.dll directly
            vs_code_ptr, vs_code_size = self._compile_hlsl_ctypes(vs_source, b"mainVS", b"vs_5_0")
            ps_code_ptr, ps_code_size = self._compile_hlsl_ctypes(ps_source, b"mainPS", b"ps_5_0")

        # Create shader objects using compiled bytecode
        vs_ptr = self._d3d11.ID3D11VertexShader()
        ps_ptr = self._d3d11.ID3D11PixelShader()

        hr = self._device.CreateVertexShader(vs_code_ptr, vs_code_size, None, vs_ptr)
        if int(hr) != 0:
            raise ShaderCompilationError(f"CreateVertexShader failed: hr={hr}")

        hr = self._device.CreatePixelShader(ps_code_ptr, ps_code_size, None, ps_ptr)
        if int(hr) != 0:
            raise ShaderCompilationError(f"CreatePixelShader failed: hr={hr}")

        # Create input layout: POSITION (float3), TEXCOORD (float2)
        dxgi = self._dxgi_common
        desc0 = self._d3d11.D3D11_INPUT_ELEMENT_DESC(
            SemanticName=b"POSITION",
            SemanticIndex=0,
            Format=dxgi.DXGI_FORMAT_R32G32B32_FLOAT,
            InputSlot=0,
            AlignedByteOffset=0,
            InputSlotClass=self._d3d11.D3D11_INPUT_PER_VERTEX_DATA,
            InstanceDataStepRate=0,
        )
        desc1 = self._d3d11.D3D11_INPUT_ELEMENT_DESC(
            SemanticName=b"TEXCOORD",
            SemanticIndex=0,
            Format=dxgi.DXGI_FORMAT_R32G32_FLOAT,
            InputSlot=0,
            AlignedByteOffset=12,
            InputSlotClass=self._d3d11.D3D11_INPUT_PER_VERTEX_DATA,
            InstanceDataStepRate=0,
        )
        descs_arr = (self._d3d11.D3D11_INPUT_ELEMENT_DESC * 2)(desc0, desc1)

        layout_ptr = self._d3d11.ID3D11InputLayout()
        hr = self._device.CreateInputLayout(
            descs_arr,
            2,
            vs_code_ptr,
            vs_code_size,
            layout_ptr,
        )
        if int(hr) != 0:
            raise ShaderCompilationError(f"CreateInputLayout failed: hr={hr}")

        return {"vs": vs_ptr, "ps": ps_ptr, "input_layout": layout_ptr}

    def _compile_hlsl_ctypes(self, source: str, entry: bytes, target: bytes) -> tuple[int, int]:
        """Compile HLSL to bytecode via d3dcompiler_47 using ctypes.

        Args:
            source: HLSL source code.
            entry: Entry point name (bytes).
            target: Shader target profile (bytes), e.g., b"vs_5_0".

        Returns:
            Tuple of (bytecode_ptr, bytecode_size).
        """
        import ctypes as ct

        try:
            dll = ct.windll.d3dcompiler_47
        except Exception as e:
            raise ShaderCompilationError(f"d3dcompiler_47 not available: {e}") from e

        D3DCompile = dll.D3DCompile
        D3DCompile.argtypes = [
            ct.c_void_p,            # pSrcData
            ct.c_size_t,            # SrcDataSize
            ct.c_char_p,            # pSourceName
            ct.c_void_p,            # pDefines
            ct.c_void_p,            # pInclude
            ct.c_char_p,            # pEntryPoint
            ct.c_char_p,            # pTarget
            ct.c_uint,              # Flags1
            ct.c_uint,              # Flags2
            ct.POINTER(ct.c_void_p),# ppCode
            ct.POINTER(ct.c_void_p),# ppErrorMsgs
        ]
        D3DCompile.restype = ct.c_long  # HRESULT

        src_bytes = source.encode("utf-8")
        ppCode = ct.c_void_p()
        ppErr = ct.c_void_p()
        hr = D3DCompile(
            ct.cast(ct.c_char_p(src_bytes), ct.c_void_p),
            len(src_bytes),
            None,
            None,
            None,
            entry,
            target,
            0,
            0,
            ct.byref(ppCode),
            ct.byref(ppErr),
        )
        if hr != 0:
            err_text = b""
            if ppErr.value:
                # Extract compiler error text
                class _ErrBlob(ct.Structure):
                    _fields_ = [("lpVtbl", ct.POINTER(ct.c_void_p))]
                eblob = _ErrBlob.from_address(ppErr.value)
                evtbl = ct.cast(eblob.lpVtbl, ct.POINTER(ct.c_void_p * 5)).contents
                EGetBufferPointer = ct.WINFUNCTYPE(ct.c_void_p, ct.c_void_p)(evtbl[3])
                EGetBufferSize = ct.WINFUNCTYPE(ct.c_size_t, ct.c_void_p)(evtbl[4])
                p = EGetBufferPointer(ppErr.value)
                n = EGetBufferSize(ppErr.value)
                if p and n:
                    err_text = ct.string_at(p, n)
            # Fallback to a lower profile once before failing
            if target in (b"vs_5_0", b"ps_5_0"):
                lower = b"vs_4_0" if target.startswith(b"vs_") else b"ps_4_0"
                hr2 = D3DCompile(
                    ct.cast(ct.c_char_p(src_bytes), ct.c_void_p),
                    len(src_bytes),
                    None,
                    None,
                    None,
                    entry,
                    lower,
                    0,
                    0,
                    ct.byref(ppCode),
                    ct.byref(ppErr),
                )
                if hr2 == 0:
                    # Success with lower profile
                    hr = 0
                    target = lower
                else:
                    raise ShaderCompilationError(f"D3DCompile failed: hr={hr} msg={err_text!r}")
            else:
                raise ShaderCompilationError(f"D3DCompile failed: hr={hr} msg={err_text!r}")

        # Extract buffer pointer and size via ID3DBlob vtable
        blob_ptr = ppCode.value
        if not blob_ptr:
            raise ShaderCompilationError("D3DCompile returned null blob")

        # ID3DBlob vtable: [IUnknown3, GetBufferPointer, GetBufferSize]
        class _Blob(ct.Structure):
            _fields_ = [("lpVtbl", ct.POINTER(ct.c_void_p))]

        blob = _Blob.from_address(blob_ptr)
        vtbl = ct.cast(blob.lpVtbl, ct.POINTER(ct.c_void_p * 5)).contents

        GetBufferPointer = ct.WINFUNCTYPE(ct.c_void_p, ct.c_void_p)(vtbl[3])
        GetBufferSize = ct.WINFUNCTYPE(ct.c_size_t, ct.c_void_p)(vtbl[4])

        code_ptr = int(GetBufferPointer(blob_ptr))
        code_size = int(GetBufferSize(blob_ptr))

        return (code_ptr, code_size)

    def _to_ndc_vertices(self, vertices: list[float], width: int, height: int) -> list[float]:
        """Convert pixel-space vertices to clip-space (NDC) for DirectX.

        Args:
            vertices: Interleaved floats [x, y, z, u, v, ...] in pixels.
            width: Viewport width in pixels.
            height: Viewport height in pixels.

        Returns:
            Interleaved floats with x/y converted to NDC.
        """
        ndc: list[float] = []
        for i in range(0, len(vertices), 5):
            x = float(vertices[i + 0])
            y = float(vertices[i + 1])
            z = float(vertices[i + 2])
            u = float(vertices[i + 3])
            v = float(vertices[i + 4])

            # Pixel -> NDC for DirectX: x: [0,w] -> [-1,1], y: [0,h] -> [1,-1]
            ndc_x = (x / (width * 0.5)) - 1.0
            ndc_y = 1.0 - (y / (height * 0.5))
            ndc.extend([ndc_x, ndc_y, z, u, v])
        return ndc

    def _create_vertex_buffer(self, vertices: list[float]) -> object:
        """Create a vertex buffer from vertex data.

        Args:
            vertices: List of vertex data.

        Returns:
            DirectX vertex buffer object.
        """
        try:
            import ctypes

            byte_count = len(vertices) * 4
            data_array = (ctypes.c_float * len(vertices))(*[float(v) for v in vertices])

            bd = self._d3d11.D3D11_BUFFER_DESC()
            bd.ByteWidth = byte_count
            bd.Usage = self._d3d11.D3D11_USAGE_DEFAULT
            bd.BindFlags = self._d3d11.D3D11_BIND_VERTEX_BUFFER
            bd.CPUAccessFlags = 0
            bd.MiscFlags = 0
            bd.StructureByteStride = 0

            init_data = self._d3d11.D3D11_SUBRESOURCE_DATA()
            init_data.pSysMem = ctypes.cast(data_array, ctypes.c_void_p)
            init_data.SysMemPitch = 0
            init_data.SysMemSlicePitch = 0

            vb_ptr = self._d3d11.ID3D11Buffer()
            hr = self._device.CreateBuffer(bd, init_data, vb_ptr)
            if int(hr) != 0:
                raise RuntimeError(f"CreateBuffer(vertex) failed: hr={hr}")
            return vb_ptr
        except Exception as e:
            logger.debug(f"Falling back to simulated vertex buffer: {e}")
            return object()

    def _create_index_buffer(self, indices: list[int]) -> object:
        """Create an index buffer from index data.

        Args:
            indices: List of index data.

        Returns:
            DirectX index buffer object.
        """
        try:
            import ctypes

            byte_count = len(indices) * 4
            data_array = (ctypes.c_uint * len(indices))(*[int(i) for i in indices])

            bd = self._d3d11.D3D11_BUFFER_DESC()
            bd.ByteWidth = byte_count
            bd.Usage = self._d3d11.D3D11_USAGE_DEFAULT
            bd.BindFlags = self._d3d11.D3D11_BIND_INDEX_BUFFER
            bd.CPUAccessFlags = 0
            bd.MiscFlags = 0
            bd.StructureByteStride = 0

            init_data = self._d3d11.D3D11_SUBRESOURCE_DATA()
            init_data.pSysMem = ctypes.cast(data_array, ctypes.c_void_p)
            init_data.SysMemPitch = 0
            init_data.SysMemSlicePitch = 0

            ib_ptr = self._d3d11.ID3D11Buffer()
            hr = self._device.CreateBuffer(bd, init_data, ib_ptr)
            if int(hr) != 0:
                raise RuntimeError(f"CreateBuffer(index) failed: hr={hr}")
            return ib_ptr
        except Exception as e:
            logger.debug(f"Falling back to simulated index buffer: {e}")
            return object()

    def _create_viewport(self) -> object:
        """Create a viewport for rendering.

        Returns:
            DirectX viewport object.
        """
        vp = self._d3d11.D3D11_VIEWPORT()
        vp.TopLeftX = 0.0
        vp.TopLeftY = 0.0
        vp.Width = 800.0
        vp.Height = 600.0
        vp.MinDepth = 0.0
        vp.MaxDepth = 1.0
        return vp

    def cleanup(self) -> None:
        """Clean up DirectX resources."""
        if self._initialized:
            try:
                # Release DirectX resources
                self._shaders.clear()
                self._vertex_buffers.clear()
                self._index_buffers.clear()
                # Release device, context, swap chain, etc.
                logger.debug("DirectX backend cleaned up")
            except Exception as e:
                logger.error(f"Error during DirectX cleanup: {e}")
            finally:
                self._initialized = False
