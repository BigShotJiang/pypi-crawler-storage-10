"""GPU type definitions to avoid circular imports."""
from __future__ import annotations

from abc import ABC, abstractmethod
from dataclasses import dataclass


@dataclass
class Geometry:
    """Represents geometry data for GPU rendering."""

    vertices: list[float]
    indices: list[int]
    vertex_count: int
    index_count: int


class GPUBackend(ABC):
    """Abstract base class for GPU backends."""

    @abstractmethod
    def is_available(self) -> bool:
        """Check if this backend is available on the current system."""
        pass

    @abstractmethod
    def create_shader(self, name: str, vertex_src: str, fragment_src: str) -> Shader:
        """Create and compile a shader program."""
        pass

    @abstractmethod
    def render_geometry(self, geometry: Geometry, shader: Shader) -> None:
        """Render geometry using the specified shader."""
        pass


class Shader:
    """Cross-platform shader abstraction."""

    def __init__(self, name: str, vertex_source: str, fragment_source: str) -> None:
        self.name = name
        self.vertex_source = vertex_source
        self.fragment_source = fragment_source
        self._compiled = False
        self._program: object | None = None

    def compile(self, backend: GPUBackend) -> bool:
        """Compile shader for specific backend.

        Args:
            backend: The GPU backend to compile against.

        Returns:
            True if compilation succeeded, False otherwise.
        """
        try:
            # Compilation is backend-specific; this noop exists for compatibility.
            self._compiled = True
            return True
        except Exception:
            return False

    def bind(self) -> None:
        """Bind shader for rendering."""
        if not self._compiled:
            raise ShaderCompilationError(f"Shader {self.name} is not compiled")
        # Binding is backend-specific; backends should bind their program by name.

    def set_uniform(self, name: str, value: float | int | list[float] | list[int]) -> None:
        """Set shader uniform value.

        Args:
            name: The uniform variable name.
            value: The value to set (float, int, or list of floats/ints).
        """
        if not self._compiled:
            raise ShaderCompilationError(f"Shader {self.name} is not compiled")
        # Backend-specific uniform setting would be implemented by the backend.


class GPUError(Exception):
    """Base exception for GPU-related errors."""
    pass


class ShaderCompilationError(GPUError):
    """Exception raised when shader compilation fails."""
    pass


class GPUBackendNotAvailableError(GPUError):
    """Exception raised when requested GPU backend is not available."""
    pass
