"""GPU uniform buffer management."""

import threading
from collections.abc import Sequence

from ..core import GPUBuffer, GPUManager

UniformValue = float | int | Sequence[float]


class UniformBuffer(GPUBuffer):
    """GPU uniform buffer for storing shader uniform data."""

    def __init__(self, data: dict[str, UniformValue], usage: str = "dynamic") -> None:
        """Initialize uniform buffer with data.

        Args:
            data: Dictionary mapping uniform names to values
            usage: Buffer usage pattern ('static', 'dynamic', 'stream')
        """
        # Pack data into structured format for GPU
        structured_data = self._pack_uniform_data(data)
        super().__init__(structured_data, usage)
        self._uniform_layout: dict[str, UniformValue] = data.copy()
        self._gpu_manager = GPUManager()
        self._buffer_id: int | None = None
        self._lock = threading.RLock()
        self._bound_slot: int | None = None

        # Initialize GPU buffer if available
        self._create_gpu_buffer()

    def _pack_uniform_data(self, data: dict[str, UniformValue]) -> list[float]:
        """Pack uniform data into a format suitable for GPU buffers.

        Handles different data types with proper alignment and padding for std140 layout.

        Args:
            data: Dictionary of uniform data

        Returns:
            Packed float data for GPU buffer
        """
        packed: list[float] = []

        for key, value in data.items():
            if isinstance(value, (int, float)):
                # Scalar values - pad to vec4 alignment
                packed.extend([float(value), 0.0, 0.0, 0.0])
            else:
                if len(value) == 2:
                    # vec2 - pad to vec4
                    packed.extend([float(value[0]), float(value[1]), 0.0, 0.0])
                elif len(value) == 3:
                    # vec3 - pad to vec4
                    packed.extend([float(value[0]), float(value[1]), float(value[2]), 0.0])
                elif len(value) == 4:
                    # vec4 - no padding needed
                    packed.extend(float(v) for v in value)
                elif len(value) == 9:
                    # mat3 - treat as 3 vec4 rows
                    packed.extend(
                        [
                            float(value[0]),
                            float(value[1]),
                            float(value[2]),
                            0.0,  # row 0
                            float(value[3]),
                            float(value[4]),
                            float(value[5]),
                            0.0,  # row 1
                            float(value[6]),
                            float(value[7]),
                            float(value[8]),
                            0.0,  # row 2
                        ]
                    )
                elif len(value) == 16:
                    # mat4 - treat as 4 vec4 rows
                    packed.extend(float(v) for v in value)
                else:
                    raise ValueError(f"Unsupported uniform array length for {key}: {len(value)}")

        return packed

    def _create_gpu_buffer(self) -> None:
        """Create the GPU buffer if GPU acceleration is available."""
        with self._lock:
            if not self._gpu_manager.is_available():
                return

            try:
                # Create uniform buffer object if OpenGL is available
                import importlib
                gl = importlib.import_module("OpenGL.GL")
                arrays = importlib.import_module("OpenGL.arrays")

                # Generate buffer
                self._buffer_id = gl.glGenBuffers(1)

                # Bind and upload data
                gl.glBindBuffer(gl.GL_UNIFORM_BUFFER, self._buffer_id)

                # Convert data to appropriate format
                if self._usage == "static":
                    usage_flag = gl.GL_STATIC_DRAW
                elif self._usage == "stream":
                    usage_flag = gl.GL_STREAM_DRAW
                else:  # dynamic
                    usage_flag = gl.GL_DYNAMIC_DRAW

                buffer_data = arrays.GLfloatArray(self._data)
                gl.glBufferData(gl.GL_UNIFORM_BUFFER, buffer_data, usage_flag)

                gl.glBindBuffer(gl.GL_UNIFORM_BUFFER, 0)

            except Exception as e:
                # Log error but don't fail - CPU fallback will be used
                from ..core import logger

                logger.warning(f"Failed to create GPU uniform buffer: {e}")
                self._buffer_id = None

    def update_uniform(self, name: str, value: UniformValue) -> None:
        """Update a specific uniform value.

        Args:
            name: Name of the uniform to update
            value: New value for the uniform

        Raises:
            ValueError: If uniform name not found or invalid value type
        """
        with self._lock:
            if name not in self._uniform_layout:
                raise ValueError(f"Uniform '{name}' not found in buffer layout")

            # Update layout
            self._uniform_layout[name] = value

            # Re-pack all data
            self._data = self._pack_uniform_data(self._uniform_layout)

            # Update GPU buffer if available
            if self._buffer_id is not None:
                self._update_gpu_buffer()

    def _update_gpu_buffer(self) -> None:
        """Update the GPU buffer with current data."""
        if self._buffer_id is None:
            return

        try:
            import importlib
            gl = importlib.import_module("OpenGL.GL")
            arrays = importlib.import_module("OpenGL.arrays")

            gl.glBindBuffer(gl.GL_UNIFORM_BUFFER, self._buffer_id)
            buffer_data = arrays.GLfloatArray(self._data)
            gl.glBufferSubData(gl.GL_UNIFORM_BUFFER, 0, buffer_data)
            gl.glBindBuffer(gl.GL_UNIFORM_BUFFER, 0)

        except Exception as e:
            from ..core import logger

            logger.warning(f"Failed to update GPU uniform buffer: {e}")

    def bind(self, slot: int = 0) -> None:
        """Bind the uniform buffer to a binding point.

        Args:
            slot: Binding point index (0-15 typically)
        """
        with self._lock:
            if self._buffer_id is not None:
                try:
                    import importlib
                    gl = importlib.import_module("OpenGL.GL")

                    gl.glBindBufferBase(gl.GL_UNIFORM_BUFFER, slot, self._buffer_id)
                    self._bound_slot = slot

                except Exception as e:
                    from ..core import logger

                    logger.warning(f"Failed to bind uniform buffer: {e}")
            else:
                # CPU fallback - no-op
                self._bound_slot = slot

    def unbind(self) -> None:
        """Unbind the uniform buffer."""
        with self._lock:
            if self._buffer_id is not None and self._bound_slot is not None:
                try:
                    import importlib
                    gl = importlib.import_module("OpenGL.GL")

                    gl.glBindBufferBase(gl.GL_UNIFORM_BUFFER, self._bound_slot, 0)
                    self._bound_slot = None

                except Exception as e:
                    from ..core import logger

                    logger.warning(f"Failed to unbind uniform buffer: {e}")
            else:
                self._bound_slot = None

    def cleanup(self) -> None:
        """Clean up GPU resources."""
        with self._lock:
            if self._buffer_id is not None:
                try:
                    import importlib
                    gl = importlib.import_module("OpenGL.GL")

                    # Unbind if currently bound
                    if self._bound_slot is not None:
                        gl.glBindBufferBase(gl.GL_UNIFORM_BUFFER, self._bound_slot, 0)
                        self._bound_slot = None

                    # Delete buffer
                    gl.glDeleteBuffers(1, [self._buffer_id])
                    self._buffer_id = None

                except Exception as e:
                    from ..core import logger

                    logger.warning(f"Error cleaning up uniform buffer: {e}")

    def __del__(self) -> None:
        """Destructor - ensure cleanup."""
        self.cleanup()
