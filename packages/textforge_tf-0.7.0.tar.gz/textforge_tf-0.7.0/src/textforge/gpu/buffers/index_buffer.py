"""GPU index buffer management."""

import threading

from ..core import GPUBuffer, GPUManager, logger


class IndexBuffer(GPUBuffer):
    """GPU index buffer for storing vertex indices.

    Manages index data storage and GPU buffer operations with automatic
    fallback to CPU when GPU acceleration is unavailable.
    """

    def __init__(self, indices: list[int], usage: str = "static") -> None:
        """Initialize index buffer with indices.

        Args:
            indices: List of vertex indices for indexed rendering.
            usage: Buffer usage pattern ('static', 'dynamic', 'stream').
        """
        super().__init__(indices, usage)
        self._index_count = len(indices)
        self._gpu_manager = GPUManager()
        self._buffer_id: int | None = None
        self._lock = threading.RLock()

        # Initialize GPU buffer if available
        self._create_gpu_buffer()

    @property
    def index_count(self) -> int:
        """Get the number of indices in the buffer."""
        return self._index_count

    def _create_gpu_buffer(self) -> None:
        """Create the GPU buffer if GPU acceleration is available."""
        with self._lock:
            if not self._gpu_manager.is_available():
                return

            try:
                # Attempt OpenGL path if available; otherwise noop (CPU fallback)
                import importlib
                gl = importlib.import_module("OpenGL.GL")
                arrays = importlib.import_module("OpenGL.arrays")

                # Generate buffer
                self._buffer_id = gl.glGenBuffers(1)

                # Bind and upload data
                gl.glBindBuffer(gl.GL_ELEMENT_ARRAY_BUFFER, self._buffer_id)

                # Convert data to appropriate format
                if self._usage == "static":
                    usage_flag = gl.GL_STATIC_DRAW
                elif self._usage == "stream":
                    usage_flag = gl.GL_STREAM_DRAW
                else:  # dynamic
                    usage_flag = gl.GL_DYNAMIC_DRAW

                buffer_data = arrays.GLuintArray(self._data)
                gl.glBufferData(gl.GL_ELEMENT_ARRAY_BUFFER, buffer_data, usage_flag)

                gl.glBindBuffer(gl.GL_ELEMENT_ARRAY_BUFFER, 0)

                logger.debug(f"Created GPU index buffer with {self._index_count} indices")

            except Exception as e:
                logger.warning(f"Failed to create GPU index buffer: {e}")
                self._buffer_id = None

    def bind(self) -> None:
        """Bind the index buffer for rendering."""
        with self._lock:
            if self._buffer_id is not None:
                try:
                    import importlib
                    gl = importlib.import_module("OpenGL.GL")

                    gl.glBindBuffer(gl.GL_ELEMENT_ARRAY_BUFFER, self._buffer_id)
                except Exception as e:
                    logger.warning(f"Failed to bind index buffer: {e}")
            # CPU fallback - no-op

    def unbind(self) -> None:
        """Unbind the index buffer."""
        with self._lock:
            if self._buffer_id is not None:
                try:
                    import importlib
                    gl = importlib.import_module("OpenGL.GL")

                    gl.glBindBuffer(gl.GL_ELEMENT_ARRAY_BUFFER, 0)
                except Exception as e:
                    logger.warning(f"Failed to unbind index buffer: {e}")
            # CPU fallback - no-op

    def update_data(self, data: list[int] | list[float]) -> None:
        """Update buffer data.

        Args:
            data: New index data to upload to the buffer.
        """
        with self._lock:
            # Convert to list of ints for parent class
            super().update_data(list(data))
            self._index_count = len(data)

            # Update GPU buffer if available
            if self._buffer_id is not None:
                self._update_gpu_buffer()

    def _update_gpu_buffer(self) -> None:
        """Update the GPU buffer with current data."""
        if self._buffer_id is None:
            return

        try:
            import importlib
            gl = importlib.import_module("OpenGL.GL")
            arrays = importlib.import_module("OpenGL.arrays")

            gl.glBindBuffer(gl.GL_ELEMENT_ARRAY_BUFFER, self._buffer_id)
            buffer_data = arrays.GLuintArray(self._data)
            gl.glBufferSubData(gl.GL_ELEMENT_ARRAY_BUFFER, 0, buffer_data)
            gl.glBindBuffer(gl.GL_ELEMENT_ARRAY_BUFFER, 0)

        except Exception as e:
            logger.warning(f"Failed to update GPU index buffer: {e}")

    def cleanup(self) -> None:
        """Clean up GPU resources."""
        with self._lock:
            if self._buffer_id is not None:
                try:
                    import importlib
                    gl = importlib.import_module("OpenGL.GL")

                    # Unbind if currently bound
                    gl.glBindBuffer(gl.GL_ELEMENT_ARRAY_BUFFER, 0)

                    # Delete buffer
                    gl.glDeleteBuffers(1, [self._buffer_id])
                    self._buffer_id = None

                    logger.debug("Index buffer cleaned up")

                except Exception as e:
                    logger.warning(f"Error cleaning up index buffer: {e}")

    def __del__(self) -> None:
        """Destructor - ensure cleanup."""
        self.cleanup()
