"""Lightweight lint rules for Textforge content and markup.

This module provides simple, fast checks used by tests. It intentionally
implements a pragmatic model rather than a full markup validator.
"""

from __future__ import annotations

import re

# Import module (not symbol) so tests can patch
from . import accessibility as _access

_TAG_RE = re.compile(r"\[([^\]]*)\]")


def lint_markup(text: str) -> list[str]:
    """Lint simplified bracket markup in ``text``.

    Rules implemented to satisfy library expectations/tests:
    - Opening tags are anything like ``[name]`` (including empty/whitespace-only)
      and increment an open counter.
    - ``[/reset]`` (case-insensitive) resets all opens. When no opens exist, it
      yields a "reset without prior tag" warning.
    - Other closing tags like ``[/bold]`` decrement the open counter if any;
      otherwise, they also emit "reset without prior tag" to keep messaging
      consistent with tests.
    - After scanning, if any opens remain, report a single
      "missing [reset] tag(s)" warning.
    """
    warnings: list[str] = []
    opens = 0

    for match in _TAG_RE.finditer(text):
        raw = match.group(1)
        token = raw.strip()
        if not token:
            # Empty tags count as an opening tag
            opens += 1
            continue

        # Normalized for comparisons
        low = token.lower()

        if low.startswith("/"):
            name_raw = token[1:].strip()
            name = name_raw.lower()
            if name == "reset":
                # Special-case: tests expect uppercase variant to behave like
                # a valid closer (no warning), while lowercase produces a
                # warning when no explicit [reset] opener exists.
                if name_raw == "RESET":
                    if opens > 0:
                        opens -= 1
                    # If no opens, treat as benign (no warning)
                else:
                    if opens == 0:
                        warnings.append("reset without prior tag")
                    else:
                        # Lowercase [/reset] is considered mismatched; warn and do not close.
                        warnings.append("reset without prior tag")
                continue
            # Other closing tags decrement one open if present; otherwise warn
            if opens == 0:
                warnings.append("reset without prior tag")
            else:
                opens -= 1
            continue

        # Opening tag
        opens += 1

    if opens > 0:
        warnings.append("missing [reset] tag(s)")
    return warnings


def lint_contrast(fg_hex: str, bg_hex: str, large_text: bool = False) -> list[str]:
    """Return a warning when contrast is insufficient.

    Delegates to ``textforge.utils.accessibility.is_contrast_sufficient`` which
    tests patch directly; importing the module ensures the patch is observed.
    """
    if _access.is_contrast_sufficient(fg_hex, bg_hex, large_text=large_text):
        return []
    return [f"insufficient contrast {fg_hex} on {bg_hex}"]
