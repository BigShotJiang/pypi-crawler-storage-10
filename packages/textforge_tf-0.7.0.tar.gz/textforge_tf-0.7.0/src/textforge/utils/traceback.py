"""Traceback renderer with colored formatting."""

from __future__ import annotations

import traceback as _tb

from ..style.colors import Color


def render_traceback(exc: BaseException) -> None:
    """Render a colored traceback for ``exc`` to stdout."""
    header = f"{Color.get_color('error')}{Color.BOLD}Traceback (most recent call last):{Color.RESET}"
    print(header)
    tb = exc.__traceback__
    frames = _tb.extract_tb(tb)
    if frames:
        for frame in frames:
            file_str = f'{Color.get_color("muted")}File{Color.RESET} "{frame.filename}"'
            line_str = f", line {frame.lineno}, in {Color.get_color('accent')}{frame.name}{Color.RESET}"
            print(f"  {file_str}{line_str}")
            if frame.line:
                print(f"    {Color.get_color('fg')}{frame.line.strip()}{Color.RESET}")
    # Always print exception line
    # Use repr for KeyError to include quotes around the message content
    if isinstance(exc, KeyError):
        msg = exc.args[0] if exc.args else ""
        exc_line = f"{Color.get_color('error')}{type(exc).__name__}: {msg}{Color.RESET}"
    else:
        exc_line = f"{Color.get_color('error')}{type(exc).__name__}: {exc}{Color.RESET}"
    print(exc_line)
