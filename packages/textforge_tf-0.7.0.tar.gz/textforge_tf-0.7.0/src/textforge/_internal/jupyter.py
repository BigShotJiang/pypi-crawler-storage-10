"""Jupyter integration helpers for Textforge.

Display ANSI strings as HTML or SVG inside notebooks using IPython display.
"""

from __future__ import annotations

import importlib
from collections.abc import Callable
from typing import TYPE_CHECKING

from ..core.text_engine import strip_ansi
from ..export import ansi_to_html, ansi_to_svg

if TYPE_CHECKING:
    from types import ModuleType


def _load_display_module() -> ModuleType | None:
    """Import the optional IPython display module if available."""
    try:
        return importlib.import_module("IPython.display")
    except Exception:
        return None


def _resolve_callable(module: ModuleType, attribute: str) -> Callable[..., object] | None:
    """Return a callable attribute from the module if it exists."""
    value = getattr(module, attribute, None)
    if not isinstance(value, Callable):
        return None

    def wrapper(*args: object, **kwargs: object) -> object:
        value(*args, **kwargs)
        return None

    return wrapper


def display_ansi_html(text: str) -> None:
    module = _load_display_module()
    if module is None:
        print(strip_ansi(text))
        return
    display_fn = _resolve_callable(module, "display")
    html_factory = _resolve_callable(module, "HTML")
    if display_fn is None or html_factory is None:
        print(strip_ansi(text))
        return
    display_fn(html_factory(ansi_to_html(text)))


def display_ansi_svg(text: str) -> None:
    module = _load_display_module()
    if module is None:
        print(strip_ansi(text))
        return
    display_fn = _resolve_callable(module, "display")
    svg_factory = _resolve_callable(module, "SVG")
    if display_fn is None or svg_factory is None:
        print(strip_ansi(text))
        return
    display_fn(svg_factory(ansi_to_svg(text)))
