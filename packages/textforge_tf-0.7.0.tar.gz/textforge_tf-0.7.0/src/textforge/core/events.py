"""Event subsystem integration for Textforge core."""

from __future__ import annotations

import threading
from typing import TYPE_CHECKING

from ..utils.logging import get_logger

if TYPE_CHECKING:
    from ..events.subsystem import EventSubsystem

logger = get_logger(__name__)

# Global event subsystem instance
_event_subsystem: EventSubsystem | None = None
_event_subsystem_lock = threading.RLock()


def get_event_subsystem() -> EventSubsystem:
    """Get the global event subsystem instance.

    Returns:
        EventSubsystem: The global event subsystem instance.

    Raises:
        RuntimeError: If the event subsystem has not been initialized.
    """
    global _event_subsystem
    with _event_subsystem_lock:
        if _event_subsystem is None:
            from ..events.subsystem import create_event_subsystem
            _event_subsystem = create_event_subsystem()
            logger.debug("Created global event subsystem instance")
        return _event_subsystem


def set_event_subsystem(subsystem: EventSubsystem) -> None:
    """Set the global event subsystem instance.

    Args:
        subsystem: The event subsystem instance to set as global.
    """
    with _event_subsystem_lock:
        global _event_subsystem
        _event_subsystem = subsystem
        logger.debug("Set global event subsystem instance")
