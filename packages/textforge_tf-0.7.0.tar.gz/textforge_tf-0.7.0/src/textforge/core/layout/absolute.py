"""Absolute positioning layout algorithm implementation."""

from __future__ import annotations

import logging
from threading import RLock

from .engine import LayoutNode, LayoutResult
from .types import Bounds, LayoutAlgorithm, LayoutCalculationError, RendererType

logger = logging.getLogger(__name__)


class AbsoluteLayout(LayoutAlgorithm):
    """Absolute positioning layout algorithm implementation."""

    def __init__(self) -> None:
        """Initialize the absolute layout algorithm."""
        self._lock = RLock()

    def calculate(self, node: LayoutNode, container_bounds: Bounds, renderer_type: RendererType) -> LayoutResult:
        """Calculate absolute positioning layout for a node.

        Implements proper absolute positioning with support for top, right,
        bottom, left properties relative to the containing block.

        Args:
            node: The layout node to calculate.
            container_bounds: The bounds of the container.
            renderer_type: The target renderer type.

        Returns:
            The calculated layout result.

        Raises:
            LayoutCalculationError: If layout calculation fails.
        """
        with self._lock:
            try:
                logger.debug(f"Calculating absolute layout for node with renderer: {renderer_type}")

                # Convert bounds to renderer units if needed
                bounds = container_bounds.to_renderer_units(renderer_type)
                available_width = int(bounds.width)
                available_height = int(bounds.height)

                style = node.style

                # Calculate padding and margin
                padding_top = style.padding_top if style.padding_top is not None else style.padding
                padding_right = style.padding_right if style.padding_right is not None else style.padding
                padding_bottom = style.padding_bottom if style.padding_bottom is not None else style.padding
                padding_left = style.padding_left if style.padding_left is not None else style.padding

                margin_top = style.margin_top if style.margin_top is not None else style.margin
                margin_right = style.margin_right if style.margin_right is not None else style.margin
                margin_bottom = style.margin_bottom if style.margin_bottom is not None else style.margin
                margin_left = style.margin_left if style.margin_left is not None else style.margin

                # For absolute positioning, first calculate the natural size
                natural_width = style.width if style.width is not None else 0
                natural_height = style.height if style.height is not None else 0

                if node.measure is not None:
                    measured_width, measured_height = node.measure(available_width, available_height)
                    if style.width is None:
                        natural_width = measured_width
                    if style.height is None:
                        natural_height = measured_height

                # Apply constraints
                natural_width = max(style.min_width or 0, min(style.max_width or natural_width, natural_width))
                natural_height = max(style.min_height or 0, min(style.max_height or natural_height, natural_height))

                # Add padding to content dimensions
                content_width = natural_width + padding_left + padding_right
                content_height = natural_height + padding_top + padding_bottom

                # Position based on absolute properties
                x = margin_left
                y = margin_top

                if style.left is not None:
                    x = style.left
                if style.top is not None:
                    y = style.top
                if style.right is not None:
                    if style.left is not None:
                        # Both left and right specified - stretch
                        content_width = available_width - style.left - style.right - margin_left - margin_right
                    else:
                        x = available_width - content_width - style.right
                if style.bottom is not None:
                    if style.top is not None:
                        # Both top and bottom specified - stretch
                        content_height = available_height - style.top - style.bottom - margin_top - margin_bottom
                    else:
                        y = available_height - content_height - style.bottom

                # Ensure non-negative dimensions
                content_width = max(0, content_width)
                content_height = max(0, content_height)

                result = LayoutResult(x=x, y=y, width=content_width + margin_left + margin_right, height=content_height + margin_top + margin_bottom)

                # Update node layout
                node.layout = result
                return result

            except Exception as e:
                logger.error(f"Absolute layout calculation failed: {e}")
                raise LayoutCalculationError(f"Failed to calculate absolute layout: {e}") from e
