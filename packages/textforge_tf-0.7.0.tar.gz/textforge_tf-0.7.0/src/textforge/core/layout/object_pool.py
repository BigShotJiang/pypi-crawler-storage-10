"""Object pooling system for efficient component reuse and memory management."""

from __future__ import annotations

import weakref
from collections import defaultdict, deque
from dataclasses import dataclass
from typing import TYPE_CHECKING, Generic, TypeVar

if TYPE_CHECKING:
    from collections.abc import Callable
    from types import TracebackType

    from .engine import LayoutNode

T = TypeVar("T")


@dataclass(slots=True)
class PoolConfig:
    """Configuration for object pooling behavior."""

    max_pool_size: int = 1000  # Maximum objects to keep in pool
    max_idle_time: float = 300.0  # Seconds before idle objects are cleaned up
    cleanup_interval: float = 60.0  # Seconds between cleanup runs
    enable_weak_refs: bool = True  # Use weak references for better GC


@dataclass(slots=True)
class PoolStats:
    """Statistics for pool usage and performance."""

    created: int = 0  # Total objects created
    reused: int = 0  # Total objects reused from pool
    returned: int = 0  # Total objects returned to pool
    evicted: int = 0  # Total objects evicted due to pool limits
    garbage_collected: int = 0  # Objects cleaned up by GC
    pool_size: int = 0  # Current pool size
    hit_rate: float = 0.0  # Reuse rate (reused / (created + reused))


class ObjectPool(Generic[T]):
    """Generic object pool for efficient reuse of objects."""

    def __init__(
        self,
        factory: Callable[[], T],
        config: PoolConfig | None = None,
        reset_func: Callable[[T], None] | None = None,
    ):
        self.factory = factory
        self.config = config or PoolConfig()
        self.reset_func = reset_func or (lambda obj: None)

        # Pool storage
        self._pool: deque[T] = deque()
        self._weak_refs: set[weakref.ReferenceType[T]] = set()

        # Statistics
        self.stats = PoolStats()

        # Cleanup tracking
        self._last_cleanup = 0.0

    def acquire(self) -> T:
        """Get an object from the pool, creating a new one if necessary."""
        import time

        current_time = time.time()

        # Try to get from pool first
        obj = self._get_from_pool()

        if obj is not None:
            self.stats.reused += 1
            self.reset_func(obj)
            return obj

        # Create new object
        obj = self.factory()
        self.stats.created += 1

        # Update hit rate
        total_requests = self.stats.created + self.stats.reused
        if total_requests > 0:
            self.stats.hit_rate = self.stats.reused / total_requests

        return obj

    def release(self, obj: T) -> None:
        """Return an object to the pool for reuse."""
        if self._should_pool_object(obj):
            self._add_to_pool(obj)
            self.stats.returned += 1
        else:
            self.stats.evicted += 1

    def clear(self) -> None:
        """Clear all objects from the pool."""
        self._pool.clear()
        self._weak_refs.clear()
        self.stats.pool_size = 0

    def cleanup(self) -> None:
        """Clean up expired objects and update statistics."""
        import time

        current_time = time.time()

        # Clean up weak references
        if self.config.enable_weak_refs:
            dead_refs = [ref for ref in self._weak_refs if ref() is None]
            self._weak_refs.difference_update(dead_refs)
            self.stats.garbage_collected += len(dead_refs)

        # Periodic cleanup of pool
        if current_time - self._last_cleanup > self.config.cleanup_interval:
            # Remove excess objects
            while len(self._pool) > self.config.max_pool_size:
                self._pool.popleft()
                self.stats.evicted += 1

            self._last_cleanup = current_time

        self.stats.pool_size = len(self._pool)

    def _get_from_pool(self) -> T | None:
        """Get an object from the pool."""
        while self._pool:
            obj = self._pool.popleft()
            # Check if object is still valid (not garbage collected)
            if self.config.enable_weak_refs:
                # For weak references, we assume the object is valid if we got it from pool
                return obj
            else:
                return obj
        return None

    def _add_to_pool(self, obj: T) -> None:
        """Add an object to the pool."""
        if len(self._pool) < self.config.max_pool_size:
            self._pool.append(obj)

            if self.config.enable_weak_refs:
                # Add weak reference for tracking
                self._weak_refs.add(weakref.ref(obj))

    def _should_pool_object(self, obj: T) -> bool:
        """Determine if an object should be pooled."""
        # Basic checks - can be extended for specific object types
        return True


class LayoutNodePool:
    """Specialized pool for LayoutNode objects."""

    def __init__(self, config: PoolConfig | None = None):
        self.config = config or PoolConfig()
        self._pools: dict[str, ObjectPool[LayoutNode]] = defaultdict(lambda: ObjectPool(self._create_node, self.config, self._reset_node))
        self._stats = PoolStats()

    def acquire(self, node_type: str = "default") -> LayoutNode:
        """Get a LayoutNode from the pool."""
        pool = self._pools[node_type]
        node = pool.acquire()

        # Update global stats
        self._update_global_stats()

        return node

    def release(self, node: LayoutNode, node_type: str = "default") -> None:
        """Return a LayoutNode to the pool."""
        pool = self._pools[node_type]
        pool.release(node)

        # Update global stats
        self._update_global_stats()

    def cleanup(self) -> None:
        """Clean up all pools."""
        for pool in self._pools.values():
            pool.cleanup()
        self._update_global_stats()

    def get_stats(self, node_type: str | None = None) -> PoolStats:
        """Get statistics for a specific node type or global stats."""
        if node_type:
            pool = self._pools.get(node_type)
            return pool.stats if pool else PoolStats()
        return self._stats

    def _create_node(self) -> LayoutNode:
        """Factory function for creating new LayoutNodes."""
        from .engine import LayoutNode, LayoutStyle

        return LayoutNode(style=LayoutStyle())

    def _reset_node(self, node: LayoutNode) -> None:
        """Reset a LayoutNode for reuse."""
        # Clear children
        node.children.clear()

        # Reset layout
        node.layout.x = 0
        node.layout.y = 0
        node.layout.width = 0
        node.layout.height = 0

        # Reset style to defaults
        style = node.style
        style.width = None
        style.height = None
        style.min_width = None
        style.min_height = None
        style.max_width = None
        style.max_height = None
        style.flex_grow = 0.0
        style.flex_shrink = 1.0
        style.flex_basis = None
        style.margin = 0
        style.padding = 0
        style.direction = "row"
        style.wrap = False
        style.gap = 0
        style.justify = "start"
        style.align = "stretch"

        # Clear grid properties
        style.grid_template_columns = None
        style.grid_template_rows = None
        style.grid_column_gap = 0
        style.grid_row_gap = 0

        # Clear positioning
        style.position = "static"
        style.top = None
        style.right = None
        style.bottom = None
        style.left = None

        # Clear box model
        style.margin_top = None
        style.margin_right = None
        style.margin_bottom = None
        style.margin_left = None
        style.padding_top = None
        style.padding_right = None
        style.padding_bottom = None
        style.padding_left = None

        # Clear measure function
        node.measure = None

    def _update_global_stats(self) -> None:
        """Update global statistics across all pools."""
        total_created = 0
        total_reused = 0
        total_returned = 0
        total_evicted = 0
        total_gc = 0
        total_pool_size = 0

        for pool in self._pools.values():
            stats = pool.stats
            total_created += stats.created
            total_reused += stats.reused
            total_returned += stats.returned
            total_evicted += stats.evicted
            total_gc += stats.garbage_collected
            total_pool_size += stats.pool_size

        self._stats.created = total_created
        self._stats.reused = total_reused
        self._stats.returned = total_returned
        self._stats.evicted = total_evicted
        self._stats.garbage_collected = total_gc
        self._stats.pool_size = total_pool_size

        total_requests = total_created + total_reused
        self._stats.hit_rate = total_reused / total_requests if total_requests > 0 else 0.0


# Global layout node pool instance
_layout_node_pool = LayoutNodePool()


def get_layout_node_pool() -> LayoutNodePool:
    """Get the global layout node pool instance."""
    return _layout_node_pool


class PooledLayoutNode:
    """Context manager for pooled LayoutNode usage."""

    def __init__(self, node_type: str = "default"):
        self.node_type = node_type
        self.node: LayoutNode | None = None

    def __enter__(self) -> LayoutNode:
        self.node = get_layout_node_pool().acquire(self.node_type)
        return self.node

    def __exit__(self, exc_type: type[BaseException] | None, exc_val: BaseException | None, exc_tb: TracebackType | None) -> None:
        if self.node is not None:
            get_layout_node_pool().release(self.node, self.node_type)


def pooled_node(node_type: str = "default") -> PooledLayoutNode:
    """Context manager for getting a pooled LayoutNode."""
    return PooledLayoutNode(node_type)
