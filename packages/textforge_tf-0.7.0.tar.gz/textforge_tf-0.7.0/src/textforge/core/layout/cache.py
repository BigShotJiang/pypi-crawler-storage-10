"""Layout caching system for performance optimization."""

from __future__ import annotations

import logging
from threading import RLock
from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from .engine import LayoutNode, LayoutResult

logger = logging.getLogger(__name__)


class LayoutCache:
    """Cache for layout calculation results."""

    def __init__(self, max_size: int = 1000) -> None:
        """Initialize the layout cache.

        Args:
            max_size: Maximum number of cached entries.
        """
        self._cache: dict[str, tuple[LayoutResult, int]] = {}
        self._max_size = max_size
        self._lock = RLock()
        self._hits = 0
        self._misses = 0

    def get(self, node: LayoutNode, available_width: int | None, available_height: int | None) -> LayoutResult | None:
        """Get cached layout result.

        Args:
            node: The layout node.
            available_width: Available width constraint.
            available_height: Available height constraint.

        Returns:
            Cached layout result if available, None otherwise.
        """
        with self._lock:
            key = self._make_key(node, available_width, available_height)
            if key in self._cache:
                result, _ = self._cache[key]
                self._hits += 1
                logger.log(5, f"Layout cache hit for key: {key}")
                return result
            else:
                self._misses += 1
                logger.log(5, f"Layout cache miss for key: {key}")
                return None

    def put(self, node: LayoutNode, available_width: int | None, available_height: int | None, result: LayoutResult) -> None:
        """Store layout result in cache.

        Args:
            node: The layout node.
            available_width: Available width constraint.
            available_height: Available height constraint.
            result: The layout result to cache.
        """
        with self._lock:
            key = self._make_key(node, available_width, available_height)

            # Simple LRU: remove oldest if at capacity
            if len(self._cache) >= self._max_size:
                # Remove the entry with the smallest access count
                oldest_key = min(self._cache.keys(), key=lambda k: self._cache[k][1])
                del self._cache[oldest_key]

            self._cache[key] = (result, 0)

    def clear(self) -> None:
        """Clear all cached entries."""
        with self._lock:
            self._cache.clear()
            self._hits = 0
            self._misses = 0
            logger.debug("Layout cache cleared")

    def get_stats(self) -> dict[str, int]:
        """Get cache statistics.

        Returns:
            Dictionary with cache statistics.
        """
        with self._lock:
            total = self._hits + self._misses
            hit_rate = (self._hits / total * 100) if total > 0 else 0
            return {"size": len(self._cache), "max_size": self._max_size, "hits": self._hits, "misses": self._misses, "hit_rate": hit_rate}

    def _make_key(self, node: LayoutNode, available_width: int | None, available_height: int | None) -> str:
        """Create cache key for layout calculation.

        Args:
            node: The layout node.
            available_width: Available width constraint.
            available_height: Available height constraint.

        Returns:
            Cache key string.
        """
        # Create a hash of relevant properties
        style_hash = hash(
            (
                node.style.width,
                node.style.height,
                node.style.direction,
                node.style.justify,
                node.style.align,
                node.style.gap,
                node.style.wrap,
                node.style.display,
                node.style.position,
            )
        )
        return f"{id(node)}:{available_width}:{available_height}:{style_hash}"


# Global cache instance
_layout_cache: LayoutCache | None = None


def get_layout_cache() -> LayoutCache:
    """Get the global layout cache instance.

    Returns:
        The global layout cache.
    """
    global _layout_cache
    if _layout_cache is None:
        _layout_cache = LayoutCache()
    return _layout_cache


def set_layout_cache(cache: LayoutCache) -> None:
    """Set the global layout cache instance.

    Args:
        cache: The layout cache to set.
    """
    global _layout_cache
    _layout_cache = cache
