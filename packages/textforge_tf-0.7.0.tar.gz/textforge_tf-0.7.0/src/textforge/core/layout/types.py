"""Layout type definitions and interfaces for TextForge."""

from __future__ import annotations

from dataclasses import dataclass
from enum import Enum
from typing import TYPE_CHECKING, Protocol

if TYPE_CHECKING:
    from ...components.base import RenderableComponent

if TYPE_CHECKING:
    from .engine import LayoutResult


class RendererType(Enum):
    """Enumeration of supported renderer types."""

    CLI = "cli"  # Terminal cells
    TTY = "tty"  # Terminal cells with ANSI
    GUI = "gui"  # Pixels
    SVG = "svg"  # Vector coordinates
    HTML = "html"  # CSS pixels
    PDF = "pdf"  # Points
    OPENGL = "opengl"  # Hardware-accelerated pixels
    VULKAN = "vulkan"  # Hardware-accelerated pixels
    METAL = "metal"  # Hardware-accelerated pixels
    DIRECTX11 = "directx11"  # Hardware-accelerated pixels


@dataclass(slots=True, frozen=True)
class Bounds:
    """Bounding box for layout calculations."""

    x: float
    y: float
    width: float
    height: float

    def to_renderer_units(self, renderer_type: RendererType) -> Bounds:
        """Convert bounds to renderer-specific units.

        Args:
            renderer_type: The target renderer type.

        Returns:
            Bounds converted to the specified renderer units.
        """
        if renderer_type == RendererType.CLI:
            # Convert pixels to cells (assuming 8x16 font)
            return Bounds(x=self.x / 8, y=self.y / 16, width=self.width / 8, height=self.height / 16)
        return self


class LayoutAlgorithm(Protocol):
    """Protocol for layout algorithms."""

    def calculate(self, component: RenderableComponent, container_bounds: Bounds, renderer_type: RendererType) -> LayoutResult:
        """Calculate layout for a component.

        Args:
            component: The renderable component to calculate.
            container_bounds: The bounds of the container.
            renderer_type: The target renderer type.

        Returns:
            The calculated layout result.
        """
        ...


class LayoutConstraint(Protocol):
    """Protocol for layout constraints."""

    def validate(self, component: RenderableComponent, bounds: Bounds) -> bool:
        """Validate if the layout satisfies the constraint.

        Args:
            component: The renderable component to validate.
            bounds: The calculated bounds.

        Returns:
            True if the constraint is satisfied, False otherwise.
        """
        ...

    def apply(self, component: RenderableComponent, bounds: Bounds) -> Bounds:
        """Apply the constraint to adjust bounds.

        Args:
            component: The renderable component to adjust.
            bounds: The current bounds.

        Returns:
            The adjusted bounds.
        """
        ...


class ResponsiveBreakpoint(Protocol):
    """Protocol for responsive breakpoints."""

    @property
    def min_width(self) -> int | None:
        """Minimum width for this breakpoint."""
        ...

    @property
    def max_width(self) -> int | None:
        """Maximum width for this breakpoint."""
        ...

    @property
    def min_height(self) -> int | None:
        """Minimum height for this breakpoint."""
        ...

    @property
    def max_height(self) -> int | None:
        """Maximum height for this breakpoint."""
        ...


class LayoutCacheKey(Protocol):
    """Protocol for layout cache keys."""

    def __hash__(self) -> int:
        """Return hash of the cache key."""
        ...

    def __eq__(self, other: object) -> bool:
        """Check equality with another cache key."""
        ...


class LayoutError(Exception):
    """Base exception for layout-related errors."""

    pass


class LayoutCalculationError(LayoutError):
    """Raised when layout calculation fails."""

    pass


class InvalidLayoutConstraintsError(LayoutError):
    """Raised when layout constraints are invalid."""

    pass


class LayoutOverflowError(LayoutError):
    """Raised when layout exceeds available space."""

    pass
