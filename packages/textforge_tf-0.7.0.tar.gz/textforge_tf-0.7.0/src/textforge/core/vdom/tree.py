"""VDOM tree structures and management."""

from __future__ import annotations

import threading
import uuid
from dataclasses import dataclass, field
from typing import TYPE_CHECKING

from ...core.layout.types import RendererType
from ...utils.logging import get_logger
from .errors import ComponentNotFoundError, InvalidVDOMOperationError
from .patcher import TreePatcher
from .reconciler import TreeReconciler

if TYPE_CHECKING:
    from ...components.base import RenderableComponent
    from .patcher import Patch

logger = get_logger(__name__)


@dataclass(slots=True)
class VDOMNode:
    """VDOM tree node."""

    component_name: str
    props: dict[str, object] = field(default_factory=dict)
    children: list[VDOMNode] = field(default_factory=list)
    key: str | None = None


@dataclass(slots=True)
class VDOMTree:
    """Virtual DOM tree for efficient component management."""

    root: VDOMNode | None = None
    renderer_type: RendererType = RendererType.CLI
    _component_refs: dict[str, RenderableComponent] = field(default_factory=dict)
    _key_map: dict[str, VDOMNode] = field(default_factory=dict)
    _lock: threading.RLock = field(default_factory=threading.RLock)
    _reconciler: TreeReconciler = field(default_factory=TreeReconciler)
    _patcher: TreePatcher = field(default_factory=TreePatcher)

    def update_component(self, key: str, new_component: RenderableComponent) -> list[Patch]:
        """Update a component and return patches."""
        with self._lock:
            if key not in self._key_map:
                raise ComponentNotFoundError(f"Component with key '{key}' not found")

            old_node = self._key_map[key]
            new_node = self._component_to_node(new_component)

            patches = self._reconciler.reconcile(old_node, new_node)
            self._patcher.apply_patches(self, patches)

            # Update component reference
            self._component_refs[key] = new_component

            logger.debug(f"Updated component with key '{key}'")
            return patches

    def add_component(self, component: RenderableComponent, key: str | None = None) -> str:
        """Add a component to the tree."""
        with self._lock:
            if key is None:
                key = self._generate_key()

            if key in self._key_map:
                raise InvalidVDOMOperationError(f"Component with key '{key}' already exists")

            node = self._component_to_node(component)
            node.key = key

            self._key_map[key] = node
            self._component_refs[key] = component

            logger.debug(f"Added component with key '{key}'")
            return key

    def remove_component(self, key: str) -> None:
        """Remove a component from the tree."""
        with self._lock:
            if key not in self._key_map:
                logger.warning(f"Component with key '{key}' not found, skipping removal")
                return

            del self._key_map[key]
            if key in self._component_refs:
                del self._component_refs[key]

            logger.debug(f"Removed component with key '{key}'")

    def get_component(self, key: str) -> RenderableComponent | None:
        """Get a component by key."""
        with self._lock:
            return self._component_refs.get(key)

    def _component_to_node(self, component: RenderableComponent) -> VDOMNode:
        """Convert a component to a VDOM node."""
        # Get component properties (simplified for now)
        props: dict[str, object] = getattr(component, "__dict__", {})

        # Convert children to nodes
        children: list[VDOMNode] = []
        if hasattr(component, "children") and component.children:
            for child in component.children:
                if hasattr(child, "to_renderable"):
                    renderable_child = child.to_renderable()
                    children.append(self._component_to_node(renderable_child))
                else:
                    # Handle non-component children
                    children.append(VDOMNode(component_name="text", props={"content": str(child)}))

        return VDOMNode(component_name=component.component_name, props=props, children=children)

    def _generate_key(self) -> str:
        """Generate a unique key for a component."""
        while True:
            key = str(uuid.uuid4())[:8]
            if key not in self._key_map:
                return key
