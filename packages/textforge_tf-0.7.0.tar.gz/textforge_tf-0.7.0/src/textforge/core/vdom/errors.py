"""VDOM subsystem error classes."""

from ...utils.logging import get_logger

logger = get_logger(__name__)


class VDOMError(Exception):
    """Base exception for VDOM-related errors."""

    pass


class ComponentNotFoundError(VDOMError):
    """Raised when a component key is not found in the VDOM tree."""

    pass


class InvalidVDOMOperationError(VDOMError):
    """Raised when an invalid VDOM operation is attempted."""

    pass


class VDOMReconciliationError(VDOMError):
    """Raised when VDOM tree reconciliation fails."""

    pass
