"""Component lifecycle management for VDOM."""

from __future__ import annotations

import threading
from typing import TYPE_CHECKING

from ...utils.logging import get_logger

if TYPE_CHECKING:
    from ...components.base import RenderableComponent

logger = get_logger(__name__)


class ComponentLifecycle:
    """Manages component lifecycle events in VDOM."""

    def __init__(self) -> None:
        self._lock = threading.RLock()
        self._mounted_components: dict[str, RenderableComponent] = {}
        self._unmounting_components: set[str] = set()

    def mount_component(self, key: str, component: RenderableComponent) -> None:
        """Mount a component."""
        with self._lock:
            if key in self._mounted_components:
                logger.warning(f"Component '{key}' is already mounted, skipping")
                return

            self._mounted_components[key] = component
            logger.debug(f"Mounted component '{key}'")

            # Trigger mount lifecycle
            self._trigger_mount(component)

    def unmount_component(self, key: str) -> None:
        """Unmount a component."""
        with self._lock:
            if key not in self._mounted_components:
                logger.warning(f"Component '{key}' is not mounted, skipping unmount")
                return

            component = self._mounted_components[key]
            self._unmounting_components.add(key)

            # Trigger unmount lifecycle
            self._trigger_unmount(component)

            del self._mounted_components[key]
            self._unmounting_components.remove(key)
            logger.debug(f"Unmounted component '{key}'")

    def update_component(self, key: str, new_component: RenderableComponent) -> None:
        """Update a component."""
        with self._lock:
            if key not in self._mounted_components:
                logger.warning(f"Component '{key}' is not mounted, skipping update")
                return

            old_component = self._mounted_components[key]

            # Trigger update lifecycle
            self._trigger_update(old_component, new_component)

            self._mounted_components[key] = new_component
            logger.debug(f"Updated component '{key}'")

    def is_mounted(self, key: str) -> bool:
        """Check if a component is mounted."""
        with self._lock:
            return key in self._mounted_components

    def get_mounted_components(self) -> list[RenderableComponent]:
        """Get all mounted components."""
        with self._lock:
            return list(self._mounted_components.values())

    def _trigger_mount(self, component: RenderableComponent) -> None:
        """Trigger component mount lifecycle."""
        # Check if component has lifecycle methods
        if hasattr(component, "on_mount"):
            try:
                component.on_mount()
                logger.log(5, f"Triggered on_mount for {component.component_name}")  # TRACE
            except Exception as e:
                logger.error(f"Error in on_mount for {component.component_name}: {e}")

    def _trigger_unmount(self, component: RenderableComponent) -> None:
        """Trigger component unmount lifecycle."""
        # Check if component has lifecycle methods
        if hasattr(component, "on_unmount"):
            try:
                component.on_unmount()
                logger.log(5, f"Triggered on_unmount for {component.component_name}")  # TRACE
            except Exception as e:
                logger.error(f"Error in on_unmount for {component.component_name}: {e}")

    def _trigger_update(self, old_component: RenderableComponent, new_component: RenderableComponent) -> None:
        """Trigger component update lifecycle."""
        # Check if component has lifecycle methods
        if hasattr(new_component, "on_update"):
            try:
                new_component.on_update(old_component)
                logger.log(5, f"Triggered on_update for {new_component.component_name}")  # TRACE
            except Exception as e:
                logger.error(f"Error in on_update for {new_component.component_name}: {e}")
