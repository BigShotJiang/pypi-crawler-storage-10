"""VDOM interface functions."""

from __future__ import annotations

import threading
from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from ...components.base import RenderableComponent
    from ...core.layout.types import RendererType
    from .patcher import Patch
    from .tree import VDOMTree

_RECONCILER_LOCAL = threading.local()


def _get_thread_reconciler() -> "TreeReconciler":
    """Return a thread-local reconciler instance."""
    reconciler = getattr(_RECONCILER_LOCAL, "reconciler", None)
    if reconciler is None:
        from .reconciler import TreeReconciler

        reconciler = TreeReconciler()
        _RECONCILER_LOCAL.reconciler = reconciler
    return reconciler


def create_vdom_tree(root_component: RenderableComponent, renderer_type: RendererType) -> VDOMTree:
    """Create a VDOM tree from a root component."""
    from .tree import VDOMTree

    tree = VDOMTree(renderer_type=renderer_type)
    root_key = tree.add_component(root_component)
    tree.root = tree._key_map.get(root_key)
    return tree


def update_vdom_component(tree: VDOMTree, key: str, new_component: RenderableComponent) -> list[Patch]:
    """Update a component in the VDOM tree."""
    return tree.update_component(key, new_component)


def reconcile_vdom_trees(old_tree: VDOMTree, new_tree: VDOMTree) -> list[Patch]:
    """Reconcile two VDOM trees."""
    return _get_thread_reconciler().reconcile(old_tree.root, new_tree.root)
