"""Virtual DOM subsystem for efficient component tree management."""

from .errors import ComponentNotFoundError, InvalidVDOMOperationError, VDOMError, VDOMReconciliationError
from .interfaces import create_vdom_tree, reconcile_vdom_trees, update_vdom_component
from .keys import ComponentKeys
from .lifecycle import ComponentLifecycle
from .memory import MemoryManager
from .patcher import Patch, PatchType, TreePatcher
from .reconciler import TreeReconciler
from .refs import ComponentRefs
from .tree import VDOMNode, VDOMTree

__all__ = [
    "VDOMTree",
    "VDOMNode",
    "TreeReconciler",
    "TreePatcher",
    "Patch",
    "PatchType",
    "ComponentLifecycle",
    "ComponentRefs",
    "ComponentKeys",
    "MemoryManager",
    "create_vdom_tree",
    "update_vdom_component",
    "reconcile_vdom_trees",
    "VDOMError",
    "ComponentNotFoundError",
    "InvalidVDOMOperationError",
    "VDOMReconciliationError",
]
