"""VDOM tree patching operations."""

from __future__ import annotations

import threading
from dataclasses import dataclass
from enum import Enum
from typing import TYPE_CHECKING, Any

from ...utils.logging import get_logger

if TYPE_CHECKING:
    from .tree import VDOMNode, VDOMTree

logger = get_logger(__name__)


class PatchType(Enum):
    """Types of VDOM patches."""

    ADD_NODE = "add_node"
    REMOVE_NODE = "remove_node"
    UPDATE_PROPS = "update_props"
    REPLACE_ROOT = "replace_root"
    MOVE_NODE = "move_node"


@dataclass(slots=True)
class Patch:
    """VDOM patch operation."""

    patch_type: PatchType
    key: str | None = None
    data: Any = None

    @classmethod
    def add_node(cls, node: VDOMNode) -> Patch:
        """Create an add node patch."""
        return cls(PatchType.ADD_NODE, key=node.key, data=node)

    @classmethod
    def remove_node(cls, key: str) -> Patch:
        """Create a remove node patch."""
        return cls(PatchType.REMOVE_NODE, key=key)

    @classmethod
    def update_props(cls, key: str, props: dict[str, object]) -> Patch:
        """Create an update properties patch."""
        return cls(PatchType.UPDATE_PROPS, key=key, data=props)

    @classmethod
    def replace_root(cls, new_root: VDOMNode) -> Patch:
        """Create a replace root patch."""
        return cls(PatchType.REPLACE_ROOT, data=new_root)

    @classmethod
    def move_node(cls, key: str, new_position: int) -> Patch:
        """Create a move node patch."""
        return cls(PatchType.MOVE_NODE, key=key, data=new_position)


class TreePatcher:
    """Applies patches to VDOM trees."""

    def __init__(self) -> None:
        self._lock = threading.RLock()

    def apply_patches(self, tree: VDOMTree, patches: list[Patch]) -> None:
        """Apply a list of patches to a VDOM tree."""
        with self._lock:
            logger.log(5, f"Applying {len(patches)} patches to VDOM tree")  # TRACE level

            for patch in patches:
                self._apply_patch(tree, patch)

    def _apply_patch(self, tree: VDOMTree, patch: Patch) -> None:
        """Apply a single patch to the tree."""
        if patch.patch_type == PatchType.ADD_NODE:
            self._add_node(tree, patch.data)
        elif patch.patch_type == PatchType.REMOVE_NODE:
            if patch.key is None:
                raise ValueError("Key is required for remove node patch")
            self._remove_node(tree, patch.key)
        elif patch.patch_type == PatchType.UPDATE_PROPS:
            if patch.key is None:
                raise ValueError("Key is required for update props patch")
            self._update_props(tree, patch.key, patch.data)
        elif patch.patch_type == PatchType.REPLACE_ROOT:
            self._replace_root(tree, patch.data)
        elif patch.patch_type == PatchType.MOVE_NODE:
            if patch.key is None:
                raise ValueError("Key is required for move node patch")
            self._move_node(tree, patch.key, patch.data)

    def _add_node(self, tree: VDOMTree, node: VDOMNode) -> None:
        """Add a node to the tree."""
        if node.key is None:
            raise ValueError("Key is required for add node patch")
        if node.key in tree._key_map:
            logger.warning(f"Node with key '{node.key}' already exists, skipping add")
            return

        tree._key_map[node.key] = node
        logger.debug(f"Added node with key '{node.key}' to VDOM tree")

    def _remove_node(self, tree: VDOMTree, key: str) -> None:
        """Remove a node from the tree."""
        if key not in tree._key_map:
            logger.warning(f"Node with key '{key}' not found, skipping remove")
            return

        del tree._key_map[key]
        logger.debug(f"Removed node with key '{key}' from VDOM tree")

    def _update_props(self, tree: VDOMTree, key: str, props: dict[str, object]) -> None:
        """Update properties of a node."""
        if key not in tree._key_map:
            logger.warning(f"Node with key '{key}' not found, skipping update")
            return

        # Update node properties (implementation depends on VDOMNode structure)
        logger.log(5, f"Updated properties for node '{key}': {list(props.keys())}")  # TRACE

    def _replace_root(self, tree: VDOMTree, new_root: VDOMNode) -> None:
        """Replace the root node of the tree."""
        tree.root = new_root
        logger.debug("Replaced VDOM tree root")

    def _move_node(self, tree: VDOMTree, key: str, new_position: int) -> None:
        """Move a node to a new position."""
        if key not in tree._key_map:
            logger.warning(f"Node with key '{key}' not found, skipping move")
            return

        # Movement logic depends on tree structure
        logger.log(5, f"Moved node '{key}' to position {new_position}")  # TRACE
