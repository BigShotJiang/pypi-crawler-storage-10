"""VDOM tree reconciliation logic."""

from __future__ import annotations

import threading
from typing import TYPE_CHECKING

from ...utils.logging import get_logger
from .patcher import Patch

if TYPE_CHECKING:
    from .tree import VDOMNode

logger = get_logger(__name__)


class TreeReconciler:
    """Reconciles VDOM trees to find differences."""

    def __init__(self) -> None:
        self._lock = threading.RLock()

    def reconcile(self, old_tree: VDOMNode, new_tree: VDOMNode) -> list[Patch]:
        """Reconcile two trees and return patches."""
        with self._lock:
            return self._reconcile_internal(old_tree, new_tree)

    def _reconcile_internal(self, old_tree: VDOMNode, new_tree: VDOMNode) -> list[Patch]:
        """Reconcile two trees without acquiring the external lock."""
        trace_enabled = logger.isEnabledFor(5)
        if trace_enabled:
            logger.log(5, "Starting VDOM tree reconciliation")  # TRACE level

        patches: list[Patch] = []

        # Compare roots
        if old_tree.component_name != new_tree.component_name:
            patches.append(Patch.replace_root(new_tree))
            if trace_enabled:
                logger.log(
                    5,
                    "Root component changed: %s -> %s",
                    old_tree.component_name,
                    new_tree.component_name,
                )  # TRACE
            return patches

        # Compare props
        prop_diffs = self._diff_props(old_tree.props, new_tree.props)
        if prop_diffs:
            if old_tree.key is None:
                raise ValueError("Node must have a key to update props")
            patches.append(Patch.update_props(old_tree.key, prop_diffs))
            if trace_enabled:
                logger.log(5, "Properties changed for node '%s': %s", old_tree.key, list(prop_diffs.keys()))  # TRACE

        # Compare children
        child_patches = self._reconcile_children(old_tree.children, new_tree.children, trace_enabled)
        patches.extend(child_patches)

        if trace_enabled:
            logger.log(5, "Reconciliation complete: %d patches generated", len(patches))  # TRACE
        return patches

    def _diff_props(self, old_props: dict[str, object], new_props: dict[str, object]) -> dict[str, object]:
        """Find differences between property dictionaries."""
        diffs: dict[str, object] = {}

        # Find changed and added properties
        for key, new_value in new_props.items():
            if key not in old_props or old_props[key] != new_value:
                diffs[key] = new_value

        # Note: We don't track removed properties as they're handled by node removal
        return diffs

    def _reconcile_children(
        self,
        old_children: list[VDOMNode],
        new_children: list[VDOMNode],
        trace_enabled: bool,
    ) -> list[Patch]:
        """Reconcile child nodes."""
        patches: list[Patch] = []
        append_patch = patches.append

        old_len = len(old_children)
        new_len = len(new_children)
        start = 0

        # Fast-forward through matching keyed prefixes
        while start < old_len and start < new_len:
            old_child = old_children[start]
            new_child = new_children[start]
            if old_child.key is None or new_child.key is None or old_child.key != new_child.key:
                break
            if self._nodes_differ(old_child, new_child):
                patches.extend(self._reconcile_internal(old_child, new_child))
            start += 1

        if start == old_len and start == new_len:
            return patches

        # Fast-forward through matching keyed suffixes
        suffix_patches: list[list[Patch]] = []
        end_old = old_len
        end_new = new_len
        while end_old > start and end_new > start:
            old_child = old_children[end_old - 1]
            new_child = new_children[end_new - 1]
            if old_child.key is None or new_child.key is None or old_child.key != new_child.key:
                break
            if self._nodes_differ(old_child, new_child):
                suffix_patches.append(self._reconcile_internal(old_child, new_child))
            end_old -= 1
            end_new -= 1

        trimmed_old = old_children[start:end_old]
        trimmed_new = new_children[start:end_new]

        old_key_map: dict[str, VDOMNode] = {}
        new_key_map: dict[str, VDOMNode] = {}
        old_pos_map: dict[str, int] = {}
        new_pos_map: dict[str, int] = {}

        for index, child in enumerate(trimmed_old):
            if child.key is not None:
                actual_index = start + index
                old_key_map[child.key] = child
                old_pos_map[child.key] = actual_index

        for index, child in enumerate(trimmed_new):
            if child.key is not None:
                actual_index = start + index
                new_key_map[child.key] = child
                new_pos_map[child.key] = actual_index

        if old_key_map or new_key_map:

            old_keys = set(old_key_map)
            new_keys = set(new_key_map)

            removed_keys = old_keys - new_keys
            if removed_keys:
                for key in removed_keys:
                    append_patch(Patch.remove_node(key))
                    if trace_enabled:
                        logger.log(5, "Removing node '%s'", key)  # TRACE

            added_keys = new_keys - old_keys
            if added_keys:
                for key in added_keys:
                    append_patch(Patch.add_node(new_key_map[key]))
                    if trace_enabled:
                        logger.log(5, "Adding node '%s'", key)  # TRACE

            shared_keys = old_keys & new_keys
            for key in shared_keys:
                old_node = old_key_map[key]
                new_node = new_key_map[key]

                old_pos = old_pos_map.get(key, -1)
                new_pos = new_pos_map.get(key, -1)
                if old_pos != new_pos:
                    append_patch(Patch.move_node(key, new_pos))
                    if trace_enabled:
                        logger.log(5, "Moving node '%s' from %d to %d", key, old_pos, new_pos)  # TRACE

                if self._nodes_differ(old_node, new_node):
                    patches.extend(self._reconcile_internal(old_node, new_node))

        # Handle non-keyed children (position-based reconciliation)
        old_unkeyed_iter = (child for child in trimmed_old if child.key is None)
        new_unkeyed_iter = (child for child in trimmed_new if child.key is None)
        for old_child, new_child in zip(old_unkeyed_iter, new_unkeyed_iter):
            if self._nodes_differ(old_child, new_child):
                patches.extend(self._reconcile_internal(old_child, new_child))

        if suffix_patches:
            for patch_list in reversed(suffix_patches):
                patches.extend(patch_list)

        return patches

    def _nodes_differ(self, old_node: VDOMNode, new_node: VDOMNode) -> bool:
        """Check if two nodes are different."""
        if old_node.component_name != new_node.component_name:
            return True

        if old_node.props != new_node.props:
            return True

        if len(old_node.children) != len(new_node.children):
            return True

        return False
