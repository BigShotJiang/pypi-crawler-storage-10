"""Component key generation and management for VDOM."""

from __future__ import annotations

import hashlib
import threading
from typing import TYPE_CHECKING

from ...utils.logging import get_logger

if TYPE_CHECKING:
    from ...components.base import RenderableComponent

logger = get_logger(__name__)


class ComponentKeys:
    """Manages component keys for VDOM reconciliation."""

    def __init__(self) -> None:
        self._lock = threading.RLock()
        self._used_keys: set[str] = set()

    def generate_key(self, component: RenderableComponent, parent_key: str | None = None) -> str:
        """Generate a unique key for a component."""
        with self._lock:
            # Create a stable hash based on component properties
            component_hash = self._hash_component(component)

            # Include parent key for hierarchical uniqueness
            if parent_key:
                full_key = f"{parent_key}:{component_hash}"
            else:
                full_key = component_hash

            # Ensure uniqueness
            counter = 0
            unique_key = full_key
            while unique_key in self._used_keys:
                counter += 1
                unique_key = f"{full_key}:{counter}"

            self._used_keys.add(unique_key)
            logger.debug(f"Generated key '{unique_key}' for component")
            return unique_key

    def release_key(self, key: str) -> None:
        """Release a key for reuse."""
        with self._lock:
            if key in self._used_keys:
                self._used_keys.remove(key)
                logger.debug(f"Released key '{key}'")

    def is_key_used(self, key: str) -> bool:
        """Check if a key is currently in use."""
        with self._lock:
            return key in self._used_keys

    def clear_all_keys(self) -> None:
        """Clear all used keys (for testing/debugging)."""
        with self._lock:
            count = len(self._used_keys)
            self._used_keys.clear()
            logger.debug(f"Cleared {count} component keys")

    def _hash_component(self, component: RenderableComponent) -> str:
        """Create a hash string from component properties."""
        # Use component name and key properties for stable hashing
        props_str = f"{component.component_name}"

        # Add important properties that affect identity
        if hasattr(component, "__dict__"):
            # Sort keys for consistent hashing
            sorted_props = sorted(component.__dict__.items())
            for key, value in sorted_props:
                if not key.startswith("_"):  # Skip private attributes
                    props_str += f":{key}={value}"

        # Create hash
        hash_obj = hashlib.md5(props_str.encode())
        return hash_obj.hexdigest()[:8]  # Use first 8 chars for brevity
