"""Core runtime primitives: console, VDOM and diffing."""

from __future__ import annotations

from .console import (
    CallableRenderable,
    CompositeRenderable,
    Console,
    LazyRenderable,
    Measure,
    Renderable,
    composite,
    lazy,
    render_call,
    tfprint,
    use_console,
)
from .events import get_event_subsystem
from .vdom import (
    ComponentKeys,
    ComponentLifecycle,
    ComponentRefs,
    MemoryManager,
    TreePatcher,
    TreeReconciler,
    VDOMNode,
    VDOMTree,
    create_vdom_tree,
    reconcile_vdom_trees,
    update_vdom_component,
)

__all__ = [
    "Console",
    "use_console",
    "Renderable",
    "Measure",
    "CallableRenderable",
    "CompositeRenderable",
    "LazyRenderable",
    "render_call",
    "composite",
    "lazy",
    "tfprint",
    "get_event_subsystem",
    "VDOMTree",
    "VDOMNode",
    "TreeReconciler",
    "TreePatcher",
    "ComponentLifecycle",
    "ComponentRefs",
    "ComponentKeys",
    "MemoryManager",
    "create_vdom_tree",
    "update_vdom_component",
    "reconcile_vdom_trees",
]
