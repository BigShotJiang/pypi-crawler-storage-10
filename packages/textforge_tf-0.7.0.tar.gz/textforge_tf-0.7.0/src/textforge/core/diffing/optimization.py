"""Patch optimization for diffing operations."""


from .patches import Patch, PatchType


class PatchOptimizer:
    """Optimizes patches to reduce rendering overhead."""

    def optimize(self, patches: list[Patch]) -> list[Patch]:
        """Optimize a list of patches."""
        if not patches:
            return patches

        # Remove redundant patches
        optimized = self._remove_redundant_patches(patches)

        # Merge compatible patches
        optimized = self._merge_compatible_patches(optimized)

        # Sort patches for efficient application
        optimized = self._sort_patches(optimized)

        return optimized

    def _remove_redundant_patches(self, patches: list[Patch]) -> list[Patch]:
        """Remove patches that cancel each other out."""
        # Simple implementation: remove duplicate operations on same key
        seen: set[tuple[str, str]] = set()
        result: list[Patch] = []

        for patch in patches:
            key = (patch.patch_type.value, patch.key)
            if key not in seen:
                seen.add(key)
                result.append(patch)

        return result

    def _merge_compatible_patches(self, patches: list[Patch]) -> list[Patch]:
        """Merge patches that can be combined."""
        # For now, return as-is. Could be extended to merge multiple prop updates
        return patches

    def _sort_patches(self, patches: list[Patch]) -> list[Patch]:
        """Sort patches for optimal application order."""
        # Sort by operation type priority
        priority = {
            PatchType.REMOVE_NODE: 0,
            PatchType.ADD_NODE: 1,
            PatchType.MOVE_NODE: 2,
            PatchType.UPDATE_PROPS: 3,
            PatchType.REPLACE_ROOT: 4,
        }

        return sorted(patches, key=lambda p: priority.get(p.patch_type, 999))
