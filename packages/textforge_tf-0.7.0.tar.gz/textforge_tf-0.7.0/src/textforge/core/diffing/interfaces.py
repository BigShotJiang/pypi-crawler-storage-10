"""Public interfaces for the diffing subsystem."""

from typing import TYPE_CHECKING

from .engine import DiffingEngine

if TYPE_CHECKING:
    from ..vdom.tree import VDOMTree

# Global engine instance
_engine = DiffingEngine()


def diff_vdom_trees(old_tree: VDOMTree, new_tree: VDOMTree) -> list[dict[str, object]]:
    """Diff two VDOM trees and return patches."""
    return _engine.diff_trees(old_tree, new_tree)


def apply_patches(tree: VDOMTree, patches: list[dict[str, object]]) -> VDOMTree:
    """Apply patches to a VDOM tree."""
    # This would integrate with the VDOM patcher
    # For now, return the tree unchanged
    return tree
