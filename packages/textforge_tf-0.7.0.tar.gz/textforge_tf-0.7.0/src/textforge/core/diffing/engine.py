"""Diffing engine for efficient VDOM tree comparison and patch generation."""

import logging
from threading import RLock
from typing import TYPE_CHECKING

from .algorithms import IncrementalDiff, KeyedDiff, SimpleDiff
from .cache import DiffCache
from .errors import DiffingError
from .optimization import PatchOptimizer

if TYPE_CHECKING:
    from textforge.core.vdom.tree import VDOMNode

    from ..vdom.tree import VDOMTree

logger = logging.getLogger(__name__)


class DiffingEngine:
    """Engine for efficient VDOM tree diffing and patch generation."""

    def __init__(self) -> None:
        """Initialize the diffing engine."""
        self._algorithms = {"simple": SimpleDiff(), "keyed": KeyedDiff(), "incremental": IncrementalDiff()}
        self._cache = DiffCache()
        self._optimizer = PatchOptimizer()
        self._lock = RLock()

    def diff_trees(self, old_tree: VDOMTree, new_tree: VDOMTree) -> list[object]:
        """Diff two VDOM trees and return patches."""
        with self._lock:
            try:
                logger.debug(f"Starting diff operation for trees of size {self._tree_size(old_tree)} -> {self._tree_size(new_tree)}")

                # Check cache first
                cache_key = self._make_cache_key(old_tree, new_tree)
                if cache_key in self._cache:
                    logger.debug("Using cached diff result")
                    return self._cache[cache_key]

                # Select appropriate algorithm
                algorithm = self._select_algorithm(old_tree, new_tree)
                logger.log(5, f"Selected algorithm: {algorithm.__class__.__name__}")

                # Perform diffing
                patches = algorithm.diff(old_tree, new_tree)

                # Optimize patches
                patches = self._optimizer.optimize(patches)
                logger.log(5, f"Generated {len(patches)} optimized patches")

                # Cache result
                self._cache[cache_key] = patches

                logger.debug("Diff operation completed successfully")
                return patches

            except Exception as e:
                logger.error(f"Diff operation failed: {e}")
                raise DiffingError(f"Tree diffing failed: {e}") from e

    def _select_algorithm(self, old_tree: VDOMTree, new_tree: VDOMTree):
        """Select appropriate diffing algorithm based on tree characteristics."""
        old_size = self._tree_size(old_tree)
        new_size = self._tree_size(new_tree)

        # Use incremental diff for large trees
        if old_size > 1000 or new_size > 1000:
            return self._algorithms["incremental"]

        # Use keyed diff if trees have keys
        if self._has_keys(old_tree) and self._has_keys(new_tree):
            return self._algorithms["keyed"]

        # Default to simple diff
        return self._algorithms["simple"]

    def _tree_size(self, tree: VDOMTree) -> int:
        """Calculate the size of a VDOM tree."""

        def count_nodes(node: VDOMNode | None) -> int:
            if node is None:
                return 0
            return 1 + sum(count_nodes(child) for child in node.children)

        return count_nodes(tree.root)

    def _has_keys(self, tree: VDOMTree) -> bool:
        """Check if tree has keyed components."""

        def check_keys(node: VDOMNode | None) -> bool:
            if node is None:
                return False
            if node.key:
                return True
            return any(check_keys(child) for child in node.children)

        return check_keys(tree.root)

    def _make_cache_key(self, old_tree: VDOMTree, new_tree: VDOMTree) -> str:
        """Create cache key for diff operation."""
        # Simple cache key based on tree roots
        return f"{id(old_tree.root)}:{id(new_tree.root)}"
