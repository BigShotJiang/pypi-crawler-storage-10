"""Diffing subsystem for efficient VDOM tree comparison and patch generation."""

from .engine import DiffingEngine
from .errors import DiffingError, InvalidTreeStructureError, PatchApplicationError
from .interfaces import apply_patches, diff_vdom_trees
from .object_pool import (
    PatchObjectPool,
    PatchPoolConfig,
    PatchPoolStats,
    get_patch_object_pool,
    pooled_patch,
)

__all__ = [
    "DiffingEngine",
    "diff_vdom_trees",
    "apply_patches",
    "DiffingError",
    "InvalidTreeStructureError",
    "PatchApplicationError",
    "PatchObjectPool",
    "PatchPoolConfig",
    "PatchPoolStats",
    "get_patch_object_pool",
    "pooled_patch",
]
