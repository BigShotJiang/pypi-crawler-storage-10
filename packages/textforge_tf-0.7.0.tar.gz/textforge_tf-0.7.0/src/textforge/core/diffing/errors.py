"""Error classes for the diffing subsystem."""

from ..vdom.errors import VDOMError


class DiffingError(VDOMError):
    """Base exception for diffing subsystem errors."""


class InvalidTreeStructureError(DiffingError):
    """Raised when tree structure is invalid for diffing."""


class PatchApplicationError(DiffingError):
    """Raised when patch application fails."""
