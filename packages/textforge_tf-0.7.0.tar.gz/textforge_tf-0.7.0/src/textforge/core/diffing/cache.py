"""Caching for diffing operations."""

from threading import RLock
from typing import Any


class DiffCache:
    """Cache for diffing operations to improve performance."""

    def __init__(self, max_size: int = 1000) -> None:
        """Initialize the diff cache."""
        self._cache: dict[str, Any] = {}
        self._max_size = max_size
        self._lock = RLock()

    def __getitem__(self, key: str) -> object:
        """Get an item from the cache."""
        with self._lock:
            return self._cache.get(key)

    def __setitem__(self, key: str, value: object) -> None:
        """Set an item in the cache."""
        with self._lock:
            if len(self._cache) >= self._max_size:
                # Simple LRU: remove oldest item
                oldest_key = next(iter(self._cache))
                del self._cache[oldest_key]
            self._cache[key] = value

    def __contains__(self, key: str) -> bool:
        """Check if key exists in cache."""
        with self._lock:
            return key in self._cache

    def clear(self) -> None:
        """Clear the cache."""
        with self._lock:
            self._cache.clear()
