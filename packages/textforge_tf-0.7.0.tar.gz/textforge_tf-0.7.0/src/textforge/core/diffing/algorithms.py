"""Advanced diffing algorithms for efficient VDOM tree comparison."""

from __future__ import annotations

import logging
from threading import RLock
from typing import TYPE_CHECKING

from .errors import DiffingError
from .patches import Patch

if TYPE_CHECKING:
    from ..vdom.tree import VDOMNode, VDOMTree

logger = logging.getLogger(__name__)


class IncrementalDiff:
    """Incremental diffing algorithm optimized for large trees."""

    def __init__(self) -> None:
        """Initialize incremental diff algorithm."""
        self._cache = {}
        self._lock = RLock()

    def diff(self, old_tree: VDOMTree, new_tree: VDOMTree) -> list[Patch]:
        """Perform incremental diff between trees."""
        with self._lock:
            try:
                logger.debug(f"Starting incremental diff: {self._tree_size(old_tree)} -> {self._tree_size(new_tree)} nodes")

                # Use tree hashing for fast comparison
                old_hashes = self._compute_tree_hashes(old_tree)
                new_hashes = self._compute_tree_hashes(new_tree)

                # Find changed subtrees
                changed_paths = self._find_changed_paths(old_hashes, new_hashes)

                # Generate patches for changed subtrees only
                patches: list[Patch] = []
                for path in changed_paths:
                    old_subtree = self._get_subtree_at_path(old_tree, path)
                    new_subtree = self._get_subtree_at_path(new_tree, path)

                    if old_subtree is None and new_subtree is not None:
                        patches.append(Patch.add_node(new_subtree))
                    elif old_subtree is not None and new_subtree is None:
                        patches.append(Patch.remove_node(path))
                    elif old_subtree is not None and new_subtree is not None:
                        subtree_patches = self._diff_subtrees(old_subtree, new_subtree, path)
                        patches.extend(subtree_patches)

                logger.debug(f"Generated {len(patches)} incremental patches")
                return patches

            except Exception as e:
                logger.error(f"Incremental diff failed: {e}")
                raise DiffingError(f"Incremental diffing failed: {e}") from e

    def _compute_tree_hashes(self, tree: VDOMTree) -> dict[str, int]:
        """Compute content hashes for tree nodes."""
        hashes: dict[str, int] = {}

        def hash_node(node: VDOMNode, path: str = "") -> int:
            if node is None:
                return 0

            current_path = f"{path}.{node.component_name}" if path else node.component_name

            # Create hash from node properties
            node_hash = hash(node.component_name)

            # Include props in hash
            if hasattr(node, 'props') and node.props:
                for key, value in sorted(node.props.items()):
                    node_hash ^= hash((key, value))

            # Include children in hash
            if hasattr(node, 'children') and node.children:
                for child in node.children:
                    child_path = f"{current_path}.{child.component_name}" if current_path else child.component_name
                    child_hash = hash_node(child, current_path)
                    node_hash ^= child_hash

            hashes[current_path] = node_hash
            return node_hash

        hash_node(tree.root)
        return hashes

    def _find_changed_paths(self, old_hashes: dict[str, int], new_hashes: dict[str, int]) -> list[str]:
        """Find paths that have changed between hash sets."""
        all_paths = set(old_hashes.keys()) | set(new_hashes.keys())
        changed: list[str] = []

        for path in all_paths:
            old_hash = old_hashes.get(path)
            new_hash = new_hashes.get(path)

            if old_hash != new_hash:
                changed.append(path)

        return changed

    def _get_subtree_at_path(self, tree: VDOMTree, path: str) -> VDOMNode | None:
        """Get subtree at specified path."""
        if not path:
            return tree.root

        parts = path.split('.')
        current = tree.root

        for part in parts:
            if current is None:
                return None

            if hasattr(current, 'children') and current.children:
                found = False
                for child in current.children:
                    if child.component_name == part:
                        current = child
                        found = True
                        break
                if not found:
                    return None
            else:
                return None

        return current

    def _diff_subtrees(self, old_node: VDOMNode, new_node: VDOMNode, base_path: str) -> list[Patch]:
        """Diff two subtrees with path context."""
        patches: list[Patch] = []

        # Compare node properties
        if old_node.component_name != new_node.component_name:
            patches.append(Patch.replace_root(new_node))
            return patches

        # Compare props
        if hasattr(old_node, 'props') and hasattr(new_node, 'props'):
            old_props = old_node.props or {}
            new_props = new_node.props or {}

            if old_props != new_props:
                patches.append(Patch.update_props(base_path, new_props))

        # Compare children using keyed algorithm for efficiency
        old_children = old_node.children if hasattr(old_node, 'children') else []
        new_children = new_node.children if hasattr(new_node, 'children') else []

        child_patches = self._diff_children(old_children, new_children, base_path)
        patches.extend(child_patches)

        return patches

    def _diff_children(self, old_children: list[VDOMNode], new_children: list[VDOMNode], base_path: str) -> list[Patch]:
        """Diff child lists using key-based algorithm."""
        patches: list[Patch] = []

        # Build key maps
        old_keyed: dict[str, tuple[int, VDOMNode]] = {}
        old_unkeyed: list[tuple[int, VDOMNode]] = []
        new_keyed: dict[str, tuple[int, VDOMNode]] = {}
        new_unkeyed: list[tuple[int, VDOMNode]] = []

        for i, child in enumerate(old_children):
            if hasattr(child, 'key') and child.key is not None:
                old_keyed[child.key] = (i, child)
            else:
                old_unkeyed.append((i, child))

        for i, child in enumerate(new_children):
            if hasattr(child, 'key') and child.key is not None:
                new_keyed[child.key] = (i, child)
            else:
                new_unkeyed.append((i, child))

        # Handle keyed children
        handled_keys: set[str] = set()

        for key, (new_index, new_child) in new_keyed.items():
            if key in old_keyed:
                old_index, old_child = old_keyed[key]
                handled_keys.add(key)

                # Check if position changed
                if old_index != new_index:
                    patches.append(Patch.move_node(f"{base_path}.{key}", new_index))

                # Diff the child
                child_patches = self._diff_subtrees(old_child, new_child, f"{base_path}.{key}")
                patches.extend(child_patches)
            else:
                # New keyed child
                patches.append(Patch.add_node(new_child))

        # Handle removed keyed children
        for key in set(old_keyed.keys()) - handled_keys:
            patches.append(Patch.remove_node(f"{base_path}.{key}"))

        # Handle unkeyed children with simple diff
        max_len = max(len(old_unkeyed), len(new_unkeyed))
        for i in range(max_len):
            old_child = old_unkeyed[i][1] if i < len(old_unkeyed) else None
            new_child = new_unkeyed[i][1] if i < len(new_unkeyed) else None

            if old_child is None and new_child is not None:
                patches.append(Patch.add_node(new_child))
            elif old_child is not None and new_child is None:
                patches.append(Patch.remove_node(f"{base_path}.child_{i}"))
            elif old_child is not None and new_child is not None:
                child_patches = self._diff_subtrees(old_child, new_child, f"{base_path}.child_{i}")
                patches.extend(child_patches)

        return patches

    def _tree_size(self, tree: VDOMTree) -> int:
        """Calculate tree size."""
        def count_nodes(node: VDOMNode) -> int:
            if node is None:
                return 0
            count = 1
            if hasattr(node, 'children') and node.children:
                for child in node.children:
                    count += count_nodes(child)
            return count

        return count_nodes(tree.root)


class KeyedDiff:
    """Key-based diffing algorithm optimized for lists with stable keys."""

    def __init__(self) -> None:
        """Initialize keyed diff algorithm."""
        self._lock = RLock()

    def diff(self, old_tree: VDOMTree, new_tree: VDOMTree) -> list[Patch]:
        """Perform key-based diff between trees."""
        with self._lock:
            try:
                logger.debug("Starting keyed diff")

                # Build key-to-node mappings
                old_keys = self._build_key_map(old_tree)
                new_keys = self._build_key_map(new_tree)

                patches: list[Patch] = []
                processed_keys: set[str] = set()

                # Find moved, added, and updated nodes
                for key, new_node in new_keys.items():
                    if key in old_keys:
                        processed_keys.add(key)
                        old_node = old_keys[key]

                        # Check if position changed
                        if old_node['position'] != new_node['position']:
                            patches.append(Patch.move_node(key, new_node['position']))

                        # Diff node content if changed
                        if not self._nodes_equal(old_node['node'], new_node['node']):
                            content_patches = self._diff_node_content(old_node['node'], new_node['node'], key)
                            patches.extend(content_patches)
                    else:
                        # New node
                        patches.append(Patch.add_node(new_node['node']))

                # Find removed nodes
                for key in set(old_keys.keys()) - processed_keys:
                    patches.append(Patch.remove_node(key))

                logger.debug(f"Generated {len(patches)} keyed patches")
                return patches

            except Exception as e:
                logger.error(f"Keyed diff failed: {e}")
                raise DiffingError(f"Keyed diffing failed: {e}") from e

    def _build_key_map(self, tree: VDOMTree) -> dict[str, dict[str, VDOMNode | str | int]]:
        """Build mapping of keys to nodes with positions."""
        key_map: dict[str, dict[str, VDOMNode | str | int]] = {}

        def traverse(node: VDOMNode, path: str = "", position: int = 0) -> int:
            if node is None:
                return position

            current_path = f"{path}.{node.component_name}" if path else node.component_name

            if hasattr(node, 'key') and node.key is not None:
                key_map[node.key] = {
                    'node': node,
                    'path': current_path,
                    'position': position
                }

            pos = position
            if hasattr(node, 'children') and node.children:
                for child in node.children:
                    pos = traverse(child, current_path, pos)
            return pos + 1

        traverse(tree.root)
        return key_map

    def _nodes_equal(self, node1: VDOMNode, node2: VDOMNode) -> bool:
        """Check if two nodes are equal."""
        if node1.component_name != node2.component_name:
            return False

        # Compare props
        props1 = getattr(node1, 'props', {}) or {}
        props2 = getattr(node2, 'props', {}) or {}
        if props1 != props2:
            return False

        # Compare children count
        children1 = getattr(node1, 'children', []) or []
        children2 = getattr(node2, 'children', []) or []
        if len(children1) != len(children2):
            return False

        return True

    def _diff_node_content(self, old_node: VDOMNode, new_node: VDOMNode, path: str) -> list[Patch]:
        """Diff content of two nodes."""
        patches: list[Patch] = []

        # Props diff
        old_props = getattr(old_node, 'props', {}) or {}
        new_props = getattr(new_node, 'props', {}) or {}
        if old_props != new_props:
            patches.append(Patch.update_props(path, new_props))

        # Children diff using recursive approach
        old_children = getattr(old_node, 'children', []) or []
        new_children = getattr(new_node, 'children', []) or []

        # Simple positional diff for children
        max_len = max(len(old_children), len(new_children))
        for i in range(max_len):
            old_child = old_children[i] if i < len(old_children) else None
            new_child = new_children[i] if i < len(new_children) else None

            child_path = f"{path}.child_{i}"

            if old_child is None and new_child is not None:
                patches.append(Patch.add_node(new_child))
            elif old_child is not None and new_child is None:
                patches.append(Patch.remove_node(child_path))
            elif old_child is not None and new_child is not None:
                if not self._nodes_equal(old_child, new_child):
                    child_patches = self._diff_node_content(old_child, new_child, child_path)
                    patches.extend(child_patches)

        return patches


class SimpleDiff:
    """Simple recursive diffing algorithm for basic use cases."""

    def __init__(self) -> None:
        """Initialize simple diff algorithm."""
        self._lock = RLock()

    def diff(self, old_tree: VDOMTree, new_tree: VDOMTree) -> list[Patch]:
        """Perform simple recursive diff."""
        with self._lock:
            try:
                logger.debug("Starting simple diff")
                return self._diff_recursive(old_tree.root, new_tree.root, "")

            except Exception as e:
                logger.error(f"Simple diff failed: {e}")
                raise DiffingError(f"Simple diffing failed: {e}") from e

    def _diff_recursive(self, old_node: VDOMNode, new_node: VDOMNode, path: str) -> list[Patch]:
        """Recursively diff two nodes."""
        patches: list[Patch] = []

        if old_node is None and new_node is None:
            return patches

        if old_node is None and new_node is not None:
            patches.append(Patch.add_node(new_node))
            return patches

        if old_node is not None and new_node is None:
            patches.append(Patch.remove_node(path))
            return patches

        # Compare node types
        if old_node.component_name != new_node.component_name:
            patches.append(Patch.replace_root(new_node))
            return patches

        # Compare properties
        old_props = getattr(old_node, 'props', {}) or {}
        new_props = getattr(new_node, 'props', {}) or {}
        if old_props != new_props:
            patches.append(Patch.update_props(path, new_props))

        # Compare children
        old_children = getattr(old_node, 'children', []) or []
        new_children = getattr(new_node, 'children', []) or []

        max_children = max(len(old_children), len(new_children))
        for i in range(max_children):
            child_path = f"{path}.child_{i}" if path else f"child_{i}"

            old_child = old_children[i] if i < len(old_children) else None
            new_child = new_children[i] if i < len(new_children) else None

            child_patches = self._diff_recursive(old_child, new_child, child_path)
            patches.extend(child_patches)

        return patches