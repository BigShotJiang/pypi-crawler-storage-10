"""Patch data structures for diffing operations."""

from dataclasses import dataclass
from enum import Enum
from typing import Any


class PatchType(Enum):
    """Types of diffing patches."""

    ADD_NODE = "add_node"
    REMOVE_NODE = "remove_node"
    UPDATE_PROPS = "update_props"
    REPLACE_ROOT = "replace_root"
    MOVE_NODE = "move_node"


@dataclass(slots=True)
class Patch:
    """Represents a single patch operation."""

    patch_type: PatchType
    key: str | None = None
    data: Any = None

    @classmethod
    def add_node(cls, node: object) -> Patch:
        """Create an add node patch."""
        return cls(PatchType.ADD_NODE, key=getattr(node, "key", None), data=node)

    @classmethod
    def remove_node(cls, key: str) -> Patch:
        """Create a remove node patch."""
        return cls(PatchType.REMOVE_NODE, key=key)

    @classmethod
    def update_props(cls, key: str, props: dict[str, Any]) -> Patch:
        """Create an update properties patch."""
        return cls(PatchType.UPDATE_PROPS, key=key, data=props)

    @classmethod
    def move_node(cls, key: str, position: int) -> Patch:
        """Create a move node patch."""
        return cls(PatchType.MOVE_NODE, key=key, data=position)

    @classmethod
    def replace_root(cls, new_root: object) -> Patch:
        """Create a replace root patch."""
        return cls(PatchType.REPLACE_ROOT, data=new_root)
