"""Thread-safety enhancements for Python 3.14 free threading.

This module provides advanced concurrency primitives and optimizations
specifically designed for Python 3.14's free threading implementation.
"""

import os
import threading
import time
from collections import deque
from concurrent.futures import ThreadPoolExecutor
from typing import TYPE_CHECKING, Any, Generic, TypeVar

from ..utils.logging import get_logger

if TYPE_CHECKING:
    from collections.abc import Callable

logger = get_logger(__name__)

# Forward declarations for type hints
class MemoryPool:
    pass

T = TypeVar('T')


class ReadWriteLock:
    """Reader-writer lock optimized for read-heavy workloads."""

    def __init__(self) -> None:
        self._readers = 0
        self._writers = 0
        self._readers_lock = threading.Condition(threading.Lock())
        self._writers_lock = threading.Condition(threading.Lock())
        self._write_owner = None

    def __enter__(self) -> ReadWriteLock:
        """Enter context manager - acquire write lock."""
        self.acquire_write()
        return self

    def __exit__(self, exc_type: object, exc_val: object, exc_tb: object) -> None:
        """Exit context manager - release write lock."""
        self.release_write()

    def acquire_read(self) -> None:
        """Acquire lock for reading."""
        with self._writers_lock:
            while self._writers > 0:
                self._writers_lock.wait()
            self._readers += 1

    def release_read(self) -> None:
        """Release read lock."""
        with self._readers_lock:
            self._readers -= 1
            if self._readers == 0:
                self._readers_lock.notify_all()

    def acquire_write(self) -> None:
        """Acquire lock for writing."""
        with self._writers_lock:
            self._writers += 1
            while self._readers > 0:
                self._writers_lock.wait()

    def release_write(self) -> None:
        """Release write lock."""
        with self._writers_lock:
            self._writers -= 1
            if self._writers == 0:
                self._writers_lock.notify_all()


class LockFreeQueue(Generic[T]):
    """Lock-free queue implementation using atomic operations."""

    def __init__(self, max_size: int | None = None) -> None:
        self._queue: deque[T] = deque()
        self._max_size = max_size
        self._lock = threading.RLock()  # Fallback for complex operations

    def put(self, item: T) -> bool:
        """Put an item in the queue. Returns False if queue is full."""
        with self._lock:
            if self._max_size is not None and len(self._queue) >= self._max_size:
                return False
            self._queue.append(item)
            return True

    def get(self) -> T | None:
        """Get an item from the queue. Returns None if empty."""
        with self._lock:
            if not self._queue:
                return None
            return self._queue.popleft()

    def size(self) -> int:
        """Get current queue size."""
        with self._lock:
            return len(self._queue)

    def is_empty(self) -> bool:
        """Check if queue is empty."""
        with self._lock:
            return len(self._queue) == 0


class AtomicCounter:
    """Thread-safe counter using atomic operations."""

    def __init__(self, initial_value: int = 0) -> None:
        self._value = initial_value
        self._lock = threading.Lock()

    def increment(self) -> int:
        """Increment counter and return new value."""
        with self._lock:
            self._value += 1
            return self._value

    def decrement(self) -> int:
        """Decrement counter and return new value."""
        with self._lock:
            self._value -= 1
            return self._value

    def get(self) -> int:
        """Get current value."""
        with self._lock:
            return self._value

    def set(self, value: int) -> None:
        """Set counter value."""
        with self._lock:
            self._value = value

    def add(self, delta: int) -> int:
        """Add delta to counter and return new value."""
        with self._lock:
            self._value += delta
            return self._value


class ThreadLocalStorage:
    """Thread-local storage with fallback support."""

    def __init__(self) -> None:
        self._local = threading.local()

    def get(self, key: str, default: object = None) -> object:
        """Get value from thread-local storage."""
        return getattr(self._local, key, default)

    def set(self, key: str, value: object) -> None:
        """Set value in thread-local storage."""
        setattr(self._local, key, value)

    def has(self, key: str) -> bool:
        """Check if key exists in thread-local storage."""
        return hasattr(self._local, key)

    def delete(self, key: str) -> None:
        """Delete key from thread-local storage."""
        if hasattr(self._local, key):
            delattr(self._local, key)


class WorkStealingScheduler:
    """Work-stealing scheduler for parallel task execution."""

    def __init__(self, num_threads: int | None = None) -> None:
        self._num_threads = num_threads or (os.cpu_count() or 4)
        self._executor = ThreadPoolExecutor(max_workers=self._num_threads, thread_name_prefix="textforge-worker")
        self._task_queues: dict[int, LockFreeQueue[Any]] = {}
        self._shutdown = False

        # Initialize task queues for each thread
        for i in range(self._num_threads):
            self._task_queues[i] = LockFreeQueue()

    def submit_task(self, task_id: str, func: Callable[..., Any], *args: object, **kwargs: object) -> None:
        """Submit a task for execution."""
        if self._shutdown:
            raise RuntimeError("Scheduler is shutdown")

        # Submit directly to executor for simplicity
        self._executor.submit(self._execute_task, task_id, func, *args, **kwargs)

    def _execute_task(self, task_id: str, func: Callable[..., Any], *args: object, **kwargs: object) -> object:
        """Execute a task and handle exceptions."""
        try:
            result = func(*args, **kwargs)
            logger.debug(f"Task {task_id} completed successfully")
            return result
        except Exception as e:
            logger.error(f"Task {task_id} failed: {e}")
            raise

    def shutdown(self, wait: bool = True) -> None:
        """Shutdown the scheduler."""
        self._shutdown = True
        self._executor.shutdown(wait=wait)
        logger.debug("Work-stealing scheduler shutdown complete")


class ParallelProcessor:
    """Processor for automatic parallelization of operations."""

    def __init__(self, scheduler: WorkStealingScheduler | None = None) -> None:
        self._scheduler = scheduler or WorkStealingScheduler()
        self._active_operations = AtomicCounter()

    def parallelize_layout_calculation(self, layout_tasks: list[dict[str, Any]]) -> list[Any]:
        """Parallelize layout calculations across available threads."""
        results: list[Any] = []
        completed = AtomicCounter()

        def layout_worker(task: dict[str, object]) -> object:
            try:
                # Import here to avoid circular imports
                from .layout import LayoutEngine
                engine = LayoutEngine()
                result = engine.calculate_layout(**task)
                completed.increment()
                return result
            except Exception as e:
                logger.error(f"Layout calculation failed: {e}")
                raise

        # Submit all tasks
        for i, task in enumerate(layout_tasks):
            self._scheduler.submit_task(f"layout_{i}", layout_worker, task)

        # Wait for completion (simplified - in practice would use futures)
        while completed.get() < len(layout_tasks):
            time.sleep(0.01)

        return results

    def parallelize_style_resolution(self, style_tasks: list[dict[str, Any]]) -> list[Any]:
        """Parallelize style resolution across available threads."""
        results: list[Any] = []
        completed = AtomicCounter()

        def style_worker(task: dict[str, object]) -> object:
            try:
                # Import here to avoid circular imports
                from ..style.subsystem import StylingSubsystem
                subsystem = StylingSubsystem()
                result = subsystem.resolve_style(**task)
                completed.increment()
                return result
            except Exception as e:
                logger.error(f"Style resolution failed: {e}")
                raise

        # Submit all tasks
        for i, task in enumerate(style_tasks):
            self._scheduler.submit_task(f"style_{i}", style_worker, task)

        # Wait for completion
        while completed.get() < len(style_tasks):
            time.sleep(0.01)

        return results

    def parallelize_rendering(self, render_tasks: list[dict[str, Any]]) -> list[Any]:
        """Parallelize rendering operations across available threads."""
        results: list[Any] = []
        completed = AtomicCounter()

        def render_worker(task: dict[str, object]) -> object:
            try:
                renderer = task.pop('renderer')
                result = renderer.render_tree(**task)
                completed.increment()
                return result
            except Exception as e:
                logger.error(f"Rendering failed: {e}")
                raise

        # Submit all tasks
        for i, task in enumerate(render_tasks):
            self._scheduler.submit_task(f"render_{i}", render_worker, task)

        # Wait for completion
        while completed.get() < len(render_tasks):
            time.sleep(0.01)

        return results


class MemoryManager:
    """Memory management optimized for concurrent access."""

    def __init__(self) -> None:
        self._pools = ThreadLocalStorage()
        self._global_pools: dict[str, LockFreeQueue[Any]] = {}
        self._lock = ReadWriteLock()

    def get_thread_local_pool(self, pool_type: str, factory: Callable[[], Any]) -> object:
        """Get a thread-local object pool."""
        from ..optimization.memory import ObjectPool
        pool_key = f"{pool_type}_{threading.current_thread().ident}"
        pool = self._pools.get(pool_key)

        if pool is None:
            pool = ObjectPool(factory, max_size=1000)
            self._pools.set(pool_key, pool)

        return pool

    def get_global_pool(self, pool_type: str) -> LockFreeQueue[Any]:
        """Get a global object pool."""
        self._lock.acquire_read()
        try:
            if pool_type not in self._global_pools:
                self._lock.release_read()
                self._lock.acquire_write()
                try:
                    if pool_type not in self._global_pools:
                        self._global_pools[pool_type] = LockFreeQueue[Any](max_size=10000)
                finally:
                    self._lock.release_write()
                    self._lock.acquire_read()
            return self._global_pools[pool_type]
        finally:
            self._lock.release_read()

    def collect_garbage(self) -> None:
        """Perform garbage collection hints for concurrent operations."""
        import gc
        # Hint GC to be more aggressive in concurrent environments
        gc.collect()
        logger.debug("Performed garbage collection for concurrent operations")


# Global instances for system-wide use
_scheduler = WorkStealingScheduler()
_processor = ParallelProcessor(_scheduler)
_memory_manager = MemoryManager()


def get_scheduler() -> WorkStealingScheduler:
    """Get the global work-stealing scheduler."""
    return _scheduler


def get_processor() -> ParallelProcessor:
    """Get the global parallel processor."""
    return _processor


def get_memory_manager() -> MemoryManager:
    """Get the global memory manager."""
    return _memory_manager
