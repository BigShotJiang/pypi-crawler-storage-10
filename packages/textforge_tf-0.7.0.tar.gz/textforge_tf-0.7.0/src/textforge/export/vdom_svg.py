"""SVG export renderer for vector graphics output."""

from __future__ import annotations

import math
from threading import RLock
from typing import TYPE_CHECKING, Sequence

from ..core.layout.types import Bounds, RendererType
from ..renderers.base import Renderer, RenderingError, RenderOutput
from ..utils.logging import get_logger

if TYPE_CHECKING:
    from collections.abc import Callable

    from ..core.layout.engine import LayoutResult
    from ..core.vdom.tree import VDOMTree

logger = get_logger(__name__)


class SVGRenderer(Renderer):
    """Renderer for SVG vector graphics export with full component support."""

    def __init__(self) -> None:
        """Initialize the SVG renderer."""
        super().__init__(RendererType.SVG)
        self._svg_buffer: list[str] = []
        self._render_lock = RLock()
        self._defs_buffer: list[str] = []
        self._id_counter = 0
        logger.debug("Initialized SVGRenderer")

    def render_tree(self, tree: VDOMTree, layout_result: LayoutResult) -> RenderOutput:
        """Render VDOM tree to SVG format.

        Args:
            tree: The VDOM tree to render.
            layout_result: The layout result containing positioning information.

        Returns:
            RenderOutput containing the SVG content and metadata.

        Raises:
            RenderingError: If rendering fails.
        """
        try:
            with self._render_lock:
                logger.debug(f"Rendering VDOM tree to SVG with {len(tree._key_map)} nodes")

                self._svg_buffer.clear()
                self._defs_buffer.clear()
                self._id_counter = 0

                # Start SVG document
                self._start_svg_document(layout_result)

                # Render SVG content
                self._render_svg_content(tree, layout_result)

                # End SVG document
                self._end_svg_document()

                svg_content = "".join(self._svg_buffer)
                return RenderOutput(
                    content=svg_content,
                    renderer_type=self.renderer_type,
                    metadata={
                        "format": "svg",
                        "vector": True,
                        "width": layout_result.width,
                        "height": layout_result.height
                    }
                )

        except Exception as e:
            logger.error(f"SVG rendering failed: {e}")
            raise RenderingError(f"Failed to render SVG: {e}") from e

    def apply_patches(self, patches: Sequence[object]) -> None:
        """Apply patches to SVG (not typically used for exports).

        Args:
            patches: List of patches to apply (ignored for SVG exports).
        """
        with self._render_lock:
            logger.debug("SVG patches applied (no-op for exports)")

    def _start_svg_document(self, layout_result: LayoutResult) -> None:
        """Start SVG document with proper headers and viewBox.

        Args:
            layout_result: The layout result to determine SVG dimensions.
        """
        width = layout_result.width
        height = layout_result.height

        self._svg_buffer.append('<?xml version="1.0" encoding="UTF-8"?>\n')
        self._svg_buffer.append(
            f'<svg xmlns="http://www.w3.org/2000/svg" version="1.1" '
            f'width="{width}" height="{height}" viewBox="0 0 {width} {height}">\n'
        )

        # Add defs section for reusable elements
        self._svg_buffer.append('  <defs>\n')
        self._svg_buffer.extend(self._defs_buffer)
        self._svg_buffer.append('  </defs>\n')

    def _end_svg_document(self) -> None:
        """End SVG document."""
        self._svg_buffer.append('</svg>\n')

    def _render_svg_content(self, tree: VDOMTree, layout_result: LayoutResult) -> None:
        """Render VDOM tree content as SVG elements.

        Args:
            tree: The VDOM tree to render.
            layout_result: The layout result with positioning.
        """
        if tree.root is None:
            logger.warning("VDOM tree has no root node")
            return

        def render_node(node: object, bounds: Bounds) -> None:
            """Recursively render a VDOM node to SVG.

            Args:
                node: The VDOM node to render.
                bounds: The bounds for this node.
            """
            # Convert bounds to renderer units
            svg_bounds = bounds.to_renderer_units(RendererType.SVG)

            # Get component renderer
            renderer_func = self._get_component_renderer(getattr(node, 'component_name', 'unknown'))
            if renderer_func:
                svg_elements = renderer_func(node, svg_bounds)
                self._svg_buffer.extend(svg_elements)

            # Render children with their layout bounds
            if hasattr(node, 'children') and node.children:
                # For now, use simple bounds division - in practice this would use actual layout
                child_bounds = self._calculate_child_bounds(node.children, svg_bounds)
                for child, child_bound in zip(node.children, child_bounds):
                    render_node(child, child_bound)

        # Start rendering from root
        root_bounds = Bounds(0, 0, layout_result.width, layout_result.height)
        render_node(tree.root, root_bounds)

    def _get_component_renderer(self, component_name: str) -> Callable[[object, Bounds], list[str]] | None:
        """Get the SVG renderer function for a component type.

        Args:
            component_name: Name of the component type.

        Returns:
            Renderer function or None if not supported.
        """
        renderers = {
            "text": self._render_text_component,
            "box": self._render_box_component,
            "panel": self._render_panel_component,
            "button": self._render_button_component,
            "divider": self._render_divider_component,
            "progress_bar": self._render_progress_bar_component,
            "gauge": self._render_gauge_component,
            "image": self._render_image_component,
            "canvas": self._render_canvas_component,
        }

        renderer = renderers.get(component_name)
        if renderer is None:
            logger.warning(f"No SVG renderer for component type: {component_name}")
        return renderer

    def _render_text_component(self, node: object, bounds: Bounds) -> list[str]:
        """Render a text component to SVG.

        Args:
            node: The text component node.
            bounds: The bounds for the text.

        Returns:
            List of SVG element strings.
        """
        content = getattr(node, 'props', {}).get('content', '')
        if not content:
            return []

        # Basic text rendering - in practice would handle styling
        x = bounds.x + 2  # Small padding
        y = bounds.y + bounds.height / 2  # Vertical center

        return [
            f'  <text x="{x}" y="{y}" font-family="Arial, sans-serif" '
            f'font-size="12" fill="black" dominant-baseline="middle">{self._escape_xml(content)}</text>\n'
        ]

    def _render_box_component(self, node: object, bounds: Bounds) -> list[str]:
        """Render a box component to SVG.

        Args:
            node: The box component node.
            bounds: The bounds for the box.

        Returns:
            List of SVG element strings.
        """
        elements: list[str] = []

        # Render background rectangle
        elements.append(
            f'  <rect x="{bounds.x}" y="{bounds.y}" width="{bounds.width}" height="{bounds.height}" '
            f'fill="#f0f0f0" stroke="#cccccc" stroke-width="1" rx="4"/>\n'
        )

        # Render border
        elements.append(
            f'  <rect x="{bounds.x}" y="{bounds.y}" width="{bounds.width}" height="{bounds.height}" '
            f'fill="none" stroke="#999999" stroke-width="1" rx="4"/>\n'
        )

        return elements

    def _render_panel_component(self, node: object, bounds: Bounds) -> list[str]:
        """Render a panel component to SVG.

        Args:
            node: The panel component node.
            bounds: The bounds for the panel.

        Returns:
            List of SVG element strings.
        """
        elements: list[str] = []

        # Panel background
        elements.append(
            f'  <rect x="{bounds.x}" y="{bounds.y}" width="{bounds.width}" height="{bounds.height}" '
            f'fill="#ffffff" stroke="#666666" stroke-width="2" rx="8"/>\n'
        )

        # Panel title bar
        title_height = 24
        elements.append(
            f'  <rect x="{bounds.x}" y="{bounds.y}" width="{bounds.width}" height="{title_height}" '
            f'fill="#e0e0e0" stroke="none" rx="8"/>\n'
        )

        # Title text
        title = getattr(node, 'props', {}).get('title', 'Panel')
        elements.append(
            f'  <text x="{bounds.x + 8}" y="{bounds.y + 16}" font-family="Arial, sans-serif" '
            f'font-size="14" font-weight="bold" fill="#333333">{self._escape_xml(title)}</text>\n'
        )

        return elements

    def _render_button_component(self, node: object, bounds: Bounds) -> list[str]:
        """Render a button component to SVG.

        Args:
            node: The button component node.
            bounds: The bounds for the button.

        Returns:
            List of SVG element strings.
        """
        elements: list[str] = []

        # Button background
        elements.append(
            f'  <rect x="{bounds.x}" y="{bounds.y}" width="{bounds.width}" height="{bounds.height}" '
            f'fill="#007acc" stroke="#005999" stroke-width="1" rx="6"/>\n'
        )

        # Button text
        text = getattr(node, 'props', {}).get('text', 'Button')
        text_x = bounds.x + bounds.width / 2
        text_y = bounds.y + bounds.height / 2

        elements.append(
            f'  <text x="{text_x}" y="{text_y}" text-anchor="middle" font-family="Arial, sans-serif" '
            f'font-size="12" font-weight="bold" fill="white" dominant-baseline="middle">{self._escape_xml(text)}</text>\n'
        )

        return elements

    def _render_divider_component(self, node: object, bounds: Bounds) -> list[str]:
        """Render a divider component to SVG.

        Args:
            node: The divider component node.
            bounds: The bounds for the divider.

        Returns:
            List of SVG element strings.
        """
        # Horizontal line
        y = bounds.y + bounds.height / 2
        return [
            f'  <line x1="{bounds.x}" y1="{y}" x2="{bounds.x + bounds.width}" y2="{y}" '
            f'stroke="#cccccc" stroke-width="1"/>\n'
        ]

    def _render_progress_bar_component(self, node: object, bounds: Bounds) -> list[str]:
        """Render a progress bar component to SVG.

        Args:
            node: The progress bar component node.
            bounds: The bounds for the progress bar.

        Returns:
            List of SVG element strings.
        """
        elements: list[str] = []

        # Background
        elements.append(
            f'  <rect x="{bounds.x}" y="{bounds.y}" width="{bounds.width}" height="{bounds.height}" '
            f'fill="#e0e0e0" stroke="#cccccc" stroke-width="1" rx="2"/>\n'
        )

        # Progress fill
        progress = getattr(node, 'props', {}).get('progress', 0.0)
        progress = max(0.0, min(1.0, progress))  # Clamp to [0, 1]
        fill_width = bounds.width * progress

        if fill_width > 0:
            elements.append(
                f'  <rect x="{bounds.x}" y="{bounds.y}" width="{fill_width}" height="{bounds.height}" '
                f'fill="#4caf50" rx="2"/>\n'
            )

        return elements

    def _render_gauge_component(self, node: object, bounds: Bounds) -> list[str]:
        """Render a gauge component to SVG.

        Args:
            node: The gauge component node.
            bounds: The bounds for the gauge.

        Returns:
            List of SVG element strings.
        """
        elements: list[str] = []

        # Calculate center and radius
        center_x = bounds.x + bounds.width / 2
        center_y = bounds.y + bounds.height / 2
        radius = min(bounds.width, bounds.height) / 2 - 4

        # Background circle
        elements.append(
            f'  <circle cx="{center_x}" cy="{center_y}" r="{radius}" '
            f'fill="#f0f0f0" stroke="#cccccc" stroke-width="2"/>\n'
        )

        # Progress arc
        value = getattr(node, 'props', {}).get('value', 0.0)
        value = max(0.0, min(1.0, value))  # Clamp to [0, 1]

        if value > 0:
            # Draw progress arc
            start_angle = -90  # Start from top
            end_angle = start_angle + (value * 360)

            # Convert to radians
            start_rad = math.radians(start_angle)
            end_rad = math.radians(end_angle)

            # Calculate arc path
            x1 = center_x + radius * math.cos(start_rad)
            y1 = center_y + radius * math.sin(start_rad)
            x2 = center_x + radius * math.cos(end_rad)
            y2 = center_y + radius * math.sin(end_rad)

            large_arc = 1 if value > 0.5 else 0

            path = f'M {x1} {y1} A {radius} {radius} 0 {large_arc} 1 {x2} {y2}'
            elements.append(
                f'  <path d="{path}" fill="none" stroke="#2196f3" stroke-width="4" '
                f'stroke-linecap="round"/>\n'
            )

        return elements

    def _render_image_component(self, node: object, bounds: Bounds) -> list[str]:
        """Render an image component to SVG.

        Args:
            node: The image component node.
            bounds: The bounds for the image.

        Returns:
            List of SVG element strings.
        """
        # For SVG export, we can embed images as data URIs or reference external URLs
        src = getattr(node, 'props', {}).get('src', '')

        if not src:
            # Placeholder rectangle
            return [
                f'  <rect x="{bounds.x}" y="{bounds.y}" width="{bounds.width}" height="{bounds.height}" '
                f'fill="#cccccc" stroke="#999999" stroke-width="1"/>\n',
                f'  <text x="{bounds.x + bounds.width/2}" y="{bounds.y + bounds.height/2}" '
                f'text-anchor="middle" font-family="Arial, sans-serif" font-size="10" fill="#666666" '
                f'dominant-baseline="middle">Image</text>\n'
            ]

        # For external images, use SVG image element
        return [
            f'  <image x="{bounds.x}" y="{bounds.y}" width="{bounds.width}" height="{bounds.height}" '
            f'href="{self._escape_xml(src)}"/>\n'
        ]

    def _render_canvas_component(self, node: object, bounds: Bounds) -> list[str]:
        """Render a canvas component to SVG.

        Args:
            node: The canvas component node.
            bounds: The bounds for the canvas.

        Returns:
            List of SVG element strings.
        """
        # Canvas background
        return [
            f'  <rect x="{bounds.x}" y="{bounds.y}" width="{bounds.width}" height="{bounds.height}" '
            f'fill="white" stroke="#cccccc" stroke-width="1"/>\n'
        ]

    def _calculate_child_bounds(self, children: list[object], parent_bounds: Bounds) -> list[Bounds]:
        """Calculate bounds for child components.

        Args:
            children: List of child nodes.
            parent_bounds: Bounds of the parent.

        Returns:
            List of bounds for each child.
        """
        if not children:
            return []

        # Simple vertical stacking for now
        child_height = parent_bounds.height / len(children)
        bounds_list: list[Bounds] = []

        for i, child in enumerate(children):
            child_bounds = Bounds(
                x=parent_bounds.x,
                y=parent_bounds.y + i * child_height,
                width=parent_bounds.width,
                height=child_height
            )
            bounds_list.append(child_bounds)

        return bounds_list

    def _escape_xml(self, text: str) -> str:
        """Escape XML special characters.

        Args:
            text: Text to escape.

        Returns:
            XML-escaped text.
        """
        return (text.replace('&', '&')
                .replace('<', '<')
                .replace('>', '>')
                .replace('"', '"')
                .replace("'", "'"))

    def _generate_id(self) -> str:
        """Generate a unique ID for SVG elements.

        Returns:
            Unique ID string.
        """
        self._id_counter += 1
        return f"svg_{self._id_counter}"