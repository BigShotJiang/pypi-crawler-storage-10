"""Plain text export renderer."""

from __future__ import annotations

from threading import RLock

from ...utils.logging import get_logger
from ..base import Renderer, RenderOutput

logger = get_logger(__name__)


class PlainTextRenderer(Renderer):
    """Renderer for plain text export."""

    def __init__(self) -> None:
        super().__init__("plain")
        self._text_buffer: list[str] = []
        self._render_lock = RLock()
        logger.debug("Initialized PlainTextRenderer")

    def render_tree(self, tree: object, layout_result: object) -> RenderOutput:
        """Render VDOM tree to plain text format."""
        with self._render_lock:
            self._text_buffer.clear()

            # Render plain text content
            self._render_plain_content(tree, layout_result)

            text_content = "".join(self._text_buffer)
            return RenderOutput(content=text_content, renderer_type="plain", metadata={"format": "text", "encoding": "utf-8"})

    def apply_patches(self, patches: list[object]) -> None:
        """Apply patches to plain text (not typically used for exports)."""
        with self._render_lock:
            # Plain text exports are typically static
            logger.debug("Plain text patches applied (no-op for exports)")

    def _render_plain_content(self, tree: object, layout_result: object) -> None:
        """Render content as plain text."""
        # Placeholder plain text content
        self._text_buffer.append("Plain text export\n")
        self._text_buffer.append("=================\n\n")
        self._text_buffer.append("This is exported content without formatting.\n")