"""Export utilities (HTML, SVG, PDF, and render-tree helpers)."""

from __future__ import annotations

from importlib import import_module

from .html import ansi_to_html
from .pdf import ansi_to_pdf
from .plain import ansi_to_text
from .svg import ansi_to_svg

__all__ = [
    "ansi_to_html",
    "ansi_to_svg",
    "ansi_to_text",
    "ansi_to_pdf",
    "HTMLRenderer",
    "PDFRenderer",
    "PlainTextRenderer",
    "SVGRenderer",
]


def __getattr__(name: str) -> object:
    if name in {
        "HTMLRenderer",
        "PDFRenderer",
        "PlainTextRenderer",
        "SVGRenderer",
    }:
        module = import_module(f"textforge.export.vdom_{name.split('Renderer')[0].lower()}")
        attr = getattr(module, name)
        globals()[name] = attr
        return attr
    raise AttributeError(f"module 'textforge.export' has no attribute '{name}'")
