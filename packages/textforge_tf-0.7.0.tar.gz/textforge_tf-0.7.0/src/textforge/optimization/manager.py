"""Optimization manager for Textforge performance optimizations."""

import threading
import time
from typing import TYPE_CHECKING, Any

from ..utils.logging import get_logger

if TYPE_CHECKING:
    from collections.abc import Callable

logger = get_logger(__name__)

# Import additional optimization modules
try:
    from .acceleration import AccelerationManager
    from .memory.zero_copy import BufferPool, ZeroCopyRenderer
    from .reactivity import ReactiveSystem
    _reactivity_available = True
except ImportError:
    logger.warning("Advanced optimization modules not available")
    ReactiveSystem = None
    AccelerationManager = None
    BufferPool = None
    ZeroCopyRenderer = None
    _reactivity_available = False


class OptimizationError(Exception):
    """Base exception for optimization errors."""

    pass


class CythonNotAvailableError(OptimizationError):
    """Raised when Cython is not available."""

    pass


class MemoryPool:
    """Memory pool for object reuse."""

    def __init__(self, object_type: type, max_size: int = 1000) -> None:
        self.object_type = object_type
        self.max_size = max_size
        self._pool: list[Any] = []
        self._lock = threading.RLock()

    def acquire(self) -> object:
        """Acquire an object from the pool."""
        with self._lock:
            if self._pool:
                return self._pool.pop()
            return self.object_type()

    def release(self, obj: object) -> None:
        """Release an object back to the pool."""
        with self._lock:
            if len(self._pool) < self.max_size:
                self._pool.append(obj)


class ProfilingResult:
    """Result of a profiling operation."""

    def __init__(self, execution_time: float, memory_usage: int, call_count: int) -> None:
        self.execution_time = execution_time
        self.memory_usage = memory_usage
        self.call_count = call_count


class OptimizationManager:
    """Manager for applying performance optimizations."""

    def __init__(self) -> None:
        self._cython_enabled = self._check_cython_available()
        self._memory_pools: dict[str, MemoryPool] = {}
        self._lock = threading.RLock()

        # Initialize advanced optimization modules if available
        self._reactive_system = None
        self._acceleration_manager = None
        self._buffer_pool = None
        self._zero_copy_renderer = None

        if _reactivity_available and ReactiveSystem is not None:
            try:
                self._reactive_system = ReactiveSystem()
                self._acceleration_manager = AccelerationManager() if AccelerationManager is not None else None
                self._buffer_pool = BufferPool() if BufferPool is not None else None
                self._zero_copy_renderer = ZeroCopyRenderer() if ZeroCopyRenderer is not None else None
                logger.debug("Advanced optimization modules initialized")
            except Exception as e:
                logger.warning(f"Failed to initialize advanced optimization modules: {e}")

    def optimize_function(self, func: Callable[..., Any]) -> Callable[..., Any]:
        """Apply optimizations to a function.

        Args:
            func: The function to optimize.

        Returns:
            The optimized function.
        """
        if self._cython_enabled:
            return self._cython_optimize(func)
        return func

    def get_memory_pool(self, pool_type: str, object_type: type, max_size: int = 1000) -> MemoryPool:
        """Get or create a memory pool for object reuse.

        Args:
            pool_type: Identifier for the pool type.
            object_type: The type of objects in the pool.
            max_size: Maximum number of objects to keep in the pool.

        Returns:
            The memory pool instance.
        """
        with self._lock:
            if pool_type not in self._memory_pools:
                self._memory_pools[pool_type] = MemoryPool(object_type, max_size)
            return self._memory_pools[pool_type]

    def profile_function(self, func: Callable[..., Any], *args: object, **kwargs: object) -> ProfilingResult:
        """Profile a function's performance with accurate memory measurement.

        Args:
            func: The function to profile.
            *args: Positional arguments for the function.
            **kwargs: Keyword arguments for the function.

        Returns:
            Profiling results.
        """
        import tracemalloc

        import psutil

        process = psutil.Process()

        # Get initial memory stats
        initial_memory_info = process.memory_info()
        initial_memory = initial_memory_info.rss

        # Start detailed memory tracing
        tracemalloc.start()

        # Get memory snapshot before execution
        snapshot1 = tracemalloc.take_snapshot()

        start_time = time.perf_counter()

        # Execute function multiple times for accurate measurement
        call_count = 10
        for _ in range(call_count):
            func(*args, **kwargs)

        end_time = time.perf_counter()

        # Get memory snapshot after execution
        snapshot2 = tracemalloc.take_snapshot()

        # Calculate memory statistics
        stats = snapshot2.compare_to(snapshot1, "lineno")
        total_memory_diff = sum(stat.size_diff for stat in stats)

        # Get final process memory
        final_memory_info = process.memory_info()
        final_memory = final_memory_info.rss
        process_memory_diff = final_memory - initial_memory

        # Use the more accurate measurement
        memory_usage = max(total_memory_diff, process_memory_diff)

        tracemalloc.stop()

        execution_time = (end_time - start_time) / call_count

        logger.debug(f"Profiled function {func.__name__}: time={execution_time:.6f}s, memory={memory_usage} bytes, calls={call_count}")

        return ProfilingResult(execution_time, memory_usage, call_count)

    def _cython_optimize(self, func: Callable[..., Any]) -> Callable[..., Any]:
        """Apply Cython optimizations to a function.

        Args:
            func: The function to optimize.

        Returns:
            The Cython-optimized function.

        Raises:
            CythonNotAvailableError: If Cython is not available.
            OptimizationError: If optimization fails.
        """
        if not self._cython_enabled:
            raise CythonNotAvailableError("Cython is not available for optimization")
        from .cython.compiler import CythonCompilationError, CythonCompiler

        try:
            # Initialize compiler if not already done
            if not hasattr(self, "_cython_compiler"):
                with self._lock:
                    if not hasattr(self, "_cython_compiler"):
                        self._cython_compiler = CythonCompiler()

            compiler = self._cython_compiler

            # Determine which Cython module to use based on function characteristics
            module_name = self._select_cython_module(func)
            if not module_name:
                logger.debug(f"No suitable Cython optimization for {func.__name__}")
                return func

            # Load or compile the Cython module
            cython_module = compiler.compile_and_load_module(f"src/textforge/optimization/cython/{module_name}.pyx", f"textforge_cython_{module_name}")

            # Get the optimized function from the module
            optimized_func = self._get_optimized_function(cython_module, func)
            if optimized_func:
                logger.debug(f"Successfully applied Cython optimization to {func.__name__}")
                return optimized_func
            else:
                logger.warning(f"Could not find optimized version for {func.__name__}")
                return func

        except CythonCompilationError as e:
            logger.warning(f"Cython compilation failed for {func.__name__}: {e}")
            return func
        except Exception as e:
            logger.error(f"Unexpected error during Cython optimization: {e}")
            raise OptimizationError(f"Cython optimization failed: {e}") from e

    def _select_cython_module(self, func: Callable[..., Any]) -> str | None:
        """Select appropriate Cython module based on function characteristics.

        Args:
            func: The function to analyze.

        Returns:
            Module name or None if no suitable module found.
        """
        func_name = func.__name__.lower()

        # Map function names/patterns to Cython modules
        if any(keyword in func_name for keyword in ["diff", "compare", "patch", "tree_hash"]):
            return "diffing_ops"
        elif any(keyword in func_name for keyword in ["text", "display", "width", "truncate", "split"]):
            return "text_ops"
        elif any(keyword in func_name for keyword in ["layout", "flex", "grid", "calculate", "position"]):
            return "layout_ops"
        elif any(keyword in func_name for keyword in ["render", "box", "table", "buffer"]):
            return "rendering_ops"
        elif any(keyword in func_name for keyword in ["color", "rgb", "hsv", "blend", "brightness"]):
            return "color_ops"

        return None

    def _get_optimized_function(self, cython_module: object, original_func: Callable[..., Any]) -> Callable[..., Any] | None:
        """Get the optimized function from a Cython module.

        Args:
            cython_module: The loaded Cython module.
            original_func: The original Python function.

        Returns:
            Optimized function or None if not found.
        """
        func_name = original_func.__name__

        # Look for optimized versions in the module
        optimized_names = [f"fast_{func_name}", f"cython_{func_name}", f"optimized_{func_name}"]

        for name in optimized_names:
            if hasattr(cython_module, name):
                return getattr(cython_module, name)

        # Try to find a class with optimized methods
        for attr_name in dir(cython_module):
            attr = getattr(cython_module, attr_name)
            if hasattr(attr, func_name):
                method = getattr(attr, func_name)
                if callable(method):
                    return method

        return None

    def apply_zero_copy_optimization(self, component_tree: object) -> object:
        """Apply zero-copy optimizations to component trees.

        Args:
            component_tree: The component tree to optimize.

        Returns:
            Optimized component tree with zero-copy operations.
        """
        from .memory.zero_copy import CopyOnWriteTree
        return CopyOnWriteTree(component_tree)

    def apply_reactive_optimization(self, component: object) -> object:
        """Apply reactive optimizations to minimize recomputation.

        Args:
            component: The component to make reactive.

        Returns:
            Component with reactive optimizations applied.
        """
        from .reactivity import ReactiveComponentMixin

        # Mix in reactive capabilities if not already present
        if not isinstance(component, ReactiveComponentMixin):
            component.__class__ = type(
                component.__class__.__name__,
                (ReactiveComponentMixin, component.__class__),
                {}
            )

        return component

    def apply_accelerated_operation(self, operation: str, data: object, **kwargs: object) -> object:
        """Apply hardware acceleration to operations.

        Args:
            operation: Name of the operation.
            data: Input data.
            **kwargs: Additional arguments.

        Returns:
            Result of the accelerated operation.
        """
        from .acceleration import AccelerationManager

        if not hasattr(self, '_accel_manager'):
            self._accel_manager = AccelerationManager()

        return self._accel_manager.accelerate_operation(operation, data, **kwargs)

    def get_compact_structure(self) -> CompactDataStructure:
        """Get a compact data structure for memory-efficient storage.

        Returns:
            Compact data structure instance.
        """
        from .memory.pool import CompactDataStructure
        compact_structure = CompactDataStructure()
        return compact_structure

    def get_reactive_system(self) -> object:
        """Get the reactive system for reactive computations.

        Returns:
            The reactive system instance, or None if not available.
        """
        return self._reactive_system

    def get_acceleration_manager(self) -> object:
        """Get the acceleration manager for hardware acceleration.

        Returns:
            The acceleration manager instance, or None if not available.
        """
        return self._acceleration_manager

    def get_buffer_pool(self) -> object:
        """Get the buffer pool for zero-copy operations.

        Returns:
            The buffer pool instance, or None if not available.
        """
        return self._buffer_pool

    def get_zero_copy_renderer(self) -> object:
        """Get the zero-copy renderer for high-performance rendering.

        Returns:
            The zero-copy renderer instance, or None if not available.
        """
        return self._zero_copy_renderer

    def accelerate_operation(self, operation: str, data: object, **kwargs: object) -> object:
        """Accelerate an operation using available hardware acceleration.

        Args:
            operation: Name of the operation to accelerate.
            data: Input data for the operation.
            **kwargs: Additional arguments for the operation.

        Returns:
            Result of the accelerated operation, or original data if acceleration unavailable.
        """
        if self._acceleration_manager is not None:
            try:
                return self._acceleration_manager.accelerate_operation(operation, data, **kwargs)
            except Exception as e:
                logger.warning(f"Acceleration failed for operation '{operation}': {e}")
                return data
        return data

    def create_reactive_value(self, name: str, initial_value: object) -> object:
        """Create a reactive value for reactive computations.

        Args:
            name: Unique name for the reactive value.
            initial_value: Initial value.

        Returns:
            The reactive value instance, or None if reactivity not available.
        """
        if self._reactive_system is not None:
            return self._reactive_system.create_reactive_value(name, initial_value)
        return None

    def _check_cython_available(self) -> bool:
        """Check if Cython is available for optimizations.

        Returns:
            True if Cython is available, False otherwise.
        """
        try:
            import importlib.util

            importlib.util.find_spec("cython")
            return True
        except ImportError:
            return False
