"""Optimization subsystem for Textforge.

This module provides performance optimization tools including Cython compilation,
memory management, caching, profiling, benchmarking, monitoring, reactive computations,
hardware acceleration, and zero-copy operations.
"""

from .manager import OptimizationManager

# Define all exports
__all__ = ["OptimizationManager"]

# Import additional optimization modules if available
try:
    from .acceleration import AccelerationManager, SIMDOperations
    from .memory.zero_copy import BufferPool, SharedBuffer, ZeroCopyRenderer
    from .reactivity import ComputedValue, ReactiveComponentMixin, ReactiveSystem, ReactiveValue
    __all__.extend([
        "ReactiveSystem", "ReactiveValue", "ComputedValue", "ReactiveComponentMixin",
        "AccelerationManager", "SIMDOperations",
        "BufferPool", "ZeroCopyRenderer", "SharedBuffer"
    ])
except ImportError:
    # Advanced modules not available, but core OptimizationManager still works
    pass
