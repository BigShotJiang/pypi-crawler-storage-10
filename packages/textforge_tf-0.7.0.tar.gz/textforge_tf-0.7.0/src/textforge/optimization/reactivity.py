"""Event-driven reactivity system to minimize recomputation on state changes."""

from __future__ import annotations

import threading
import weakref
from collections import defaultdict
from typing import TYPE_CHECKING, Any, Generic, TypeVar

from ..utils.logging import get_logger

if TYPE_CHECKING:
    from collections.abc import Callable

logger = get_logger(__name__)

T = TypeVar('T')


class ReactiveValue(Generic[T]):
    """A reactive value that triggers updates when changed."""

    def __init__(self, initial_value: T) -> None:
        """Initialize reactive value.

        Args:
            initial_value: Initial value for the reactive variable.
        """
        self._value = initial_value
        self._observers: list[weakref.ref[Callable[[T, int], None]]] = []
        self._lock = threading.RLock()
        self._version = 0

    def get(self) -> T:
        """Get the current value."""
        with self._lock:
            return self._value

    def set(self, new_value: T) -> None:
        """Set a new value and notify observers."""
        with self._lock:
            if self._value != new_value:
                self._value = new_value
                self._version += 1
                self._notify_observers()

    def update(self, updater: Callable[[T], T]) -> None:
        """Update value using a function and notify observers."""
        with self._lock:
            new_value = updater(self._value)
            if self._value != new_value:
                self._value = new_value
                self._version += 1
                self._notify_observers()

    def subscribe(self, observer: Callable[[T, int], None]) -> Callable[[], None]:
        """Subscribe to value changes.

        Args:
            observer: Function called with (new_value, version) when value changes.

        Returns:
            Unsubscribe function.
        """
        with self._lock:
            ref = weakref.ref(observer)
            self._observers.append(ref)

            # Return unsubscribe function
            def unsubscribe():
                with self._lock:
                    self._observers = [r for r in self._observers if r() is not None and r() is not observer]

            return unsubscribe

    def _notify_observers(self) -> None:
        """Notify all observers of the value change."""
        # Collect alive observers
        alive_observers: list[Callable[[T, int], None]] = []
        with self._lock:
            for ref in self._observers:
                observer = ref()
                if observer is not None:
                    alive_observers.append(observer)

        # Notify observers outside the lock to avoid deadlocks
        for observer in alive_observers:
            try:
                observer(self._value, self._version)
            except Exception as e:
                logger.warning(f"Observer notification failed: {e}")

    @property
    def version(self) -> int:
        """Get the current version number."""
        with self._lock:
            return self._version


class ComputedValue(Generic[T]):
    """A computed value that automatically updates when dependencies change."""

    def __init__(self, compute_func: Callable[[], T], dependencies: list[ReactiveValue[Any]]) -> None:
        """Initialize computed value.

        Args:
            compute_func: Function to compute the value.
            dependencies: List of reactive values this computation depends on.
        """
        self._compute_func = compute_func
        self._dependencies: list[ReactiveValue[Any]] = dependencies
        self._value: T | None = None
        self._computed_version = -1
        self._dependency_versions = [dep.version for dep in dependencies]
        self._observers: list[weakref.ref[Callable[[T | None, int], None]]] = []
        self._lock = threading.RLock()

        # Subscribe to dependency changes
        self._unsubscribers: list[Callable[[], None]] = []
        for dep in dependencies:
            unsub = dep.subscribe(self._on_dependency_changed)
            self._unsubscribers.append(unsub)

        # Initial computation
        self._recompute()

    def get(self) -> T:
        """Get the current computed value."""
        with self._lock:
            self._ensure_up_to_date()
            return self._value

    def subscribe(self, observer: Callable[[T, int], None]) -> Callable[[], None]:
        """Subscribe to computed value changes.

        Args:
            observer: Function called with (new_value, version) when value changes.

        Returns:
            Unsubscribe function.
        """
        with self._lock:
            ref: weakref.ref[Callable[[T, int], None]] = weakref.ref(observer)
            self._observers.append(ref)

            # Return unsubscribe function
            def unsubscribe():
                with self._lock:
                    self._observers = [r for r in self._observers if r() is not None and r() is not observer]

            return unsubscribe

    def _on_dependency_changed(self, new_value: object, version: int) -> None:
        """Handle dependency value changes."""
        with self._lock:
            # Check if any dependency has changed
            current_versions = [dep.version for dep in self._dependencies]
            if current_versions != self._dependency_versions:
                self._dependency_versions = current_versions
                self._recompute()

    def _ensure_up_to_date(self) -> None:
        """Ensure the computed value is up to date."""
        current_versions = [dep.version for dep in self._dependencies]
        if current_versions != self._dependency_versions:
            self._dependency_versions = current_versions
            self._recompute()

    def _recompute(self) -> None:
        """Recompute the value and notify observers."""
        try:
            new_value = self._compute_func()
            if self._value != new_value:
                self._value = new_value
                self._computed_version += 1
                self._notify_observers()
        except Exception as e:
            logger.error(f"Computed value recomputation failed: {e}")

    def _notify_observers(self) -> None:
        """Notify observers of value changes."""
        # Collect alive observers
        alive_observers: list[Callable[[T | None, int], None]] = []
        with self._lock:
            for ref in self._observers:
                observer = ref()
                if observer is not None:
                    alive_observers.append(observer)

        # Notify observers outside the lock
        for observer in alive_observers:
            try:
                observer(self._value, self._computed_version)
            except Exception as e:
                logger.warning(f"Computed value observer notification failed: {e}")


class ReactiveSystem:
    """Central system for managing reactive computations and minimizing recomputation."""

    def __init__(self) -> None:
        """Initialize reactive system."""
        self._reactive_values: dict[str, ReactiveValue[Any]] = {}
        self._computed_values: dict[str, ComputedValue[Any]] = {}
        self._change_listeners: dict[str, list[weakref.ref[Callable[[Any, int], None]]]] = defaultdict(list)
        self._lock = threading.RLock()

    def create_reactive_value(self, name: str, initial_value: object) -> ReactiveValue[Any]:
        """Create a named reactive value.

        Args:
            name: Unique name for the reactive value.
            initial_value: Initial value.

        Returns:
            The created reactive value.
        """
        with self._lock:
            if name in self._reactive_values:
                raise ValueError(f"Reactive value '{name}' already exists")

            rv = ReactiveValue(initial_value)
            self._reactive_values[name] = rv
            logger.debug(f"Created reactive value: {name}")
            return rv

    def get_reactive_value(self, name: str) -> ReactiveValue[Any] | None:
        """Get a reactive value by name.

        Args:
            name: Name of the reactive value.

        Returns:
            The reactive value, or None if not found.
        """
        with self._lock:
            return self._reactive_values.get(name)

    def create_computed_value(self, name: str, compute_func: Callable[[], Any],
                             dependencies: list[str]) -> ComputedValue[Any]:
        """Create a computed value that depends on reactive values.

        Args:
            name: Unique name for the computed value.
            compute_func: Function to compute the value.
            dependencies: List of reactive value names this computation depends on.

        Returns:
            The created computed value.
        """
        with self._lock:
            if name in self._computed_values:
                raise ValueError(f"Computed value '{name}' already exists")

            # Resolve dependency reactive values
            dep_values: list[ReactiveValue[Any]] = []
            for dep_name in dependencies:
                rv = self.get_reactive_value(dep_name)
                if rv is None:
                    raise ValueError(f"Dependency '{dep_name}' not found")
                dep_values.append(rv)

            cv = ComputedValue(compute_func, dep_values)
            self._computed_values[name] = cv
            logger.debug(f"Created computed value: {name} with dependencies {dependencies}")
            return cv

    def get_computed_value(self, name: str) -> ComputedValue[Any] | None:
        """Get a computed value by name.

        Args:
            name: Name of the computed value.

        Returns:
            The computed value, or None if not found.
        """
        with self._lock:
            return self._computed_values.get(name)

    def add_change_listener(self, value_name: str, listener: Callable[[Any, int], None]) -> Callable[[], None]:
        """Add a change listener for a reactive or computed value.

        Args:
            value_name: Name of the value to listen to.
            listener: Function called when value changes.

        Returns:
            Unsubscribe function.
        """
        with self._lock:
            ref = weakref.ref(listener)
            self._change_listeners[value_name].append(ref)

            # Try to subscribe to the actual value
            rv = self.get_reactive_value(value_name)
            cv = self.get_computed_value(value_name)

            if rv is not None:
                rv.subscribe(listener)
            elif cv is not None:
                cv.subscribe(listener)
            else:
                logger.warning(f"No reactive or computed value found for '{value_name}'")

            # Return unsubscribe function
            def unsubscribe():
                with self._lock:
                    self._change_listeners[value_name] = [
                        r for r in self._change_listeners[value_name]
                        if r() is not None and r() is not listener
                    ]

            return unsubscribe

    def batch_update(self, updates: dict[str, Any]) -> None:
        """Batch multiple reactive value updates to minimize notifications.

        Args:
            updates: Dictionary mapping value names to new values.
        """
        with self._lock:
            # Collect all reactive values to update
            to_update: list[tuple[ReactiveValue[Any], Any]] = []
            for name, new_value in updates.items():
                rv: ReactiveValue[Any] | None = self.get_reactive_value(name)
                if rv is not None:
                    to_update.append((rv, new_value))

            # Update all values (but don't notify yet due to batching)
            for rv, new_value in to_update:
                # Temporarily disable notifications during batch update
                old_value = rv._value
                if old_value != new_value:
                    rv._value = new_value
                    rv._version += 1

            # Now notify all observers after all updates are complete
            for rv, new_value in to_update:
                rv._notify_observers()

            logger.debug(f"Batch updated {len(to_update)} reactive values")

    def get_dependency_graph(self) -> dict[str, list[str]]:
        """Get the dependency graph of computed values.

        Returns:
            Dictionary mapping computed value names to their dependency names.
        """
        with self._lock:
            graph: dict[str, list[str]] = {}

            for name, cv in self._computed_values.items():
                dep_names: list[str] = []
                for dep in cv._dependencies:
                    # Find the name of this dependency
                    for rv_name, rv in self._reactive_values.items():
                        if rv is dep:
                            dep_names.append(rv_name)
                            break
                graph[name] = dep_names

            return graph

    def invalidate_computed_values(self) -> None:
        """Force invalidation of all computed values (for debugging/performance testing)."""
        with self._lock:
            for cv in self._computed_values.values():
                cv._computed_version = -1  # Force recomputation
            logger.debug("Invalidated all computed values")


class ReactiveComponentMixin:
    """Mixin class for components that use reactive state management."""

    def __init__(self, *args: object, **kwargs: object) -> None:
        """Initialize reactive component."""
        super().__init__(*args, **kwargs)
        self._reactive_system = ReactiveSystem()
        self._reactive_cleanup_funcs: list[Callable[[], None]] = []

    def reactive_value(self, name: str, initial_value: object) -> ReactiveValue[Any]:
        """Create or get a reactive value for this component.

        Args:
            name: Name of the reactive value.
            initial_value: Initial value (only used if creating).

        Returns:
            The reactive value instance.
        """
        full_name = f"{self.__class__.__name__}.{id(self)}.{name}"
        rv: ReactiveValue[Any] | None = self._reactive_system.get_reactive_value(full_name)
        if rv is None:
            rv = self._reactive_system.create_reactive_value(full_name, initial_value)
        return rv

    def computed_value(self, name: str, compute_func: Callable[[], Any],
                      dependencies: list[str]) -> ComputedValue[Any]:
        """Create or get a computed value for this component.

        Args:
            name: Name of the computed value.
            compute_func: Function to compute the value.
            dependencies: List of reactive value names.

        Returns:
            The computed value instance.
        """
        full_name = f"{self.__class__.__name__}.{id(self)}.{name}"
        full_deps = [f"{self.__class__.__name__}.{id(self)}.{dep}" for dep in dependencies]

        cv = self._reactive_system.get_computed_value(full_name)
        if cv is None:
            cv = self._reactive_system.create_computed_value(full_name, compute_func, full_deps)
        return cv

    def watch_reactive(self, value_name: str, callback: Callable[[Any, int], None]) -> None:
        """Watch a reactive value for changes.

        Args:
            value_name: Name of the reactive value to watch.
            callback: Function called when value changes.
        """
        full_name = f"{self.__class__.__name__}.{id(self)}.{value_name}"
        unsub = self._reactive_system.add_change_listener(full_name, callback)
        self._reactive_cleanup_funcs.append(unsub)

    def cleanup_reactivity(self) -> None:
        """Clean up reactive subscriptions."""
        for cleanup_func in self._reactive_cleanup_funcs:
            try:
                cleanup_func()
            except Exception as e:
                logger.warning(f"Reactive cleanup failed: {e}")

        self._reactive_cleanup_funcs.clear()
