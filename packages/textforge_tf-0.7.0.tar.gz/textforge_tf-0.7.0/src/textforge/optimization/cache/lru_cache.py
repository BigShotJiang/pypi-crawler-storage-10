"""LRU cache implementation for optimization."""

import threading
from collections import OrderedDict
from typing import Any

from ...utils.logging import get_logger

logger = get_logger(__name__)


class LRUCache:
    """Least Recently Used (LRU) cache implementation."""

    def __init__(self, max_size: int = 1000) -> None:
        """Initialize the LRU cache.

        Args:
            max_size: Maximum number of items to store in the cache.
        """
        self.max_size = max_size
        self._cache: OrderedDict[Any, Any] = OrderedDict()
        self._lock = threading.RLock()
        self._hits = 0
        self._misses = 0

    def get(self, key: object) -> object:
        """Get an item from the cache.

        Args:
            key: The cache key.

        Returns:
            The cached value or None if not found.
        """
        with self._lock:
            if key in self._cache:
                # Move to end (most recently used)
                self._cache.move_to_end(key)
                self._hits += 1
                return self._cache[key]
            self._misses += 1
            return None

    def put(self, key: object, value: object) -> None:
        """Put an item in the cache.

        Args:
            key: The cache key.
            value: The value to cache.
        """
        with self._lock:
            if key in self._cache:
                # Update existing item and move to end
                self._cache.move_to_end(key)
            else:
                # Add new item
                if len(self._cache) >= self.max_size:
                    # Remove least recently used item
                    removed_key, _ = self._cache.popitem(last=False)
                    logger.debug(f"Cache evicted key: {removed_key}")

            self._cache[key] = value

    def remove(self, key: object) -> bool:
        """Remove an item from the cache.

        Args:
            key: The cache key to remove.

        Returns:
            True if the key was removed, False if it wasn't found.
        """
        with self._lock:
            if key in self._cache:
                del self._cache[key]
                return True
            return False

    def clear(self) -> None:
        """Clear all items from the cache."""
        with self._lock:
            self._cache.clear()
            self._hits = 0
            self._misses = 0

    def size(self) -> int:
        """Get the current number of items in the cache.

        Returns:
            The number of items in the cache.
        """
        with self._lock:
            return len(self._cache)

    def hit_rate(self) -> float:
        """Get the cache hit rate.

        Returns:
            The hit rate as a float between 0.0 and 1.0.
        """
        with self._lock:
            total = self._hits + self._misses
            return self._hits / total if total > 0 else 0.0

    def stats(self) -> dict[str, int | float]:
        """Get cache statistics.

        Returns:
            Dictionary with cache statistics.
        """
        with self._lock:
            total = self._hits + self._misses
            return {
                "size": len(self._cache),
                "max_size": self.max_size,
                "hits": self._hits,
                "misses": self._misses,
                "hit_rate": self._hits / total if total > 0 else 0.0,
            }
