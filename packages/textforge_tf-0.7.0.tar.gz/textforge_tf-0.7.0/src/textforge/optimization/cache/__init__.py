"""Caching optimization utilities for Textforge."""

from .lru_cache import LRUCache

__all__ = ["LRUCache"]
