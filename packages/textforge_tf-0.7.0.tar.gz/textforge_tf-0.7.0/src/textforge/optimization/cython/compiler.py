"""Cython compilation utilities for cross-platform module building."""

import importlib.util
import subprocess
import sys
import tempfile
from pathlib import Path

from ...utils.logging import get_logger

logger = get_logger(__name__)


class CythonCompilationError(Exception):
    """Raised when Cython compilation fails."""

    pass


class CythonCompiler:
    """Cross-platform Cython compilation manager."""

    def __init__(self, build_dir: str | None = None) -> None:
        """Initialize the Cython compiler.

        Args:
            build_dir: Directory to use for compilation artifacts.
        """
        self.build_dir = Path(build_dir) if build_dir else Path(tempfile.gettempdir()) / "textforge_cython"
        self.build_dir.mkdir(exist_ok=True)
        self._compiled_modules: dict[str, object] = {}

    def compile_and_load_module(self, pyx_file: str, module_name: str) -> object:
        """Compile a .pyx file and load the resulting module.

        Args:
            pyx_file: Path to the .pyx source file.
            module_name: Name for the compiled module.

        Returns:
            The loaded compiled module.

        Raises:
            CythonCompilationError: If compilation fails.
        """
        pyx_path = Path(pyx_file)
        if not pyx_path.exists():
            raise FileNotFoundError(f"Cython source file not found: {pyx_file}")

        # Check if already compiled and cached
        if module_name in self._compiled_modules:
            return self._compiled_modules[module_name]

        try:
            # Generate C code from .pyx
            c_file = self._generate_c_code(pyx_path, module_name)

            # Compile C code to extension module
            extension_file = self._compile_extension(c_file, module_name)

            # Load the compiled module
            module = self._load_compiled_module(extension_file, module_name)

            # Cache the loaded module
            self._compiled_modules[module_name] = module

            logger.debug(f"Successfully compiled and loaded Cython module: {module_name}")
            return module

        except Exception as e:
            logger.error(f"Failed to compile Cython module {module_name}: {e}")
            raise CythonCompilationError(f"Cython compilation failed: {e}") from e

    def _generate_c_code(self, pyx_path: Path, module_name: str) -> Path:
        """Generate C code from .pyx file using Cython.

        Args:
            pyx_path: Path to the .pyx file.
            module_name: Module name.

        Returns:
            Path to generated C file.
        """
        c_file = self.build_dir / f"{module_name}.c"

        # Use cython command to generate C code
        cmd = [sys.executable, "-m", "cython", "--embed-positions", "-o", str(c_file), str(pyx_path)]

        try:
            subprocess.run(cmd, capture_output=True, text=True, check=True, cwd=self.build_dir)
            logger.debug(f"Generated C code for {module_name}")
            return c_file

        except subprocess.CalledProcessError as e:
            error_msg = f"Cython code generation failed: {e.stderr}"
            logger.error(error_msg)
            raise CythonCompilationError(error_msg) from e

    def _compile_extension(self, c_file: Path, module_name: str) -> Path:
        """Compile C code to Python extension module.

        Args:
            c_file: Path to the C source file.
            module_name: Module name.

        Returns:
            Path to compiled extension file.
        """
        # Determine extension file suffix based on platform
        if sys.platform == "win32":
            ext_suffix = ".pyd"
        else:
            ext_suffix = ".so"

        extension_file = self.build_dir / f"{module_name}{ext_suffix}"

        # Use setuptools/distutils to compile
        from setuptools import Extension, setup

        extension = Extension(
            module_name,
            sources=[str(c_file)],
            include_dirs=[],  # Add include dirs if needed
            library_dirs=[],  # Add library dirs if needed
            libraries=[],  # Add libraries if needed
            extra_compile_args=self._get_compile_args(),
            extra_link_args=self._get_link_args(),
        )

        # Compile in a temporary directory to avoid polluting the source
        with tempfile.TemporaryDirectory() as temp_dir:
            setup(name=module_name, ext_modules=[extension], script_name="setup.py", script_args=["build_ext", "--inplace"], cwd=temp_dir)

            # Move the compiled extension to our build directory
            temp_extension = Path(temp_dir) / "build" / f"{module_name}{ext_suffix}"
            if temp_extension.exists():
                temp_extension.replace(extension_file)
            else:
                # Try to find it in subdirectories
                for file in Path(temp_dir).rglob(f"{module_name}{ext_suffix}"):
                    file.replace(extension_file)
                    break
                else:
                    raise CythonCompilationError(f"Compiled extension not found for {module_name}")

        logger.debug(f"Compiled extension module: {extension_file}")
        return extension_file

    def _load_compiled_module(self, extension_file: Path, module_name: str) -> object:
        """Load a compiled extension module.

        Args:
            extension_file: Path to the compiled extension.
            module_name: Module name.

        Returns:
            The loaded module.
        """
        # Add the build directory to Python path temporarily
        sys.path.insert(0, str(self.build_dir))

        try:
            # Load the module
            spec = importlib.util.spec_from_file_location(module_name, extension_file)
            if spec is None or spec.loader is None:
                raise ImportError(f"Could not load module spec for {module_name}")

            module = importlib.util.module_from_spec(spec)
            spec.loader.exec_module(module)

            logger.debug(f"Loaded compiled module: {module_name}")
            return module

        finally:
            # Clean up path
            if sys.path[0] == str(self.build_dir):
                sys.path.pop(0)

    def _get_compile_args(self) -> list[str]:
        """Get platform-specific compile arguments."""
        if sys.platform == "win32":
            return ["/O2", "/Wall"]
        elif sys.platform == "darwin":
            return ["-O3", "-Wno-unused-function"]
        else:  # Linux and others
            return ["-O3", "-Wno-unused-function"]

    def _get_link_args(self) -> list[str]:
        """Get platform-specific link arguments."""
        if sys.platform == "win32":
            return []
        elif sys.platform == "darwin":
            return []
        else:  # Linux and others
            return []

    def cleanup(self) -> None:
        """Clean up compilation artifacts."""
        try:
            for file in self.build_dir.glob("*"):
                file.unlink()
            self.build_dir.rmdir()
            logger.debug("Cleaned up Cython compilation artifacts")
        except Exception as e:
            logger.warning(f"Failed to cleanup Cython artifacts: {e}")
