"""Zero-copy operations and memory-efficient data structures for high-performance rendering."""

from __future__ import annotations

import logging
from threading import RLock
from typing import TYPE_CHECKING, Any, Generic, TypeVar

if TYPE_CHECKING:
    import weakref

    from ...components.base import RenderableComponent

logger = logging.getLogger(__name__)

T = TypeVar('T')


class SharedBuffer:
    """Shared memory buffer for zero-copy operations."""

    def __init__(self, size: int, data_type: type = bytes) -> None:
        """Initialize shared buffer.

        Args:
            size: Buffer size in elements.
            data_type: Type of data stored in buffer.
        """
        self.size = size
        self.data_type = data_type
        self._buffer = bytearray(size)
        self._lock = RLock()
        self._references: list[weakref.ref] = []

    def get_view(self, offset: int = 0, length: int | None = None) -> memoryview:
        """Get a memory view of the buffer.

        Args:
            offset: Starting offset in buffer.
            length: Length of view, or None for remaining buffer.

        Returns:
            Memory view of buffer segment.
        """
        with self._lock:
            if length is None:
                length = self.size - offset

            return memoryview(self._buffer)[offset:offset + length]

    def write_data(self, data: bytes | bytearray, offset: int = 0) -> None:
        """Write data to buffer.

        Args:
            data: Data to write.
            offset: Offset to write at.
        """
        with self._lock:
            end_pos = offset + len(data)
            if end_pos > self.size:
                raise ValueError(f"Data too large for buffer (size: {self.size}, needed: {end_pos})")

            self._buffer[offset:end_pos] = data

    def copy_on_write(self) -> SharedBuffer:
        """Create a copy-on-write duplicate of this buffer.

        Returns:
            New buffer that shares memory until modified.
        """
        with self._lock:
            new_buffer = SharedBuffer(self.size, self.data_type)
            # For now, create a full copy. In a real implementation,
            # this would use copy-on-write at the OS level
            new_buffer._buffer[:] = self._buffer
            return new_buffer


class CopyOnWriteTree:
    """Copy-on-write tree structure for efficient component tree operations."""

    def __init__(self, root: object | None = None) -> None:
        """Initialize copy-on-write tree.

        Args:
            root: Root node of the tree.
        """
        self._root = root
        self._lock = RLock()
        self._is_copy = False

    def get_root(self) -> object:
        """Get the root node."""
        with self._lock:
            return self._root

    def set_root(self, root: object) -> None:
        """Set the root node."""
        with self._lock:
            if self._is_copy:
                # Create a copy when modifying
                self._root = self._deep_copy(root)
                self._is_copy = False
            else:
                self._root = root

    def create_copy(self) -> CopyOnWriteTree:
        """Create a copy-on-write copy of this tree.

        Returns:
            New tree that shares structure until modified.
        """
        with self._lock:
            copy_tree = CopyOnWriteTree(self._root)
            copy_tree._is_copy = True
            return copy_tree

    def _deep_copy(self, node: object) -> object:
        """Create a deep copy of a tree node."""
        if node is None:
            return None

        # Create shallow copy of node
        copied_node = type(node).__new__(type(node))

        # Copy attributes
        for attr in dir(node):
            if not attr.startswith('_') and not callable(getattr(node, attr)):
                try:
                    value = getattr(node, attr)
                    if not callable(value):
                        setattr(copied_node, attr, value)
                except (AttributeError, TypeError):
                    pass

        # Deep copy children if they exist
        if hasattr(node, 'children') and node.children:
            copied_node.children = [self._deep_copy(child) for child in node.children]

        return copied_node


class ImmutableBuffer(Generic[T]):
    """Immutable buffer for zero-copy data sharing."""

    def __init__(self, data: list[T]) -> None:
        """Initialize immutable buffer.

        Args:
            data: Data to store immutably.
        """
        self._data = tuple(data)  # Convert to immutable tuple
        self._lock = RLock()

    def get_item(self, index: int) -> T:
        """Get item at index.

        Args:
            index: Index to retrieve.

        Returns:
            Item at the specified index.
        """
        with self._lock:
            return self._data[index]

    def get_slice(self, start: int = 0, end: int | None = None) -> tuple[T, ...]:
        """Get slice of data.

        Args:
            start: Start index.
            end: End index, or None for end of data.

        Returns:
            Tuple slice of the data.
        """
        with self._lock:
            return self._data[start:end]

    def __len__(self) -> int:
        """Get length of buffer."""
        return len(self._data)

    def __iter__(self):
        """Iterate over buffer data."""
        return iter(self._data)


class BufferPool:
    """Pool of reusable buffers for memory efficiency."""

    def __init__(self, buffer_size: int = 8192, max_buffers: int = 100) -> None:
        """Initialize buffer pool.

        Args:
            buffer_size: Size of each buffer.
            max_buffers: Maximum number of buffers to pool.
        """
        self.buffer_size = buffer_size
        self.max_buffers = max_buffers
        self._available_buffers: list[SharedBuffer] = []
        self._lock = RLock()

    def acquire_buffer(self) -> SharedBuffer:
        """Acquire a buffer from the pool.

        Returns:
            Available buffer from pool, or new buffer if pool is empty.
        """
        with self._lock:
            if self._available_buffers:
                buffer = self._available_buffers.pop()
                logger.debug("Acquired buffer from pool")
                return buffer
            else:
                buffer = SharedBuffer(self.buffer_size)
                logger.debug("Created new buffer for pool")
                return buffer

    def release_buffer(self, buffer: SharedBuffer) -> None:
        """Release a buffer back to the pool.

        Args:
            buffer: Buffer to return to pool.
        """
        with self._lock:
            if len(self._available_buffers) < self.max_buffers:
                # Clear buffer before returning to pool
                buffer._buffer[:] = b'\x00'
                self._available_buffers.append(buffer)
                logger.debug("Released buffer back to pool")
            else:
                logger.debug("Pool full, discarding buffer")


class ZeroCopyRenderer:
    """Renderer that uses zero-copy operations for maximum performance."""

    def __init__(self) -> None:
        """Initialize zero-copy renderer."""
        self._buffer_pool = BufferPool()
        self._component_cache: dict[str, SharedBuffer] = {}
        self._lock = RLock()

    def render_component_zero_copy(self, component: RenderableComponent) -> SharedBuffer:
        """Render component using zero-copy operations.

        Args:
            component: Component to render.

        Returns:
            Shared buffer containing rendered output.
        """
        with self._lock:
            component_id = getattr(component, 'component_name', 'unknown')

            # Check cache first
            if component_id in self._component_cache:
                cached_buffer = self._component_cache[component_id]
                # Return copy-on-write copy
                return cached_buffer.copy_on_write()

            # Render to new buffer
            buffer = self._buffer_pool.acquire_buffer()

            # Perform rendering (simplified)
            render_data = self._generate_render_data(component)
            buffer.write_data(render_data.encode('utf-8'))

            # Cache the buffer
            self._component_cache[component_id] = buffer

            return buffer

    def _generate_render_data(self, component: RenderableComponent) -> str:
        """Generate render data for component."""
        # Simplified rendering logic
        name = getattr(component, 'component_name', 'component')
        return f"<{name}></{name}>"

    def invalidate_cache(self, component_id: str | None = None) -> None:
        """Invalidate render cache.

        Args:
            component_id: Specific component to invalidate, or None for all.
        """
        with self._lock:
            if component_id:
                if component_id in self._component_cache:
                    buffer = self._component_cache.pop(component_id)
                    self._buffer_pool.release_buffer(buffer)
                    logger.debug(f"Invalidated cache for {component_id}")
            else:
                for buffer in self._component_cache.values():
                    self._buffer_pool.release_buffer(buffer)
                self._component_cache.clear()
                logger.debug("Invalidated all render cache")


class MemoryMappedComponentTree:
    """Memory-mapped component tree for efficient large tree operations."""

    def __init__(self, max_components: int = 10000) -> None:
        """Initialize memory-mapped component tree.

        Args:
            max_components: Maximum number of components to support.
        """
        self.max_components = max_components
        self._component_data: list[dict[str, Any]] = []
        self._component_index: dict[str, int] = {}
        self._lock = RLock()

    def add_component(self, component_id: str, component_data: dict[str, Any]) -> None:
        """Add component to memory-mapped tree.

        Args:
            component_id: Unique component identifier.
            component_data: Component data dictionary.
        """
        with self._lock:
            if len(self._component_data) >= self.max_components:
                raise ValueError(f"Maximum components ({self.max_components}) exceeded")

            if component_id in self._component_index:
                # Update existing
                index = self._component_index[component_id]
                self._component_data[index] = component_data
            else:
                # Add new
                index = len(self._component_data)
                self._component_data.append(component_data)
                self._component_index[component_id] = index

            logger.debug(f"Added component {component_id} to memory-mapped tree")

    def get_component(self, component_id: str) -> dict[str, Any] | None:
        """Get component data by ID.

        Args:
            component_id: Component identifier.

        Returns:
            Component data dictionary, or None if not found.
        """
        with self._lock:
            if component_id not in self._component_index:
                return None

            index = self._component_index[component_id]
            return self._component_data[index]

    def remove_component(self, component_id: str) -> None:
        """Remove component from tree.

        Args:
            component_id: Component identifier to remove.
        """
        with self._lock:
            if component_id in self._component_index:
                index = self._component_index[component_id]
                # Mark as removed rather than actually removing to maintain indices
                self._component_data[index] = {"_removed": True}
                del self._component_index[component_id]
                logger.debug(f"Removed component {component_id} from memory-mapped tree")

    def get_all_components(self) -> list[tuple[str, dict[str, Any]]]:
        """Get all active components.

        Returns:
            List of (component_id, component_data) tuples.
        """
        with self._lock:
            result: list[tuple[str, dict[str, Any]]] = []
            for component_id, index in self._component_index.items():
                data = self._component_data[index]
                if not data.get("_removed", False):
                    result.append((component_id, data))
            return result
