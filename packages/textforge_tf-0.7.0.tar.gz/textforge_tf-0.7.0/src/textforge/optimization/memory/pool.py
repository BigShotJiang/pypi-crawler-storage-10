"""Memory pool implementations for object reuse."""

from collections import defaultdict
from threading import RLock
from typing import TYPE_CHECKING, Any, Generic, TypeVar

from ...utils.logging import get_logger

if TYPE_CHECKING:
    import weakref
    from collections.abc import Callable

logger = get_logger(__name__)

T = TypeVar('T')


class MemoryPool(Generic[T]):
    """Memory pool for object reuse with enhanced features."""

    def __init__(self, object_type: type[T], max_size: int = 1000, factory: Callable[[], T] | None = None) -> None:
        """Initialize the memory pool.

        Args:
            object_type: The type of objects in the pool.
            max_size: Maximum number of objects to keep in the pool.
            factory: Optional factory function for creating objects.
        """
        self.object_type = object_type
        self.max_size = max_size
        self.factory = factory or (lambda: object_type())
        self._pool: list[T] = []
        self._lock = RLock()
        self._stats = {"created": 0, "reused": 0, "discarded": 0}

    def acquire(self) -> T:
        """Acquire an object from the pool.

        Returns:
            An object from the pool or a new instance if pool is empty.
        """
        with self._lock:
            if self._pool:
                obj = self._pool.pop()
                self._stats["reused"] += 1
                logger.debug(f"Reused object from pool: {self.object_type.__name__}")
                return obj
            else:
                obj = self.factory()
                self._stats["created"] += 1
                logger.debug(f"Created new object for pool: {self.object_type.__name__}")
                return obj

    def release(self, obj: T) -> None:
        """Release an object back to the pool.

        Args:
            obj: The object to release back to the pool.
        """
        with self._lock:
            if len(self._pool) < self.max_size:
                # Reset object state if possible
                self._reset_object(obj)
                self._pool.append(obj)
                logger.debug(f"Released object back to pool: {self.object_type.__name__}")
            else:
                self._stats["discarded"] += 1
                logger.debug(f"Pool full, discarded object: {self.object_type.__name__}")

    def _reset_object(self, obj: T) -> None:
        """Reset object to clean state for reuse."""
        # Try to reset common attributes
        if hasattr(obj, 'clear'):
            try:
                obj.clear()
            except Exception:
                pass  # Ignore reset failures

        # Reset numeric attributes to defaults
        for attr in ['x', 'y', 'width', 'height', 'value', 'count']:
            if hasattr(obj, attr):
                try:
                    setattr(obj, attr, 0)
                except Exception:
                    pass

        # Reset string attributes
        for attr in ['text', 'name', 'id']:
            if hasattr(obj, attr):
                try:
                    setattr(obj, attr, "")
                except Exception:
                    pass

    def size(self) -> int:
        """Get the current size of the pool.

        Returns:
            The number of objects currently in the pool.
        """
        with self._lock:
            return len(self._pool)

    def get_stats(self) -> dict[str, int]:
        """Get pool usage statistics."""
        with self._lock:
            return self._stats.copy()

    def clear(self) -> None:
        """Clear all objects from the pool."""
        with self._lock:
            self._pool.clear()
            self._stats = {"created": 0, "reused": 0, "discarded": 0}
            logger.debug(f"Cleared pool for {self.object_type.__name__}")


class ObjectPool(MemoryPool[Any]):
    """Object pool with factory function support."""

    def __init__(self, factory: Callable[[], Any], max_size: int = 1000) -> None:
        """Initialize the object pool.

        Args:
            factory: Factory function to create new objects.
            max_size: Maximum number of objects to keep in the pool.
        """
        super().__init__(object, max_size, factory)


class CompactDataStructure:
    """Compact data structure using bit-packing and memory-efficient storage."""

    def __init__(self) -> None:
        """Initialize compact data structure."""
        self._data: dict[str, Any] = {}
        self._bit_fields: dict[str, int] = {}
        self._lock = RLock()

    def set_bit_field(self, name: str, value: int, bit_width: int = 8) -> None:
        """Set a bit-packed field value.

        Args:
            name: Field name.
            value: Value to store.
            bit_width: Width of the field in bits.
        """
        with self._lock:
            max_value = (1 << bit_width) - 1
            if value < 0 or value > max_value:
                raise ValueError(f"Value {value} out of range for {bit_width}-bit field")

            self._bit_fields[name] = (value << 16) | bit_width  # Store value and width

    def get_bit_field(self, name: str) -> int:
        """Get a bit-packed field value.

        Args:
            name: Field name.

        Returns:
            The stored value.
        """
        with self._lock:
            if name not in self._bit_fields:
                return 0

            packed = self._bit_fields[name]
            value = packed >> 16
            return value

    def set_compact_data(self, name: str, data: object) -> None:
        """Set compact data with automatic compression.

        Args:
            name: Data name.
            data: Data to store compactly.
        """
        with self._lock:
            # Simple compression for common patterns
            if isinstance(data, str) and len(data) > 10:
                # Store string as bytes to reduce overhead
                self._data[name] = data.encode('utf-8')
            elif isinstance(data, list) and len(data) > 0:
                # Convert to tuple for immutability
                self._data[name] = tuple(data)
            else:
                self._data[name] = data

    def get_compact_data(self, name: str) -> object:
        """Get compact data with automatic decompression.

        Args:
            name: Data name.

        Returns:
            The stored data.
        """
        with self._lock:
            data = self._data.get(name)
            if isinstance(data, bytes):
                return data.decode('utf-8')
            return data

    def memory_usage(self) -> int:
        """Calculate approximate memory usage of the structure."""
        with self._lock:
            usage = 0
            for value in self._data.values():
                usage += self._calculate_object_size(value)
            for value in self._bit_fields.values():
                usage += 4  # 4 bytes per bit field
            return usage

    def _calculate_object_size(self, obj: object) -> int:
        """Calculate approximate size of an object."""
        if isinstance(obj, (int, float)):
            return 8
        elif isinstance(obj, str):
            return len(obj) * 2  # UTF-16 approximation
        elif isinstance(obj, bytes):
            return len(obj)
        elif isinstance(obj, (list, tuple)):
            return 64 + sum(self._calculate_object_size(item) for item in obj)  # Overhead + items
        elif isinstance(obj, dict):
            return 64 + sum(len(k) + self._calculate_object_size(v) for k, v in obj.items())
        else:
            return 64  # Default object overhead


class ObjectPoolManager:
    """Manager for multiple memory pools with automatic lifecycle management."""

    def __init__(self) -> None:
        """Initialize object pool manager."""
        self._pools: dict[str, MemoryPool[object]] = {}
        self._weak_refs: dict[str, list[weakref.ref[object]]] = defaultdict(list)
        self._lock = RLock()

    def get_pool(self, pool_name: str, object_type: type[object] | None = None, **kwargs: object) -> MemoryPool[object]:
        """Get or create a memory pool.

        Args:
            pool_name: Name of the pool.
            object_type: Type of objects in the pool.
            **kwargs: Additional arguments for pool creation.

        Returns:
            The memory pool instance.
        """
        with self._lock:
            if pool_name not in self._pools:
                if object_type is None:
                    raise ValueError(f"object_type required for new pool '{pool_name}'")

                self._pools[pool_name] = MemoryPool(object_type, **kwargs)
                logger.debug(f"Created new pool: {pool_name} for {object_type.__name__}")

            return self._pools[pool_name]

    def register_weak_ref(self, pool_name: str, obj_ref: weakref.ref[object]) -> None:
        """Register a weak reference for pool-managed object.

        Args:
            pool_name: Name of the pool.
            obj_ref: Weak reference to the object.
        """
        with self._lock:
            self._weak_refs[pool_name].append(obj_ref)

    def cleanup_pool(self, pool_name: str) -> None:
        """Clean up a specific pool and its weak references."""
        with self._lock:
            if pool_name in self._pools:
                pool = self._pools[pool_name]
                pool.clear()
                logger.debug(f"Cleaned up pool: {pool_name}")

            # Clean up dead weak references
            if pool_name in self._weak_refs:
                self._weak_refs[pool_name] = [
                    ref for ref in self._weak_refs[pool_name]
                    if ref() is not None
                ]

    def get_pool_stats(self) -> dict[str, dict[str, int]]:
        """Get statistics for all pools."""
        with self._lock:
            stats: dict[str, dict[str, int]] = {}
            for pool_name, pool in self._pools.items():
                stats[pool_name] = pool.get_stats()
            return stats

    def cleanup_all(self) -> None:
        """Clean up all pools and references."""
        with self._lock:
            for pool_name in list(self._pools.keys()):
                self.cleanup_pool(pool_name)

            self._weak_refs.clear()
            logger.debug("Cleaned up all object pools")
