"""Performance profiling utilities."""

import cProfile
import pstats
import time
from typing import TYPE_CHECKING, Any

from ...utils.logging import get_logger

if TYPE_CHECKING:
    from collections.abc import Callable

logger = get_logger(__name__)


class ProfilingResult:
    """Result of a profiling operation."""

    def __init__(self, execution_time: float, function_calls: int, memory_usage: int) -> None:
        self.execution_time = execution_time
        self.function_calls = function_calls
        self.memory_usage = memory_usage


class Profiler:
    """Performance profiler for functions and code blocks."""

    def __init__(self) -> None:
        self._profiler = cProfile.Profile()

    def profile_function(self, func: Callable[..., Any], *args: object, **kwargs: object) -> ProfilingResult:
        """Profile a function's performance.

        Args:
            func: The function to profile.
            *args: Positional arguments for the function.
            **kwargs: Keyword arguments for the function.

        Returns:
            Profiling results.
        """
        # Start profiling
        self._profiler.enable()

        # Measure execution time
        start_time = time.perf_counter()

        # Execute function
        func(*args, **kwargs)

        end_time = time.perf_counter()
        execution_time = end_time - start_time

        # Stop profiling
        self._profiler.disable()

        # Get stats
        stats = pstats.Stats(self._profiler)
        function_calls = len(stats.stats)  # Approximate number of function calls

        # Measure memory usage using tracemalloc
        import tracemalloc

        # Get memory statistics from tracemalloc
        current, peak = tracemalloc.get_traced_memory()
        memory_usage = current

        logger.debug(f"Profiled function {func.__name__}: time={execution_time:.6f}s, calls={function_calls}, memory={memory_usage} bytes")

        return ProfilingResult(execution_time, function_calls, memory_usage)

    def profile_block(self, code_block: Callable[[], Any]) -> ProfilingResult:
        """Profile a code block.

        Args:
            code_block: Callable that contains the code to profile.

        Returns:
            Profiling results.
        """
        return self.profile_function(code_block)

    def get_stats(self) -> pstats.Stats:
        """Get detailed profiling statistics.

        Returns:
            pstats.Stats object with profiling data.
        """
        return pstats.Stats(self._profiler)

    def print_stats(self, sort: str = "cumulative", lines: int = 20) -> None:
        """Print profiling statistics to stdout.

        Args:
            sort: Sort key for statistics ('cumulative', 'time', 'calls', etc.).
            lines: Number of lines to display.
        """
        stats = self.get_stats()
        stats.sort_stats(sort).print_stats(lines)

    def reset(self) -> None:
        """Reset the profiler for a new profiling session."""
        self._profiler = cProfile.Profile()
