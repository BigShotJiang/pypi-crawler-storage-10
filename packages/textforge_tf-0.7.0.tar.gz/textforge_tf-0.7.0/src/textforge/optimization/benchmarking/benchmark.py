"""Benchmarking utilities for performance measurement."""

import statistics
import time
from typing import TYPE_CHECKING, Any

from ...utils.logging import get_logger

if TYPE_CHECKING:
    from collections.abc import Callable

logger = get_logger(__name__)


class BenchmarkResult:
    """Result of a benchmark run."""

    def __init__(self, name: str, times: list[float], iterations: int) -> None:
        self.name = name
        self.times = times
        self.iterations = iterations
        self.min_time = min(times)
        self.max_time = max(times)
        self.mean_time = statistics.mean(times)
        self.median_time = statistics.median(times)
        self.std_dev = statistics.stdev(times) if len(times) > 1 else 0.0

    def __str__(self) -> str:
        return (
            f"Benchmark '{self.name}':\n"
            f"  Iterations: {self.iterations}\n"
            f"  Min: {self.min_time:.6f}s\n"
            f"  Max: {self.max_time:.6f}s\n"
            f"  Mean: {self.mean_time:.6f}s\n"
            f"  Median: {self.median_time:.6f}s\n"
            f"  Std Dev: {self.std_dev:.6f}s"
        )


class BenchmarkRunner:
    """Runner for executing performance benchmarks."""

    def __init__(self) -> None:
        self._benchmarks: dict[str, Callable[[], Any]] = {}

    def register(self, name: str, func: Callable[[], Any]) -> None:
        """Register a benchmark function.

        Args:
            name: Name of the benchmark.
            func: Function to benchmark.
        """
        self._benchmarks[name] = func

    def run_benchmark(self, name: str, iterations: int = 100, warmup: int = 10) -> BenchmarkResult:
        """Run a specific benchmark.

        Args:
            name: Name of the benchmark to run.
            iterations: Number of iterations to run.
            warmup: Number of warmup iterations.

        Returns:
            Benchmark results.

        Raises:
            ValueError: If benchmark name is not registered.
        """
        if name not in self._benchmarks:
            raise ValueError(f"Benchmark '{name}' not registered")

        func = self._benchmarks[name]

        # Warmup
        for _ in range(warmup):
            func()

        # Benchmark
        times: list[float] = []
        for _ in range(iterations):
            start = time.perf_counter()
            func()
            end = time.perf_counter()
            times.append(end - start)

        result = BenchmarkResult(name, times, iterations)
        logger.debug(f"Completed benchmark: {result}")
        return result

    def run_all(self, iterations: int = 100, warmup: int = 10) -> dict[str, BenchmarkResult]:
        """Run all registered benchmarks.

        Args:
            iterations: Number of iterations per benchmark.
            warmup: Number of warmup iterations per benchmark.

        Returns:
            Dictionary of benchmark results.
        """
        results: dict[str, BenchmarkResult] = {}
        for name in self._benchmarks:
            results[name] = self.run_benchmark(name, iterations, warmup)
        return results

    def compare(self, baseline: BenchmarkResult, current: BenchmarkResult) -> dict[str, float]:
        """Compare two benchmark results.

        Args:
            baseline: Baseline benchmark result.
            current: Current benchmark result.

        Returns:
            Dictionary with comparison metrics.
        """
        return {
            "mean_ratio": current.mean_time / baseline.mean_time,
            "mean_difference": current.mean_time - baseline.mean_time,
            "median_ratio": current.median_time / baseline.median_time,
            "median_difference": current.median_time - baseline.median_time,
        }
