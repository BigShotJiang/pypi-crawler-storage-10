"""Performance monitoring utilities."""

import threading
import time
from collections import defaultdict

from ...utils.logging import get_logger

logger = get_logger(__name__)


class PerformanceMetrics:
    """Container for performance metrics."""

    def __init__(self) -> None:
        self.operation_count = 0
        self.total_time = 0.0
        self.min_time = float("inf")
        self.max_time = 0.0
        self.start_times: dict[str, float] = {}

    def record_operation(self, duration: float) -> None:
        """Record a completed operation.

        Args:
            duration: Duration of the operation in seconds.
        """
        self.operation_count += 1
        self.total_time += duration
        self.min_time = min(self.min_time, duration)
        self.max_time = max(self.max_time, duration)

    def get_average_time(self) -> float:
        """Get the average operation time.

        Returns:
            Average time in seconds.
        """
        return self.total_time / self.operation_count if self.operation_count > 0 else 0.0

    def get_operations_per_second(self) -> float:
        """Get operations per second.

        Returns:
            Operations per second.
        """
        return self.operation_count / self.total_time if self.total_time > 0 else 0.0


class PerformanceMonitor:
    """Monitor for tracking performance metrics."""

    def __init__(self) -> None:
        self._metrics: dict[str, PerformanceMetrics] = defaultdict(PerformanceMetrics)
        self._lock = threading.RLock()

    def start_operation(self, operation_name: str, operation_id: str | None = None) -> str:
        """Start timing an operation.

        Args:
            operation_name: Name of the operation.
            operation_id: Optional unique identifier for the operation.

        Returns:
            Operation identifier for use with end_operation.
        """
        op_id = operation_id or f"{operation_name}_{id(self)}"
        with self._lock:
            self._metrics[operation_name].start_times[op_id] = time.perf_counter()
        return op_id

    def end_operation(self, operation_name: str, operation_id: str) -> float:
        """End timing an operation.

        Args:
            operation_name: Name of the operation.
            operation_id: Operation identifier from start_operation.

        Returns:
            Duration of the operation in seconds.
        """
        end_time = time.perf_counter()
        with self._lock:
            metrics = self._metrics[operation_name]
            if operation_id in metrics.start_times:
                start_time = metrics.start_times.pop(operation_id)
                duration = end_time - start_time
                metrics.record_operation(duration)
                return duration
        return 0.0

    def record_operation(self, operation_name: str, duration: float) -> None:
        """Record a completed operation with known duration.

        Args:
            operation_name: Name of the operation.
            duration: Duration of the operation in seconds.
        """
        with self._lock:
            self._metrics[operation_name].record_operation(duration)

    def get_metrics(self, operation_name: str) -> PerformanceMetrics:
        """Get metrics for a specific operation.

        Args:
            operation_name: Name of the operation.

        Returns:
            Performance metrics for the operation.
        """
        with self._lock:
            return self._metrics[operation_name]

    def get_all_metrics(self) -> dict[str, PerformanceMetrics]:
        """Get metrics for all operations.

        Returns:
            Dictionary of operation names to metrics.
        """
        with self._lock:
            return dict(self._metrics)

    def reset_metrics(self, operation_name: str | None = None) -> None:
        """Reset metrics.

        Args:
            operation_name: Name of operation to reset, or None to reset all.
        """
        with self._lock:
            if operation_name:
                self._metrics[operation_name] = PerformanceMetrics()
            else:
                self._metrics.clear()

    def log_summary(self) -> None:
        """Log a summary of all performance metrics."""
        with self._lock:
            for operation_name, metrics in self._metrics.items():
                if metrics.operation_count > 0:
                    logger.debug(
                        f"Performance summary for '{operation_name}': "
                        f"count={metrics.operation_count}, "
                        f"avg={metrics.get_average_time():.6f}s, "
                        f"min={metrics.min_time:.6f}s, "
                        f"max={metrics.max_time:.6f}s, "
                        f"ops/sec={metrics.get_operations_per_second():.2f}"
                    )
