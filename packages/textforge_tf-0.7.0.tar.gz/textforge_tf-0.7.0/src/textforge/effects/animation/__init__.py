"""Animation subsystem for Textforge."""

from .coordinator import AnimationCoordinator
from .easing import EasingFunction, ease_in_out, ease_in_out_quad, linear_easing
from .engine import AnimationEngine
from .events import AnimationEvent, AnimationEventType, dispatch_animation_event
from .interfaces import (
    animate_component,
    create_timeline,
    get_active_animations,
    get_timeline,
    pause_animation,
    resume_animation,
    start_animation,
    stop_animation,
    update_animations,
)
from .keyframes import Animation, AnimationDirection, Keyframe
from .optimization import AnimationOptimizer
from .timeline import AnimationScheduler, Timeline

__all__ = [
    "AnimationEngine",
    "Keyframe",
    "Animation",
    "AnimationDirection",
    "EasingFunction",
    "linear_easing",
    "ease_in_out",
    "ease_in_out_quad",
    "Timeline",
    "AnimationScheduler",
    "AnimationCoordinator",
    "AnimationEvent",
    "AnimationEventType",
    "AnimationOptimizer",
    "animate_component",
    "create_timeline",
    "get_active_animations",
    "get_timeline",
    "pause_animation",
    "resume_animation",
    "start_animation",
    "stop_animation",
    "update_animations",
    "dispatch_animation_event",
]
