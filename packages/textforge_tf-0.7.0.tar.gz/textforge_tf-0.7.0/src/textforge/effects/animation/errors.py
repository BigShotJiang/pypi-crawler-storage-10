"""Animation error classes."""


class AnimationError(Exception):
    """Base exception for animation-related errors."""

    def __init__(self, message: str, animation_id: str | None = None) -> None:
        """Initialize animation error.

        Args:
            message: Error message.
            animation_id: Optional animation ID.
        """
        super().__init__(message)
        self.animation_id = animation_id


class InvalidKeyframeError(AnimationError):
    """Exception raised for invalid keyframe definitions."""

    def __init__(self, message: str, keyframe_offset: float | None = None) -> None:
        """Initialize invalid keyframe error.

        Args:
            message: Error message.
            keyframe_offset: Optional keyframe offset that caused the error.
        """
        super().__init__(message)
        self.keyframe_offset = keyframe_offset


class AnimationNotFoundError(AnimationError):
    """Exception raised when an animation ID is not found."""

    def __init__(self, animation_id: str) -> None:
        """Initialize animation not found error.

        Args:
            animation_id: The animation ID that was not found.
        """
        super().__init__(f"Animation with ID '{animation_id}' not found", animation_id)


class AnimationStateError(AnimationError):
    """Exception raised for invalid animation state operations."""

    def __init__(self, message: str, current_state: str, requested_operation: str) -> None:
        """Initialize animation state error.

        Args:
            message: Error message.
            current_state: Current animation state.
            requested_operation: Operation that was requested.
        """
        super().__init__(message)
        self.current_state = current_state
        self.requested_operation = requested_operation


class EasingFunctionError(AnimationError):
    """Exception raised for invalid easing function usage."""

    def __init__(self, message: str, easing_function_name: str | None = None) -> None:
        """Initialize easing function error.

        Args:
            message: Error message.
            easing_function_name: Optional name of the easing function.
        """
        super().__init__(message)
        self.easing_function_name = easing_function_name
