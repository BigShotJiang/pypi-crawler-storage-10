"""Particle rendering for different output formats."""

from __future__ import annotations

import threading
from typing import TYPE_CHECKING, Any

from ...core.layout.types import RendererType
from ...renderers.base import RenderOutput
from ...utils.logging import get_logger

if TYPE_CHECKING:
    from .emitter import Particle

logger = get_logger(__name__)


class ParticleRenderer:
    """Renderer for particle systems across different backends.

    Handles rendering particles to different output formats including CLI terminals,
    GUI canvases, SVG documents, and other supported renderer types.

    Attributes:
        _lock: Thread synchronization lock for render operations.
    """

    def __init__(self) -> None:
        """Initialize the particle renderer with thread-safe operations."""
        self._lock = threading.RLock()
        self._render_stats = {
            "particles_rendered": 0,
            "render_calls": 0,
            "total_particles": 0,
            "average_particles_per_call": 0.0
        }

        logger.debug("Initialized particle renderer")

    def render_particles(self, particles: list[Particle], renderer_type: RendererType, target: object = None) -> RenderOutput:
        """Render particles to the specified renderer type.

        Args:
            particles: List of particles to render.
            renderer_type: Target renderer type for output.
            target: Optional rendering target (buffer, canvas, etc.).

        Returns:
            RenderOutput containing the rendered content and metadata.

        Raises:
            ValueError: If renderer type is not supported.
        """
        with self._lock:
            active_particles = [p for p in particles if p.life > 0]
            self._render_stats["render_calls"] += 1
            self._render_stats["total_particles"] += len(active_particles)

            if renderer_type == RendererType.CLI:
                output = self._render_cli(active_particles, target)
            elif renderer_type == RendererType.GUI:
                output = self._render_gui(active_particles, target)
            elif renderer_type == RendererType.SVG:
                output = self._render_svg(active_particles, target)
            elif renderer_type == RendererType.HTML:
                output = self._render_html(active_particles, target)
            elif renderer_type == RendererType.PDF:
                output = self._render_pdf(active_particles, target)
            else:
                raise ValueError(f"Unsupported renderer type for particles: {renderer_type}")

            self._render_stats["particles_rendered"] += len(active_particles)
            logger.debug(f"Rendered {len(active_particles)} particles to {renderer_type.value}")
            return output

    def _render_cli(self, particles: list[Particle], target: object = None) -> RenderOutput:
        """Render particles to CLI terminal output.

        Args:
            particles: Active particles to render.
            target: Optional target buffer (defaults to new list).

        Returns:
            RenderOutput with CLI-formatted particle representation.
        """
        buffer = target if isinstance(target, list) else []

        # Create a simple grid representation
        width, height = 80, 24  # Default terminal size
        grid = [[' ' for _ in range(width)] for _ in range(height)]

        for particle in particles:
            # Convert to integer coordinates
            x = max(0, min(width - 1, int(particle.x)))
            y = max(0, min(height - 1, int(particle.y)))

            # Choose character based on size
            if particle.size < 0.5:
                char = '.'
            elif particle.size < 1.0:
                char = 'o'
            else:
                char = 'O'

            # Only overwrite if this particle is more prominent (larger)
            if grid[y][x] == ' ' or (grid[y][x] == '.' and char != '.') or (grid[y][x] == 'o' and char == 'O'):
                grid[y][x] = char

        # Convert grid to string buffer
        output_lines = [''.join(row) for row in grid]
        buffer.extend(output_lines)

        return RenderOutput(
            content='\n'.join(output_lines),
            renderer_type=RendererType.CLI,
            metadata={
                "particle_count": len(particles),
                "terminal_size": (width, height)
            }
        )

    def _render_gui(self, particles: list[Particle], canvas: object = None) -> RenderOutput:
        """Render particles to GUI canvas.

        Args:
            particles: Active particles to render.
            canvas: Optional GUI canvas object for drawing.

        Returns:
            RenderOutput with GUI rendering metadata.
        """
        # In a real implementation, this would draw to an actual GUI canvas
        # For now, we return metadata about what would be rendered
        render_commands: list[dict[str, Any]] = []

        for particle in particles:
            x, y = particle.x, particle.y
            radius = max(1.0, particle.size * 2)
            color = particle.color

            render_commands.append({
                "type": "circle",
                "x": x,
                "y": y,
                "radius": radius,
                "color": color,
                "rotation": particle.rotation
            })

            logger.debug(f"GUI particle at ({x}, {y}) radius={radius}")

        return RenderOutput(
            content="",  # GUI rendering doesn't produce text content
            renderer_type=RendererType.GUI,
            metadata={
                "particle_count": len(particles),
                "render_commands": render_commands,
                "canvas_required": canvas is None
            }
        )

    def _render_svg(self, particles: list[Particle], svg_document: object = None) -> RenderOutput:
        """Render particles to SVG format.

        Args:
            particles: Active particles to render.
            svg_document: Optional SVG document object.

        Returns:
            RenderOutput with SVG XML content.
        """
        svg_elements: list[str] = []

        for particle in particles:
            cx, cy = particle.x, particle.y
            r = max(0.5, particle.size * 2)
            r, g, b, a = particle.color
            color_str = f"rgba({r},{g},{b},{a/255:.2f})"

            # Create SVG circle element
            circle = f'<circle cx="{cx}" cy="{cy}" r="{r}" fill="{color_str}" ' \
                    f'transform="rotate({particle.rotation} {cx} {cy})"/>'
            svg_elements.append(circle)

            logger.debug(f"SVG particle at ({cx}, {cy}) radius={r}")

        svg_content = '\n'.join(svg_elements)

        return RenderOutput(
            content=svg_content,
            renderer_type=RendererType.SVG,
            metadata={
                "particle_count": len(particles),
                "svg_elements": len(svg_elements),
                "content_type": "xml"
            }
        )

    def _render_html(self, particles: list[Particle], target: object = None) -> RenderOutput:
        """Render particles to HTML format.

        Args:
            particles: Active particles to render.
            target: Optional target for HTML output.

        Returns:
            RenderOutput with HTML content.
        """
        html_elements: list[str] = []

        for particle in particles:
            x, y = particle.x, particle.y
            size = max(2, int(particle.size * 4))
            r, g, b, a = particle.color

            # Create styled div element
            style = (f"position: absolute; left: {x}px; top: {y}px; "
                    f"width: {size}px; height: {size}px; "
                    f"background-color: rgba({r},{g},{b},{a/255:.2f}); "
                    f"border-radius: 50%; transform: rotate({particle.rotation}deg);")
            div = f'<div style="{style}"></div>'
            html_elements.append(div)

        html_content = '\n'.join(html_elements)

        return RenderOutput(
            content=html_content,
            renderer_type=RendererType.HTML,
            metadata={
                "particle_count": len(particles),
                "html_elements": len(html_elements),
                "content_type": "html"
            }
        )

    def _render_pdf(self, particles: list[Particle], target: object = None) -> RenderOutput:
        """Render particles to PDF format.

        Args:
            particles: Active particles to render.
            target: Optional PDF document object.

        Returns:
            RenderOutput with PDF rendering metadata.
        """
        # PDF rendering would require a PDF library
        # For now, return metadata about particles
        particle_data: list[dict[str, Any]] = []
        for particle in particles:
            particle_data.append({
                "x": particle.x,
                "y": particle.y,
                "size": particle.size,
                "color": particle.color,
                "rotation": particle.rotation
            })

        return RenderOutput(
            content="",  # PDF is binary format, content provided in metadata
            renderer_type=RendererType.PDF,
            metadata={
                "particle_count": len(particles),
                "particle_data": particle_data,
                "content_type": "binary",
                "requires_pdf_library": True
            }
        )

    def get_render_stats(self) -> dict[str, Any]:
        """Get rendering statistics.

        Returns:
            Dictionary with current rendering statistics.
        """
        with self._lock:
            stats = dict(self._render_stats)  # Create a copy
            if stats["render_calls"] > 0:
                stats["average_particles_per_call"] = stats["total_particles"] / stats["render_calls"]
            else:
                stats["average_particles_per_call"] = 0.0
            return stats
