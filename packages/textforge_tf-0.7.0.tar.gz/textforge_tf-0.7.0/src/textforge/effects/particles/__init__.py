"""Particle effects subsystem for Textforge.

This module provides a complete particle system for creating visual effects
like explosions, fireworks, weather effects, and custom particle animations.
The system supports multiple rendering backends and includes physics simulation,
optimization features, and performance monitoring.
"""

from .config import ParticleSystemConfig
from .effects import ParticleEffects
from .emitter import Particle, ParticleEmitter
from .engine import ParticleEngine
from .errors import InvalidParticleConfigError, ParticleError, ParticleSystemNotFoundError
from .interfaces import (
    create_particle_effect,
    destroy_particle_effect,
    get_active_particle_systems,
    get_particle_engine,
    get_particle_system,
    optimize_particle_systems,
    render_particles,
    update_particles,
)
from .optimization import ParticleOptimization
from .physics import ParticlePhysics
from .renderer import ParticleRenderer

__all__ = [
    # Core classes
    "ParticleEngine",
    "ParticleEmitter",
    "ParticlePhysics",
    "ParticleRenderer",
    "ParticleEffects",
    "ParticleOptimization",
    "ParticleSystemConfig",

    # Data structures
    "Particle",

    # Error classes
    "ParticleError",
    "InvalidParticleConfigError",
    "ParticleSystemNotFoundError",

    # Public API functions
    "get_particle_engine",
    "create_particle_effect",
    "update_particles",
    "render_particles",
    "destroy_particle_effect",
    "get_particle_system",
    "get_active_particle_systems",
    "optimize_particle_systems",
]
