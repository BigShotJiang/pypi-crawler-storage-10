"""Particle subsystem error classes."""

from __future__ import annotations


class ParticleError(Exception):
    """Base exception for particle-related errors.

    This exception serves as the root exception for all particle subsystem
    errors, allowing for consistent error handling and logging across the
    particle system.
    """


class InvalidParticleConfigError(ParticleError):
    """Raised when particle configuration is invalid.

    This exception is raised when a particle system configuration contains
    invalid or missing required parameters, or when configuration values
    are outside acceptable ranges.
    """


class ParticleSystemNotFoundError(ParticleError):
    """Raised when a particle system is not found.

    This exception is raised when attempting to access or manipulate a
    particle system that doesn't exist in the particle engine.
    """
