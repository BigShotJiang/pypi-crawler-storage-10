"""Textforge command-line entry point (modular)."""

from __future__ import annotations

import argparse
import sys
from typing import TYPE_CHECKING, NoReturn

# Ensure valid Windows stdin as early as possible when this module is imported
from ..utils.io import ensure_windows_valid_stdin
from ..utils.logging import get_logger
from .errors import CLIError, ExitCode

try:
    ensure_windows_valid_stdin()
except Exception as e:
    get_logger().debug(f"Failed to ensure valid Windows stdin during import: {e}")

if TYPE_CHECKING:
    from collections.abc import Sequence


class _Parser(argparse.ArgumentParser):

    def error(self, message: str) -> NoReturn:
        self.print_usage(sys.stderr)
        print(f"error: {message}", file=sys.stderr)
        raise SystemExit(ExitCode.USAGE)


def build_parser() -> argparse.ArgumentParser:
    parser = _Parser(prog="textforge", description="Textforge CLI utilities")
    parser.add_argument("--debug", action="store_true", help=argparse.SUPPRESS)
    subparsers = parser.add_subparsers(dest="command", required=True)

    # Register commands from submodules
    from .commands import (
        bench,
        demo,
        dsl,
        export,
        list,
        live,
        markup,
        new,
        plugins,
        preview,
        theme,
        typewriter,
    )

    add_parser = subparsers.add_parser
    list.register(add_parser)
    demo.register(add_parser)
    typewriter.register(add_parser)
    preview.register(add_parser)
    export.register(add_parser)
    live.register(add_parser)
    theme.register(add_parser)
    markup.register(add_parser)
    new.register(add_parser)
    plugins.register(add_parser)
    dsl.register(add_parser)
    bench.register(add_parser)

    return parser


def main(argv: Sequence[str] | None = None) -> int:
    # On Windows under captured subprocesses, stdin handle duplication can fail.
    # Attempt to ensure stdin is backed by a valid handle to prevent WinError 6.
    from ..utils.io import ensure_windows_valid_stdin
    from ..utils.logging import get_logger

    try:
        ensure_windows_valid_stdin()
    except Exception as e:
        get_logger().debug(f"Failed to ensure valid Windows stdin in main: {e}")
    parser = build_parser()
    try:
        args = parser.parse_args(argv)
        try:
            args.func(args)
        except CLIError as e:
            print(str(e), file=sys.stderr)
            return e.code
        except OSError as e:
            print(f"I/O error: {e}", file=sys.stderr)
            return ExitCode.IO_ERROR
        except KeyboardInterrupt:
            print("Interrupted.", file=sys.stderr)
            return ExitCode.RUNTIME_ERROR
        except Exception as e:
            if getattr(args, "debug", False):
                raise
            print(f"Error: {e}", file=sys.stderr)
            return ExitCode.RUNTIME_ERROR
        return ExitCode.OK
    except SystemExit as se:
        # Normalize Windows subprocess handle errors into non-zero exit rather than raising
        try:
            code = int(se.code) if isinstance(se.code, int) else ExitCode.RUNTIME_ERROR
        except Exception:
            code = ExitCode.RUNTIME_ERROR
        return code


if __name__ == "__main__":
    raise SystemExit(main())
