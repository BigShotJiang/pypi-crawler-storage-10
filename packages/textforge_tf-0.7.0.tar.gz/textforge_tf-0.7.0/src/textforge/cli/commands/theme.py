from __future__ import annotations

from pathlib import Path
from typing import TYPE_CHECKING

from ...core import tfprint

if TYPE_CHECKING:
    import argparse

    from ._types import SubparserFactory


def _run_list(_: argparse.Namespace) -> None:
    """List available themes."""
    themes_dir = Path(__file__).parent.parent.parent / "style" / "themes"
    themes = sorted(p.stem for p in themes_dir.glob("*.tfs"))
    tfprint("Available themes:")
    for name in themes:
        tfprint(f"  - {name}")


def register(add_parser: SubparserFactory) -> None:
    """Register the theme command subparsers.

    Args:
        add_parser: Callable used to register the theme command.
    """
    parser = add_parser("theme", help="Theme operations")
    sub = parser.add_subparsers(dest="theme_cmd", required=True)
    p_list = sub.add_parser("list", help="List available themes")
    p_list.set_defaults(func=_run_list)
