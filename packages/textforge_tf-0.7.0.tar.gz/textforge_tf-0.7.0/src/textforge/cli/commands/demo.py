from __future__ import annotations

from typing import TYPE_CHECKING

# Import demo templates when they are built

if TYPE_CHECKING:
    import argparse

    from ._types import SubparserFactory


def _run(args: argparse.Namespace) -> None:
    # Implement running after demo templates are built
    pass


def register(add_parser: SubparserFactory) -> None:
    parser = add_parser("demo", help="Run showcase demos")
    parser.add_argument(
        "--preset",
        choices=["not implemented"],
        default="not implemented",
        help="Demo preset to render",
    )
    parser.set_defaults(func=_run)
