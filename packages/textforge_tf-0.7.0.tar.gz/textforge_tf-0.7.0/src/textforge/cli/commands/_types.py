"""Shared typing helpers for CLI command registration."""

from __future__ import annotations

import argparse
from collections.abc import Callable

SubparserFactory = Callable[..., argparse.ArgumentParser]
"""Type alias for a callable that produces an `ArgumentParser` for a sub-command."""
