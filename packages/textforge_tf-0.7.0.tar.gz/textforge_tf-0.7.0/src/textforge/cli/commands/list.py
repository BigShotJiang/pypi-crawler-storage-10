from __future__ import annotations

from typing import TYPE_CHECKING

from ... import components
from ...core import tfprint

if TYPE_CHECKING:
    import argparse

    from ._types import SubparserFactory


def _run(_: argparse.Namespace) -> None:
    tfprint("Available components:")
    for name in sorted(components.__all__):
        tfprint(f"  - {name}")


def register(add_parser: SubparserFactory) -> None:
    parser = add_parser("list", help="List available renderable components")
    parser.set_defaults(func=_run)
