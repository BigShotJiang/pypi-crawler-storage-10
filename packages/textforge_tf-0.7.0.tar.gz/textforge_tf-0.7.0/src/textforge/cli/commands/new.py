from __future__ import annotations

import os
from dataclasses import dataclass
from typing import TYPE_CHECKING

from ..errors import CLIError

if TYPE_CHECKING:
    import argparse

    from ._types import SubparserFactory


@dataclass(frozen=True)
class ScaffoldConfig:
    """Configuration for generating a scaffold project."""

    name: str
    directory: str


def _scaffold_main_py() -> str:
    """Return the scaffolded `main.py` contents."""
    # Use helpers and tfprint rather than immediate printing in component renderers
    return (
        "from textforge import tfprint, components as C\n\n"
        "def main():\n"
        "    banner = C.title(text='Hello Textforge', width=60, color='primary')\n"
        "    para = C.paragraph(text='Project scaffold created.', width=60)\n"
        "    tfprint(banner)\n"
        "    tfprint(para)\n\n"
        "if __name__ == '__main__':\n"
        "    main()\n"
    )


def _build_config(args: argparse.Namespace) -> ScaffoldConfig:
    """Translate argparse namespace to a scaffold configuration."""
    name = getattr(args, "name", None)
    directory = getattr(args, "dir", None)
    if not isinstance(name, str) or not isinstance(directory, str):
        raise CLIError("Arguments 'name' and '--dir' must be provided as strings.")
    return ScaffoldConfig(name=name, directory=directory)


def _run(args: argparse.Namespace) -> None:
    """Create a new Textforge project scaffold on disk."""
    config = _build_config(args)
    target = os.path.join(config.directory, config.name)
    try:
        os.makedirs(target, exist_ok=True)
    except OSError as error:
        raise CLIError(f"Failed to create directory '{target}': {error}") from error
    main_py = os.path.join(target, "main.py")
    if not os.path.exists(main_py):
        try:
            with open(main_py, "w", encoding="utf-8") as handle:
                handle.write(_scaffold_main_py())
        except OSError as error:
            raise CLIError(f"Failed to write scaffold file: {error}") from error
    print(f"Scaffold created at {target}")


def register(add_parser: SubparserFactory) -> None:
    """Register the `new` CLI command."""
    parser = add_parser("new", help="Scaffold a new Textforge demo project")
    parser.add_argument("name", help="Project name")
    parser.add_argument("--dir", default=".", help="Target directory")
    parser.set_defaults(func=_run)
