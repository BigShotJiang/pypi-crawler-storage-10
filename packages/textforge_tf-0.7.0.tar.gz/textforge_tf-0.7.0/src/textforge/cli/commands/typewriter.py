from __future__ import annotations

import sys
import time
from dataclasses import dataclass
from typing import TYPE_CHECKING

from ...style.colors import Color
from ..errors import CLIError

if TYPE_CHECKING:
    import argparse

    from ._types import SubparserFactory


@dataclass(frozen=True)
class TypewriterConfig:
    """Configuration for the typewriter command."""

    message: str
    delay: float
    color: str | None


def _build_config(args: argparse.Namespace) -> TypewriterConfig:
    """Translate argparse namespace values into a configuration object."""
    message = getattr(args, "message", None)
    if not isinstance(message, str):
        raise CLIError("Argument 'message' must be provided as text.")
    delay_value = getattr(args, "delay", 0.05)
    try:
        delay = float(delay_value)
    except (TypeError, ValueError) as error:
        raise CLIError("Argument '--delay' must be a numeric value.") from error
    color_value = getattr(args, "color", None)
    if color_value is not None and not isinstance(color_value, str):
        raise CLIError("Argument '--color' must be text when provided.")
    return TypewriterConfig(message=message, delay=delay, color=color_value)


def _format_character(character: str, color: str | None) -> str:
    """Format a single character with optional color."""
    if color is None:
        return character
    return f"{Color.get_color(color)}{character}{Color.RESET}"


def _run(args: argparse.Namespace) -> None:
    """Render the typewriter animation to stdout."""
    config = _build_config(args)
    for character in config.message:
        sys.stdout.write(_format_character(character, config.color))
        sys.stdout.flush()
        time.sleep(config.delay)
    sys.stdout.write("\n")
    sys.stdout.flush()


def register(add_parser: SubparserFactory) -> None:
    """Register the `typewriter` CLI command."""
    parser = add_parser("typewriter", help="Play a typewriter animation")
    parser.add_argument("message", help="Message to animate")
    parser.add_argument("--delay", type=float, default=0.05, help="Delay between characters")
    parser.add_argument("--color", default=None, help="Optional text color")
    parser.set_defaults(func=_run)
