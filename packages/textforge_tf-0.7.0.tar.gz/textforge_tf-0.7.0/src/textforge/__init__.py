"""Textforge: modular terminal text and UI rendering toolkit."""

from __future__ import annotations

# Submodules are imported lazily to avoid premature subsystem initialization.
from importlib import import_module

# Core functionality - most commonly used
from .api import (
    TextForgeAPI,
    create_component,
    export_html,
    export_pdf,
    export_svg,
    export_text,
    render,
)
from .core import Console, render_call, tfprint
from .gpu import GPUManager
from .markup import MarkupEngine
from .style import Color, get_style_engine

__all__ = [
    # Core classes and functions
    "Console",
    "render_call",
    "tfprint",
    "Color",
    "get_style_engine",
    "MarkupEngine",
    "TextForgeAPI",
    "create_component",
    "render",
    "export_html",
    "export_pdf",
    "export_svg",
    "export_text",
    "GPUManager",
]


def __getattr__(name: str) -> object:
    """Lazily expose heavy-weight subpackages on first access.

    Parameters
    ----------
    name : str
        Attribute name requested from the ``textforge`` package.

    Returns
    -------
    object
        The requested module if it is a lazily exposed subpackage.

    Raises
    ------
    AttributeError
        Raised when the attribute is not a supported lazy submodule.
    """
    if name in {"components", "effects", "templates", "utils"}:
        module = import_module(f"textforge.{name}")
        globals()[name] = module
        return module
    raise AttributeError(f"module 'textforge' has no attribute '{name}'")
