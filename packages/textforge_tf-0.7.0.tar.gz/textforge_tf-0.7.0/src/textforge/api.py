"""Public Textforge API surface consolidating component creation and rendering."""

from __future__ import annotations

import threading
from dataclasses import dataclass
from importlib import import_module
from itertools import count

from .components.base import (
    Component,
    ComponentNotFoundError,
    ComponentValidationError,
    InvalidComponentPropertyError,
    RenderableComponent,
)
from .core.layout.types import RendererType
from .export import ansi_to_html, ansi_to_pdf, ansi_to_svg, ansi_to_text
from .gpu import GPUManager
from .renderers.base import RenderingError
from .renderers.interfaces import render_component
from .style.subsystem import StylingContext
from .utils.logging import get_logger

_COMPONENT_PATHS: dict[str, tuple[str, str]] = {
    "text": ("textforge.components.text", "Text"),
    "title": ("textforge.components.typography.title", "Title"),
    "paragraph": ("textforge.components.typography.paragraph", "Paragraph"),
    "list": ("textforge.components.typography.list", "List"),
    "box": ("textforge.components.containers.box", "Box"),
    "panel": ("textforge.components.containers.panel", "Panel"),
    "card": ("textforge.components.containers.card", "Card"),
    "dialog": ("textforge.components.containers.dialog", "Dialog"),
    "columns": ("textforge.components.layout.columns", "Columns"),
    "flex": ("textforge.components.layout.flex", "Flex"),
    "grid": ("textforge.components.layout.grid", "Grid"),
    "canvas": ("textforge.components.visual.canvas", "Canvas"),
    "graph": ("textforge.components.visual.graph", "Graph"),
    "image": ("textforge.components.visual.image", "Image"),
    "button": ("textforge.components.interactive.button", "Button"),
    "checkbox": ("textforge.components.interactive.checkbox", "Checkbox"),
    "slider": ("textforge.components.interactive.slider", "Slider"),
    "form": ("textforge.components.interactive.form", "Form"),
    "table": ("textforge.components.data.table", "Table"),
    "chart": ("textforge.components.data.chart", "Chart"),
    "progress": ("textforge.components.data.progress", "Progress"),
    "progress_bar": ("textforge.components.status.progress_bar", "ProgressBar"),
    "gauge": ("textforge.components.status.gauge", "Gauge"),
    "spinner": ("textforge.components.status.spinner", "Spinner"),
    "alert": ("textforge.components.feedback.alert", "Alert"),
    "toast": ("textforge.components.feedback.toast", "Toast"),
    "snackbar": ("textforge.components.feedback.snackbar", "Snackbar"),
    "breadcrumbs": ("textforge.components.navigation.breadcrumbs", "Breadcrumbs"),
    "menu": ("textforge.components.navigation.menu", "Menu"),
    "tabs": ("textforge.components.navigation.tabs", "Tabs"),
    "asciiart": ("textforge.components.decorative.ascii_art", "ASCIIArt"),
    "ascii_art": ("textforge.components.decorative.ascii_art", "ASCIIArt"),
    "banner": ("textforge.components.decorative.banner", "Banner"),
    "divider": ("textforge.components.decorative.divider", "Divider"),
}
_COMPONENT_PATHS["progressbar"] = _COMPONENT_PATHS["progress_bar"]


@dataclass(frozen=True)
class ComponentRecord:
    """Metadata tracked for every component created via the public API."""

    identifier: str
    component: Component


class TextForgeAPI:
    """Thread-safe façade that exposes the stable Textforge API."""

    def __init__(self) -> None:
        """Initialize the API facade and supporting registries.

        Parameters
        ----------
        self : TextForgeAPI
            The API instance being initialized.

        Returns
        -------
        None
            This initializer configures internal state in place.
        """

        self._logger = get_logger("textforge.api")
        self._component_registry = self._build_registry()
        self._components: dict[str, ComponentRecord] = {}
        self._id_counter = count(1)
        self._lock = threading.RLock()
        self._render_lock = threading.RLock()

    def _build_registry(self) -> dict[str, tuple[str, str]]:
        """Build a component registry mapping names to import targets.

        Parameters
        ----------
        self : TextForgeAPI
            The active API instance requesting the registry snapshot.

        Returns
        -------
        dict[str, tuple[str, str]]
            Mapping of normalized component identifiers to module path and class name pairs.
        """

        return dict(_COMPONENT_PATHS)

    def create_component(self, component_type: str, **props: object) -> Component:
        """Create a component instance of the requested type.

        Parameters
        ----------
        self : TextForgeAPI
            The API facade managing component creation.
        component_type : str
            Name of the component type to create; whitespace and hyphens are normalized.
        **props : object
            Keyword arguments passed directly to the component constructor.

        Returns
        -------
        Component
            The instantiated component registered with this API instance.
        """
        normalized = self._normalize(component_type)
        with self._lock:
            target = self._component_registry.get(normalized)
            if target is None:
                raise ComponentNotFoundError(f"Unknown component type '{component_type}'")

        try:
            component = self._instantiate_component(target, props)
        except InvalidComponentPropertyError:
            raise
        except TypeError as exc:  # Incorrect arguments
            raise ComponentValidationError(str(exc)) from exc

        identifier = self._allocate_identifier(component)
        with self._lock:
            self._components[identifier] = ComponentRecord(identifier, component)
        self._logger.debug("Created component %s (id=%s)", component.component_name, identifier)
        return component

    def render(self, component: Component | RenderableComponent | str, target: str = "cli", **options: object) -> str | bytes:
        """Render a component to the requested target.

        Parameters
        ----------
        self : TextForgeAPI
            The API facade orchestrating rendering.
        component : Component | RenderableComponent | str
            Component instance, renderable, or identifier previously returned by :meth:`create_component`.
        target : str, default="cli"
            Rendering backend identifier such as ``"cli"``, ``"html"``, ``"svg"``, ``"pdf"``, ``"text"``, or ``"tty"``.
        **options : object
            Additional renderer or exporter specific keyword arguments.

        Returns
        -------
        str | bytes
            Rendered payload for the requested backend; export formats may return bytes for binary content.
        """

        normalized_target = target.lower().strip()
        if normalized_target == "cli":
            return self._render_terminal(component)
        if normalized_target == "tty":
            renderable = self._ensure_renderable(component)
            self._logger.debug("TTY target requested; falling back to CLI renderer")
            return self._render_cli(renderable)
        if normalized_target in {"html", "svg", "pdf", "text"}:
            return self.export(component, normalized_target, **options)
        raise ValueError(f"Unsupported render target '{target}'")

    def export(self, component: Component | RenderableComponent | str, format: str, **options: object) -> str | bytes:
        """Export a component to a textual or document representation.

        Parameters
        ----------
        self : TextForgeAPI
            The API facade managing the export operation.
        component : Component | RenderableComponent | str
            Component or identifier to export; resolved to a renderable prior to export.
        format : str
            Export format identifier such as ``"html"``, ``"svg"``, ``"pdf"``, or ``"text"``.
        **options : object
            Optional exporter configuration forwarded to the export helpers.

        Returns
        -------
        str | bytes
            Exported representation for the requested format; binary formats return bytes.
        """

        renderable = self._ensure_renderable(component)
        ansi_text = self._render_cli(renderable)
        fmt = format.lower().strip()
        if fmt == "html":
            return ansi_to_html(ansi_text)
        if fmt == "svg":
            return ansi_to_svg(ansi_text, **options)
        if fmt == "pdf":
            return ansi_to_pdf(ansi_text, **options)
        if fmt in {"text", "plain"}:
            return ansi_to_text(ansi_text)
        raise ValueError(f"Unsupported export format '{format}'")

    def render_gpu(self, component: Component | RenderableComponent | str, target_surface: object = None) -> None:
        """Render a component using GPU acceleration when available.

        This method provides hardware-accelerated rendering for components,
        automatically falling back to CPU rendering if GPU acceleration is
        not available.

        Parameters
        ----------
        component : Component | RenderableComponent | str
            The component to render, either as an instance, renderable, or
            identifier from create_component().
        target_surface : object, optional
            The target rendering surface. If None, uses default surface.

        Returns
        -------
        None
            Renders directly to the GPU or target surface.

        Raises
        ------
        ComponentNotFoundError
            If identifier is provided but not found.
        RenderingError
            If rendering fails.

        Examples
        --------
        >>> api = TextForgeAPI()
        >>> component = api.create_component("text", content="GPU accelerated!")
        >>> api.render_gpu(component)
        """
        try:
            renderable = self._ensure_renderable(component)
            gpu_manager = GPUManager()

            if gpu_manager.is_available():
                self._logger.debug("Rendering component with GPU acceleration")
                from .gpu import render_with_gpu_acceleration
                render_with_gpu_acceleration(renderable, target_surface)
            else:
                self._logger.debug("GPU not available, falling back to CPU rendering")
                # Fall back to regular rendering
                self.render(component, target="cli")

        except Exception as e:
            self._logger.error(f"GPU rendering failed: {e}")
            raise RenderingError(f"GPU rendering failed: {e}") from e

    def list_components(self) -> list[str]:
        """Return identifiers for components created through the API.

        Parameters
        ----------
        self : TextForgeAPI
            The API facade holding the component registry.

        Returns
        -------
        list[str]
            Snapshot of component identifiers created by this API instance.
        """

        with self._lock:
            return list(self._components.keys())

    def get_component(self, identifier: str) -> Component:
        """Retrieve a component by identifier.

        Parameters
        ----------
        self : TextForgeAPI
            The API facade performing component lookup.
        identifier : str
            Identifier previously produced by :meth:`create_component`.

        Returns
        -------
        Component
            The component instance registered under the provided identifier.
        """

        with self._lock:
            record = self._components.get(identifier)
        if record is None:
            raise ComponentNotFoundError(f"Component with id '{identifier}' was not created by this API instance")
        return record.component

    def _render_terminal(self, component: Component | RenderableComponent | str) -> str:
        """Render the component or identifier using the CLI renderer.

        Parameters
        ----------
        self : TextForgeAPI
            The API facade coordinating rendering.
        component : Component | RenderableComponent | str
            Component, renderable, or identifier to render on the CLI backend.

        Returns
        -------
        str
            Rendered ANSI text output from the CLI renderer.
        """

        renderable = self._ensure_renderable(component)
        try:
            with self._render_lock:
                output = render_component(renderable, RendererType.CLI)
        except RenderingError as exc:
            self._logger.warning(
                "Primary CLI rendering failed (%s); using fallback renderer", exc
            )
            return self._fallback_render(renderable)
        content = output.content
        if isinstance(content, bytes):
            return content.decode("utf-8", errors="replace")
        return content

    def _render_cli(self, renderable: RenderableComponent) -> str:
        """Render a renderable component directly to the CLI backend.

        Parameters
        ----------
        self : TextForgeAPI
            The API facade orchestrating the render call.
        renderable : RenderableComponent
            Prepared renderable instance expected by the CLI renderer.

        Returns
        -------
        str
            Rendered CLI output encoded as a string.
        """

        try:
            with self._render_lock:
                output = render_component(renderable, RendererType.CLI)
        except RenderingError as exc:
            self._logger.warning(
                "Primary CLI rendering failed (%s); using fallback renderer", exc
            )
            return self._fallback_render(renderable)
        content = output.content
        return content.decode("utf-8", errors="replace") if isinstance(content, bytes) else content

    def _ensure_renderable(self, component: Component | RenderableComponent | str) -> RenderableComponent:
        """Convert a component, renderable, or identifier into a renderable instance.

        Parameters
        ----------
        self : TextForgeAPI
            The API facade resolving the component reference.
        component : Component | RenderableComponent | str
            Component instance, identifier, or already renderable object.

        Returns
        -------
        RenderableComponent
            Renderable ready for rendering or exporting.
        """

        resolved = self._resolve_component(component)
        if isinstance(resolved, RenderableComponent):
            return resolved
        styling_context = StylingContext(component_name=resolved.component_name)
        return resolved.to_renderable(styling_context)

    def _resolve_component(self, component: Component | RenderableComponent | str) -> Component | RenderableComponent:
        """Resolve component references or identifiers to concrete instances.

        Parameters
        ----------
        self : TextForgeAPI
            The API facade performing the resolution.
        component : Component | RenderableComponent | str
            Component instance, renderable, or identifier to resolve.

        Returns
        -------
        Component | RenderableComponent
            The resolved component or renderable reference.
        """

        if isinstance(component, str):
            return self.get_component(component)
        return component

    def _allocate_identifier(self, component: Component) -> str:
        """Allocate a unique identifier for a component instance.

        Parameters
        ----------
        self : TextForgeAPI
            The API facade issuing the identifier.
        component : Component
            Newly created component requiring registration.

        Returns
        -------
        str
            Generated identifier combining the component name and a sequence number.
        """

        return f"{component.component_name}-{next(self._id_counter)}"

    def _normalize(self, value: str) -> str:
        """Normalize component names to simplified lookup keys.

        Parameters
        ----------
        self : TextForgeAPI
            The API facade performing name normalization.
        value : str
            Raw component type string provided by the caller.

        Returns
        -------
        str
            Lower-case, underscore-separated key suitable for registry lookups.
        """

        return value.replace(" ", "_").replace("-", "_").lower()

    def _instantiate_component(self, target: tuple[str, str], props: dict[str, object]) -> Component:
        """Instantiate a component from an import target tuple.

        Parameters
        ----------
        self : TextForgeAPI
            The API facade coordinating component construction.
        target : tuple[str, str]
            Module path and class name identifying the component implementation.
        props : dict[str, object]
            Keyword arguments forwarded to the component constructor.

        Returns
        -------
        Component
            Newly created component instance.
        """

        module_path, class_name = target
        module = import_module(module_path)
        factory = getattr(module, class_name)
        return factory(**props)

    def _fallback_render(self, renderable: RenderableComponent) -> str:
        """Render the component using best-effort fallbacks when the CLI renderer fails.

        Parameters
        ----------
        self : TextForgeAPI
            The API facade orchestrating the fallback rendering.
        renderable : RenderableComponent
            Renderable instance requiring fallback rendering support.

        Returns
        -------
        str
            String representation generated from the renderable as a last resort.
        """

        from .core import Console

        console = Console()
        try:
            try:
                result = renderable.render(console)
            except TypeError:
                try:
                    result = renderable.render(console)
                except TypeError:
                    result = renderable.render(console=console)
        except Exception:
            text_payload = (
                getattr(renderable, "content", None)
                or getattr(renderable, "text", None)
                or getattr(renderable, "_text", None)
            )
            if text_payload is not None:
                return str(text_payload)
            return renderable.component_name
        if result is None:
            return ""
        if isinstance(result, list):
            return "\n".join(str(part) for part in result)
        return str(result)


_default_api = TextForgeAPI()


def create_component(component_type: str, **props: object) -> Component:
    """Create a component using the shared :class:`TextForgeAPI` instance.

    Parameters
    ----------
    component_type : str
        Name of the component to create; normalized before lookup.
    **props : object
        Keyword arguments forwarded to the component constructor.

    Returns
    -------
    Component
        Component instance created by the shared API facade.
    """

    return _default_api.create_component(component_type, **props)


def render(component: Component | RenderableComponent | str, target: str = "cli", **options: object) -> str | bytes:
    """Render a component using the shared :class:`TextForgeAPI` instance.

    Parameters
    ----------
    component : Component | RenderableComponent | str
        Component instance, renderable, or identifier previously returned by :func:`create_component`.
    target : str, default="cli"
        Rendering backend identifier forwarded to :meth:`TextForgeAPI.render`.
    **options : object
        Optional keyword arguments forwarded to the renderer.

    Returns
    -------
    str | bytes
        Rendered output for the requested backend.
    """

    return _default_api.render(component, target=target, **options)


def export_html(component: Component | RenderableComponent | str) -> str:
    """Export a component to HTML.

    Parameters
    ----------
    component : Component | RenderableComponent | str
        Component instance, renderable, or identifier for export.

    Returns
    -------
    str
        HTML string generated by the shared API facade.
    """

    exported = _default_api.export(component, "html")
    return exported if isinstance(exported, str) else exported.decode("utf-8", errors="replace")


def export_svg(component: Component | RenderableComponent | str, **options: object) -> str:
    """Export a component to SVG.

    Parameters
    ----------
    component : Component | RenderableComponent | str
        Component instance, renderable, or identifier for export.
    **options : object
        Optional configuration forwarded to the SVG exporter.

    Returns
    -------
    str
        SVG string produced by the exporter.
    """

    exported = _default_api.export(component, "svg", **options)
    return exported if isinstance(exported, str) else exported.decode("utf-8", errors="replace")


def export_pdf(component: Component | RenderableComponent | str, **options: object) -> bytes:
    """Export a component to PDF.

    Parameters
    ----------
    component : Component | RenderableComponent | str
        Component instance, renderable, or identifier for export.
    **options : object
        Optional configuration forwarded to the PDF exporter.

    Returns
    -------
    bytes
        Binary PDF payload generated by the exporter.
    """

    exported = _default_api.export(component, "pdf", **options)
    return exported if isinstance(exported, bytes) else exported.encode("utf-8")


def export_text(component: Component | RenderableComponent | str) -> str:
    """Export a component to plain text.

    Parameters
    ----------
    component : Component | RenderableComponent | str
        Component instance, renderable, or identifier for export.

    Returns
    -------
    str
        Plain-text representation of the rendered component.
    """

    exported = _default_api.export(component, "text")
    return exported if isinstance(exported, str) else exported.decode("utf-8", errors="replace")


__all__ = [
    "TextForgeAPI",
    "create_component",
    "render",
    "export_html",
    "export_pdf",
    "export_svg",
    "export_text",
]
