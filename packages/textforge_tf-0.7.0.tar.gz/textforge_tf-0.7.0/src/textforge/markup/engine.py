"""Markup parsing facilities.

Upgraded to include a small tokenizer that can handle nested tags, escaping,
and custom tag callbacks of the form {tag:payload}. Malformed tags degrade to
literal text. The public surface remains MarkupEngine.register_tag/render.
"""

from __future__ import annotations

import re as _re
from collections import deque
from threading import Lock
from typing import TYPE_CHECKING

from ..style.colors import Color

if TYPE_CHECKING:
    from collections.abc import Callable


class MarkupEngine:
    """Inline markup renderer with simple custom-tag registry.

    Supports registering custom handlers for tags: {tagname:payload} → handler(payload).
    If a handler returns a string, it is injected in-place; otherwise the original tag
    is left intact. Handlers are evaluated before the stock color/effect processor.
    """

    # Global registry so CLIs and consoles can share known tags
    _global_handlers: dict[str, Callable[[str], str | None]] = {}

    # Precompiled patterns for performance (class-level to reuse across instances)
    _CUSTOM_CURLY_RE = _re.compile(r"\{([^\}]+)\}")
    _CUSTOM_BRACKET_RE = _re.compile(r"\[([^\]]+)\]")
    _ESCAPE_TOKENS = {
        "[[": "\x00__LBR__\x00",
        "]]": "\x00__RBR__\x00",
        "\\[": "\x00__LBR__\x00",
        "\\]": "\x00__RBR__\x00",
        "{{": "\x00__LCB__\x00",
        "}}": "\x00__RCB__\x00",
        "\\{": "\x00__LCB__\x00",
        "\\}": "\x00__RCB__\x00",
    }
    _ESCAPE_RESTORE = {
        "\x00__LBR__\x00": "[",
        "\x00__RBR__\x00": "]",
        "\x00__LCB__\x00": "{",
        "\x00__RCB__\x00": "}",
    }

    def __init__(self, *, safe_mode: bool = False) -> None:
        # Start with a copy of global handlers to make instances independent
        self._tag_handlers: dict[str, Callable[[str], str | None]] = dict(self._global_handlers)
        # When enabled, all markup sequences are treated as literal text
        # and escaped so they render safely without evaluation.
        self._safe_mode = bool(safe_mode)
        # Tiny per-instance output cache to avoid reprocessing repeated inputs
        # (size-limited to prevent unbounded growth)
        self._cache: dict[str, str] = {}
        self._cache_order: deque[str] = deque()
        self._cache_limit = 128
        self._cache_lock = Lock()

    def _cache_get(self, key: str) -> str | None:
        """Return cached render result when available.

        Args:
            key (str): Input string used as cache key.

        Returns:
            str | None: Cached render output when present.
        """
        with self._cache_lock:
            return self._cache.get(key)

    def _cache_put(self, key: str, value: str) -> None:
        """Store rendered output respecting the FIFO size limit.

        Args:
            key (str): Cache key representing the input text.
            value (str): Rendered markup output to store.

        Returns:
            None
        """
        with self._cache_lock:
            if key in self._cache:
                return
            if len(self._cache) >= self._cache_limit:
                oldest = self._cache_order.popleft()
                self._cache.pop(oldest, None)
            self._cache[key] = value
            self._cache_order.append(key)

    def register_tag(self, name: str, handler: Callable[[str], str | None]) -> None:
        """Register a custom tag handler for this markup engine instance.

        Args:
            name: The tag name (case-insensitive).
            handler: A callable that takes a payload string and returns a replacement string or None.

        Returns:
            None
        """
        self._tag_handlers[name] = handler

    # Class-level registration for global availability
    @classmethod
    def register_global_tag(cls, name: str, handler: Callable[[str], str | None]) -> None:
        """Register a custom tag handler globally for all markup engine instances.

        Args:
            name: The tag name (case-insensitive).
            handler: A callable that takes a payload string and returns a replacement string or None.

        Returns:
            None
        """
        cls._global_handlers[name] = handler

    @classmethod
    def list_global_tags(cls) -> list[str]:
        """List all globally registered custom tag names.

        Returns:
            A sorted list of registered tag names.
        """
        return sorted(cls._global_handlers.keys())

    def render(self, text: str) -> str:
        """Render markup text with custom tags and color/effect processing.

        Processes the input text through several phases: escape handling, custom tag replacement,
        color/effect markup application, and escape restoration. In safe mode, all markup is
        escaped to render literally.

        Args:
            text (str): The input text containing markup.

        Returns:
            str: The rendered text with markup processed.
        """
        # Fast path: when the text contains no markup delimiters, return unchanged
        if not self._safe_mode and ("[" not in text and "{" not in text):
            return text

        # Cache fast-path: repeated renders of identical input
        cached = self._cache_get(text)
        if cached is not None:
            return cached

        # In safe mode, neutralize markup and custom-tag syntax entirely
        if self._safe_mode:
            # Escape bracket/brace markup so it renders literally
            rendered_safe = text.replace("[", "[[").replace("]", "]]").replace("{", "{{").replace("}", "}}")
            self._cache_put(text, rendered_safe)
            return rendered_safe
        # Tokenize to protect escaped delimiters and nested constructs
        # 1) Protect escaped brackets and braces
        s = text
        escape_tokens = self._ESCAPE_TOKENS
        escape_restore = self._ESCAPE_RESTORE
        for marker, token in escape_tokens.items():
            if marker in s:
                s = s.replace(marker, token)

        # 2) Custom tags: {name:payload}
        if self._tag_handlers and ("{" in s or "[" in s):
            handlers = self._tag_handlers
            handlers_get = handlers.get

            def _custom_replace(m: _re.Match[str]) -> str:
                inner = m.group(1)
                if ":" not in inner:
                    return m.group(0)
                name, payload = inner.split(":", 1)
                name = name.strip().lower()
                payload = payload.strip()
                handler = handlers_get(name)
                if not handler:
                    return m.group(0)
                try:
                    result = handler(payload)
                except Exception:
                    return m.group(0)
                return result if isinstance(result, str) else m.group(0)

            if "{" in s:
                s = self._CUSTOM_CURLY_RE.sub(_custom_replace, s)

            # Support bracket-syntax custom tags: [name:payload]
            # Only intercept when name is a registered custom tag to avoid
            # interfering with stock color/effect tags like [red]
            def _bracket_replace(m: _re.Match[str]) -> str:
                inner = m.group(1)
                # Only treat as custom tag if it contains a ':' and the name is registered
                if ":" not in inner:
                    return m.group(0)
                name, payload = inner.split(":", 1)
                name = name.strip().lower()
                payload = payload.strip()
                handler = handlers_get(name)
                if not handler:
                    return m.group(0)
                try:
                    result = handler(payload)
                except Exception:
                    return m.group(0)
                return result if isinstance(result, str) else m.group(0)

            # Only transform bracket custom tags that match registered names to ensure
            # idempotence when re-rendering text that already contains stock tags.
            if "[" in s:
                s = self._CUSTOM_BRACKET_RE.sub(_bracket_replace, s)

        # 3) Apply stock color/effect processor exactly once. If the string
        # already contains SGR sequences from a prior render, skip to ensure
        # idempotence.
        if "\x1b[" not in s:
            s = Color.apply_inline_markup(s)

        # 4) Restore escapes
        for token, literal in escape_restore.items():
            if token in s:
                s = s.replace(token, literal)

        # Store in small output cache
        self._cache_put(text, s)
        return s
