"""Gradient helpers for color interpolation."""

from __future__ import annotations

from .ansi import rgb_to_ansi


def blend(rgb_a: tuple[int, int, int], rgb_b: tuple[int, int, int], t: float) -> tuple[int, int, int]:
    """Return the colour between ``rgb_a`` and ``rgb_b`` at ratio ``t``."""

    t = max(0.0, min(1.0, t))
    return (
        int(rgb_a[0] + (rgb_b[0] - rgb_a[0]) * t),
        int(rgb_a[1] + (rgb_b[1] - rgb_a[1]) * t),
        int(rgb_a[2] + (rgb_b[2] - rgb_a[2]) * t),
    )


def apply_gradient(text: str, start_rgb: tuple[int, int, int], end_rgb: tuple[int, int, int]) -> str:
    """Apply a simple linear gradient across ``text``."""

    if not text:
        return text
    n = len(text)
    out: list[str] = []
    inv = 1.0 / max(1, n - 1)
    to_ansi = rgb_to_ansi
    sr, sg, sb = start_rgb
    er, eg, eb = end_rgb
    dr = er - sr
    dg = eg - sg
    db = eb - sb
    append = out.append
    for i, ch in enumerate(text):
        t = i * inv
        r = int(sr + dr * t)
        g = int(sg + dg * t)
        b = int(sb + db * t)
        append(f"{to_ansi((r, g, b))}{ch}")
    return "".join(out)


__all__ = ["blend", "apply_gradient"]
