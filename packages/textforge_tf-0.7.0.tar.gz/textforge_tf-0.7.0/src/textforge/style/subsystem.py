"""Public interface for the Textforge styling subsystem."""

from __future__ import annotations

import threading
from dataclasses import dataclass
from typing import TYPE_CHECKING, Any

from ..core.concurrency import AtomicCounter, ReadWriteLock, get_processor
from ..utils.logging import get_logger
from .tfs.tfs_engine import StyleEngine

if TYPE_CHECKING:
    from collections.abc import Mapping

    from .tfs.tfs_cascade import ResolvedStyle


class StyleResolutionError(Exception):
    """Raised when the styling engine fails to resolve a component."""


class InvalidStyleValueError(Exception):
    """Raised when a style property value is invalid."""


class StyleNotFoundError(Exception):
    """Raised when a style cannot be found for a component."""


class ThemeOverrideError(Exception):
    """Raised when theme overrides conflict with registered tokens."""


@dataclass(slots=True, frozen=True)
class StylingContext:
    """Context data required to resolve a component style."""

    component_name: str
    state: Mapping[str, bool] | None = None
    theme_overrides: Mapping[str, str] | None = None
    caps: Any = None

    def active_states(self) -> frozenset[str]:
        """Return the set of active states."""

        return frozenset(k for k, v in (self.state or {}).items() if v)


@dataclass(slots=True, frozen=True)
class _CacheKey:
    """Internal cache key used by :class:`StylingSubsystem`."""

    component: str
    states: frozenset[str]
    overrides: tuple[tuple[str, str], ...]
    theme_version: int


class StylingSubsystem:
    """Facade around :class:`StyleEngine` providing caching and logging."""

    def __init__(self) -> None:
        self._engine = StyleEngine()
        self._cache: dict[_CacheKey, ResolvedStyle] = {}
        self._lock = ReadWriteLock()  # Upgrade to read-write lock for better concurrency
        self._parallel_processor = get_processor()
        self._resolution_counter = AtomicCounter()
        self._logger = get_logger("textforge.style.subsystem")

    def resolve_style(self, context: StylingContext) -> ResolvedStyle:
        """Resolve the style for ``context`` using caching."""

        overrides_key = tuple(sorted((context.theme_overrides or {}).items()))
        key = _CacheKey(
            component=context.component_name,
            states=context.active_states(),
            overrides=overrides_key,
            theme_version=self._engine.theme_version,
        )

        with self._lock:
            cached = self._cache.get(key)
            if cached is not None:
                self._logger.debug("style cache hit for %s states=%s", key.component, sorted(key.states))
                return cached

        self._logger.debug("style cache miss for %s states=%s", key.component, sorted(key.states))
        resolved = self._engine.resolve(
            node={"component_name": context.component_name},
            state=context.state or {},
            caps=context.caps,
            overrides=context.theme_overrides,
        )

        with self._lock:
            self._cache[key] = resolved
        return resolved

    def invalidate_cache(self, component_name: str | None = None) -> None:
        """Invalidate cached styles."""

        with self._lock:
            if component_name is None:
                self._cache.clear()
                return
            to_remove = [key for key in self._cache if key.component == component_name]
            for key in to_remove:
                del self._cache[key]

    def set_theme(self, theme_name: str) -> None:
        """Switch the active theme and clear the cache."""

        self._engine.set_theme(theme_name)
        self.invalidate_cache()

    def load_stylesheet(self, path: str) -> None:
        """Load an additional stylesheet and clear cached entries."""

        self._engine.load_stylesheet(path)
        self.invalidate_cache()

    def resolve_styles_parallel(self, contexts: list[StylingContext]) -> list[ResolvedStyle]:
        """Resolve styles for multiple contexts in parallel.

        Args:
            contexts: List of styling contexts to resolve.

        Returns:
            List of resolved styles in the same order as input contexts.
        """
        if not contexts:
            return []

        # Prepare tasks for parallel processing
        processed_tasks: list[tuple[int, StylingContext, _CacheKey]] = []
        cached_results = {}

        for i, context in enumerate(contexts):
            overrides_key = tuple(sorted((context.theme_overrides or {}).items()))
            key = _CacheKey(
                component=context.component_name,
                states=context.active_states(),
                overrides=overrides_key,
                theme_version=self._engine.theme_version,
            )

            # Check cache first (thread-safe read)
            with self._lock.acquire_read():
                cached = self._cache.get(key)
                if cached is not None:
                    cached_results[i] = cached
                else:
                    processed_tasks.append((i, context, key))

        # Process non-cached tasks in parallel
        if processed_tasks:
            style_tasks: list[dict[str, Any]] = []
            for _, context, _ in processed_tasks:
                style_tasks.append({
                    'component_name': context.component_name,
                    'state': context.state or {},
                    'caps': context.caps,
                    'theme_overrides': context.theme_overrides
                })

            # Use parallel processor for style resolution
            results = self._parallel_processor.parallelize_style_resolution(style_tasks)

            # Store results and update cache
            for (original_index, _, cache_key), result in zip(processed_tasks, results, strict=True):
                if result is not None:
                    cached_results[original_index] = result
                    # Cache the result
                    with self._lock.acquire_write():
                        self._cache[cache_key] = result

        # Collect all results in original order
        final_results: list[ResolvedStyle] = []
        for i in range(len(contexts)):
            final_results.append(cached_results[i])

        self._logger.debug(f"Parallel style resolution completed for {len(contexts)} contexts")
        return final_results

    def get_style_stats(self) -> dict[str, int]:
        """Get styling subsystem statistics.

        Returns:
            Dictionary with styling statistics.
        """
        with self._lock.acquire_read():
            return {
                'cache_size': len(self._cache),
                'total_resolutions': self._resolution_counter.get(),
                'theme_version': self._engine.theme_version
            }

    def load_stylesheet_text(self, name: str, text: str) -> None:
        """Load a stylesheet from raw text and clear cached entries."""

        self._engine.load_stylesheet_text(name, text)
        self.invalidate_cache()

    def clear_extra_stylesheets(self) -> None:
        """Remove all additional stylesheets and clear cached entries."""

        self._engine.clear_extra_stylesheets()
        self.invalidate_cache()

    def get_engine(self) -> StyleEngine:
        """Return the underlying style engine."""

        return self._engine


_subsystem: StylingSubsystem | None = None
_subsystem_lock = threading.RLock()


def get_styling_subsystem() -> StylingSubsystem:
    """Return the process-wide :class:`StylingSubsystem`."""

    global _subsystem
    if _subsystem is None:
        with _subsystem_lock:
            if _subsystem is None:
                _subsystem = StylingSubsystem()
    return _subsystem


def resolve_component_style(
    component_name: str,
    *,
    state: Mapping[str, bool] | None = None,
    theme_overrides: Mapping[str, str] | None = None,
    caps: object | None = None,
) -> ResolvedStyle:
    """Resolve a component style using the global subsystem."""

    subsystem = get_styling_subsystem()
    context = StylingContext(component_name, state, theme_overrides, caps)
    return subsystem.resolve_style(context)


__all__ = [
    "StylingSubsystem",
    "StylingContext",
    "resolve_component_style",
    "StyleResolutionError",
    "InvalidStyleValueError",
    "StyleNotFoundError",
    "ThemeOverrideError",
    "get_styling_subsystem",
]
