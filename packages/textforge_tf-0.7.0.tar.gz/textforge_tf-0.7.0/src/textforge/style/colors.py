"""
Color utilities for Textforge.

This module now acts as a high-level facade that builds on split modules:
- `textforge/style/palette.py` for static maps and effect codes
- `textforge/style/ansi.py` for low-level conversions
- `textforge/style/gradients.py` for gradient rendering
"""

from __future__ import annotations

import colorsys
import re
from collections import deque
from threading import Lock
from typing import ClassVar, Generic, TypeVar

from . import ansi as _ansi
from .gradients import apply_gradient as _apply_gradient
from .palette import (
    ANSI_4BIT_RGB,
    BG_COLORS,
    EFFECTS,
    NAMED_COLORS,
    NAMED_HEX,
)
from .palette import (
    RESET as RESET_CODE,
)
from .tfs.tfs_values import HSLA, RGBA, ColorBlend, ColorFunction

_T = TypeVar("_T")
_ANSI_SEQUENCE_PATTERN = re.compile(r"\[(\d+)m")
_BRACKET_PATTERN = re.compile(r"\[([^\]]+)\]")
_BRACKET_ESCAPE_MAP = {
    "[[": "\x00__LBRACKET__\x00",
    "]]": "\x00__RBRACKET__\x00",
    "\\[": "\x00__LBRACKET__\x00",
    "\\]": "\x00__RBRACKET__\x00",
}
_BRACKET_RESTORE_MAP = {
    "\x00__LBRACKET__\x00": "[",
    "\x00__RBRACKET__\x00": "]",
}


class _BoundedCache(Generic[_T]):
    """Thread-safe FIFO cache with a fixed capacity."""

    __slots__ = ("_limit", "_data", "_order", "_lock")

    def __init__(self, limit: int) -> None:
        """Initialize cache with ``limit`` slots.

        Args:
            limit (int): Maximum number of entries retained.

        Returns:
            None
        """
        self._limit = max(1, limit)
        self._data: dict[str, _T] = {}
        self._order: deque[str] = deque()
        self._lock = Lock()

    def get(self, key: str) -> _T | None:
        """Return cached value for ``key`` when present.

        Args:
            key (str): Cache lookup key.

        Returns:
            _T | None: Cached value when available.
        """
        with self._lock:
            return self._data.get(key)

    def put(self, key: str, value: _T) -> None:
        """Insert ``value`` under ``key`` evicting the oldest entry if needed.

        Args:
            key (str): Cache key to store under.
            value (_T): Value to store.

        Returns:
            None
        """
        with self._lock:
            if key in self._data:
                return
            if len(self._data) >= self._limit:
                oldest = self._order.popleft()
                self._data.pop(oldest, None)
            self._data[key] = value
            self._order.append(key)


class Color:
    """Manages ANSI color codes and conversions."""

    # Back-compat: expose underlying maps as class attributes
    NAMED_COLORS = NAMED_COLORS
    NAMED_HEX = NAMED_HEX
    ANSI_4BIT_RGB = ANSI_4BIT_RGB
    BG_COLORS = BG_COLORS
    EFFECTS = EFFECTS

    # Re-exported effect constants for convenience
    RESET = RESET_CODE
    BOLD = EFFECTS["bold"]
    DIM = EFFECTS["dim"]
    ITALIC = EFFECTS["italic"]
    UNDERLINE = EFFECTS["underline"]
    BLINK = EFFECTS["blink"]
    REVERSE = EFFECTS["reverse"]
    HIDDEN = EFFECTS["hidden"]
    STRIKETHROUGH = EFFECTS["strikethrough"]

    # Cache for resolved color specs keyed by color_spec
    _ANSI_CACHE_LIMIT: ClassVar[int] = 1024
    _RGB_CACHE_LIMIT: ClassVar[int] = 1024
    _ansi_cache: ClassVar[_BoundedCache[str]] = _BoundedCache[str](_ANSI_CACHE_LIMIT)
    _rgb_cache: ClassVar[_BoundedCache[tuple[int, int, int]]] = _BoundedCache[tuple[int, int, int]](_RGB_CACHE_LIMIT)
    _GRADIENT_CACHE_LIMIT: ClassVar[int] = 64
    _gradient_cache: ClassVar[_BoundedCache[str]] = _BoundedCache[str](_GRADIENT_CACHE_LIMIT)

    @staticmethod
    def _cache_put(key: str, value: str) -> None:
        """Insert into ANSI cache with simple FIFO eviction.

        Args:
            key (str): Cache key for the ANSI sequence.
            value (str): ANSI escape sequence to cache.

        Returns:
            None
        """
        Color._ansi_cache.put(key, value)

    @staticmethod
    def _rgb_cache_put(key: str, value: tuple[int, int, int]) -> None:
        """Insert into RGB cache with simple FIFO eviction.

        Args:
            key (str): Cache key for the RGB triplet.
            value (tuple[int, int, int]): RGB value to cache.

        Returns:
            None
        """
        Color._rgb_cache.put(key, value)

    @staticmethod
    def get_color(color_spec: str | RGBA | HSLA | ColorFunction | ColorBlend | None) -> str:
        """
        Convert color specification to ANSI code.

        Args:
            color_spec (str | RGBA | HSLA | ColorFunction | ColorBlend | None): Color input to convert.

        Returns:
            str: ANSI escape code for the color, or empty string if invalid.
        """
        if not color_spec:
            return ""

        # Handle advanced color types
        if isinstance(color_spec, RGBA):
            rgb = (color_spec.r, color_spec.g, color_spec.b)
            ansi_code = _ansi.rgb_to_ansi(rgb)
            if color_spec.a < 1.0:
                # For alpha blending, we need to blend with background
                # For now, just return the RGB color (alpha blending would require background knowledge)
                return ansi_code
            return ansi_code

        elif isinstance(color_spec, HSLA):
            rgb = Color.hsl_to_rgb(color_spec.h, color_spec.s, color_spec.lightness)
            ansi_code = _ansi.rgb_to_ansi(rgb)
            if color_spec.a < 1.0:
                # Alpha blending - simplified for now
                return ansi_code
            return ansi_code

        elif isinstance(color_spec, ColorFunction):
            # For now, just return a placeholder - full implementation would parse the function
            if color_spec.name == "color-mix":
                # Simplified color-mix implementation
                return "#888888"  # Placeholder
            return ""

        elif isinstance(color_spec, ColorBlend):
            # For now, just return the first color - full blending would require complex calculations
            return Color.get_color(color_spec.color_a)

        # Handle string color specs
        color_spec_str = str(color_spec) if not color_spec else color_spec
        color_spec_str = color_spec_str.strip()

        cache_key = color_spec_str
        cached = Color._ansi_cache.get(cache_key)
        if cached is not None:
            return cached

        low = color_spec_str.lower()

        result: str

        if low.startswith("var(") and low.endswith(")"):
            # Theme token resolution removed - ThemeManager no longer used
            result = ""
        elif color_spec_str.startswith("$"):
            # Theme token resolution removed - ThemeManager no longer used
            result = ""
        elif low in NAMED_COLORS:
            result = NAMED_COLORS[low]
        elif low.startswith("ansi") and low[4:].isdigit():
            try:
                index = int(low[4:])
            except ValueError:
                result = ""
            else:
                if 0 <= index <= 15:
                    base_code = 30 + (index % 8)
                    if index >= 8:
                        base_code += 60
                    result = f"\033[{base_code}m"
                else:
                    result = ""
        elif low.startswith("#"):
            result = _ansi.hex_to_ansi(low)
        elif low.startswith("rgb(") and low.endswith(")"):
            result = _ansi.rgb_str_to_ansi(low[4:-1])
        elif low.startswith("rgba(") and low.endswith(")"):
            # Parse rgba(r,g,b,a) - for now ignore alpha
            rgba_inner = low[5:-1]
            rgb_part = rgba_inner.split(",")[:3]
            rgb_str = ",".join(rgb_part)
            result = _ansi.rgb_str_to_ansi(rgb_str)
        elif low.startswith("hsl(") and low.endswith(")"):
            hsl_inner = low[4:-1]
            parts = [p.strip() for p in hsl_inner.split(",")]
            if len(parts) == 3:
                try:
                    h = float(parts[0])
                    s = float(parts[1].rstrip("%")) / 100.0 if parts[1].endswith("%") else float(parts[1])
                    lightness = float(parts[2].rstrip("%")) / 100.0 if parts[2].endswith("%") else float(parts[2])
                    rgb = Color.hsl_to_rgb(h, s, lightness)
                    result = _ansi.rgb_to_ansi(rgb)
                except Exception:
                    result = ""
            else:
                result = ""
        elif low.startswith("hsla(") and low.endswith(")"):
            # Parse hsla(h,s,l,a) - for now ignore alpha
            hsla_inner = low[5:-1]
            hsl_part = hsla_inner.split(",")[:3]
            hsl_str = ",".join(hsl_part)
            result = Color.get_color(f"hsl({hsl_str})")
        elif "," in low and not low.startswith(("rgb(", "hsl(")):
            # Plain r,g,b format
            result = _ansi.rgb_str_to_ansi(low)
        elif low in EFFECTS:
            result = EFFECTS[low]
        else:
            # Theme token as bare word - ThemeManager no longer used
            result = ""

        Color._cache_put(cache_key, result)
        return result

    @staticmethod
    def get_bg_color(color_spec: str | None) -> str:
        """
        Convert color specification to ANSI background code, honoring theme tokens.

        Accepts the same inputs as get_color, but returns a background (48;2) code.

        Args:
            color_spec (str | None): Foreground color specification.

        Returns:
            str: ANSI background escape code or an empty string when unresolved.
        """
        if not color_spec:
            return ""

        cache_key = f"bg::{color_spec}"
        cached = Color._ansi_cache.get(cache_key)
        if cached is not None:
            return cached

        low = color_spec.strip().lower()

        def resolve_theme_token(token: str) -> str:
            # Theme token resolution removed - ThemeManager no longer used
            return ""

        if low.startswith("var(") and low.endswith(")"):
            inner = low[4:-1].strip()
            resolved = resolve_theme_token(inner)
            result = Color.get_bg_color(resolved) if resolved else ""
        elif color_spec.startswith("$"):
            token = color_spec[1:]
            resolved = resolve_theme_token(token)
            result = Color.get_bg_color(resolved) if resolved else ""
        elif low.startswith("bg#"):
            result = _ansi.hex_to_bg_ansi(low[2:])
        elif low.startswith("bg:"):
            result = _ansi.rgb_str_to_bg_ansi(low[3:])
        elif low in BG_COLORS:
            result = BG_COLORS[low]
        elif low.startswith("#"):
            result = _ansi.hex_to_bg_ansi(low)
        elif "," in low:
            result = _ansi.rgb_str_to_bg_ansi(low)
        else:
            # Try themed background: treat as token first; then fallback by converting fg to bg
            resolved = resolve_theme_token(low)
            if resolved:
                result = Color.get_bg_color(resolved)
            else:
                fg = Color.get_color(low)
                result = fg.replace("[38;", "[48;") if "[38;" in fg else ""

        Color._cache_put(cache_key, result)
        return result

    @staticmethod
    def hex_to_rgb(hex_color: str) -> tuple[int, int, int] | None:
        """Convert #RRGGBB string to an RGB tuple."""
        return _ansi.hex_to_rgb(hex_color)

    @staticmethod
    def rgb_to_hex(rgb: tuple[int, int, int]) -> str:
        """Return a #RRGGBB string for the given RGB tuple."""
        r, g, b = (max(0, min(255, int(v))) for v in rgb)
        return f"#{r:02x}{g:02x}{b:02x}"

    @staticmethod
    def hex_to_ansi(hex_color: str) -> str:
        """Convert #RRGGBB to ANSI 24-bit color."""
        return _ansi.hex_to_ansi(hex_color)

    @staticmethod
    def resolve_rgb(spec: str | RGBA | HSLA | ColorFunction | ColorBlend | None) -> tuple[int, int, int] | None:
        """Resolve a color specification into an RGB tuple if possible.

        Accepts theme tokens, named colors, hex strings, comma-delimited
        RGB strings, and advanced color types. Returns None when the spec cannot be resolved.

        Args:
            spec (str | RGBA | HSLA | ColorFunction | ColorBlend | None): Color specification to resolve.

        Returns:
            tuple[int, int, int] | None: Resolved RGB triple or ``None`` when parsing fails.
        """
        if not spec:
            return None

        # Handle advanced color types first
        if isinstance(spec, RGBA):
            return (spec.r, spec.g, spec.b)

        if isinstance(spec, HSLA):
            return Color.hsl_to_rgb(spec.h, spec.s, spec.lightness)

        if isinstance(spec, ColorFunction):
            # For now, return None for complex functions
            return None

        if isinstance(spec, ColorBlend):
            # For blending, just return the first color
            return Color.resolve_rgb(spec.color_a)

        # Handle string specs
        spec_key = str(spec).strip().lower()

        # Cache lookup
        cached_rgb = Color._rgb_cache.get(spec_key)
        if cached_rgb is not None:
            return cached_rgb

        # Theme manager indirection removed - ThemeManager no longer used

        result: tuple[int, int, int] | None = None

        if spec_key.startswith("rgba(") and spec_key.endswith(")"):
            rgba_inner = spec_key[5:-1]
            parts = [p.strip() for p in rgba_inner.split(",")]
            if len(parts) >= 3:
                try:
                    r, g, b = (int(float(p)) for p in parts[:3])
                    result = (max(0, min(255, r)), max(0, min(255, g)), max(0, min(255, b)))
                except ValueError:
                    result = None

        elif spec_key.startswith("rgb(") and spec_key.endswith(")"):
            rgb_inner = spec_key[4:-1]
            parts = [p.strip() for p in rgb_inner.split(",")]
            if len(parts) == 3:
                try:
                    r, g, b = (int(float(part)) for part in parts)
                    result = (max(0, min(255, r)), max(0, min(255, g)), max(0, min(255, b)))
                except ValueError:
                    result = None

        elif spec_key.startswith("hsla(") and spec_key.endswith(")"):
            hsla_inner = spec_key[5:-1]
            parts = [p.strip() for p in hsla_inner.split(",")]
            if len(parts) >= 3:
                try:
                    hue = float(parts[0])
                    saturation = float(parts[1].rstrip("%")) / 100.0 if parts[1].endswith("%") else float(parts[1])
                    lightness = float(parts[2].rstrip("%")) / 100.0 if parts[2].endswith("%") else float(parts[2])
                    result = Color.hsl_to_rgb(hue, saturation, lightness)
                except ValueError:
                    result = None

        elif spec_key.startswith("hsl(") and spec_key.endswith(")"):
            hsl_inner = spec_key[4:-1]
            parts = [p.strip() for p in hsl_inner.split(",")]
            if len(parts) == 3:
                try:
                    hue = float(parts[0])
                    saturation = float(parts[1].rstrip("%")) / 100.0 if parts[1].endswith("%") else float(parts[1])
                    lightness = float(parts[2].rstrip("%")) / 100.0 if parts[2].endswith("%") else float(parts[2])
                    result = Color.hsl_to_rgb(hue, saturation, lightness)
                except ValueError:
                    result = None

        elif spec_key in NAMED_HEX:
            result = _ansi.hex_to_rgb(NAMED_HEX[spec_key])

        elif spec_key.startswith("#"):
            result = Color.hex_to_rgb(spec_key)

        elif "," in spec_key and not spec_key.startswith(("rgb(", "hsl(")):
            parts = [p.strip() for p in spec_key.split(",")]
            if len(parts) == 3:
                try:
                    r, g, b = (int(float(value)) for value in parts)
                    result = (max(0, min(255, r)), max(0, min(255, g)), max(0, min(255, b)))
                except ValueError:
                    result = None

        elif spec_key in NAMED_COLORS:
            code = NAMED_COLORS[spec_key]
            match = _ANSI_SEQUENCE_PATTERN.search(code)
            if match:
                rgb_lookup = ANSI_4BIT_RGB.get(match.group(1))
                if rgb_lookup:
                    result = rgb_lookup

        if result is not None:
            Color._rgb_cache_put(spec_key, result)
        return result

    @staticmethod
    def blend(rgb_a: tuple[int, int, int], rgb_b: tuple[int, int, int], t: float) -> tuple[int, int, int]:
        """Linear blend between two RGB tuples."""
        t = max(0.0, min(1.0, t))
        return (
            int(rgb_a[0] + (rgb_b[0] - rgb_a[0]) * t),
            int(rgb_a[1] + (rgb_b[1] - rgb_a[1]) * t),
            int(rgb_a[2] + (rgb_b[2] - rgb_a[2]) * t),
        )

    @staticmethod
    def rgb_to_hsv(r: int, g: int, b: int) -> tuple[float, float, float]:
        """Convert RGB to HSV where H is degrees 0-360."""
        h, s, v = colorsys.rgb_to_hsv(r / 255.0, g / 255.0, b / 255.0)
        return (h * 360.0, s, v)

    @staticmethod
    def hsv_to_rgb(h: float, s: float, v: float) -> tuple[int, int, int]:
        """Convert HSV (degrees, 0-1, 0-1) to RGB tuple."""
        r, g, b = colorsys.hsv_to_rgb((h % 360) / 360.0, max(0.0, min(1.0, s)), max(0.0, min(1.0, v)))
        return (int(round(r * 255)), int(round(g * 255)), int(round(b * 255)))

    @staticmethod
    def rgb_to_hsl(r: int, g: int, b: int) -> tuple[float, float, float]:
        """Convert RGB to HSL where H is degrees."""
        h, light, s = colorsys.rgb_to_hls(r / 255.0, g / 255.0, b / 255.0)
        return (h * 360.0, s, light)

    @staticmethod
    def hsl_to_rgb(h: float, s: float, light: float) -> tuple[int, int, int]:
        """Convert HSL (degrees, sat, light) to RGB tuple."""
        r, g, b = colorsys.hls_to_rgb((h % 360) / 360.0, max(0.0, min(1.0, light)), max(0.0, min(1.0, s)))
        return (int(round(r * 255)), int(round(g * 255)), int(round(b * 255)))

    @staticmethod
    def adjust_luminance(rgb: tuple[int, int, int], amount: float) -> tuple[int, int, int]:
        """Lighten (>0) or darken (<0) an RGB color by adjusting HSL lightness."""
        h, s, light = Color.rgb_to_hsl(*rgb)
        light = max(0.0, min(1.0, light + amount))
        return Color.hsl_to_rgb(h, s, light)

    @staticmethod
    def mix(spec_a: str, spec_b: str, t: float) -> str:
        """Blend two color specs and return the resulting ANSI code."""
        rgb_a = Color.resolve_rgb(spec_a)
        rgb_b = Color.resolve_rgb(spec_b)
        if rgb_a is None or rgb_b is None:
            return Color.get_color(spec_a if t < 0.5 else spec_b)
        rgb = Color.blend(rgb_a, rgb_b, t)
        return Color.rgb_to_ansi(rgb)

    @staticmethod
    def rgb_to_ansi(rgb: tuple[int, int, int]) -> str:
        return _ansi.rgb_to_ansi(rgb)

    @staticmethod
    def rgb_str_to_ansi(rgb_color: str) -> str:
        """Convert 'r,g,b' to ANSI 24-bit color."""
        return _ansi.rgb_str_to_ansi(rgb_color)

    @staticmethod
    def hex_to_bg_ansi(hex_color: str) -> str:
        """Convert #RRGGBB to ANSI 24-bit background color."""
        return _ansi.hex_to_bg_ansi(hex_color)

    @staticmethod
    def rgb_to_bg_ansi(rgb_color: str) -> str:
        """Convert 'r,g,b' to ANSI 24-bit background color."""
        return _ansi.rgb_str_to_bg_ansi(rgb_color)

    @staticmethod
    def apply_inline_markup(text: str) -> str:
        """
        Process inline color markup in text.

        Usage: "This is [red]red text[reset] and [blue]blue text[reset]"
        Supports: colors, bg_colors, bold, italic, underline, etc.

        Args:
            text (str): Text with inline markup tags.

        Returns:
            str: Text with ANSI codes applied.
        """

        # Fast path: no markup-like bracket
        if "[" not in text:
            return text

        # Protect escaped brackets: "[[" "]]" and backslash-escaped \[ \]
        protected = text
        for raw, token in _BRACKET_ESCAPE_MAP.items():
            if raw in protected:
                protected = protected.replace(raw, token)

        if "[" not in protected:
            for token, literal in _BRACKET_RESTORE_MAP.items():
                protected = protected.replace(token, literal)
            return protected

        def resolve_tag(tag_raw: str) -> str | None:
            tag = tag_raw.strip().lower()

            if not tag:
                return None

            if tag in EFFECTS:
                return EFFECTS[tag]

            if tag in BG_COLORS:
                return BG_COLORS[tag]

            if tag.startswith("bg#"):
                return _ansi.hex_to_bg_ansi(tag[2:])
            if tag.startswith("bg:"):
                return _ansi.rgb_str_to_bg_ansi(tag[3:])

            if tag.startswith("fg=") or tag.startswith("fg:"):
                token = tag.split("=", 1)[-1] if "=" in tag else tag.split(":", 1)[-1]
                return Color.get_color(token)

            if tag.startswith("bg=") or tag.startswith("bg:"):
                token = tag.split("=", 1)[-1] if "=" in tag else tag.split(":", 1)[-1]
                if token.startswith("#"):
                    return _ansi.hex_to_bg_ansi(token)
                if "," in token:
                    return _ansi.rgb_str_to_bg_ansi(token)
                named_bg = BG_COLORS.get(f"bg_{token}", "")
                if named_bg:
                    return named_bg
                fg = Color.get_color(token)
                return fg.replace("[38;", "[48;") if "[38;" in fg else ""

            if tag in NAMED_COLORS:
                return Color.get_color(tag)

            if tag.startswith("#"):
                return _ansi.hex_to_ansi(tag)

            if "," in tag:
                return _ansi.rgb_str_to_ansi(tag)

            return None

        segments: list[str] = []
        cursor = 0
        length = len(protected)
        while cursor < length:
            start = protected.find("[", cursor)
            if start == -1:
                segments.append(protected[cursor:])
                break
            segments.append(protected[cursor:start])
            end = protected.find("]", start + 1)
            if end == -1:
                segments.append(protected[start:])
                break

            tag_text = protected[start + 1 : end]
            replacement = resolve_tag(tag_text)
            if replacement is None:
                segments.append(protected[start : end + 1])
            else:
                segments.append(replacement)
            cursor = end + 1

        rendered = "".join(segments)
        for token, literal in _BRACKET_RESTORE_MAP.items():
            if token in rendered:
                rendered = rendered.replace(token, literal)
        return rendered

    @staticmethod
    def gradient(text: str, start_color: tuple[int, int, int], end_color: tuple[int, int, int]) -> str:
        cache_key = f"{start_color[0]}:{start_color[1]}:{start_color[2]}|{end_color[0]}:{end_color[1]}:{end_color[2]}|{text}"
        cached = Color._gradient_cache.get(cache_key)
        if cached is not None:
            return cached

        rendered = _apply_gradient(text, start_color, end_color)
        result = rendered + Color.RESET
        Color._gradient_cache.put(cache_key, result)
        return result

    # --- Contrast and luminance helpers (moved from utils/accessibility) ---

    @staticmethod
    def luminance_from_rgb(r: int, g: int, b: int) -> float:
        srgb = [v / 255 for v in (r, g, b)]
        lin = [((c + 0.055) / 1.055) ** 2.4 if c > 0.03928 else c / 12.92 for c in srgb]
        return 0.2126 * lin[0] + 0.7152 * lin[1] + 0.0722 * lin[2]

    @staticmethod
    def contrast_ratio_rgb(rgb_a: tuple[int, int, int], rgb_b: tuple[int, int, int]) -> float:
        l1 = Color.luminance_from_rgb(*rgb_a)
        l2 = Color.luminance_from_rgb(*rgb_b)
        lighter, darker = (l1, l2) if l1 >= l2 else (l2, l1)
        return (lighter + 0.05) / (darker + 0.05)

    @staticmethod
    def is_contrast_sufficient(
        fg_spec: str,
        bg_spec: str = "#000000",
        *,
        large_text: bool = False,
    ) -> bool:
        """Return True if contrast between two color specs meets WCAG AA.

        Accepts theme tokens, named colors, hex strings, or "r,g,b" strings.
        """
        fg_rgb = Color.resolve_rgb(fg_spec)
        bg_rgb = Color.resolve_rgb(bg_spec)
        if fg_rgb is None or bg_rgb is None:
            return True
        ratio = Color.contrast_ratio_rgb(fg_rgb, bg_rgb)
        threshold = 3.0 if large_text else 4.5
        return ratio >= threshold

    @staticmethod
    def ensure_min_contrast(
        fg_spec: str,
        bg_spec: str,
        *,
        min_ratio: float = 4.5,
        max_steps: int = 40,
    ) -> str:
        """Adjust a foreground color until the requested contrast ratio is met.

        Returns a color spec as hex string when adjustment was successful; falls
        back to the original spec when inputs cannot be resolved.
        """
        fg_rgb = Color.resolve_rgb(fg_spec)
        bg_rgb = Color.resolve_rgb(bg_spec)
        if fg_rgb is None or bg_rgb is None:
            return fg_spec

        current = fg_rgb
        attempt = 0
        while Color.contrast_ratio_rgb(current, bg_rgb) < min_ratio and attempt < max_steps:
            lf = Color.luminance_from_rgb(*current)
            lb = Color.luminance_from_rgb(*bg_rgb)
            # Darken if foreground is lighter than background; otherwise lighten
            delta = -0.04 if lf > lb else 0.04
            current = Color.adjust_luminance(current, delta)
            attempt += 1
        return Color.rgb_to_hex(current)

    @staticmethod
    def simulate_color_blind(rgb: tuple[int, int, int], mode: str = "protanopia") -> tuple[int, int, int]:
        """Simulate color vision deficiencies using matrix transforms."""
        r, g, b = [c / 255.0 for c in rgb]
        matrices: dict[str, tuple[tuple[float, float, float], ...]] = {
            "protanopia": (
                (0.56667, 0.43333, 0.00000),
                (0.55833, 0.44167, 0.00000),
                (0.00000, 0.24167, 0.75833),
            ),
            "deuteranopia": (
                (0.62500, 0.37500, 0.00000),
                (0.70000, 0.30000, 0.00000),
                (0.00000, 0.30000, 0.70000),
            ),
            "tritanopia": (
                (0.95000, 0.05000, 0.00000),
                (0.00000, 0.43333, 0.56667),
                (0.00000, 0.47500, 0.52500),
            ),
        }
        mat = matrices.get(mode, matrices["protanopia"])
        r2 = r * mat[0][0] + g * mat[0][1] + b * mat[0][2]
        g2 = r * mat[1][0] + g * mat[1][1] + b * mat[1][2]
        b2 = r * mat[2][0] + g * mat[2][1] + b * mat[2][2]
        return (
            int(max(0, min(1, r2)) * 255),
            int(max(0, min(1, g2)) * 255),
            int(max(0, min(1, b2)) * 255),
        )


__all__ = ["Color"]
