"""Border symbol sets and styles for different capabilities."""

from __future__ import annotations

# Basic box drawing characters
UNICODE_BOX: dict[str, str] = {
    "h": "─",
    "v": "│",
    "tl": "┌",
    "tr": "┐",
    "bl": "└",
    "br": "┘",
    "t": "┬",
    "b": "┴",
    "l": "├",
    "r": "┤",
    "c": "┼",
}

ASCII_BOX: dict[str, str] = {
    "h": "-",
    "v": "|",
    "tl": "+",
    "tr": "+",
    "bl": "+",
    "br": "+",
    "t": "+",
    "b": "+",
    "l": "+",
    "r": "+",
    "c": "+",
}

# Double-line box drawing
UNICODE_DOUBLE_BOX: dict[str, str] = {
    "h": "═",
    "v": "║",
    "tl": "╔",
    "tr": "╗",
    "bl": "╚",
    "br": "╝",
    "t": "╦",
    "b": "╩",
    "l": "╠",
    "r": "╣",
    "c": "╬",
}

# Rounded corners box drawing
UNICODE_ROUNDED_BOX: dict[str, str] = {
    "h": "─",
    "v": "│",
    "tl": "╭",
    "tr": "╮",
    "bl": "╰",
    "br": "╯",
    "t": "┬",
    "b": "┴",
    "l": "├",
    "r": "┤",
    "c": "┼",
}

# Thick box drawing
UNICODE_THICK_BOX: dict[str, str] = {
    "h": "━",
    "v": "┃",
    "tl": "┏",
    "tr": "┓",
    "bl": "┗",
    "br": "┛",
    "t": "┳",
    "b": "┻",
    "l": "┣",
    "r": "┫",
    "c": "╋",
}

# Border style configurations
BORDER_STYLES: dict[str, dict[str, str]] = {
    "solid": UNICODE_BOX,
    "double": UNICODE_DOUBLE_BOX,
    "round": UNICODE_ROUNDED_BOX,
    "thick": UNICODE_THICK_BOX,
    "ascii": ASCII_BOX,
    "dashed": ASCII_BOX,  # Placeholder - would need custom dashed characters
    "dotted": ASCII_BOX,  # Placeholder - would need custom dotted characters
}


def border_set(style: str = "solid", ascii_only: bool = False) -> dict[str, str]:
    """Get border character set for a given style."""
    if ascii_only:
        return ASCII_BOX

    return BORDER_STYLES.get(style, UNICODE_BOX)


def get_border_chars(style: str = "solid", ascii_only: bool = False) -> dict[str, str]:
    """Alias for border_set for backward compatibility."""
    return border_set(style, ascii_only)


__all__ = [
    "UNICODE_BOX",
    "ASCII_BOX",
    "UNICODE_DOUBLE_BOX",
    "UNICODE_ROUNDED_BOX",
    "UNICODE_THICK_BOX",
    "BORDER_STYLES",
    "border_set",
    "get_border_chars",
]
