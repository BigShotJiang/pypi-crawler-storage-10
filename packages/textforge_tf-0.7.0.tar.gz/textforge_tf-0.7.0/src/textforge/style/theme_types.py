"""Theme type definitions for Textforge.

This module contains type definitions for themes to avoid circular imports.
"""

from __future__ import annotations

from dataclasses import dataclass


@dataclass(slots=True, frozen=True)
class Theme:
    """A theme defines semantic color tokens mapped to color specs.

    Color specs can be named colors (e.g., "cyan"), hex strings (e.g., "#00ffff"),
    or raw ANSI codes. Resolution to ANSI is delegated to `Color.get_color`.
    """

    name: str
    palette: dict[str, str]
