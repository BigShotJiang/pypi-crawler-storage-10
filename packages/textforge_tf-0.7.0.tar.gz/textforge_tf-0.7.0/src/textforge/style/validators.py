"""
Style validation utilities for Textforge.

This module provides comprehensive validation for style compatibility across different renderers,
style property validation, and theme validation.
"""

from __future__ import annotations

import re
from dataclasses import fields as _dc_fields
from dataclasses import is_dataclass
from typing import TYPE_CHECKING

from ..core.layout.types import RendererType
from ..utils.logging import get_logger

if TYPE_CHECKING:
    from collections.abc import Mapping

    from .tfs.tfs_cascade import ResolvedStyle


def _style_to_dict(style_obj: ResolvedStyle | Mapping[str, object]) -> dict[str, object]:
    if isinstance(style_obj, dict):
        return style_obj
    if is_dataclass(style_obj):
        return {f.name: getattr(style_obj, f.name) for f in _dc_fields(style_obj)}
    try:
        return dict(style_obj)
    except Exception:
        return {}


class ValidationError(Exception):
    """Base exception for style validation errors."""

    def __init__(self, message: str, property_name: str | None = None, renderer_type: RendererType | None = None) -> None:
        self.message = message
        self.property_name = property_name
        self.renderer_type = renderer_type
        super().__init__(f"{message} (property: {property_name}, renderer: {renderer_type})" if property_name and renderer_type else message)


class StyleValidator:
    """Validates style compatibility and correctness across renderers."""

    _logger = get_logger("textforge.style.validation")

    # Valid CSS-like properties for each renderer type
    VALID_PROPERTIES = {
        RendererType.CLI: {
            "color",
            "background",
            "background-color",
            "border",
            "border-color",
            "border-style",
            "border-width",
            "padding",
            "margin",
            "width",
            "height",
            "display",
            "position",
            "font-family",
            "font-size",
            "font-weight",
            "text-decoration",
            "text-align",
            "opacity",
            "visibility",
        },
        RendererType.TTY: {
            "color",
            "background",
            "background-color",
            "border",
            "border-color",
            "border-style",
            "border-width",
            "padding",
            "margin",
            "width",
            "height",
            "display",
            "position",
            "font-family",
            "font-size",
            "font-weight",
            "text-decoration",
            "text-align",
            "opacity",
            "visibility",
            "text-shadow",
            "box-shadow",
        },
        RendererType.GUI: {
            "color",
            "background",
            "background-color",
            "border",
            "border-color",
            "border-style",
            "border-width",
            "border-radius",
            "padding",
            "margin",
            "width",
            "height",
            "display",
            "position",
            "font-family",
            "font-size",
            "font-weight",
            "text-decoration",
            "text-align",
            "opacity",
            "visibility",
            "text-shadow",
            "box-shadow",
            "transform",
            "transition",
            "animation",
            "cursor",
            "z-index",
            "overflow",
        },
        RendererType.SVG: {
            "color",
            "fill",
            "stroke",
            "stroke-width",
            "stroke-linecap",
            "stroke-linejoin",
            "opacity",
            "visibility",
            "transform",
            "font-family",
            "font-size",
            "font-weight",
            "text-decoration",
            "text-anchor",
        },
        RendererType.HTML: {
            "color",
            "background",
            "background-color",
            "border",
            "border-color",
            "border-style",
            "border-width",
            "border-radius",
            "padding",
            "margin",
            "width",
            "height",
            "display",
            "position",
            "font-family",
            "font-size",
            "font-weight",
            "text-decoration",
            "text-align",
            "opacity",
            "visibility",
            "text-shadow",
            "box-shadow",
            "transform",
            "transition",
            "animation",
            "cursor",
            "z-index",
            "overflow",
            "flex",
            "grid",
        },
        RendererType.PDF: {
            "color",
            "background",
            "background-color",
            "border",
            "border-color",
            "border-style",
            "border-width",
            "padding",
            "margin",
            "width",
            "height",
            "display",
            "position",
            "font-family",
            "font-size",
            "font-weight",
            "text-decoration",
            "text-align",
            "opacity",
            "visibility",
        },
    }

    # Property value patterns for validation
    VALUE_PATTERNS = {
        "color": re.compile(
            r"^#([0-9a-fA-F]{3}|[0-9a-fA-F]{6}|[0-9a-fA-F]{8})|rgb\(\s*\d+\s*,\s*\d+\s*,\s*\d+\s*\)|rgba\(\s*\d+\s*,\s*\d+\s*,\s*\d+\s*,\s*[\d.]+\s*\)|hsl\(\s*\d+\s*,\s*\d+%\s*,\s*\d+%\s*\)|hsla\(\s*\d+\s*,\s*\d+%\s*,\s*\d+%\s*,\s*[\d.]+\s*\)|[a-zA-Z]+|\$[\w-]+|var\([^)]+\)$"
        ),
        "background": re.compile(
            r"^#([0-9a-fA-F]{3}|[0-9a-fA-F]{6}|[0-9a-fA-F]{8})|rgb\(\s*\d+\s*,\s*\d+\s*,\s*\d+\s*\)|rgba\(\s*\d+\s*,\s*\d+\s*,\s*\d+\s*,\s*[\d.]+\s*\)|hsl\(\s*\d+\s*,\s*\d+%\s*,\s*\d+%\s*\)|hsla\(\s*\d+\s*,\s*\d+%\s*,\s*\d+%\s*,\s*[\d.]+\s*\)|[a-zA-Z]+|\$[\w-]+|var\([^)]+\)|none|transparent$"
        ),
        "border-width": re.compile(r"^\d+(px|em|rem|pt|%|thin|medium|thick)$"),
        "border-style": re.compile(r"^(solid|dashed|dotted|double|groove|ridge|inset|outset|none)$"),
        "padding": re.compile(r"^\d+(px|em|rem|pt|%)(\s+\d+(px|em|rem|pt|%))*$"),
        "margin": re.compile(r"^\d+(px|em|rem|pt|%)(\s+\d+(px|em|rem|pt|%))*$"),
        "width": re.compile(r"^\d+(px|em|rem|pt|%|vw|vh|auto)$"),
        "height": re.compile(r"^\d+(px|em|rem|pt|%|vw|vh|auto)$"),
        "font-size": re.compile(r"^\d+(px|em|rem|pt|%)$"),
        "font-weight": re.compile(r"^(normal|bold|lighter|bolder|100|200|300|400|500|600|700|800|900)$"),
        "opacity": re.compile(r"^[\d.]+$"),
        "z-index": re.compile(r"^-?\d+$"),
        "border-radius": re.compile(r"^\d+(px|em|rem|pt|%)$"),
    }

    @staticmethod
    def validate_style_compatibility(style: ResolvedStyle | Mapping[str, object], renderer_type: RendererType) -> list[ValidationError]:
        """
        Validate that a resolved style is compatible with the specified renderer.

        Args:
            style: The resolved style to validate
            renderer_type: The target renderer type

        Returns:
            List of validation errors found
        """
        errors: list[ValidationError] = []
        style_dict = _style_to_dict(style)
        valid_properties = StyleValidator.VALID_PROPERTIES.get(renderer_type, set())

        # property compatibility
        for prop_name in style_dict.keys():
            if prop_name not in valid_properties:
                StyleValidator._logger.warning(f"Property '{prop_name}' is not supported by {renderer_type.value} renderer")
                errors.append(ValidationError(f"Property '{prop_name}' is not supported by {renderer_type.value} renderer", prop_name, renderer_type))

        # value validation
        for prop_name, prop_value in style_dict.items():
            error = StyleValidator._validate_property_value(prop_name, str(prop_value))
            if error:
                StyleValidator._logger.warning(f"Style validation error: {error}")
                errors.append(ValidationError(error, prop_name, renderer_type))

        # renderer-specific
        if renderer_type == RendererType.CLI:
            errors.extend(StyleValidator._validate_cli_specific(style_dict))
        elif renderer_type == RendererType.GUI:
            errors.extend(StyleValidator._validate_gui_specific(style_dict))
        elif renderer_type == RendererType.SVG:
            errors.extend(StyleValidator._validate_svg_specific(style_dict))

        if errors:
            StyleValidator._logger.warning(f"Found {len(errors)} style validation errors for {renderer_type.value} renderer")
        return errors

    @staticmethod
    def validate_property_value(property_name: str, value: str) -> str | None:
        """
        Validate a single property value.

        Args:
            property_name: The CSS property name
            value: The property value to validate

        Returns:
            Error message if invalid, None if valid
        """
        return StyleValidator._validate_property_value(property_name, value)

    @staticmethod
    def _validate_property_value(property_name: str, value: str) -> str | None:
        """Internal property value validation."""
        if property_name not in StyleValidator.VALUE_PATTERNS:
            # Unknown property - allow for extensibility
            return None

        pattern = StyleValidator.VALUE_PATTERNS[property_name]
        if not pattern.match(str(value)):
            return f"Invalid value '{value}' for property '{property_name}'"

        # Additional numeric validations
        if property_name in ("opacity",):
            try:
                num_val = float(value)
                if not (0.0 <= num_val <= 1.0):
                    return f"Opacity must be between 0.0 and 1.0, got {num_val}"
            except ValueError:
                return f"Opacity must be a number, got '{value}'"

        elif property_name == "z-index":
            try:
                int(value)
            except ValueError:
                return f"Z-index must be an integer, got '{value}'"

        return None

    @staticmethod
    def _validate_cli_specific(style: ResolvedStyle) -> list[ValidationError]:
        """CLI-specific style validations."""
        errors: list[ValidationError] = []
        unsupported_props = {"box-shadow", "text-shadow", "transform", "transition", "animation"}
        for prop in unsupported_props:
            if prop in style:
                errors.append(ValidationError(f"CLI renderer does not support '{prop}' property", prop, RendererType.CLI))
        if "border-radius" in style and style["border-radius"] not in (None, "0", 0):
            errors.append(ValidationError("CLI renderer does not support border-radius", "border-radius", RendererType.CLI))
        return errors

    @staticmethod
    def _validate_gui_specific(style: dict[str, object]) -> list[ValidationError]:
        return []

    @staticmethod
    def _validate_svg_specific(style: dict[str, object]) -> list[ValidationError]:
        errors: list[ValidationError] = []
        if "background" in style and "fill" not in style:
            errors.append(ValidationError("SVG renderer prefers 'fill' over 'background'", "background", RendererType.SVG))
        if "color" in style and "stroke" not in style:
            errors.append(ValidationError("SVG renderer prefers 'stroke' over 'color' for borders", "color", RendererType.SVG))
        return errors

    @staticmethod
    def validate_theme_compatibility(theme_data: dict[str, dict[str, str]], renderer_type: RendererType) -> list[ValidationError]:
        """
        Validate that a theme is compatible with the specified renderer.

        Args:
            theme_data: Theme dictionary with component styles
            renderer_type: Target renderer type

        Returns:
            List of validation errors found
        """
        errors: list[ValidationError] = []

        for component_name, component_styles in theme_data.items():
            # Validate each component's styles
            component_errors = StyleValidator.validate_style_compatibility(component_styles, renderer_type)
            for error in component_errors:
                # Prefix component name to error message
                new_error = ValidationError(f"Component '{component_name}': {error.message}", error.property_name, error.renderer_type)
                errors.append(new_error)

        return errors

    @staticmethod
    def validate_color_value(color_value: str) -> bool:
        """
        Validate that a color value is properly formatted.

        Args:
            color_value: Color value to validate

        Returns:
            True if valid, False otherwise
        """
        return StyleValidator.VALUE_PATTERNS["color"].match(color_value) is not None

    @staticmethod
    def validate_numeric_value(value: str, min_val: float | None = None, max_val: float | None = None, allow_percent: bool = False) -> bool:
        """
        Validate a numeric CSS value.

        Args:
            value: Value to validate
            min_val: Minimum allowed value
            max_val: Maximum allowed value
            allow_percent: Whether to allow percentage values

        Returns:
            True if valid, False otherwise
        """
        try:
            if allow_percent and value.endswith("%"):
                num_val = float(value[:-1])
            else:
                num_val = float(value)

            if min_val is not None and num_val < min_val:
                return False
            if max_val is not None and num_val > max_val:
                return False

            return True
        except ValueError:
            return False


__all__ = ["ValidationError", "StyleValidator"]
