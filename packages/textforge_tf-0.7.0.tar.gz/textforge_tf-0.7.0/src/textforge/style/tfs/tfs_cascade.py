"""Cascade resolution for the Textforge Styling language."""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import TYPE_CHECKING, Any

from .tfs_values import (
    Animation,
    Border,
    BorderRadius,
    BoxShadow,
    ColorSpec,
    Gradient,
    Insets,
    Keyframes,
    Length,
    TextShadow,
    Transition,
)

if TYPE_CHECKING:
    from collections.abc import Mapping

    from .tfs_ast import ComponentRule, Stylesheet


@dataclass(slots=True)
class ResolvedStyle:
    """Fully resolved style for a component."""

    color: ColorSpec | None = None
    background: ColorSpec | None = None
    border: Border | None = None
    border_color: ColorSpec | None = None
    border_radius: BorderRadius | None = None
    padding: Insets | None = None
    margin: Insets | None = None
    font: str | None = None
    font_size: Length | None = None
    weight: str | int | None = None
    outline: ColorSpec | None = None
    line_height: float | Length | None = None
    letter_spacing: Length | None = None
    word_spacing: Length | None = None
    text_decoration: str | None = None
    text_decoration_color: ColorSpec | None = None
    text_decoration_style: str | None = None
    text_transform: str | None = None
    text_shadow: TextShadow | None = None
    box_shadow: list[BoxShadow] | None = None
    text_align: str | None = None
    vertical_align: str | None = None
    display: str | None = None
    position: str | None = None
    top: Length | None = None
    right: Length | None = None
    bottom: Length | None = None
    left: Length | None = None
    width: Length | None = None
    height: Length | None = None
    min_width: Length | None = None
    min_height: Length | None = None
    max_width: Length | None = None
    max_height: Length | None = None
    flex_direction: str | None = None
    flex_wrap: str | None = None
    justify_content: str | None = None
    align_items: str | None = None
    align_content: str | None = None
    flex_grow: float | None = None
    flex_shrink: float | None = None
    flex_basis: Length | None = None
    align_self: str | None = None
    grid_template_columns: str | None = None
    grid_template_rows: str | None = None
    grid_gap: Length | None = None
    grid_column_gap: Length | None = None
    grid_row_gap: Length | None = None
    animations: list[Animation] | None = None
    transitions: list[Transition] | None = None
    keyframes: dict[str, Keyframes] | None = None
    filter: str | None = None
    transform: str | None = None
    transform_origin: str | None = None
    opacity: float | None = None
    background_image: Gradient | str | None = None
    background_position: str | None = None
    background_size: str | None = None
    background_repeat: str | None = None
    component_extras: dict[str, object] | None = field(default_factory=dict)
    raw_meta: dict[str, object] | None = None
    custom_properties: dict[str, str] | None = field(default_factory=dict)

    def merge(self, other: ResolvedStyle) -> ResolvedStyle:
        """Merge ``other`` into ``self`` returning a new instance."""

        merged = ResolvedStyle()
        for field_name in merged.__dataclass_fields__:
            value = getattr(other, field_name)
            if value is not None and field_name not in {"component_extras", "custom_properties"}:
                setattr(merged, field_name, value)
            else:
                setattr(merged, field_name, getattr(self, field_name))
        base_extras = self.component_extras or {}
        incoming_extras = other.component_extras or {}
        if base_extras or incoming_extras:
            merged.component_extras = {**base_extras}
            for key, value in incoming_extras.items():
                if key in merged.component_extras:
                    existing: list[Any] = merged.component_extras[key]
                    if isinstance(existing, list):
                        if isinstance(value, list):
                            existing.extend(value)
                        else:
                            existing.append(value)
                    else:
                        merged.component_extras[key] = [existing, value] if not isinstance(value, list) else [existing, *value]
                else:
                    merged.component_extras[key] = value
        else:
            merged.component_extras = None

        base_props = self.custom_properties or {}
        incoming_props = other.custom_properties or {}
        if base_props or incoming_props:
            merged.custom_properties = {**base_props, **incoming_props}
        else:
            merged.custom_properties = None
        return merged


def resolve_stylesheet(
    sheet: Stylesheet,
    component: str,
    states: frozenset[str],
    colors: Mapping[str, str],
    fonts: Mapping[str, Any],
) -> ResolvedStyle:
    """Resolve ``component`` for ``states`` using ``sheet``."""

    resolved = ResolvedStyle()
    resolved.keyframes = dict(sheet.keyframes)
    custom_properties: dict[str, str] = {}
    extras: dict[str, Any] = {}

    applicable_rules = [rule for rule in sheet.rules if _matches_component(rule, component)]
    if not applicable_rules:
        return resolved

    for rule in applicable_rules:
        for block in rule.blocks:
            if not block.matches(states):
                continue
            _apply_block(resolved, block, colors, fonts, custom_properties, extras)

    resolved.custom_properties = custom_properties or None
    resolved.component_extras = extras or None
    return resolved


def _matches_component(rule: ComponentRule, component: str) -> bool:
    """Return ``True`` when ``rule`` applies to ``component``."""

    selector = rule.component.strip()
    if selector == "*":
        return True
    return selector.lower() == component.lower()


def _apply_block(
    resolved: ResolvedStyle,
    block: object,
    colors: Mapping[str, str],
    fonts: Mapping[str, Any],
    custom_properties: dict[str, str],
    extras: dict[str, object],
) -> None:
    """Apply a state block to ``resolved``."""

    raw_props = block.raw_props or [(prop.name, str(prop.value)) for prop in block.properties]
    for name, value in raw_props:
        if name.startswith("--"):
            custom_properties[name] = value
            continue
        handler = _PROPERTY_HANDLERS.get(name.lower())
        if handler:
            handler(resolved, value, colors, fonts)
            continue
        extras.setdefault(name, []).append(value)


def _split_tokens(value: str) -> list[str]:
    """Split a property value into tokens while respecting parentheses."""

    tokens: list[str] = []
    buff: list[str] = []
    depth = 0
    quote: str | None = None
    for ch in value.strip():
        if quote:
            buff.append(ch)
            if ch == quote:
                quote = None
            continue
        if ch in {'"', "'"}:
            buff.append(ch)
            quote = ch
            continue
        if ch == '(':
            depth += 1
            buff.append(ch)
            continue
        if ch == ')':
            depth = max(0, depth - 1)
            buff.append(ch)
            continue
        if ch.isspace() and depth == 0:
            if buff:
                tokens.append("".join(buff))
                buff = []
            continue
        buff.append(ch)
    if buff:
        tokens.append("".join(buff))
    return tokens


def _resolve_color(value: str, colors: Mapping[str, str]) -> str:
    """Resolve a colour token using ``colors`` as lookup table."""

    stripped = value.strip()
    if stripped.startswith("var(") and stripped.endswith(")"):
        inner = stripped[4:-1].strip()
        return colors.get(inner, stripped)
    if stripped.startswith("#") or stripped.startswith("rgb") or stripped.startswith("hsl"):
        return stripped
    return colors.get(stripped, stripped)


def _handle_color(resolved: ResolvedStyle, value: str, colors: Mapping[str, str], _: Mapping[str, Any]) -> None:
    """Handle the ``color`` property."""

    resolved.color = _resolve_color(value, colors)


def _handle_background(resolved: ResolvedStyle, value: str, colors: Mapping[str, str], _: Mapping[str, Any]) -> None:
    """Handle the ``background`` property."""

    resolved.background = _resolve_color(value, colors)


def _handle_outline(resolved: ResolvedStyle, value: str, colors: Mapping[str, str], _: Mapping[str, Any]) -> None:
    """Handle the ``outline`` property."""

    resolved.outline = _resolve_color(value, colors)


def _handle_border_color(resolved: ResolvedStyle, value: str, colors: Mapping[str, str], _: Mapping[str, Any]) -> None:
    """Handle the ``border-color`` property."""

    resolved.border_color = _resolve_color(value, colors)


def _handle_padding(resolved: ResolvedStyle, value: str, _: Mapping[str, str], __: Mapping[str, Any]) -> None:
    """Handle the ``padding`` shorthand."""

    tokens = _split_tokens(value)
    resolved.padding = Insets.from_tokens(tokens if tokens else [value])


def _handle_margin(resolved: ResolvedStyle, value: str, _: Mapping[str, str], __: Mapping[str, Any]) -> None:
    """Handle the ``margin`` shorthand."""

    tokens = _split_tokens(value)
    resolved.margin = Insets.from_tokens(tokens if tokens else [value])


def _handle_font(resolved: ResolvedStyle, value: str, _: Mapping[str, str], fonts: Mapping[str, Any]) -> None:
    """Handle the ``font`` property referencing theme fonts."""

    token = value.strip()
    resolved.font = token
    if token in fonts:
        font = fonts[token]
        if font.size is not None:
            resolved.font_size = Length(font.size, "px")
        if font.weight is not None:
            resolved.weight = font.weight


def _handle_font_weight(resolved: ResolvedStyle, value: str, _: Mapping[str, str], __: Mapping[str, Any]) -> None:
    """Handle ``font-weight`` overrides."""

    resolved.weight = value.strip()


def _handle_font_size(resolved: ResolvedStyle, value: str, _: Mapping[str, str], __: Mapping[str, Any]) -> None:
    """Handle ``font-size`` overrides."""

    resolved.font_size = Length.from_token(value.strip())


def _handle_border(resolved: ResolvedStyle, value: str, colors: Mapping[str, str], __: Mapping[str, Any]) -> None:
    """Handle the ``border`` shorthand."""

    tokens = _split_tokens(value)
    width = float(tokens[0].rstrip("px")) if tokens else 0.0
    style = tokens[1] if len(tokens) > 1 else "solid"
    color = _resolve_color(tokens[2], colors) if len(tokens) > 2 else None
    resolved.border = Border(width, style, color)


def _handle_border_radius(resolved: ResolvedStyle, value: str, _: Mapping[str, str], __: Mapping[str, Any]) -> None:
    """Handle the ``border-radius`` shorthand."""

    tokens = _split_tokens(value)
    insets = Insets.from_tokens(tokens if tokens else [value])
    resolved.border_radius = BorderRadius(
        top_left=insets.top,
        top_right=insets.right,
        bottom_right=insets.bottom,
        bottom_left=insets.left,
    )


def _handle_box_shadow(resolved: ResolvedStyle, value: str, colors: Mapping[str, str], __: Mapping[str, Any]) -> None:
    """Handle ``box-shadow`` declarations."""

    tokens = _split_tokens(value)
    inset = False
    if tokens and tokens[-1].lower() == "inset":
        inset = True
        tokens = tokens[:-1]
    if len(tokens) < 4:
        return
    offset_x = Length.from_token(tokens[0])
    offset_y = Length.from_token(tokens[1])
    blur = Length.from_token(tokens[2])
    color_index = 3
    try:
        spread = Length.from_token(tokens[3])
        color_index = 4
    except ValueError:
        spread = Length(0.0, "px")
    color = _resolve_color(tokens[color_index], colors) if len(tokens) > color_index else "#000000"
    shadow = BoxShadow(offset_x, offset_y, blur, spread, color, inset)
    if resolved.box_shadow is None:
        resolved.box_shadow = [shadow]
    else:
        resolved.box_shadow.append(shadow)


def _handle_line_height(resolved: ResolvedStyle, value: str, _: Mapping[str, str], __: Mapping[str, Any]) -> None:
    """Handle numeric and relative ``line-height`` values."""

    stripped = value.strip()
    try:
        resolved.line_height = float(stripped)
    except ValueError:
        resolved.line_height = Length.from_token(stripped)


def _handle_letter_spacing(resolved: ResolvedStyle, value: str, _: Mapping[str, str], __: Mapping[str, Any]) -> None:
    """Handle ``letter-spacing`` declarations."""

    resolved.letter_spacing = Length.from_token(value.strip())


def _handle_word_spacing(resolved: ResolvedStyle, value: str, _: Mapping[str, str], __: Mapping[str, Any]) -> None:
    """Handle ``word-spacing`` declarations."""

    resolved.word_spacing = Length.from_token(value.strip())


def _handle_text_align(resolved: ResolvedStyle, value: str, _: Mapping[str, str], __: Mapping[str, Any]) -> None:
    """Handle ``text-align`` declarations."""

    resolved.text_align = value.strip()


def _handle_text_transform(resolved: ResolvedStyle, value: str, _: Mapping[str, str], __: Mapping[str, Any]) -> None:
    """Handle ``text-transform`` declarations."""

    resolved.text_transform = value.strip()


def _handle_transform(resolved: ResolvedStyle, value: str, _: Mapping[str, str], __: Mapping[str, Any]) -> None:
    """Handle generic ``transform`` declarations."""

    resolved.transform = value.strip()


def _handle_text_decoration(resolved: ResolvedStyle, value: str, colors: Mapping[str, str], __: Mapping[str, Any]) -> None:
    """Handle the ``text-decoration`` shorthand."""

    tokens = _split_tokens(value)
    if tokens:
        resolved.text_decoration = tokens[0]
    if len(tokens) > 1:
        resolved.text_decoration_style = tokens[1]
    if len(tokens) > 2:
        resolved.text_decoration_color = _resolve_color(tokens[2], colors)


def _handle_opacity(resolved: ResolvedStyle, value: str, _: Mapping[str, str], __: Mapping[str, Any]) -> None:
    """Handle ``opacity`` declarations."""

    resolved.opacity = float(value)


def _handle_height(resolved: ResolvedStyle, value: str, _: Mapping[str, str], __: Mapping[str, Any]) -> None:
    """Handle ``height`` declarations."""

    resolved.height = Length.from_token(value.strip())


def _handle_width(resolved: ResolvedStyle, value: str, _: Mapping[str, str], __: Mapping[str, Any]) -> None:
    """Handle ``width`` declarations."""

    resolved.width = Length.from_token(value.strip())


def _handle_background_image(resolved: ResolvedStyle, value: str, _: Mapping[str, str], __: Mapping[str, Any]) -> None:
    """Handle ``background-image`` declarations."""

    resolved.background_image = value.strip()


def _handle_background_repeat(resolved: ResolvedStyle, value: str, _: Mapping[str, str], __: Mapping[str, Any]) -> None:
    """Handle ``background-repeat`` declarations."""

    resolved.background_repeat = value.strip()


def _handle_background_size(resolved: ResolvedStyle, value: str, _: Mapping[str, str], __: Mapping[str, Any]) -> None:
    """Handle ``background-size`` declarations."""

    resolved.background_size = value.strip()


def _handle_background_position(resolved: ResolvedStyle, value: str, _: Mapping[str, str], __: Mapping[str, Any]) -> None:
    """Handle ``background-position`` declarations."""

    resolved.background_position = value.strip()


def _handle_component_extra(resolved: ResolvedStyle, value: str, _: Mapping[str, str], __: Mapping[str, Any]) -> None:
    """Store unknown properties for downstream consumers."""

    extras = resolved.component_extras or {}
    extras.setdefault("extras", []).append(value)
    resolved.component_extras = extras


_PROPERTY_HANDLERS: dict[str, Any] = {
    "color": _handle_color,
    "background": _handle_background,
    "outline": _handle_outline,
    "border-color": _handle_border_color,
    "padding": _handle_padding,
    "margin": _handle_margin,
    "font": _handle_font,
    "font-weight": _handle_font_weight,
    "font-size": _handle_font_size,
    "border": _handle_border,
    "border-radius": _handle_border_radius,
    "box-shadow": _handle_box_shadow,
    "line-height": _handle_line_height,
    "letter-spacing": _handle_letter_spacing,
    "word-spacing": _handle_word_spacing,
    "text-align": _handle_text_align,
    "text-transform": _handle_text_transform,
    "transform": _handle_transform,
    "text-decoration": _handle_text_decoration,
    "opacity": _handle_opacity,
    "height": _handle_height,
    "width": _handle_width,
    "background-image": _handle_background_image,
    "background-repeat": _handle_background_repeat,
    "background-size": _handle_background_size,
    "background-position": _handle_background_position,
    "component-extra": _handle_component_extra,
}


__all__ = ["ResolvedStyle", "resolve_stylesheet"]

resolve_style = resolve_stylesheet
__all__ = ["ResolvedStyle", "resolve_stylesheet", "resolve_style"]