from __future__ import annotations

_LAST_ERRORS: list[str] = []
_LAST_WARNINGS: list[str] = []


def warn(msg: str) -> None:
    _LAST_WARNINGS.append(msg)


def error(msg: str) -> None:
    _LAST_ERRORS.append(msg)


def last_errors() -> list[str]:
    return list(_LAST_ERRORS)


def last_warnings() -> list[str]:
    return list(_LAST_WARNINGS)


def clear() -> None:
    _LAST_ERRORS.clear()
    _LAST_WARNINGS.clear()
