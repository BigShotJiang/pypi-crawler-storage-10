"""Core value objects used by the Textforge Styling (TFS) engine.

The classes defined in this module are intentionally lightweight data
containers.  They are frozen dataclasses to ensure immutability when values
are shared across threads.  Helper constructors are provided for parsing the
string tokens produced by the grammar and cascade modules.
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import TYPE_CHECKING, Literal

if TYPE_CHECKING:
    from .tfs_ast import ComponentRule

LengthUnit = Literal["px", "cell", "%", "em"]
_SUFFIX_TO_UNIT: dict[str, LengthUnit] = {
    "px": "px",
    "em": "em",
    "cell": "cell",
    "%": "%",
}


@dataclass(slots=True, frozen=True)
class Length:
    """Numeric value tagged with a unit."""

    value: float
    unit: LengthUnit = "px"

    @classmethod
    def from_token(cls, token: str) -> Length:
        """Parse a CSS-like length token."""

        stripped = token.strip()
        if not stripped:
            raise ValueError("length token cannot be empty")
        detected_unit: LengthUnit = "px"
        number = stripped
        for suffix, unit in _SUFFIX_TO_UNIT.items():
            if stripped.endswith(suffix) and suffix != "px":
                detected_unit = unit
                number = stripped[: -len(suffix)]
                break
        else:
            if stripped.endswith("px"):
                detected_unit = "px"
                number = stripped[:-2]
        return cls(float(number), detected_unit)


@dataclass(slots=True, frozen=True)
class Insets:
    """Four sided inset (top/right/bottom/left)."""

    top: Length
    right: Length
    bottom: Length
    left: Length

    @classmethod
    def from_tokens(cls, tokens: list[str]) -> Insets:
        """Convert one to four tokens into an ``Insets`` structure."""

        if not tokens:
            raise ValueError("at least one token required for insets")
        parsed = [Length.from_token(token) for token in tokens]
        if len(parsed) == 1:
            top = right = bottom = left = parsed[0]
        elif len(parsed) == 2:
            top, right = parsed
            bottom = top
            left = right
        elif len(parsed) == 3:
            top, right, bottom = parsed
            left = right
        else:
            top, right, bottom, left = parsed[:4]
        return cls(top, right, bottom, left)


@dataclass(slots=True, frozen=True)
class Border:
    """Border definition containing width and optional style."""

    width: float
    style: Literal["round", "square", "ascii", "double", "dashed", "dotted", "solid"] | None = None
    color: str | None = None


@dataclass(slots=True, frozen=True)
class FontProfile:
    """Semantic font declaration."""

    name: str
    size_px: float | None = None
    weight: str | int | None = None
    family: str | None = None


@dataclass(slots=True, frozen=True)
class RGBA:
    """RGBA colour with floating point alpha."""

    r: int
    g: int
    b: int
    a: float = 1.0


@dataclass(slots=True, frozen=True)
class HSLA:
    """HSLA colour specification."""

    h: float
    s: float
    lightness: float
    a: float = 1.0


@dataclass(slots=True, frozen=True)
class ColorFunction:
    """Generic functional colour specification (e.g. ``color-mix``)."""

    name: str
    args: list[str]


@dataclass(slots=True, frozen=True)
class ColorBlend:
    """Two colour blending specification."""

    mode: Literal[
        "multiply",
        "screen",
        "overlay",
        "soft-light",
        "hard-light",
        "color-dodge",
        "color-burn",
        "difference",
        "exclusion",
        "hue",
        "saturation",
        "color",
        "luminosity",
    ]
    color_a: str | RGBA | HSLA
    color_b: str | RGBA | HSLA


ColorSpec = str | RGBA | HSLA | ColorFunction | ColorBlend


@dataclass(slots=True, frozen=True)
class BoxShadow:
    """Box shadow definition."""

    offset_x: Length
    offset_y: Length
    blur_radius: Length
    spread_radius: Length
    color: ColorSpec
    inset: bool = False


@dataclass(slots=True, frozen=True)
class BorderRadius:
    """Border radius for the four corners."""

    top_left: Length
    top_right: Length
    bottom_right: Length
    bottom_left: Length


@dataclass(slots=True, frozen=True)
class TextShadow:
    """Text shadow specification."""

    offset_x: Length
    offset_y: Length
    blur_radius: Length
    color: ColorSpec


@dataclass(slots=True, frozen=True)
class Gradient:
    """Representation of a linear, radial, or conic gradient."""

    type: Literal["linear", "radial", "conic"]
    colors: list[tuple[ColorSpec, float]]
    angle: float = 0.0
    center_x: float = 0.5
    center_y: float = 0.5


@dataclass(slots=True, frozen=True)
class Keyframe:
    """Single animation keyframe."""

    position: float
    properties: dict[str, str]


@dataclass(slots=True, frozen=True)
class Keyframes:
    """Sequence of keyframes for an animation."""

    name: str
    keyframes: list[Keyframe]


EasingFunction = Literal[
    "linear",
    "ease",
    "ease-in",
    "ease-out",
    "ease-in-out",
    "step-start",
    "step-end",
    "cubic-bezier",
]


@dataclass(slots=True, frozen=True)
class Animation:
    """Animation metadata."""

    name: str
    duration: float
    delay: float = 0.0
    iteration_count: float | str = 1
    direction: str = "normal"
    fill_mode: str = "none"
    timing_function: str = "ease"
    play_state: str = "running"


@dataclass(slots=True, frozen=True)
class Transition:
    """Property transition metadata."""

    property: str
    duration: float
    delay: float = 0.0
    timing_function: str = "ease"


@dataclass(slots=True, frozen=True)
class MediaQuery:
    """Single media query constraint."""

    feature: str
    operator: str
    value: str | int | float
    negated: bool = False


@dataclass(slots=True, frozen=True)
class MediaRule:
    """A collection of component rules under media constraints."""

    queries: list[MediaQuery]
    rules: list[ComponentRule]


__all__ = [
    "Animation",
    "Border",
    "BorderRadius",
    "BoxShadow",
    "ColorBlend",
    "ColorFunction",
    "ColorSpec",
    "Gradient",
    "HSLA",
    "Insets",
    "Keyframe",
    "Keyframes",
    "Length",
    "LengthUnit",
    "MediaQuery",
    "MediaRule",
    "RGBA",
    "TextShadow",
    "Transition",
    "FontProfile",
]
