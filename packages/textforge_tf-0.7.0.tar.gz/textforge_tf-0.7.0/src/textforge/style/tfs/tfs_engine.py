"""Runtime style engine for the Textforge Styling subsystem."""

from __future__ import annotations

import threading
from collections import OrderedDict
from dataclasses import dataclass, fields
from pathlib import Path
from typing import TYPE_CHECKING, Any

from ...utils.logging import get_logger
from . import tfs_diag as diag
from .tfs_cascade import ResolvedStyle, resolve_stylesheet
from .tfs_grammar import parse_stylesheet

if TYPE_CHECKING:
    from collections.abc import Mapping

    from .tfs_ast import Stylesheet

_CACHE_LIMIT = 1024


@dataclass(frozen=True)
class _CacheKey:
    """Immutable cache key for resolved styles."""

    component: str
    states: frozenset[str]
    theme_version: int
    caps_signature: int


class StyleEngine:
    """Parse, cache, and resolve Textforge Style (TFS) stylesheets."""

    def __init__(self) -> None:
        self._lock = threading.RLock()
        self._cache: OrderedDict[_CacheKey, ResolvedStyle] = OrderedDict()
        self._sheets: list[Stylesheet] = []
        self._default_sheet: Stylesheet | None = None
        self._use_default = True
        self._version = 0
        self._logger = get_logger("textforge.style.engine")
        self._load_default_stylesheet()

    @property
    def theme_version(self) -> int:
        return self._version

    def load_stylesheet(self, path: str | Path) -> None:
        """Load and parse a TFS stylesheet from disk."""
        path_obj = Path(path)
        text = path_obj.read_text(encoding="utf-8")
        self.load_stylesheet_text(path_obj.name, text)

    def load_stylesheet_text(self, name: str, text: str) -> None:
        """Load a stylesheet from raw TFS source."""
        self._logger.debug(f"Parsing stylesheet '{name}' ({len(text)} chars)")
        diag.clear()
        sheet = parse_stylesheet(name, text)
        warnings = diag.last_warnings()
        for message in warnings:
            self._logger.warning(f"{name}: {message}")

        with self._lock:
            self._sheets.append(sheet)
            self._use_default = False
            self._version += 1
            self._invalidate_cache_unlocked()
            self._logger.debug(
                "Registered stylesheet '%s' (total sheets: %d, version: %d)",
                name,
                len(self._sheets),
                self._version,
            )

    def clear_styles(self) -> None:
        """Remove all user-provided stylesheets and revert to defaults."""
        with self._lock:
            self._logger.debug("Clearing user stylesheets and resetting cache")
            self._sheets.clear()
            self._use_default = True
            self._version += 1
            self._invalidate_cache_unlocked()

    def resolve(self, *, node: object, state: Mapping[str, bool], caps: object, overrides: Mapping[str, str] | None = None) -> ResolvedStyle:
        """Resolve the merged style for a component node."""
        component = _extract_component_name(node)
        if not component:
            self._logger.warning("Unable to resolve style for node without component name: %r", node)
            return ResolvedStyle()

        active_states = frozenset(key for key, value in state.items() if value)
        caps_signature = _caps_signature(caps)

        with self._lock:
            key = _CacheKey(component, active_states, self._version, caps_signature)
            cached = self._cache.get(key)
            if cached is not None:
                self._logger.debug("Style cache hit for %s (states=%s)", component, sorted(active_states))
                # Move key to end to maintain LRU ordering
                self._cache.move_to_end(key)
                return cached

            default_sheet = self._default_sheet if self._use_default else None
            sheets_snapshot = list(self._sheets)
            version = self._version

        self._logger.debug(
            "Resolving style for %s (states=%s, sheets=%d, version=%d)",
            component,
            sorted(active_states),
            len(sheets_snapshot) + (1 if default_sheet else 0),
            version,
        )

        resolved = self._resolve_from_sheets(
            component=component,
            active_states=active_states,
            default_sheet=default_sheet,
            sheets=sheets_snapshot,
            caps=caps,
        )

        with self._lock:
            self._cache[key] = resolved
            if len(self._cache) > _CACHE_LIMIT:
                self._cache.popitem(last=False)
            return resolved

    def _resolve_from_sheets(
        self,
        *,
        component: str,
        active_states: frozenset[str],
        default_sheet: Stylesheet | None,
        sheets: list[Stylesheet],
        caps: object,
    ) -> ResolvedStyle:
        resolved = ResolvedStyle()
        inherited_custom_props: dict[str, str] = {}
        accumulated_keyframes: dict[str, Any] = {}

        active_sheets: list[object] = []
        if default_sheet is not None:
            active_sheets.append(default_sheet)
        active_sheets.extend(sheets)

        for sheet in active_sheets:
            # build plain color map (token name -> hex/string)
            colors_map = {name: tok.value for name, tok in sheet.colors.items()}
            fonts_map = sheet.fonts  # FontDef instances are fine as-is

            partial = resolve_stylesheet(
                sheet=sheet,
                component=component,
                states=active_states,
                colors=colors_map,
                fonts=fonts_map,
            )
            if partial.custom_properties:
                inherited_custom_props.update(partial.custom_properties)
            if partial.keyframes:
                accumulated_keyframes.update(partial.keyframes)
            resolved = _merge_styles(resolved, partial)

        return resolved

    def _load_default_stylesheet(self) -> None:
        assets_dir = Path(__file__).resolve().parent.parent / "assets"
        default_path = assets_dir / "defaults.tfs"
        fallback_path = assets_dir / "default.tfs"

        try:
            path = default_path if default_path.exists() else fallback_path
            text = path.read_text(encoding="utf-8")
        except FileNotFoundError:
            self._logger.error("Default theme file is missing (looked for %s)", default_path)
            return

        self._logger.debug("Loading built-in theme from %s", path.name)
        diag.clear()
        sheet = parse_stylesheet(path.name, text)
        warnings = diag.last_warnings()
        for message in warnings:
            self._logger.warning(f"{path.name}: {message}")

        with self._lock:
            self._default_sheet = sheet
            self._use_default = True
            self._version += 1
            self._invalidate_cache_unlocked()

    def _invalidate_cache_unlocked(self) -> None:
        self._cache.clear()

    # ADD no-op compatibility methods used by the public facade
    def set_theme(self, theme_name: str) -> None:
        # No themed bundles yet; bump version so caches invalidate consistently
        with self._lock:
            self._version += 1
            self._invalidate_cache_unlocked()

    def clear_extra_stylesheets(self) -> None:
        # Alias to existing clear that re-enables default sheet
        self.clear_styles()


def _merge_styles(base: ResolvedStyle, update: ResolvedStyle) -> ResolvedStyle:
    values: dict[str, Any] = {}
    for field in fields(ResolvedStyle):
        new_value = getattr(update, field.name)
        if new_value is not None:
            values[field.name] = new_value
        else:
            values[field.name] = getattr(base, field.name)
    return ResolvedStyle(**values)


def _caps_signature(caps: object) -> int:
    depth = _safe_call(caps, "color_depth")
    dpi = _safe_call(caps, "dpi")
    metrics = _safe_call(caps, "cell_metrics")
    return hash((depth, dpi, metrics))


def _safe_call(obj: object, attribute: str) -> str:
    if obj is None:
        return "?"
    try:
        candidate = getattr(obj, attribute)
    except AttributeError:
        return "?"
    try:
        return repr(candidate()) if callable(candidate) else repr(candidate)
    except Exception:
        return "?"


def _extract_component_name(node: object) -> str | None:
    if isinstance(node, dict):
        component = node.get("component_name")
        if isinstance(component, str) and component:
            return component
    component = getattr(node, "component_name", None)
    if isinstance(component, str) and component:
        return component
    cls = getattr(node, "__class__", None)
    name = getattr(cls, "__name__", None)
    return name if isinstance(name, str) else None


__all__ = ["StyleEngine"]
