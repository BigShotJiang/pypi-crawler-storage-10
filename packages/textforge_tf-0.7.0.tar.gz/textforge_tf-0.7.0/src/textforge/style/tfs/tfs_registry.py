from __future__ import annotations

from dataclasses import dataclass


@dataclass(slots=True, frozen=True)
class PropertyMeta:
    name: str
    inheritable: bool = False


_PROPERTIES: dict[str, PropertyMeta] = {
    "color": PropertyMeta("color"),
    "background": PropertyMeta("background"),
    "border": PropertyMeta("border"),
    "border-style": PropertyMeta("border-style"),
    "border-color": PropertyMeta("border-color"),
    "padding": PropertyMeta("padding"),
    "font": PropertyMeta("font"),
    "font-size": PropertyMeta("font-size"),
    "weight": PropertyMeta("weight"),
    "family": PropertyMeta("family"),
    "outline": PropertyMeta("outline"),
    "fill": PropertyMeta("fill"),
    "track": PropertyMeta("track"),
}


def has_property(name: str) -> bool:
    return name in _PROPERTIES
