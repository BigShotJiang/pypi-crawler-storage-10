from __future__ import annotations

from typing import TYPE_CHECKING, Any

if TYPE_CHECKING:
    from collections.abc import Callable

    from ..tfs_cascade import ResolvedStyle
    from ..tfs_values import Length


def _length_to_px(length: Length | None, *, cell_metrics: Callable[[], tuple[int, int]], font_metrics: Callable[[], tuple[int, int]]) -> int | None:
    if length is None:
        return None
    unit = getattr(length, "unit", "px")
    val = getattr(length, "value", 0)
    if unit == "px":
        return int(val)
    if unit == "cell":
        cm = cell_metrics() if callable(cell_metrics) else None
        cell_w = cm[0] if (isinstance(cm, (tuple, list)) and len(cm) >= 1) else 10
        return int(val * cell_w)
    if unit == "%":
        # Percentage resolution requires layout context; mapper leaves None
        return None
    if unit == "em":
        # Approximate using a default font size when metrics unavailable
        # font_metrics(profile) can be used by higher layer with resolved.font
        base_px = 16
        return int(val * base_px)
    return None


def map_to_gui(resolved: ResolvedStyle | None, *, cell_metrics: Callable[[], tuple[int, int]], font_metrics: Callable[[], tuple[int, int]]) -> dict[str, Any]:
    """Map normalized ResolvedStyle into GUI drawing attributes.

    Uses provided capability query functions.
    """
    if resolved is None:
        return {}

    data: dict[str, object] = {}
    if resolved.color:
        data["fg"] = resolved.color
    if resolved.background:
        data["bg"] = resolved.background
    if resolved.border is not None:
        # Border width can be a pixel notion; leave unit conversion to higher level if needed
        data["border_px"] = max(0, int(resolved.border.width))
    if resolved.border_color:
        data["border_color"] = resolved.border_color
    if resolved.padding is not None:
        t = _length_to_px(resolved.padding.top, cell_metrics=cell_metrics, font_metrics=font_metrics)
        r = _length_to_px(resolved.padding.right, cell_metrics=cell_metrics, font_metrics=font_metrics)
        b = _length_to_px(resolved.padding.bottom, cell_metrics=cell_metrics, font_metrics=font_metrics)
        left_px = _length_to_px(resolved.padding.left, cell_metrics=cell_metrics, font_metrics=font_metrics)
        data["padding_px"] = (t or 0, r or 0, b or 0, left_px or 0)
    if resolved.font:
        data["font_profile"] = resolved.font
    if resolved.font_size is not None:
        data["font_size_px"] = _length_to_px(resolved.font_size, cell_metrics=cell_metrics, font_metrics=font_metrics)
    if resolved.outline:
        data["outline"] = resolved.outline
    if resolved.component_extras:
        data.update(resolved.component_extras)
    return data
