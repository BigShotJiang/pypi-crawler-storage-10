from __future__ import annotations

from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from collections.abc import Callable

    from textforge.style.tfs.tfs_values import Length

    from ..tfs_cascade import ResolvedStyle


def _hex_to_rgb(value: str) -> tuple[int, int, int] | None:
    s = value.strip().lower()
    if s.startswith("#") and len(s) == 7:
        try:
            r = int(s[1:3], 16)
            g = int(s[3:5], 16)
            b = int(s[5:7], 16)
            return r, g, b
        except Exception:
            return None
    if s.startswith("rgb(") and s.endswith(")"):
        try:
            parts = s[4:-1].split(",")
            r = int(parts[0])
            g = int(parts[1])
            b = int(parts[2])
            return r, g, b
        except Exception:
            return None
    return None


def _rgb_to_ansi256(r: int, g: int, b: int) -> int:
    # Map to grayscale if near gray
    if r == g == b:
        if r < 8:
            return 16
        if r > 248:
            return 231
        return 232 + int((r - 8) / 10.8)
    # 6x6x6 color cube

    def _to_6(x: int) -> int:
        return int(round(x / 255 * 5))

    ri, gi, bi = _to_6(r), _to_6(g), _to_6(b)
    return 16 + 36 * ri + 6 * gi + bi


def _rgb_to_ansi16(r: int, g: int, b: int) -> int:
    # Approximate mapping to 16-color ANSI using luminance and primary channels
    # Base colors 0-7 and bright 8-15
    bright = (r + g + b) / 3 > 127
    idx = 0
    if r > 127:
        idx |= 1
    if g > 127:
        idx |= 2
    if b > 127:
        idx |= 4
    return (8 if bright else 0) + (idx if idx != 0 else 0)


def _downsample_color(color: str, depth: str) -> dict[str, object]:
    rgb = _hex_to_rgb(color)
    if rgb is None:
        return {"hex": color}
    r, g, b = rgb
    d = (depth or "C256").upper()
    if d == "TRUECOLOR":
        return {"hex": f"#{r:02x}{g:02x}{b:02x}"}
    if d in ("C256", "256"):
        return {"ansi256": _rgb_to_ansi256(r, g, b)}
    if d in ("C16", "16"):
        return {"ansi16": _rgb_to_ansi16(r, g, b)}
    return {"hex": f"#{r:02x}{g:02x}{b:02x}"}


def _length_to_cells(length: Length | None) -> int:
    """Returns integer cell count; '%': 0 (layout-dependent), 'px': caller converts via pixel_to_cell"""
    if length is None:
        return 0
    unit = getattr(length, "unit", "px")
    val = getattr(length, "value", 0)
    if unit == "cell":
        return int(val)
    if unit == "px":
        # caller handles px→cell via pixel_to_cell
        return int(val)
    if unit == "%":
        # layout-dependent; not resolved here
        return 0
    if unit == "em":
        # approximate: 1em ~ 1 cell
        return int(val)
    return 0


def map_to_tty(resolved: ResolvedStyle, *, pixel_to_cell: Callable[[float | int], int], color_depth: Callable[[], str]) -> dict[str, object]:
    """Map normalized ResolvedStyle into TTY-friendly attributes.

    Returns a small dict used by the CLI/TTY adapter to render borders, padding, colors.
    Includes best-effort downsampling based on color depth.
    """
    data: dict[str, object] = {}
    _depth_raw = color_depth() if callable(color_depth) else color_depth
    depth: str = str(_depth_raw or "C256")
    if resolved.color:
        data["fg"] = _downsample_color(str(resolved.color), depth)
    if resolved.background:
        data["bg"] = _downsample_color(str(resolved.background), depth)
    if resolved.border is not None:
        width_cells = max(0, int(pixel_to_cell(resolved.border.width)))
        # Enforce minimum of 1 cell when a non-zero border resolves to 0 cells
        if resolved.border.width > 0 and width_cells == 0:
            width_cells = 1
        data["border_width"] = max(0, width_cells)
    if resolved.border_color:
        data["border_color"] = _downsample_color(str(resolved.border_color), depth)
    if resolved.padding is not None:
        t = _length_to_cells(resolved.padding.top)
        r = _length_to_cells(resolved.padding.right)
        b = _length_to_cells(resolved.padding.bottom)
        left_cells = _length_to_cells(resolved.padding.left)
        # Convert px→cell if necessary for any px units (best-effort)
        t = t if getattr(resolved.padding.top, "unit", "cell") == "cell" else pixel_to_cell(getattr(resolved.padding.top, "value", 0))
        r = r if getattr(resolved.padding.right, "unit", "cell") == "cell" else pixel_to_cell(getattr(resolved.padding.right, "value", 0))
        b = b if getattr(resolved.padding.bottom, "unit", "cell") == "cell" else pixel_to_cell(getattr(resolved.padding.bottom, "value", 0))
        left_cells = left_cells if getattr(resolved.padding.left, "unit", "cell") == "cell" else pixel_to_cell(getattr(resolved.padding.left, "value", 0))
        data["padding"] = (int(t), int(r), int(b), int(left_cells))
    if resolved.outline:
        data["outline"] = _downsample_color(str(resolved.outline), depth)
    if resolved.component_extras:
        data.update(resolved.component_extras)
    return data
