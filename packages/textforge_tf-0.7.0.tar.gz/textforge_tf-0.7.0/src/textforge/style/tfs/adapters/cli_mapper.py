from __future__ import annotations

from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from ..tfs_cascade import ResolvedStyle


def map_to_cli(resolved: ResolvedStyle) -> dict[str, object]:
    """Map normalized style for basic stdout-only rendering."""
    data: dict[str, object] = {}
    if resolved.color:
        data["fg"] = resolved.color
    if resolved.background:
        data["bg"] = resolved.background
    return data
