"""AST nodes for the Textforge Styling (TFS) language."""

from __future__ import annotations

from dataclasses import dataclass
from typing import TYPE_CHECKING, Any

if TYPE_CHECKING:
    from .tfs_values import Keyframes, MediaRule


@dataclass(slots=True, frozen=True)
class Span:
    """Location information for diagnostics."""

    filename: str
    line: int
    column: int


@dataclass(slots=True, frozen=True)
class ColorToken:
    """Named colour entry declared through ``@colors``."""

    name: str
    value: str
    span: Span


@dataclass(slots=True, frozen=True)
class FontDef:
    """Font profile declared through ``@fonts``."""

    name: str
    size: float | None
    weight: str | int | None
    family: str | None
    span: Span


@dataclass(slots=True, frozen=True)
class Property:
    """Single property assignment in a state block."""

    name: str
    value: Any
    span: Span


@dataclass(slots=True, frozen=True)
class StateBlock:
    """Component block optionally restricted to states."""

    states: frozenset[str]
    properties: list[Property]
    span: Span
    raw_props: list[tuple[str, str]] | None = None

    def matches(self, active_states: frozenset[str]) -> bool:
        """Return ``True`` when this block applies to ``active_states``."""

        if not self.states or self.states == frozenset({"default"}):
            return True
        return self.states.issubset(active_states)


@dataclass(slots=True, frozen=True)
class ComponentRule:
    """Collection of state blocks for a component selector."""

    component: str
    blocks: list[StateBlock]
    span: Span


@dataclass(slots=True, frozen=True)
class Stylesheet:
    """Top level stylesheet container."""

    filename: str
    colors: dict[str, ColorToken]
    fonts: dict[str, FontDef]
    keyframes: dict[str, Keyframes]
    media_rules: list[MediaRule]
    rules: list[ComponentRule]


__all__ = [
    "ColorToken",
    "ComponentRule",
    "FontDef",
    "Property",
    "Span",
    "StateBlock",
    "Stylesheet",
]
