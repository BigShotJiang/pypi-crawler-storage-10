"""Textforge Style (TFS) engine and parsing."""
