"""Textforge Style (TFS) public API exports.

This package hosts the styling language and resolution engine used across
all renderers (CLI/TTY/GUI/export). It is backend-agnostic
and also contains Style tokens and theming hooks."""

from __future__ import annotations

from textforge.style.tfs.tfs_cascade import ResolvedStyle
from textforge.style.tfs.tfs_engine import StyleEngine
from textforge.style.tfs.tfs_grammar import parse_stylesheet

from . import ansi, borders, gradients, palette, tokens
from .colors import Color
from .subsystem import get_styling_subsystem, resolve_component_style
from .themes import (
    Theme,
    ThemeManager,
    extend_theme,
    get_current_theme,
    get_theme_manager,
    load_custom_theme,
    set_theme,
)


def get_style_engine() -> StyleEngine:
    """Return the process-global :class:`StyleEngine`."""

    return get_styling_subsystem().get_engine()


__all__ = [
    "Color",
    "ResolvedStyle",
    "StyleEngine",
    "get_style_engine",
    "parse_stylesheet",
    "resolve_component_style",
    "get_styling_subsystem",
    "Theme",
    "ThemeManager",
    "get_theme_manager",
    "load_custom_theme",
    "set_theme",
    "get_current_theme",
    "extend_theme",
    "ansi",
    "borders",
    "gradients",
    "palette",
    "tokens",
]
