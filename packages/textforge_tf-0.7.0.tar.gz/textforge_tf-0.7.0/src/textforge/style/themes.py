"""Theme management system for TFS themes.

This module provides theme loading, management, and customization capabilities
for Textforge's TFS (Textforge Style) system.
"""

from __future__ import annotations

import threading
from pathlib import Path

from ..utils.logging import get_logger
from .theme_types import Theme

logger = get_logger(__name__)


class ThemeManager:
    """Manager for loading and managing TFS themes with thread-safe operations."""

    def __init__(self, theme_dir: Path | str | None = None) -> None:
        """Initialize the theme manager.

        Args:
            theme_dir: Directory containing theme files. Defaults to style/assets.
        """
        if theme_dir is None:
            # Default to the assets directory
            theme_dir = Path(__file__).parent / "assets"

        self.theme_dir = Path(theme_dir)
        self._themes: dict[str, Theme] = {}
        self._current_theme: str | None = None
        self._lock = threading.RLock()
        self._load_builtin_themes()

    def _load_builtin_themes(self) -> None:
        """Load the built-in themes (defaults, dark, light)."""
        builtin_themes = ["defaults", "dark", "light"]

        for theme_name in builtin_themes:
            theme_file = self.theme_dir / f"{theme_name}.tfs"
            if theme_file.exists():
                try:
                    self._load_theme_from_file(theme_name, theme_file)
                    logger.debug(f"Loaded built-in theme: {theme_name}")
                except Exception as e:
                    logger.warning(f"Failed to load built-in theme '{theme_name}': {e}")

    def load_theme(self, name: str, theme_data: str | Path) -> None:
        """Load a custom theme from string or file path.

        Args:
            name: Name to register the theme under.
            theme_data: Theme content as string or path to .tfs file.

        Raises:
            FileNotFoundError: If theme file doesn't exist.
            ValueError: If theme parsing fails.
        """
        with self._lock:
            theme_path = Path(theme_data)
            if theme_path.exists():
                self._load_theme_from_file(name, theme_path)
            else:
                # Treat as theme content string
                self._load_theme_from_string(name, str(theme_data))

            logger.debug(f"Loaded custom theme: {name}")

    def _load_theme_from_file(self, name: str, file_path: Path) -> None:
        """Load theme from a .tfs file.

        Args:
            name: Theme name.
            file_path: Path to the .tfs file.
        """
        try:
            with open(file_path, encoding="utf-8") as f:
                content = f.read()
            self._load_theme_from_string(name, content)
        except Exception as e:
            raise ValueError(f"Failed to load theme from {file_path}: {e}") from e

    def _load_theme_from_string(self, name: str, content: str) -> None:
        """Load theme from a string content.

        Args:
            name: Theme name.
            content: Theme content as string.
        """
        try:
            # For now, create a simple theme with basic palette
            # TODO: Implement proper TFS parsing for theme extraction
            palette: dict[str, str] = {}

            # Simple parsing for @colors block
            lines = content.strip().split("\n")
            in_colors_block = False
            for line in lines:
                line = line.strip()
                if line.startswith("@colors {"):
                    in_colors_block = True
                    continue
                if line.startswith("}") and in_colors_block:
                    in_colors_block = False
                    continue
                if in_colors_block and ":" in line:
                    # Parse color definitions like "primary: #ff6b6b;"
                    parts = line.split(":", 1)
                    if len(parts) == 2:
                        key = parts[0].strip()
                        value = parts[1].strip().rstrip(";")
                        palette[key] = value

            theme = Theme(name=name, palette=palette)
            self._themes[name] = theme

        except Exception as e:
            raise ValueError(f"Failed to parse theme '{name}': {e}") from e

    def get_theme(self, name: str) -> Theme | None:
        """Get a theme by name.

        Args:
            name: Name of the theme to retrieve.

        Returns:
            The theme if found, None otherwise.
        """
        with self._lock:
            return self._themes.get(name)

    def list_themes(self) -> list[str]:
        """List all available theme names.

        Returns:
            List of theme names.
        """
        with self._lock:
            return list(self._themes.keys())

    def set_current_theme(self, name: str) -> None:
        """Set the current active theme.

        Args:
            name: Name of the theme to set as current.

        Raises:
            ValueError: If theme doesn't exist.
        """
        with self._lock:
            if name not in self._themes:
                raise ValueError(f"Theme '{name}' not found")
            self._current_theme = name
            logger.debug(f"Set current theme to: {name}")

            # Notify styling subsystem of theme change
            try:
                from .subsystem import get_styling_subsystem
                subsystem = get_styling_subsystem()
                subsystem.invalidate_cache()
            except Exception as e:
                logger.warning(f"Failed to notify styling subsystem of theme change: {e}")

    def get_current_theme(self) -> Theme | None:
        """Get the current active theme.

        Returns:
            The current theme if set, None otherwise.
        """
        with self._lock:
            if self._current_theme:
                return self._themes.get(self._current_theme)
            return None

    def get_current_theme_name(self) -> str | None:
        """Get the name of the current active theme.

        Returns:
            The current theme name if set, None otherwise.
        """
        with self._lock:
            return self._current_theme

    def extend_theme(self, base_theme_name: str, overrides: dict[str, str]) -> Theme:
        """Create a new theme by extending an existing theme.

        Args:
            base_theme_name: Name of the base theme to extend.
            overrides: Dictionary of color overrides.

        Returns:
            A new Theme instance with the overrides applied.

        Raises:
            ValueError: If base theme doesn't exist.
        """
        with self._lock:
            base_theme = self._themes.get(base_theme_name)
            if base_theme is None:
                raise ValueError(f"Base theme '{base_theme_name}' not found")

            # Create new palette with overrides
            new_palette = base_theme.palette.copy()
            new_palette.update(overrides)

            new_theme_name = f"{base_theme_name}_extended_{len(overrides)}"
            new_theme = Theme(name=new_theme_name, palette=new_palette)
            self._themes[new_theme_name] = new_theme

            logger.debug(f"Created extended theme: {new_theme_name}")
            return new_theme

    def save_theme(self, name: str, file_path: Path | str) -> None:
        """Save a theme to a .tfs file.

        Args:
            name: Name of the theme to save.
            file_path: Path where to save the theme.

        Raises:
            ValueError: If theme doesn't exist.
        """
        with self._lock:
            theme = self._themes.get(name)
            if theme is None:
                raise ValueError(f"Theme '{name}' not found")

            file_path = Path(file_path)
            file_path.parent.mkdir(parents=True, exist_ok=True)

            # Convert theme back to TFS format
            content = self._theme_to_tfs(theme)

            with open(file_path, 'w', encoding='utf-8') as f:
                f.write(content)

            logger.debug("Saved theme '%s' to %s", name, file_path)

    def _theme_to_tfs(self, theme: Theme) -> str:
        """Convert a Theme object back to TFS format.

        Args:
            theme: The theme to convert.

        Returns:
            TFS-formatted string.
        """
        lines = ["@colors {{"]
        for key, value in sorted(theme.palette.items()):
            lines.append(f"  {key}: {value};")
        lines.append("}")
        return "\n".join(lines)


# Global theme manager instance
_theme_manager = ThemeManager()


def get_theme_manager() -> ThemeManager:
    """Get the global theme manager instance.

    Returns:
        The global ThemeManager instance.
    """
    return _theme_manager


def load_custom_theme(name: str, theme_data: str | Path) -> None:
    """Load a custom theme globally.

    Args:
        name: Name to register the theme under.
        theme_data: Theme content as string or path to .tfs file.
    """
    _theme_manager.load_theme(name, theme_data)


def set_theme(name: str) -> None:
    """Set the current theme globally.

    Args:
        name: Name of the theme to set.
    """
    _theme_manager.set_current_theme(name)


def get_current_theme() -> Theme | None:
    """Get the current theme globally.

    Returns:
        The current theme if set, None otherwise.
    """
    return _theme_manager.get_current_theme()


def extend_theme(base_theme_name: str, overrides: dict[str, str]) -> Theme:
    """Extend an existing theme globally.

    Args:
        base_theme_name: Name of the base theme to extend.
        overrides: Dictionary of color overrides.

    Returns:
        A new Theme instance with the overrides applied.
    """
    return _theme_manager.extend_theme(base_theme_name, overrides)
