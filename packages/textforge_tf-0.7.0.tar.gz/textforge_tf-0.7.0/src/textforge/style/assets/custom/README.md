# Custom Themes

Place additional `.tfs` theme files in this directory to make them available
for runtime loading through the styling subsystem. Themes must follow the TFS
syntax described in `SUBSYSTEM_ARCHITECTURE.md` and should declare their color
palette inside an `@colors` block.
