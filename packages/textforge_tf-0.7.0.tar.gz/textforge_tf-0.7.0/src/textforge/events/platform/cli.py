"""CLI-specific event handling for Textforge."""

from __future__ import annotations

import os
import select
import shutil
import sys
import time

from ...utils.logging import get_logger
from ..types import Event, EventType, KeyEvent
from . import PlatformEventHandler

logger = get_logger(__name__)


class CLIEventHandler(PlatformEventHandler):
    """CLI-specific event handler using stdin and terminal capabilities."""

    _WINDOWS_SPECIAL_KEYS = {
        "H": "arrow_up",
        "P": "arrow_down",
        "K": "arrow_left",
        "M": "arrow_right",
        "G": "home",
        "O": "end",
        "R": "insert",
        "S": "delete",
        "I": "page_up",
        "Q": "page_down",
    }

    _POSIX_ESCAPE_KEYS = {
        "A": "arrow_up",
        "B": "arrow_down",
        "C": "arrow_right",
        "D": "arrow_left",
        "H": "home",
        "F": "end",
    }

    def __init__(self) -> None:
        """Initialize CLI event handler."""
        super().__init__()
        self._use_windows_api = os.name == "nt"
        self._raw_mode_enabled = False
        self._original_terminal_settings: tuple[int, ...] | None = None
        self._pending_windows_prefix: str | None = None
        self._last_size = self._read_terminal_size()
        logger.debug("Initialized CLI event handler")

    def is_available(self) -> bool:
        """Return ``True`` because CLI handling is always available as a fallback.

        Returns:
            bool: ``True`` for all platforms.
        """

        return True

    def _start_native_loop(self) -> None:
        """Setup terminal state prior to starting the event loop.

        Returns:
            None
        """
        if not self._use_windows_api and self._stdin_is_tty():
            self._enable_raw_mode()

    def _stop_native_loop(self) -> None:
        """Restore terminal configuration after the event loop stops.

        Returns:
            None
        """
        if self._raw_mode_enabled:
            self._restore_terminal()

    def _poll_native_events(self, timeout: float) -> list[Event]:
        """Poll stdin for key events and detect terminal resize events.

        Args:
            timeout: Maximum time in seconds to wait for input.

        Returns:
            list[Event]: Events detected during the polling window.
        """
        events: list[Event] = []

        events.extend(self._poll_keyboard(timeout))
        resize_event = self._detect_resize_event()
        if resize_event is not None:
            events.append(resize_event)

        return events

    def _send_native_event(self, event: Event) -> None:
        """Log attempts to forward events, as CLI handlers cannot send to the OS.

        Args:
            event: Event instance being forwarded.

        Returns:
            None
        """
        logger.log(5, "CLI handler received synthetic event %s", event.type.value)

    def _poll_keyboard(self, timeout: float) -> list[Event]:
        """Collect keyboard events depending on the current platform.

        Args:
            timeout: Maximum time in seconds to wait for input.

        Returns:
            list[Event]: Events constructed from keyboard input.
        """
        if self._use_windows_api:
            return self._poll_windows_keyboard(timeout)
        return self._poll_posix_keyboard(timeout)

    def _poll_windows_keyboard(self, timeout: float) -> list[Event]:
        """Collect key events using the Windows console API.

        Args:
            timeout: Maximum time in seconds to wait for input.

        Returns:
            list[Event]: Events representing key presses.
        """
        events: list[Event] = []
        try:
            import msvcrt
        except ImportError:
            logger.warning("msvcrt not available; Windows key polling disabled")
            return events

        end_time = time.perf_counter() + timeout
        while msvcrt.kbhit():
            char = msvcrt.getwch()
            events.extend(self._translate_windows_input(char))
            if time.perf_counter() >= end_time:
                break

        return events

    def _poll_posix_keyboard(self, timeout: float) -> list[Event]:
        """Collect key events from stdin on POSIX systems.

        Args:
            timeout: Maximum time in seconds to wait for input.

        Returns:
            list[Event]: Events representing key presses.
        """
        events: list[Event] = []
        if not self._stdin_is_tty():
            return events

        fd = sys.stdin.fileno()
        try:
            readable, _, _ = select.select([fd], [], [], timeout)
        except (ValueError, OSError):
            return events

        while readable:
            try:
                data = os.read(fd, 32)
            except OSError as exc:
                logger.warning(f"Failed to read stdin: {exc}")
                break

            if not data:
                break

            text = data.decode("utf-8", errors="ignore")
            events.extend(self._translate_posix_input(text))
            readable, _, _ = select.select([fd], [], [], 0)

        return events

    def _translate_windows_input(self, char: str) -> list[Event]:
        """Convert Windows console input into Textforge events.

        Args:
            char: Character returned by the Windows console API.

        Returns:
            list[Event]: Events representing the interpreted key presses.
        """
        events: list[Event] = []

        if char in {"\x00", "\xe0"}:
            self._pending_windows_prefix = char
            return events

        if self._pending_windows_prefix:
            key = self._WINDOWS_SPECIAL_KEYS.get(char)
            if key:
                events.append(self._make_key_event(key))
            self._pending_windows_prefix = None
            return events

        events.append(self._make_key_event(self._normalize_char(char)))
        return events

    def _translate_posix_input(self, text: str) -> list[Event]:
        """Convert POSIX escape sequences into Textforge events.

        Args:
            text: Raw text read from stdin.

        Returns:
            list[Event]: Events created from the parsed escape sequences.
        """
        events: list[Event] = []
        index = 0

        while index < len(text):
            char = text[index]
            if char == "\x1b":
                if index + 1 < len(text) and text[index + 1] == "[":
                    if index + 2 < len(text):
                        key_code = text[index + 2]
                        mapped = self._POSIX_ESCAPE_KEYS.get(key_code)
                        if mapped:
                            events.append(self._make_key_event(mapped))
                            index += 3
                            continue
                events.append(self._make_key_event("escape"))
                index += 1
                continue

            events.append(self._make_key_event(self._normalize_char(char)))
            index += 1

        return events

    def _make_key_event(self, key: str) -> Event:
        """Create a key-down event for the provided key identifier.

        Args:
            key: Semantic key identifier.

        Returns:
            Event: Key-down event carrying :class:`KeyEvent` data.
        """
        key_event = KeyEvent(key=key, modifiers=set(), repeat=False, location="standard")
        return Event(type=EventType.KEY_DOWN, data=key_event)

    def _normalize_char(self, char: str) -> str:
        """Normalize raw characters into semantic key identifiers.

        Args:
            char: Raw character read from input.

        Returns:
            str: Semantic identifier for the key.
        """
        if char in {"\r", "\n"}:
            return "enter"
        if char == "\t":
            return "tab"
        if char == "\x7f" or char == "\b":
            return "backspace"
        if char == " ":
            return "space"
        if char == "\x1b":
            return "escape"
        return char

    def _detect_resize_event(self) -> Event | None:
        """Detect terminal resize events based on terminal size changes.

        Returns:
            Event | None: Resize event when the terminal dimensions change.
        """
        columns, rows = self._read_terminal_size()
        if (columns, rows) != self._last_size:
            self._last_size = (columns, rows)
            return Event(
                type=EventType.WINDOW_RESIZE,
                data={"columns": columns, "rows": rows},
            )
        return None

    def _read_terminal_size(self) -> tuple[int, int]:
        """Read the current terminal size with fallbacks.

        Returns:
            tuple[int, int]: Terminal columns and rows.
        """
        size = shutil.get_terminal_size(fallback=(0, 0))
        return size.columns, size.lines

    def _stdin_is_tty(self) -> bool:
        """Return ``True`` when stdin is attached to a TTY device."""
        try:
            return sys.stdin.isatty()
        except Exception:
            return False

    def _enable_raw_mode(self) -> None:
        """Enable raw terminal mode for accurate key capture.

        Returns:
            None
        """
        try:
            import termios
            import tty
        except ImportError:
            logger.warning("termios not available; raw terminal mode disabled")
            return

        try:
            fd = sys.stdin.fileno()
            self._original_terminal_settings = termios.tcgetattr(fd)
            tty.setraw(fd)
            self._raw_mode_enabled = True
            logger.debug("Enabled raw terminal input mode")
        except Exception as exc:
            logger.warning(f"Unable to enable raw terminal mode: {exc}")
            self._original_terminal_settings = None

    def _restore_terminal(self) -> None:
        """Restore the terminal to the state captured during initialization.

        Returns:
            None
        """
        if self._original_terminal_settings is None:
            return

        try:
            import termios

            termios.tcsetattr(sys.stdin, termios.TCSADRAIN, self._original_terminal_settings)
            logger.debug("Restored terminal settings")
        except Exception as exc:
            logger.error(f"Could not restore terminal settings: {exc}")
        finally:
            self._original_terminal_settings = None
            self._raw_mode_enabled = False


__all__ = ["CLIEventHandler"]

