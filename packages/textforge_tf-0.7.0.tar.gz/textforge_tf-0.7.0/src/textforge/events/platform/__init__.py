"""Platform-specific event handling for Textforge."""

from __future__ import annotations

import platform
import threading
import time
from abc import ABC, abstractmethod
from collections import deque
from typing import TYPE_CHECKING

from ...utils.logging import get_logger

if TYPE_CHECKING:
    from collections.abc import Iterable

    from ..types import Event
    from .cli import CLIEventHandler
    from .linux import LinuxEventHandler
    from .macos import MacOSEventHandler
    from .windows import WindowsEventHandler

logger = get_logger(__name__)


class PlatformEventHandler(ABC):
    """Base class for platform-specific event handling."""

    def __init__(self) -> None:
        """Initialize platform event handler with shared queue state."""
        self.platform = platform.system().lower()
        self._queue: deque[Event] = deque()
        self._queue_lock = threading.RLock()
        self._lock = threading.RLock()
        self._stop_signal = threading.Event()
        self._event_thread: threading.Thread | None = None
        self._poll_interval = 0.05
        logger.debug(f"Initialized platform event handler for {self.platform}")

    def start_event_loop(self) -> None:
        """Start the platform-specific event loop in a background thread.

        Returns:
            None
        """
        with self._lock:
            if self._event_thread and self._event_thread.is_alive():
                logger.debug("Platform event loop already running")
                return

            self._stop_signal.clear()

            try:
                self._start_native_loop()
            except Exception as exc:
                self._stop_signal.set()
                logger.error(f"Failed to start native event loop: {exc}")
                raise

            thread_name = f"{self.platform}-event-loop"
            self._event_thread = threading.Thread(
                target=self._run_loop,
                name=thread_name,
                daemon=True,
            )
            self._event_thread.start()
            logger.debug("Started platform event loop thread %s", thread_name)

    def stop_event_loop(self) -> None:
        """Stop the platform event loop and wait for shutdown.

        Returns:
            None
        """
        with self._lock:
            if not self._event_thread:
                return

            self._stop_signal.set()
            thread = self._event_thread
            self._event_thread = None

        if thread:
            thread.join(timeout=1.0)

        try:
            self._stop_native_loop()
        finally:
            logger.debug("Platform event loop stopped")

    def poll_events(self) -> list[Event]:
        """Poll for new events queued by the platform loop.

        Returns:
            list[Event]: Events retrieved from the queue.
        """
        with self._queue_lock:
            events = list(self._queue)
            self._queue.clear()
        if events:
            logger.log(5, "Polled %d platform events", len(events))
        return events

    def send_event(self, event: Event) -> None:
        """Queue an event for local processing and forward to the platform.

        Args:
            event: Event instance to send to the platform.

        Returns:
            None
        """
        self.queue_events([event])
        try:
            self._send_native_event(event)
        except Exception as exc:
            logger.warning(f"Unable to forward platform event: {exc}")

    def queue_events(self, events: Iterable[Event]) -> None:
        """Queue pre-built events for retrieval by :meth:`poll_events`.

        Args:
            events: Iterable of events to append to the local queue.

        Returns:
            None
        """
        with self._queue_lock:
            for event in events:
                self._queue.append(event)

    def is_running(self) -> bool:
        """Return whether the background loop thread is active.

        Returns:
            bool: ``True`` when the loop thread is alive.
        """
        with self._lock:
            return bool(self._event_thread and self._event_thread.is_alive())

    @abstractmethod
    def is_available(self) -> bool:
        """Return ``True`` when the handler can operate on the current system."""

    @abstractmethod
    def _poll_native_events(self, timeout: float) -> list[Event]:
        """Poll for native platform events.

        Args:
            timeout: Maximum time in seconds to wait for events.

        Returns:
            list[Event]: Events retrieved from the native platform.
        """
    @abstractmethod
    def _start_native_loop(self) -> None:
        """Perform platform-specific loop initialization.

        Returns:
            None
        """
    @abstractmethod
    def _stop_native_loop(self) -> None:
        """Perform platform-specific loop teardown.

        Returns:
            None
        """
    @abstractmethod
    def _send_native_event(self, event: Event) -> None:
        """Forward an event to the underlying platform implementation.

        Args:
            event: Event instance forwarded to the platform.

        Returns:
            None
        """

    def _run_loop(self) -> None:
        """Internal worker loop that polls native events.

        Returns:
            None
        """
        logger.debug("Platform event loop thread started")
        try:
            while not self._stop_signal.is_set():
                try:
                    events = self._poll_native_events(self._poll_interval)
                except Exception as exc:
                    logger.error(f"Platform event polling failed: {exc}")
                    time.sleep(self._poll_interval)
                    continue

                if events:
                    self.queue_events(events)

                time.sleep(self._poll_interval)
        finally:
            logger.debug("Platform event loop thread exiting")


def create_platform_handler() -> PlatformEventHandler:
    """Create the appropriate platform event handler.

    Returns:
        PlatformEventHandler: Handler tailored to the current system.
    """
    system = platform.system().lower()

    try:
        if system == "windows":
            from .windows import WindowsEventHandler

            handler = WindowsEventHandler()
            logger.debug("Created Windows event handler")
            return handler
        if system == "darwin":
            from .macos import MacOSEventHandler

            handler = MacOSEventHandler()
            logger.debug("Created macOS event handler")
            return handler
        if system == "linux":
            from .linux import LinuxEventHandler

            handler = LinuxEventHandler()
            logger.debug("Created Linux event handler")
            return handler

        from .cli import CLIEventHandler

        handler = CLIEventHandler()
        logger.debug(f"Created CLI event handler for unknown platform {system}")
        return handler
    except ImportError as exc:
        logger.warning(f"Platform-specific handler not available: {exc}, falling back to CLI")
        from .cli import CLIEventHandler

        return CLIEventHandler()


def get_platform_name() -> str:
    """Return the lowercase platform identifier for the current system.

    Returns:
        str: Platform name reported by :func:`platform.system` in lowercase.
    """

    return platform.system().lower()


def is_windows() -> bool:
    """Return ``True`` when running on Windows.

    Returns:
        bool: ``True`` for Windows platforms.
    """

    return get_platform_name() == "windows"


def is_macos() -> bool:
    """Return ``True`` when running on macOS.

    Returns:
        bool: ``True`` for macOS platforms.
    """

    return get_platform_name() == "darwin"


def is_linux() -> bool:
    """Return ``True`` when running on Linux.

    Returns:
        bool: ``True`` for Linux platforms.
    """

    return get_platform_name() == "linux"


def supports_gui_events() -> bool:
    """Return ``True`` when GUI event handlers are available.

    Returns:
        bool: ``True`` when GUI event handling is supported.
    """

    return is_windows() or is_macos() or is_linux()


__all__ = [
    "PlatformEventHandler",
    "create_platform_handler",
    "get_platform_name",
    "is_windows",
    "is_macos",
    "is_linux",
    "supports_gui_events",
    "CLIEventHandler",
    "WindowsEventHandler",
    "MacOSEventHandler",
    "LinuxEventHandler",
]


def __getattr__(name: str) -> object:
    """Dynamically load platform handlers on demand.

    Args:
        name: Handler attribute requested from the module.

    Returns:
        Any: Platform handler class matching ``name``.

    Raises:
        AttributeError: If the requested handler is not available.
    """
    if name == "CLIEventHandler":
        from .cli import CLIEventHandler as _CLIEventHandler

        return _CLIEventHandler
    if name == "WindowsEventHandler":
        from .windows import WindowsEventHandler as _WindowsEventHandler

        return _WindowsEventHandler
    if name == "MacOSEventHandler":
        from .macos import MacOSEventHandler as _MacOSEventHandler

        return _MacOSEventHandler
    if name == "LinuxEventHandler":
        from .linux import LinuxEventHandler as _LinuxEventHandler

        return _LinuxEventHandler
    raise AttributeError(name)

