"""Windows-specific event handling for Textforge."""

from __future__ import annotations

import os
from typing import TYPE_CHECKING

from ...utils.logging import get_logger
from .cli import CLIEventHandler

if TYPE_CHECKING:
    from ..types import Event

logger = get_logger(__name__)


class WindowsEventHandler(CLIEventHandler):
    """Windows-specific event handler leveraging console APIs."""

    def __init__(self) -> None:
        """Initialize the Windows event handler."""
        super().__init__()
        logger.debug("Initialized Windows event handler")

    def is_available(self) -> bool:
        """Return ``True`` when running on Windows."""
        return os.name == "nt"

    def _send_native_event(self, event: Event) -> None:
        """Log synthetic event forwarding; console injection is unsupported."""
        logger.log(5, "Windows handler received synthetic event %s", event.type.value)


__all__ = ["WindowsEventHandler"]

