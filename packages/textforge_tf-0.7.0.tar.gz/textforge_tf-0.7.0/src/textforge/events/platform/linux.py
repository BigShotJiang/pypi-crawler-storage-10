"""Linux-specific event handling for Textforge."""

from __future__ import annotations

import sys
from typing import TYPE_CHECKING

from ...utils.logging import get_logger
from .cli import CLIEventHandler

if TYPE_CHECKING:
    from ..types import Event

logger = get_logger(__name__)


class LinuxEventHandler(CLIEventHandler):
    """Linux-specific event handler using POSIX terminal facilities."""

    def __init__(self) -> None:
        """Initialize the Linux event handler."""
        super().__init__()
        logger.debug("Initialized Linux event handler")

    def is_available(self) -> bool:
        """Return ``True`` when running on Linux."""
        return sys.platform.startswith("linux")

    def _send_native_event(self, event: Event) -> None:
        """Log synthetic event forwarding; OS level injection is not supported."""
        logger.log(5, "Linux handler received synthetic event %s", event.type.value)


__all__ = ["LinuxEventHandler"]

