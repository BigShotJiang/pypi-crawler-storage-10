"""Asynchronous event processing for Textforge."""

from __future__ import annotations

import threading
import time
from concurrent.futures import Future, ThreadPoolExecutor
from tracemalloc import Traceback
from typing import TYPE_CHECKING, Any

from ..utils.logging import get_logger
from .types import Event, EventError

if TYPE_CHECKING:
    from collections.abc import Callable

logger = get_logger(__name__)


class AsyncEventProcessor:
    """Thread-pool backed processor for asynchronous event dispatch."""

    def __init__(self, max_workers: int | None = None) -> None:
        """Create the processor.

        Args:
            max_workers: Optional worker limit for the internal pool. When not
                provided a heuristic based on the active thread count is used.
        """

        worker_count = max_workers or min(32, threading.active_count() * 2)
        self._executor = ThreadPoolExecutor(
            max_workers=worker_count,
            thread_name_prefix="event-processor",
        )
        self._running = True
        self._lock = threading.RLock()
        self._worker_count = worker_count

        logger.debug("Initialised AsyncEventProcessor with %d workers", worker_count)

    def process_event_async(self, event: Event, handler: Callable[[Event], Any]) -> None:
        """Dispatch ``event`` to ``handler`` in the background.

        Args:
            event: Event to process asynchronously.
            handler: Callable invoked by a worker thread.
        """

        if not self._running:
            logger.warning("Async processor is shutting down, ignoring event")
            return

        try:
            future = self._executor.submit(self._execute_handler, event, handler)
            future.add_done_callback(lambda fut: self._handle_completion(fut, event))
        except Exception as exc:
            logger.warning("Failed to submit async event %s: %s", event.type.value, exc)

    def process_event_sync(self, event: Event, handler: Callable[[Event], Any]) -> object:
        """Run ``handler`` synchronously for testing scenarios.

        Args:
            event: Event to process.
            handler: Callable executed inline.

        Returns:
            Any: Result returned by ``handler``.
        """

        return self._execute_handler(event, handler)

    def shutdown(self, wait: bool = True) -> None:
        """Stop accepting new events and optionally wait for completion.

        Args:
            wait: When ``True`` blocks until all queued work completes.
        """

        with self._lock:
            if not self._running:
                return
            self._running = False
            logger.debug("Shutting down AsyncEventProcessor")
            self._executor.shutdown(wait=wait)

    def get_active_count(self) -> int:
        """Return the number of currently active worker threads.

        Returns:
            int: Number of active threads in the interpreter.
        """

        return threading.active_count()

    def get_queue_size(self) -> int:
        """Return the current approximate queue length.

        Returns:
            int: Number of pending work items.
        """

        queue = getattr(self._executor, "_work_queue", None)
        if queue is None:
            return 0
        try:
            return queue.qsize()
        except Exception as e:
            logger.debug(f"Error: {e}, Traceback: {Traceback}")
            return 0

    def _execute_handler(self, event: Event, handler: Callable[[Event], Any]) -> object:
        """Execute ``handler`` and capture execution time for diagnostics.

        Args:
            event: Event passed to the handler.
            handler: Callable being executed.

        Returns:
            Any: Result produced by the handler.

        Raises:
            EventError: When the handler raises an exception.
        """

        try:
            logger.log(5, "Executing handler for %s", event.type.value)
            start_time = time.perf_counter()
            result = handler(event)
            duration = time.perf_counter() - start_time
            logger.log(5, "Handler completed in %.3fs", duration)
            return result
        except Exception as exc:
            logger.error("Event handler failure for %s: %s", event.type.value, exc)
            raise EventError(f"Event handler execution failed: {exc}") from exc

    def _handle_completion(self, future: Future[Any], event: Event) -> None:
        """Log completion state for asynchronous work.

        Args:
            future: Future returned by :meth:`process_event_async`.
            event: Event processed by the future.

        Returns:
            None
        """

        try:
            exception = future.exception()
            if exception:
                logger.warning("Async processing failed for %s: %s", event.type.value, exception)
            else:
                logger.log(5, "Async processing completed for %s", event.type.value)
        except Exception as exc:
            logger.warning("Completion callback failed for %s: %s", event.type.value, exc)


class EventQueue:
    """Bounded, thread-safe queue used by event processors."""

    def __init__(self, max_size: int = 1000) -> None:
        """Create a queue with ``max_size`` capacity.

        Args:
            max_size: Maximum number of pending events.
        """

        self._max_size = max_size
        self._queue: list[Event] = []
        self._lock = threading.RLock()
        self._not_empty = threading.Condition(self._lock)
        self._not_full = threading.Condition(self._lock)
        self._shutdown = False

    def put(self, event: Event, block: bool = True, timeout: float | None = None) -> bool:
        """Insert ``event`` into the queue.

        Args:
            event: Event to enqueue.
            block: When ``True`` waits for space to become available.
            timeout: Optional timeout in seconds when blocking.

        Returns:
            bool: ``True`` when the event was enqueued.

        Raises:
            EventError: When the queue has been shut down.
        """

        with self._not_full:
            if self._shutdown:
                raise EventError("Queue is shutdown")

            if not block:
                if len(self._queue) >= self._max_size:
                    return False
            elif timeout is None:
                while len(self._queue) >= self._max_size and not self._shutdown:
                    self._not_full.wait()
            else:
                end_time = time.time() + timeout
                while len(self._queue) >= self._max_size and not self._shutdown:
                    remaining = end_time - time.time()
                    if remaining <= 0:
                        return False
                    self._not_full.wait(remaining)

            if self._shutdown:
                raise EventError("Queue is shutdown")

            self._queue.append(event)
            self._not_empty.notify()
            return True

    def get(self, block: bool = True, timeout: float | None = None) -> Event | None:
        """Retrieve the next event from the queue.

        Args:
            block: When ``True`` waits for an event to become available.
            timeout: Optional timeout in seconds when blocking.

        Returns:
            Event | None: The dequeued event or ``None`` when the timeout
            expires or the queue is empty in non-blocking mode.
        """

        with self._not_empty:
            if not block and not self._queue:
                return None

            if block and timeout is None:
                while not self._queue and not self._shutdown:
                    self._not_empty.wait()
            elif block:
                end_time = time.time() + timeout if timeout is not None else None
                while not self._queue and not self._shutdown:
                    assert end_time is not None
                    remaining = end_time - time.time()
                    if remaining <= 0:
                        return None
                    self._not_empty.wait(remaining)

            if self._shutdown and not self._queue:
                return None

            event = self._queue.pop(0)
            self._not_full.notify()
            return event

    def shutdown(self) -> None:
        """Wake waiting threads and prevent further enqueue operations.

        Returns:
            None
        """

        with self._lock:
            self._shutdown = True
            self._not_empty.notify_all()
            self._not_full.notify_all()

    def size(self) -> int:
        """Return the current number of queued events.

        Returns:
            int: Number of items in the queue.
        """

        with self._lock:
            return len(self._queue)

    def empty(self) -> bool:
        """Return ``True`` when the queue contains no events.

        Returns:
            bool: ``True`` when empty.
        """

        with self._lock:
            return not self._queue


class BatchedEventProcessor:
    """Batching helper that coalesces events for efficient handling."""

    def __init__(self, batch_size: int = 10, flush_interval: float = 0.1) -> None:
        """Create a batching processor.

        Args:
            batch_size: Maximum number of events per batch.
            flush_interval: Maximum interval in seconds before a forced flush.
        """

        self._batch_size = batch_size
        self._flush_interval = flush_interval
        self._batch: list[tuple[Event, Callable[[Event], Any]]] = []
        self._last_flush = time.time()
        self._lock = threading.RLock()

    def add_event(self, event: Event, handler: Callable[[Event], Any]) -> None:
        """Add an event to the current batch.

        Args:
            event: Event to add to the batch.
            handler: Handler responsible for processing the event.

        Returns:
            None
        """

        with self._lock:
            self._batch.append((event, handler))
            if self._should_flush():
                self._flush_batch()

    def flush(self) -> None:
        """Flush the batch immediately.

        Returns:
            None
        """

        with self._lock:
            self._flush_batch()

    def _should_flush(self) -> bool:
        """Return whether the current batch should be flushed.

        Returns:
            bool: ``True`` when size or time thresholds have been met.
        """

        size_exceeded = len(self._batch) >= self._batch_size
        time_exceeded = (time.time() - self._last_flush) >= self._flush_interval
        return size_exceeded or time_exceeded

    def _flush_batch(self) -> None:
        """Process the current batch and reset state."""

        if not self._batch:
            return

        batch = list(self._batch)
        self._batch.clear()
        self._last_flush = time.time()

        for event, handler in batch:
            try:
                handler(event)
            except Exception as exc:
                logger.warning("Batched handler failure for %s: %s", event.type.value, exc)


__all__ = [
    "AsyncEventProcessor",
    "BatchedEventProcessor",
    "EventQueue",
]
