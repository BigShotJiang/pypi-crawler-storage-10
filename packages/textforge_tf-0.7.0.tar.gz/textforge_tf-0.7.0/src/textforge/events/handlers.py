"""Event handler management for Textforge."""

from __future__ import annotations

import threading
from abc import ABC, abstractmethod
from dataclasses import dataclass
from typing import TYPE_CHECKING
from uuid import uuid4

from ..utils.logging import get_logger

if TYPE_CHECKING:
    from collections.abc import Callable

    from .types import Event

logger = get_logger(__name__)


class EventHandler(ABC):
    """Abstract base class for reusable event handlers."""

    @abstractmethod
    def can_handle(self, event: Event) -> bool:
        """Return whether this handler can process the provided event.

        Args:
            event: The event being evaluated.

        Returns:
            bool: ``True`` when the handler should process the event.
        """

    @abstractmethod
    def handle_event(self, event: Event) -> bool:
        """Handle the provided event.

        Args:
            event: The event to process.

        Returns:
            bool: ``True`` when propagation should be stopped.
        """


@dataclass(slots=True)
class EventHandlerWrapper:
    """Internal structure tracking handler metadata."""

    handler: Callable[[Event], bool] | EventHandler
    priority: int
    name: str
    identifier: str

    def should_handle(self, event: Event) -> bool:
        """Return whether the wrapped handler should run for the event.

        Args:
            event: The event under consideration.

        Returns:
            bool: ``True`` when the handler should execute.
        """

        if isinstance(self.handler, EventHandler):
            return self.handler.can_handle(event)
        return True

    def execute(self, event: Event) -> bool:
        """Execute the wrapped handler against the event.

        Args:
            event: The event to handle.

        Returns:
            bool: ``True`` when propagation should be stopped.
        """

        if isinstance(self.handler, EventHandler):
            return self.handler.handle_event(event)
        return self.handler(event)


class EventHandlerManager:
    """Registry that manages handler lifecycles and execution order."""

    def __init__(self) -> None:
        """Initialise the manager with thread-safe storage."""

        self._handlers: dict[str, list[EventHandlerWrapper]] = {}
        self._lock = threading.RLock()

    def register_handler(
        self,
        event_type: str,
        handler: Callable[[Event], bool] | EventHandler,
        priority: int = 0,
        name: str | None = None,
    ) -> str:
        """Register a handler for the supplied event type.

        Args:
            event_type: Canonical event type key.
            handler: Callable or :class:`EventHandler` instance to register.
            priority: Higher numbers execute before lower numbers.
            name: Optional human readable name for diagnostics.

        Returns:
            str: Stable identifier for the registered handler.
        """

        with self._lock:
            wrapper = EventHandlerWrapper(
                handler=handler,
                priority=priority,
                name=name or f"handler-{uuid4().hex}",
                identifier=f"{event_type}:{uuid4().hex}",
            )

            bucket = self._handlers.setdefault(event_type, [])
            bucket.append(wrapper)
            bucket.sort(key=lambda item: item.priority, reverse=True)

            logger.debug("Registered handler %s for %s", wrapper.identifier, event_type)
            return wrapper.identifier

    def unregister_handler(self, handler_id: str) -> bool:
        """Remove a handler by identifier.

        Args:
            handler_id: Identifier returned from :meth:`register_handler`.

        Returns:
            bool: ``True`` when the handler was removed.
        """

        event_type, _, _ = handler_id.partition(":")
        with self._lock:
            handlers = self._handlers.get(event_type)
            if not handlers:
                logger.warning("Handler %s not found for removal", handler_id)
                return False

            original_length = len(handlers)
            self._handlers[event_type] = [item for item in handlers if item.identifier != handler_id]
            removed = len(self._handlers[event_type]) < original_length

            if removed:
                logger.debug("Removed handler %s", handler_id)
            else:
                logger.warning("Handler %s not found for removal", handler_id)
            return removed

    def execute_handlers(self, event: Event) -> bool:
        """Execute registered handlers in priority order.

        Args:
            event: The event to dispatch to registered handlers.

        Returns:
            bool: ``True`` if any handler requested propagation to stop.
        """

        event_type = event.type.value
        with self._lock:
            handlers = list(self._handlers.get(event_type, ()))

        stopped = False
        for wrapper in handlers:
            if event.propagation_stopped:
                logger.log(5, "Propagation already stopped for %s", event_type)
                break

            if not wrapper.should_handle(event):
                continue

            try:
                logger.log(5, "Executing handler %s for %s", wrapper.name, event_type)
                if wrapper.execute(event):
                    event.stop_propagation()
                    stopped = True
                    logger.log(5, "Handler %s stopped propagation", wrapper.name)
            except Exception as exc:
                logger.warning("Handler %s failed for %s: %s", wrapper.name, event_type, exc)

        return stopped

    def get_handler_count(self, event_type: str | None = None) -> int:
        """Return the number of registered handlers.

        Args:
            event_type: Optional event type key to scope the query.

        Returns:
            int: Count of registered handlers for the requested scope.
        """

        with self._lock:
            if event_type is not None:
                return len(self._handlers.get(event_type, ()))
            return sum(len(items) for items in self._handlers.values())

    def clear_handlers(self, event_type: str | None = None) -> int:
        """Remove handlers either globally or for a single event type.

        Args:
            event_type: Optional event type key to restrict the removal.

        Returns:
            int: Number of handlers removed.
        """

        with self._lock:
            if event_type is not None:
                removed = len(self._handlers.get(event_type, ()))
                self._handlers.pop(event_type, None)
                logger.debug("Cleared %d handlers for %s", removed, event_type)
                return removed

            removed = sum(len(items) for items in self._handlers.values())
            self._handlers.clear()
            logger.debug("Cleared %d handlers across all event types", removed)
            return removed


__all__ = [
    "EventHandler",
    "EventHandlerManager",
    "EventHandlerWrapper",
]
