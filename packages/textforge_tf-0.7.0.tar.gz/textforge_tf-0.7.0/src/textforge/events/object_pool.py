"""Object pooling system for efficient event reuse and memory management."""

from __future__ import annotations

import threading
from dataclasses import dataclass
from typing import TYPE_CHECKING, Generic, TypeVar

if TYPE_CHECKING:
    from collections.abc import Callable
    from types import TracebackType
    from weakref import ReferenceType

    from .types import ComponentEvent, Event, KeyEvent, MouseEvent

from ..utils.logging import get_logger

logger = get_logger(__name__)

T = TypeVar("T")


@dataclass(slots=True)
class EventPoolConfig:
    """Configuration for event object pooling behavior."""

    max_pool_size: int = 1000  # Maximum events to keep in pool
    max_idle_time: float = 300.0  # Seconds before idle objects are cleaned up
    cleanup_interval: float = 60.0  # Seconds between cleanup runs
    enable_weak_refs: bool = False  # Disabled for Event objects (dataclasses with slots)


@dataclass(slots=True)
class EventPoolStats:
    """Statistics for event pool usage and performance."""

    created: int = 0  # Total events created
    reused: int = 0  # Total events reused from pool
    returned: int = 0  # Total events returned to pool
    evicted: int = 0  # Total events evicted due to pool limits
    garbage_collected: int = 0  # Events cleaned up by GC
    pool_size: int = 0  # Current pool size
    hit_rate: float = 0.0  # Reuse rate (reused / (created + reused))


class EventPool(Generic[T]):
    """Generic object pool for efficient event reuse."""

    def __init__(
        self,
        factory: Callable[[], T],
        config: EventPoolConfig | None = None,
        reset_func: Callable[[T], None] | None = lambda obj: None,
    ) -> None:
        self.factory = factory
        self.config = config or EventPoolConfig()
        self.reset_func = reset_func

        # Pool storage
        self._pool: list[T] = []
        self._weak_refs: set[ReferenceType[T]] = set()

        # Statistics
        self.stats = EventPoolStats()

        # Cleanup tracking
        self._last_cleanup = 0.0
        self._lock = threading.RLock()

    def acquire(self) -> T:
        """Get an event from the pool, creating a new one if necessary."""
        import time

        current_time = time.time()

        with self._lock:
            # Try to get from pool first
            obj = self._get_from_pool()

            if obj is not None:
                self.stats.reused += 1
                self.reset_func(obj)
                return obj

            # Create new object
            obj = self.factory()
            self.stats.created += 1

            # Update hit rate
            total_requests = self.stats.created + self.stats.reused
            if total_requests > 0:
                self.stats.hit_rate = self.stats.reused / total_requests

            return obj

    def release(self, obj: T) -> None:
        """Return an event to the pool for reuse."""
        if self._should_pool_object(obj):
            with self._lock:
                self._add_to_pool(obj)
                self.stats.returned += 1
        else:
            with self._lock:
                self.stats.evicted += 1

    def clear(self) -> None:
        """Clear all events from the pool."""
        with self._lock:
            self._pool.clear()
            self._weak_refs.clear()
            self.stats.pool_size = 0

    def cleanup(self) -> None:
        """Clean up expired events and update statistics."""
        import time

        current_time = time.time()

        with self._lock:
            # Clean up weak references (disabled for Event objects)
            if self.config.enable_weak_refs:
                dead_refs = [ref for ref in self._weak_refs if ref() is None]
                self._weak_refs.difference_update(dead_refs)
                self.stats.garbage_collected += len(dead_refs)

            # Periodic cleanup of pool
            if current_time - self._last_cleanup > self.config.cleanup_interval:
                # Remove excess objects
                while len(self._pool) > self.config.max_pool_size:
                    self._pool.pop(0)
                    self.stats.evicted += 1

                self._last_cleanup = current_time

            self.stats.pool_size = len(self._pool)

    def get_stats(self) -> EventPoolStats:
        """Get pool statistics."""
        with self._lock:
            return self.stats

    def _get_from_pool(self) -> T | None:
        """Get an event from the pool."""
        if self._pool:
            return self._pool.pop(0)
        return None

    def _add_to_pool(self, obj: T) -> None:
        """Add an event to the pool."""
        if len(self._pool) < self.config.max_pool_size:
            self._pool.append(obj)

            if self.config.enable_weak_refs:
                # Add weak reference for tracking
                self._weak_refs.add(__import__('weakref').ref(obj))

    def _should_pool_object(self, obj: T) -> bool:
        """Determine if an event should be pooled."""
        # Basic checks - can be extended for specific event types
        return True


class EventObjectPool:
    """Specialized pool for Event objects with type-based sub-pools."""

    def __init__(self, config: EventPoolConfig | None = None):
        self.config = config or EventPoolConfig()
        self._pools: dict[str, EventPool[Event]] = {}
        self._stats = EventPoolStats()
        self._lock = threading.RLock()

    def acquire_event(self, event_type: str = "generic") -> Event:
        """Get an Event from the pool."""
        pool = self._get_pool(event_type, self._create_event)
        event = pool.acquire()
        self._update_global_stats()
        return event

    def acquire_key_event(self) -> KeyEvent:
        """Get a KeyEvent from the pool."""
        pool = self._get_pool("key_event", self._create_key_event)
        event = pool.acquire()
        self._update_global_stats()
        return event

    def acquire_mouse_event(self) -> MouseEvent:
        """Get a MouseEvent from the pool."""
        pool = self._get_pool("mouse_event", self._create_mouse_event)
        event = pool.acquire()
        self._update_global_stats()
        return event

    def acquire_component_event(self) -> ComponentEvent:
        """Get a ComponentEvent from the pool."""
        pool = self._get_pool("component_event", self._create_component_event)
        event = pool.acquire()
        self._update_global_stats()
        return event

    def release_event(self, event: Event, event_type: str = "generic") -> None:
        """Return an Event to the pool."""
        pool = self._get_pool(event_type, self._create_event)
        pool.release(event)
        self._update_global_stats()

    def release_key_event(self, event: KeyEvent) -> None:
        """Return a KeyEvent to the pool."""
        pool = self._get_pool("key_event", self._create_key_event)
        pool.release(event)
        self._update_global_stats()

    def release_mouse_event(self, event: MouseEvent) -> None:
        """Return a MouseEvent to the pool."""
        pool = self._get_pool("mouse_event", self._create_mouse_event)
        pool.release(event)
        self._update_global_stats()

    def release_component_event(self, event: ComponentEvent) -> None:
        """Return a ComponentEvent to the pool."""
        pool = self._get_pool("component_event", self._create_component_event)
        pool.release(event)
        self._update_global_stats()

    def cleanup(self) -> None:
        """Clean up all pools."""
        with self._lock:
            for pool in self._pools.values():
                pool.cleanup()
            self._update_global_stats()

    def get_stats(self, event_type: str | None = None) -> EventPoolStats:
        """Get statistics for a specific event type or global stats."""
        with self._lock:
            if event_type:
                pool = self._pools.get(event_type)
                return pool.get_stats() if pool else EventPoolStats()
            return self._stats

    def _get_pool(self, event_type: str, factory: Callable[[], Event]) -> EventPool[Event]:
        """Get or create a pool for the given event type."""
        with self._lock:
            if event_type not in self._pools:
                self._pools[event_type] = EventPool(factory, self.config, self._reset_event)
            return self._pools[event_type]

    def _create_event(self) -> Event:
        """Factory function for creating Event objects."""
        from .types import Event, EventType

        return Event(type=EventType.TICK)  # Default type, will be overridden

    def _create_key_event(self) -> KeyEvent:
        """Factory function for creating KeyEvent objects."""
        from .types import KeyEvent

        return KeyEvent(key="")

    def _create_mouse_event(self) -> MouseEvent:
        """Factory function for creating MouseEvent objects."""
        from .types import MouseEvent

        return MouseEvent(x=0, y=0)

    def _create_component_event(self) -> ComponentEvent:
        """Factory function for creating ComponentEvent objects."""
        from .types import ComponentEvent

        return ComponentEvent(component_id="", component_type="")

    def _reset_event(self, event: Event) -> None:
        """Reset an event for reuse."""
        # Import here to avoid circular imports
        from .types import EventType

        # Reset common fields
        if hasattr(event, 'data'):
            event.data = None
        if hasattr(event, 'source'):
            event.source = None
        if hasattr(event, 'target'):
            event.target = None
        if hasattr(event, 'propagation_stopped'):
            event.propagation_stopped = False

        # Reset type to default
        if hasattr(event, 'type'):
            event.type = EventType.TICK

        # Type-specific resets
        if hasattr(event, 'key'):
            event.key = ""
            event.modifiers.clear()
            event.repeat = False
            event.location = "standard"
        elif hasattr(event, 'x') and hasattr(event, 'y'):
            event.x = 0
            event.y = 0
            event.button = None
            event.modifiers.clear()
            event.delta_x = 0
            event.delta_y = 0
        elif hasattr(event, 'component_id'):
            event.component_id = ""
            event.component_type = ""
            event.parent_id = None
            event.properties.clear()

    def _update_global_stats(self) -> None:
        """Update global statistics across all pools."""
        with self._lock:
            total_created = 0
            total_reused = 0
            total_returned = 0
            total_evicted = 0
            total_gc = 0
            total_pool_size = 0

            for pool in self._pools.values():
                stats = pool.get_stats()
                total_created += stats.created
                total_reused += stats.reused
                total_returned += stats.returned
                total_evicted += stats.evicted
                total_gc += stats.garbage_collected
                total_pool_size += stats.pool_size

            self._stats.created = total_created
            self._stats.reused = total_reused
            self._stats.returned = total_returned
            self._stats.evicted = total_evicted
            self._stats.garbage_collected = total_gc
            self._stats.pool_size = total_pool_size

            total_requests = total_created + total_reused
            self._stats.hit_rate = total_reused / total_requests if total_requests > 0 else 0.0


# Global event object pool instance
_event_object_pool = EventObjectPool()


def get_event_object_pool() -> EventObjectPool:
    """Get the global event object pool instance."""
    return _event_object_pool


class PooledEvent:
    """Context manager for pooled Event usage."""

    def __init__(self, event_type: str = "generic"):
        self.event_type = event_type
        self.event: Event | None = None

    def __enter__(self) -> Event:
        self.event = get_event_object_pool().acquire_event(self.event_type)
        return self.event

    def __exit__(self, exc_type: type | None, exc_val: object | None, exc_tb: TracebackType | None) -> None:
        if self.event is not None:
            get_event_object_pool().release_event(self.event, self.event_type)


class PooledKeyEvent:
    """Context manager for pooled KeyEvent usage."""

    def __init__(self):
        self.event: KeyEvent | None = None

    def __enter__(self) -> KeyEvent:
        self.event = get_event_object_pool().acquire_key_event()
        return self.event

    def __exit__(self, exc_type: type | None, exc_val: object | None, exc_tb: TracebackType | None) -> None:
        if self.event is not None:
            get_event_object_pool().release_key_event(self.event)


class PooledMouseEvent:
    """Context manager for pooled MouseEvent usage."""

    def __init__(self):
        self.event: MouseEvent | None = None

    def __enter__(self) -> MouseEvent:
        self.event = get_event_object_pool().acquire_mouse_event()
        return self.event

    def __exit__(self, exc_type: type | None, exc_val: object | None, exc_tb: TracebackType | None) -> None:
        if self.event is not None:
            get_event_object_pool().release_mouse_event(self.event)


class PooledComponentEvent:
    """Context manager for pooled ComponentEvent usage."""

    def __init__(self):
        self.event: ComponentEvent | None = None

    def __enter__(self) -> ComponentEvent:
        self.event = get_event_object_pool().acquire_component_event()
        return self.event

    def __exit__(self, exc_type: type | None, exc_val: object | None, exc_tb: TracebackType | None) -> None:
        if self.event is not None:
            get_event_object_pool().release_component_event(self.event)


def pooled_event(event_type: str = "generic"):
    """Context manager for getting a pooled Event."""
    return PooledEvent(event_type)


def pooled_key_event():
    """Context manager for getting a pooled KeyEvent."""
    return PooledKeyEvent()


def pooled_mouse_event():
    """Context manager for getting a pooled MouseEvent."""
    return PooledMouseEvent()


def pooled_component_event():
    """Context manager for getting a pooled ComponentEvent."""
    return PooledComponentEvent()
