"""Event propagation logic for Textforge."""

from __future__ import annotations

import threading
from typing import TYPE_CHECKING, Any

from ..utils.logging import get_logger
from .types import Event, EventPropagationError

if TYPE_CHECKING:
    from collections.abc import Callable, Iterable

logger = get_logger(__name__)


class EventPropagationEngine:
    """Traverse a component tree and invoke phase-specific listeners."""

    def __init__(self) -> None:
        """Initialise the propagation engine."""

        self._lock = threading.RLock()

    def propagate(
        self,
        event: Event,
        vdom_root: Any | None = None,
        target_component: Any | None = None,
    ) -> Event:
        """Propagate ``event`` through capture, target, and bubbling phases.

        Args:
            event: The event to propagate.
            vdom_root: Root node of the virtual DOM tree, if available.
            target_component: The renderable component that originated the event.

        Returns:
            Event: The event instance after propagation completes.
        """

        with self._lock:
            try:
                path = self._build_path(vdom_root, target_component)
                self._run_phase("capture", event, path[:-1])
                self._run_phase("target", event, path[-1:])
                self._run_phase("bubble", event, reversed(path[:-1]))
            except Exception as exc:
                logger.error("Propagation failed for %s: %s", event.type.value, exc)
                raise EventPropagationError(f"Propagation failed: {exc}") from exc

        return event

    def _run_phase(
        self,
        phase: str,
        event: Event,
        nodes: Iterable[Any],
    ) -> None:
        """Execute listeners for ``phase`` across ``nodes``.

        Args:
            phase: Phase identifier (``"capture"``, ``"target"``, or ``"bubble"``).
            event: Event to deliver to listeners.
            nodes: Iterable of nodes participating in this phase.
        """

        for node in nodes:
            if event.propagation_stopped:
                logger.log(5, "Propagation halted during %s phase", phase)
                break

            for listener in self._resolve_listeners(node, event, phase):
                try:
                    listener(event)
                except Exception as exc:
                    logger.warning("Listener failure during %s phase: %s", phase, exc)

    def _build_path(self, vdom_root: Any | None, target_component: Any | None) -> list[Any]:
        """Return the node path from ``vdom_root`` to ``target_component``.

        Args:
            vdom_root: Root node of the virtual DOM tree.
            target_component: Component that originated the event.

        Returns:
            list[Any]: Ordered path from root to target. When the tree is
            unavailable the result contains the target component alone.
        """

        if vdom_root is None or target_component is None:
            return [target_component] if target_component is not None else []

        path: list[Any] = []

        def visit(node: object) -> bool:
            path.append(node)
            if self._node_matches(node, target_component):
                return True

            for child in getattr(node, "children", []) or []:
                if visit(child):
                    return True

            path.pop()
            return False

        if visit(vdom_root):
            return path

        logger.warning("Unable to locate target component in VDOM tree")
        return [target_component]

    def _node_matches(self, node: object, target_component: object) -> bool:
        """Return whether ``node`` corresponds to ``target_component``.

        Args:
            node: Current node in the traversal.
            target_component: Component being searched for.

        Returns:
            bool: ``True`` when the node matches the component.
        """

        component = getattr(node, "component", None)
        if component is target_component:
            return True

        node_component = getattr(node, "renderable", None)
        return node_component is target_component

    def _resolve_listeners(self, node: object, event: Event, phase: str) -> list[Callable[[Event], None]]:
        """Resolve listeners registered on ``node`` for ``phase`` and ``event``.

        Args:
            node: Node from which to gather listeners.
            event: Event being propagated.
            phase: Current propagation phase.

        Returns:
            list[Callable[[Event], None]]: Ordered listeners to invoke.
        """

        listeners: list[Callable[[Event], None]] = []
        listeners.extend(self._listeners_from_mapping(node, event, phase))

        component = getattr(node, "component", None) or getattr(node, "renderable", None)
        if component is not None:
            listeners.extend(self._listeners_from_component(component, event, phase))

        return listeners

    def _listeners_from_mapping(self, node: object, event: Event, phase: str) -> list[Callable[[Event], None]]:
        """Extract listeners from mapping structures on ``node``.

        Args:
            node: Node potentially carrying listener mappings.
            event: Event being propagated.
            phase: Propagation phase.

        Returns:
            list[Callable[[Event], None]]: Listener callables discovered on the node.
        """

        mapping: dict[tuple[str, str], list[Callable[[Event], None]]] | None = getattr(node, "event_listeners", None)
        if not isinstance(mapping, dict):
            return []

        specific_key = (event.type.value, phase)
        listeners: list[Callable[[Event], None]] = list(mapping.get(specific_key, ()))

        wildcard_key = ("*", phase)
        listeners.extend(mapping.get(wildcard_key, ()))
        return listeners

    def _listeners_from_component(
        self,
        component: object,
        event: Event,
        phase: str,
    ) -> list[Callable[[Event], None]]:
        """Extract listeners from component methods.

        Args:
            component: Component potentially defining event hooks.
            event: Event currently being propagated.
            phase: Propagation phase identifier.

        Returns:
            list[Callable[[Event], None]]: Component methods to invoke.
        """

        listeners: list[Callable[[Event], None]] = []

        hook_names = [
            f"on_{event.type.value}_{phase}",
            f"handle_{phase}_event",
            "handle_event",
        ]

        for name in hook_names:
            hook: Callable[[Event], None] | None = getattr(component, name, None)
            if callable(hook):
                listeners.append(hook)

        return listeners


__all__ = ["EventPropagationEngine"]
