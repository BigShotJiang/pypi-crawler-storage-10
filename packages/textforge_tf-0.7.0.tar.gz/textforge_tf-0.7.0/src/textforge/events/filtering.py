"""Event filtering and transformation for Textforge."""

from __future__ import annotations

import threading
import time
from abc import ABC, abstractmethod
from dataclasses import dataclass
from typing import TYPE_CHECKING
from uuid import uuid4

from ..utils.logging import get_logger

if TYPE_CHECKING:
    from collections.abc import Callable

    from .types import Event

logger = get_logger(__name__)


class EventFilter(ABC):
    """Abstract base class for transforming or dropping events."""

    @abstractmethod
    def filter_event(self, event: Event) -> Event | None:
        """Filter or transform an event.

        Args:
            event: The event to evaluate.

        Returns:
            Event | None: ``None`` when the event should be dropped, otherwise
            the (possibly modified) event instance.
        """


@dataclass(slots=True)
class EventFilterWrapper:
    """Wrapper storing filter metadata for priority ordering."""

    filter_obj: EventFilter
    priority: int
    identifier: str


class EventFilterManager:
    """Thread-safe registry for event filters organised by event type."""

    def __init__(self) -> None:
        """Initialise the manager with empty filter storage."""

        self._filters: dict[str, list[EventFilterWrapper]] = {}
        self._lock = threading.RLock()

    def add_filter(self, event_type: str, filter_obj: EventFilter, priority: int = 0) -> str:
        """Register a filter for the supplied event type.

        Args:
            event_type: Canonical event type key.
            filter_obj: Filter implementation to register.
            priority: Higher values execute before lower values.

        Returns:
            str: Stable identifier for the registered filter.
        """

        with self._lock:
            wrapper = EventFilterWrapper(
                filter_obj=filter_obj,
                priority=priority,
                identifier=f"{event_type}:{uuid4().hex}",
            )

            bucket = self._filters.setdefault(event_type, [])
            bucket.append(wrapper)
            bucket.sort(key=lambda item: item.priority, reverse=True)

            logger.debug("Registered filter %s for %s", wrapper.identifier, event_type)
            return wrapper.identifier

    def remove_filter(self, filter_id: str) -> bool:
        """Unregister a previously registered filter.

        Args:
            filter_id: Identifier returned from :meth:`add_filter`.

        Returns:
            bool: ``True`` when a filter was removed.
        """

        event_type, _, _ = filter_id.partition(":")
        with self._lock:
            filters = self._filters.get(event_type)
            if not filters:
                logger.warning("Filter %s not found for removal", filter_id)
                return False

            original_length = len(filters)
            self._filters[event_type] = [item for item in filters if item.identifier != filter_id]
            removed = len(self._filters[event_type]) < original_length

            if removed:
                logger.debug("Removed filter %s", filter_id)
            else:
                logger.warning("Filter %s not found for removal", filter_id)
            return removed

    def apply_filters(self, event: Event) -> Event | None:
        """Apply registered filters to the event in priority order.

        Args:
            event: The event to process.

        Returns:
            Event | None: ``None`` if any filter drops the event, otherwise the
            potentially modified event.
        """

        event_type = event.type.value
        with self._lock:
            filters = list(self._filters.get(event_type, ()))

        filtered_event: Event | None = event
        for wrapper in filters:
            if filtered_event is None:
                break

            try:
                filtered_event = wrapper.filter_obj.filter_event(filtered_event)
                if filtered_event is None:
                    logger.log(5, "Filter %s dropped event %s", wrapper.identifier, event_type)
            except Exception as exc:
                logger.warning("Filter %s failed for %s: %s", wrapper.identifier, event_type, exc)

        return filtered_event

    def get_filter_count(self, event_type: str | None = None) -> int:
        """Return the number of registered filters.

        Args:
            event_type: Optional event type key to scope the query.

        Returns:
            int: Number of filters registered for the given scope.
        """

        with self._lock:
            if event_type is not None:
                return len(self._filters.get(event_type, ()))
            return sum(len(items) for items in self._filters.values())


class EventTransformer(EventFilter):
    """Base class for filters that transform rather than drop events."""

    def filter_event(self, event: Event) -> Event | None:
        """Return the unmodified event by default.

        Args:
            event: The event to return unchanged.

        Returns:
            Event | None: The original event instance.
        """

        return event


class EventDropFilter(EventFilter):
    """Filter implementation that drops events using a predicate."""

    def __init__(self, predicate: Callable[[Event], bool]) -> None:
        """Store the predicate used to evaluate events.

        Args:
            predicate: Callable returning ``True`` when the event should be dropped.
        """

        self._predicate = predicate

    def filter_event(self, event: Event) -> Event | None:
        """Drop the event when the predicate evaluates to ``True``.

        Args:
            event: The event being evaluated.

        Returns:
            Event | None: ``None`` when the predicate matches, otherwise the original event.
        """

        if self._predicate(event):
            logger.log(5, "Dropping event %s based on predicate", event.type.value)
            return None
        return event


class EventModifyFilter(EventTransformer):
    """Filter implementation that mutates event data."""

    def __init__(self, modifier: Callable[[Event], Event]) -> None:
        """Store the modifier used to transform events.

        Args:
            modifier: Callable returning the modified event.
        """

        self._modifier = modifier

    def filter_event(self, event: Event) -> Event | None:
        """Apply the modifier and return its result.

        Args:
            event: The event to transform.

        Returns:
            Event | None: The modified event. Failures fall back to the original event.
        """

        try:
            transformed = self._modifier(event)
            logger.log(5, "Modified event %s", event.type.value)
            return transformed
        except Exception as exc:
            logger.warning("Modifier failed for %s: %s", event.type.value, exc)
            return event


class EventThrottleFilter(EventFilter):
    """Rate-limiting filter preventing event floods."""

    def __init__(self, event_type: str, max_per_second: int = 10) -> None:
        """Initialise the rate limiter.

        Args:
            event_type: Event type key to throttle.
            max_per_second: Maximum number of events allowed per second.
        """

        self._event_type = event_type
        self._max_per_second = max_per_second
        self._timestamps: list[float] = []
        self._lock = threading.RLock()

    def filter_event(self, event: Event) -> Event | None:
        """Drop events when the rate exceeds the configured limit.

        Args:
            event: The event to evaluate.

        Returns:
            Event | None: ``None`` when the rate limit is exceeded.
        """

        if event.type.value != self._event_type:
            return event

        with self._lock:
            now = time.perf_counter()
            self._timestamps = [stamp for stamp in self._timestamps if now - stamp < 1.0]

            if len(self._timestamps) >= self._max_per_second:
                logger.log(5, "Throttling event %s", event.type.value)
                return None

            self._timestamps.append(now)
            return event


def create_drop_filter(predicate: Callable[[Event], bool]) -> EventDropFilter:
    """Factory for :class:`EventDropFilter`.

    Args:
        predicate: Callable returning ``True`` when the event should be dropped.

    Returns:
        EventDropFilter: Configured drop filter instance.
    """

    return EventDropFilter(predicate)


def create_modify_filter(modifier: Callable[[Event], Event]) -> EventModifyFilter:
    """Factory for :class:`EventModifyFilter`.

    Args:
        modifier: Callable returning the modified event.

    Returns:
        EventModifyFilter: Configured modify filter instance.
    """

    return EventModifyFilter(modifier)


def create_throttle_filter(event_type: str, max_per_second: int = 10) -> EventThrottleFilter:
    """Factory for :class:`EventThrottleFilter`.

    Args:
        event_type: Event type key to throttle.
        max_per_second: Maximum number of events allowed per second.

    Returns:
        EventThrottleFilter: Configured throttle filter instance.
    """

    return EventThrottleFilter(event_type, max_per_second)


__all__ = [
    "EventDropFilter",
    "EventFilter",
    "EventFilterManager",
    "EventFilterWrapper",
    "EventModifyFilter",
    "EventThrottleFilter",
    "create_drop_filter",
    "create_modify_filter",
    "create_throttle_filter",
]
