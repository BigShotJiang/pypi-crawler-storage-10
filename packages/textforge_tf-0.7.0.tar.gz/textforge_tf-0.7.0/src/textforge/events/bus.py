"""Event bus implementations for Textforge."""

from __future__ import annotations

import threading
from typing import TYPE_CHECKING

from ..utils.logging import get_logger
from .propagation import EventPropagationEngine

if TYPE_CHECKING:
    from collections.abc import Callable

    from .types import Event

logger = get_logger(__name__)


class EventBus:
    """Thread-safe publish/subscribe bus for a single subsystem."""

    def __init__(self) -> None:
        """Initialise the bus with empty subscription storage."""

        self._subscribers: dict[str, list[Callable[[Event], None]]] = {}
        self._lock = threading.RLock()
        self._global_bridge: GlobalEventBus | None = None

    def subscribe(self, event_type: str, handler: Callable[[Event], None]) -> Callable[[], None]:
        """Register a handler for the specified event type.

        Args:
            event_type: Canonical event type key.
            handler: Callable invoked whenever an event of this type is published.

        Returns:
            Callable[[], None]: Function that removes the subscription when invoked.
        """

        with self._lock:
            self._subscribers.setdefault(event_type, []).append(handler)
            logger.log(5, "Subscribed handler to %s", event_type)

        def unsubscribe() -> None:
            """Remove the associated handler from the bus."""

            self.unsubscribe(event_type, handler)

        return unsubscribe

    def unsubscribe(self, event_type: str, handler: Callable[[Event], None]) -> None:
        """Remove a previously registered handler.

        Args:
            event_type: Canonical event type key.
            handler: Handler to remove.

        Returns:
            None
        """

        with self._lock:
            handlers = self._subscribers.get(event_type)
            if not handlers:
                logger.warning("Attempted to remove handler from unknown event type %s", event_type)
                return

            try:
                handlers.remove(handler)
                logger.log(5, "Unsubscribed handler from %s", event_type)
            except ValueError:
                logger.warning("Handler not registered for %s", event_type)
                return

            if not handlers:
                self._subscribers.pop(event_type, None)

    def publish(self, event: Event) -> None:
        """Publish an event to registered handlers.

        Args:
            event: The event being published.

        Returns:
            None
        """

        event_type = event.type.value
        with self._lock:
            handlers = list(self._subscribers.get(event_type, ()))

        if not handlers:
            return

        logger.debug("Publishing %s to %d handlers", event_type, len(handlers))
        for handler in handlers:
            try:
                handler(event)
                logger.log(5, "Event %s handled by subscriber", event_type)
            except Exception as exc:
                logger.warning("Subscriber failure for %s: %s", event_type, exc)

    def set_global_bridge(self, global_bus: GlobalEventBus) -> None:
        """Attach a global bridge allowing cross-subsystem events.

        Args:
            global_bus: The global bus to receive forwarded events.

        Returns:
            None
        """

        self._global_bridge = global_bus

    def forward_to_global(self, event: Event) -> None:
        """Forward the event to the global bridge when connected.

        Args:
            event: The event to forward.

        Returns:
            None
        """

        if self._global_bridge is None:
            return

        try:
            self._global_bridge.receive_subsystem_event(self, event)
        except Exception as exc:
            logger.warning("Failed to forward event %s to global bus: %s", event.type.value, exc)

    def get_subscriber_count(self, event_type: str | None = None) -> int:
        """Return the number of subscribers.

        Args:
            event_type: Optional event type key to scope the query.

        Returns:
            int: Count of subscribers for the requested scope.
        """

        with self._lock:
            if event_type is not None:
                return len(self._subscribers.get(event_type, ()))
            return sum(len(items) for items in self._subscribers.values())


class GlobalEventBus:
    """Central bus bridging subsystem buses and global listeners."""

    def __init__(self) -> None:
        """Initialise the global bus."""

        self._subscribers: dict[str, list[Callable[[Event], None]]] = {}
        self._subsystem_connections: dict[str, EventBus] = {}
        self._propagation_engine = EventPropagationEngine()
        self._lock = threading.RLock()

    def connect_subsystem_bus(self, subsystem_name: str, bus: EventBus) -> None:
        """Connect a subsystem bus to the global event fabric.

        Args:
            subsystem_name: Name identifying the subsystem.
            bus: Subsystem bus instance to connect.

        Returns:
            None
        """

        with self._lock:
            self._subsystem_connections[subsystem_name] = bus
            bus.set_global_bridge(self)
            logger.debug("Connected subsystem %s to global bus", subsystem_name)

    def receive_subsystem_event(self, source_bus: EventBus, event: Event) -> None:
        """Receive an event from a subsystem bus.

        Args:
            source_bus: Bus that produced the event.
            event: The event generated by the subsystem.

        Returns:
            None
        """

        with self._lock:
            subsystem_name = next(
                (
                    name
                    for name, candidate in self._subsystem_connections.items()
                    if candidate is source_bus
                ),
                "unknown",
            )

        logger.log(5, "Global bus received %s from %s", event.type.value, subsystem_name)
        self.publish(event)

    def publish(self, event: Event) -> None:
        """Publish an event to global listeners and connected subsystems.

        Args:
            event: The event to broadcast.

        Returns:
            None
        """

        propagated_event = self._propagation_engine.propagate(event)
        with self._lock:
            subscribers = list(self._subscribers.get(propagated_event.type.value, ()))
            connections = dict(self._subsystem_connections)

        for handler in subscribers:
            try:
                handler(propagated_event)
            except Exception as exc:
                logger.warning("Global handler failure for %s: %s", propagated_event.type.value, exc)

        for bus in connections.values():
            try:
                bus.receive_global_event(propagated_event)
            except Exception as exc:
                logger.warning(
                    "Failed to deliver %s to subsystem: %s",
                    propagated_event.type.value,
                    exc,
                )

    def subscribe(self, event_type: str, handler: Callable[[Event], None]) -> Callable[[], None]:
        """Register a global listener.

        Args:
            event_type: Canonical event type key.
            handler: Callable to invoke for matching events.

        Returns:
            Callable[[], None]: Function that removes the subscription when invoked.
        """

        with self._lock:
            self._subscribers.setdefault(event_type, []).append(handler)

        def unsubscribe() -> None:
            """Remove the associated global handler."""

            self.unsubscribe(event_type, handler)

        return unsubscribe

    def unsubscribe(self, event_type: str, handler: Callable[[Event], None]) -> None:
        """Remove a global listener.

        Args:
            event_type: Canonical event type key.
            handler: Handler to remove.

        Returns:
            None
        """

        with self._lock:
            handlers = self._subscribers.get(event_type)
            if not handlers:
                return
            try:
                handlers.remove(handler)
            except ValueError:
                return
            if not handlers:
                self._subscribers.pop(event_type, None)


class SubsystemEventBus(EventBus):
    """Event bus that integrates with the global bus when available."""

    def __init__(self, subsystem_name: str) -> None:
        """Initialise the subsystem bus.

        Args:
            subsystem_name: Name identifying the owning subsystem.
        """

        super().__init__()
        self.subsystem_name = subsystem_name

    def publish(self, event: Event) -> None:
        """Publish locally and forward to the global bus if configured.

        Args:
            event: The event being published.

        Returns:
            None
        """

        super().publish(event)
        self.forward_to_global(event)

    def receive_global_event(self, event: Event) -> None:
        """Receive an event propagated by the global bus.

        Args:
            event: The event being delivered from the global bus.

        Returns:
            None
        """

        logger.log(5, "Subsystem %s received global event %s", self.subsystem_name, event.type.value)
        super().publish(event)


__all__ = ["EventBus", "GlobalEventBus", "SubsystemEventBus"]
