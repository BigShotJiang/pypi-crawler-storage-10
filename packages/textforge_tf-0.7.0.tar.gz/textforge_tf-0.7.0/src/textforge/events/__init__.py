"""Event subsystem for Textforge.

This module provides the event handling infrastructure for Textforge,
including event buses, propagation, filtering, and platform-specific
event handling.
"""

from .async_processor import AsyncEventProcessor
from .bus import EventBus, GlobalEventBus, SubsystemEventBus
from .filtering import EventFilter, EventFilterManager
from .handlers import EventHandler, EventHandlerManager
from .object_pool import (
    EventObjectPool,
    EventPoolConfig,
    EventPoolStats,
    get_event_object_pool,
    pooled_component_event,
    pooled_event,
    pooled_key_event,
    pooled_mouse_event,
)
from .platform import PlatformEventHandler
from .propagation import EventPropagationEngine
from .replay import EventReplayAnalyzer, EventReplayBuffer
from .subsystem import EventSubsystem, create_event_subsystem
from .types import (
    ComponentEvent,
    Event,
    EventError,
    EventHandlerError,
    EventPropagationError,
    EventReplayError,
    EventType,
    InvalidEventTypeError,
    KeyEvent,
    MouseEvent,
    QuitEvent,
    TickEvent,
)

__all__ = [
    "EventSubsystem",
    "create_event_subsystem",
    "GlobalEventBus",
    "EventBus",
    "SubsystemEventBus",
    "EventType",
    "Event",
    "KeyEvent",
    "MouseEvent",
    "ComponentEvent",
    "EventHandler",
    "EventFilter",
    "EventError",
    "EventPropagationError",
    "InvalidEventTypeError",
    "EventHandlerError",
    "EventReplayError",
    "EventHandlerManager",
    "EventPropagationEngine",
    "EventFilterManager",
    "AsyncEventProcessor",
    "EventReplayBuffer",
    "EventReplayAnalyzer",
    "PlatformEventHandler",
    "EventObjectPool",
    "EventPoolConfig",
    "EventPoolStats",
    "get_event_object_pool",
    "pooled_event",
    "pooled_key_event",
    "pooled_mouse_event",
    "pooled_component_event",
    "QuitEvent",
    "TickEvent",
]
