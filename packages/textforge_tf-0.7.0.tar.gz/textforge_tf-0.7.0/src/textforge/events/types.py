"""Event type definitions and data structures for Textforge.

This module defines the core event types, data classes, and interfaces
used throughout the event subsystem.
"""

from __future__ import annotations

import time
from dataclasses import dataclass, field
from enum import Enum
from typing import Any

from ..utils.logging import get_logger

logger = get_logger(__name__)


class EventType(Enum):
    """Enumeration of event categories used throughout the subsystem."""

    # Input events
    KEY_DOWN = "key_down"
    KEY_UP = "key_up"
    MOUSE_DOWN = "mouse_down"
    MOUSE_UP = "mouse_up"
    MOUSE_MOVE = "mouse_move"
    MOUSE_WHEEL = "mouse_wheel"

    # Window events
    WINDOW_RESIZE = "window_resize"
    WINDOW_CLOSE = "window_close"
    WINDOW_FOCUS = "window_focus"
    WINDOW_BLUR = "window_blur"
    WINDOW_MOVE = "window_move"

    # Component lifecycle events
    COMPONENT_MOUNT = "component_mount"
    COMPONENT_UNMOUNT = "component_unmount"
    COMPONENT_UPDATE = "component_update"
    COMPONENT_FOCUS = "component_focus"
    COMPONENT_BLUR = "component_blur"

    # System coordination events
    TICK = "tick"
    RENDER_FRAME = "render_frame"
    LAYOUT_INVALIDATED = "layout_invalidated"
    STYLE_INVALIDATED = "style_invalidated"

    # Animation events
    ANIMATION_START = "animation_start"
    ANIMATION_END = "animation_end"
    ANIMATION_FRAME = "animation_frame"

    # Particle system events
    PARTICLE_SYSTEM_START = "particle_system_start"
    PARTICLE_SYSTEM_END = "particle_system_end"


@dataclass(slots=True)
class Event:
    """Immutable event payload used for dispatch and propagation."""

    type: EventType
    data: Any = None
    timestamp: float = field(default_factory=time.perf_counter)
    source: str | None = None
    target: str | None = None
    propagation_stopped: bool = False

    def stop_propagation(self) -> None:
        """Stop further propagation of the event.

        Returns:
            None
        """

        self.propagation_stopped = True
        logger.log(5, "Propagation halted for event %s", self.type.value)


@dataclass(slots=True)
class KeyEvent:
    """Keyboard-specific data attached to :class:`Event` objects."""

    key: str
    modifiers: set[str] = field(default_factory=set)
    repeat: bool = False
    location: str = "standard"


@dataclass(slots=True)
class QuitEvent:
    """Event indicating the application should quit."""


@dataclass(slots=True)
class TickEvent:
    """Event indicating a tick of the clock."""
    

@dataclass(slots=True)
class MouseEvent:
    """Mouse-specific data describing pointer interactions."""

    x: int
    y: int
    button: str | None = None
    modifiers: set[str] = field(default_factory=set)
    delta_x: int = 0
    delta_y: int = 0


@dataclass(slots=True)
class ComponentEvent:
    """Component lifecycle metadata captured for an event."""

    component_id: str
    component_type: str
    parent_id: str | None = None
    properties: dict[str, Any] = field(default_factory=dict)


class EventError(Exception):
    """Base exception raised by the event subsystem."""


class EventPropagationError(EventError):
    """Exception raised when propagation through a tree fails."""


class InvalidEventTypeError(EventError):
    """Exception raised when an invalid event type is referenced."""


class EventHandlerError(EventError):
    """Exception raised when an event handler experiences a failure."""


class EventReplayError(EventError):
    """Exception raised for replay buffer and analysis errors."""


__all__ = [
    "ComponentEvent",
    "Event",
    "EventError",
    "EventHandlerError",
    "EventPropagationError",
    "EventReplayError",
    "EventType",
    "InvalidEventTypeError",
    "KeyEvent",
    "MouseEvent",
    "QuitEvent",
    "TickEvent",
]
