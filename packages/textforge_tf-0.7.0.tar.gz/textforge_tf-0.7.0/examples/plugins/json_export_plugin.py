"""Example JSON export plugin for Textforge.

This plugin demonstrates how to create custom export formats using the
Textforge plugin system.
"""

from __future__ import annotations

import json
from typing import TYPE_CHECKING, Any

from textforge.plugins.interfaces import ExportPlugin

if TYPE_CHECKING:
    from textforge.components.base import Component


class JSONExportPlugin(ExportPlugin):
    """Plugin that exports components to JSON format."""

    @property
    def name(self) -> str:
        return "json_export"

    @property
    def version(self) -> str:
        return "1.0.0"

    def initialize(self) -> None:
        """Initialize the plugin."""
        print(f"Initializing {self.name} plugin v{self.version}")

    def cleanup(self) -> None:
        """Clean up plugin resources."""
        print(f"Cleaning up {self.name} plugin")

    def get_export_formats(self) -> list[str]:
        """Return supported export formats."""
        return ["json", "json-pretty"]

    def export_component(
        self,
        component: Component,
        format_name: str,
        **options: Any
    ) -> str:
        """Export a component to JSON format.

        Args:
            component: The component to export.
            format_name: The export format ("json" or "json-pretty").
            **options: Export options.

        Returns:
            JSON representation of the component.
        """
        # Convert component to a serializable dictionary
        component_data = self._component_to_dict(component)

        # Apply formatting options
        if format_name == "json-pretty":
            indent = options.get("indent", 2)
            return json.dumps(component_data, indent=indent, ensure_ascii=False)
        else:
            return json.dumps(component_data, ensure_ascii=False)

    def _component_to_dict(self, component: Component) -> dict[str, Any]:
        """Convert a component to a dictionary representation.

        Args:
            component: The component to convert.

        Returns:
            Dictionary representation of the component.
        """
        # Basic component info
        data = {
            "component_name": getattr(component, "component_name", "unknown"),
            "type": component.__class__.__name__,
        }

        # Add component-specific properties
        if hasattr(component, "__dict__"):
            # Get all non-private attributes
            for key, value in component.__dict__.items():
                if not key.startswith("_") and key not in ["children"]:
                    # Convert simple types, skip complex objects
                    if isinstance(value, (str, int, float, bool, type(None))):
                        data[key] = value
                    elif isinstance(value, list) and all(isinstance(item, (str, int, float, bool, type(None))) for item in value):
                        data[key] = value

        # Handle children recursively
        if hasattr(component, "children") and component.children:
            data["children"] = [
                self._component_to_dict(child) for child in component.children
            ]

        return data


# Plugin registration function for entry points
def register() -> tuple[str, Any]:
    """Entry point registration function."""
    return ("json_export", JSONExportPlugin)
