#!/usr/bin/env python3
"""Textforge Extensibility Demo.

This example demonstrates all the extensibility features of Textforge:
- Custom components via inheritance and composition
- Theme customization via TFS
- Plugin system integration
"""

from __future__ import annotations

import sys
from pathlib import Path

# Add the src directory to the path so we can import textforge
sys.path.insert(0, str(Path(__file__).parent.parent / "src"))

from textforge.components import (
    Box,
    Button,
    CustomCard,
    DashboardPanel,
    InteractiveCard,
    Text,
    create_themed_button,
    register_custom_components,
)
from textforge.core.layout.types import RendererType
from textforge.plugins.manager import get_plugin_manager
from textforge.renderers.interfaces import render_component
from textforge.style import (
    extend_theme,
    get_current_theme,
    get_theme_manager,
    load_custom_theme,
    set_theme,
)


def demo_custom_components() -> None:
    """Demonstrate custom component creation and usage."""
    print("=== Custom Components Demo ===")

    # Register custom components
    register_custom_components()

    # Create a custom card using inheritance
    custom_card = CustomCard(
        title="System Status",
        content=Text("All systems operational"),
        actions=[
            create_themed_button("Refresh", "primary"),
            create_themed_button("Settings", "secondary")
        ],
        variant="elevated"
    )

    # Create a dashboard panel using composition
    dashboard = DashboardPanel(
        title="Server Metrics",
        metrics=[
            ("CPU Usage", "45%"),
            ("Memory", "2.1GB/8GB"),
            ("Disk I/O", "120MB/s"),
            ("Network", "15Mbps")
        ],
        status="normal"
    )

    # Create an interactive card with event handlers
    def on_card_click(event):
        print(f"Card clicked: {event}")

    def on_card_hover(event):
        print(f"Card hovered: {event}")

    interactive_card = InteractiveCard(
        title="Interactive Demo",
        content=Text("Click or hover over this card"),
        on_click=on_card_click,
        on_hover=on_card_hover
    )

    # Render the components
    print("Custom Card:")
    output = render_component(custom_card, RendererType.CLI)
    print(output.content if output else "No output")

    print("\nDashboard Panel:")
    output = render_component(dashboard, RendererType.CLI)
    print(output.content if output else "No output")

    print("\nInteractive Card:")
    output = render_component(interactive_card, RendererType.CLI)
    print(output.content if output else "No output")


def demo_theme_customization() -> None:
    """Demonstrate theme loading and customization."""
    print("\n=== Theme Customization Demo ===")

    theme_manager = get_theme_manager()

    # Show available themes
    print("Available themes:", theme_manager.list_themes())

    # Load a custom theme
    custom_theme_content = """
@colors {
  primary: #ff6b6b;
  secondary: #4ecdc4;
  accent: #ffe66d;
  background: #2c3e50;
  surface: #34495e;
  text: #ecf0f1;
}
"""
    load_custom_theme("custom_red_blue", custom_theme_content)
    print("Loaded custom theme: custom_red_blue")

    # Set the custom theme
    set_theme("custom_red_blue")
    print(f"Current theme: {get_current_theme().name}")

    # Extend the current theme
    extended_theme = extend_theme("custom_red_blue", {
        "warning": "#f39c12",
        "error": "#e74c3c",
        "success": "#27ae60"
    })
    print(f"Extended theme: {extended_theme.name}")

    # Create a component with the custom theme
    themed_button = Button("Themed Button", style="primary")
    output = render_component(themed_button, RendererType.CLI)
    print("Themed button output:")
    print(output.content if output else "No output")


def demo_plugin_system() -> None:
    """Demonstrate plugin loading and usage."""
    print("\n=== Plugin System Demo ===")

    plugin_manager = get_plugin_manager()

    # Add the examples directory to plugin search paths
    plugin_manager.add_plugin_directory(Path(__file__).parent / "plugins")

    # Load plugins
    loaded_count = plugin_manager.discover_and_load_plugins()
    print(f"Loaded {loaded_count} plugins")

    # List loaded plugins
    loaded_plugins = plugin_manager.list_loaded_plugins()
    print("Loaded plugins:", loaded_plugins)

    # Get export plugins
    export_plugins = plugin_manager.get_export_plugins()
    print(f"Found {len(export_plugins)} export plugins")

    if export_plugins:
        plugin = export_plugins[0]
        print(f"Plugin: {plugin.name} v{plugin.version}")
        print("Supported formats:", plugin.get_export_formats())

        # Create a test component
        test_component = Box(
            children=[
                Text("Test Component"),
                Button("Test Button")
            ]
        )

        # Export using the plugin
        try:
            json_output = plugin.export_component(test_component, "json-pretty", indent=2)
            print("JSON Export:")
            print(json_output)
        except Exception as e:
            print(f"Export failed: {e}")


def main() -> None:
    """Run all extensibility demos."""
    print("Textforge Extensibility Demo")
    print("=" * 40)

    try:
        demo_custom_components()
        demo_theme_customization()
        demo_plugin_system()

        print("\n=== Demo Complete ===")
        print("All extensibility features demonstrated successfully!")

    except Exception as e:
        print(f"Demo failed with error: {e}")
        import traceback
        traceback.print_exc()
        sys.exit(1)


if __name__ == "__main__":
    main()
