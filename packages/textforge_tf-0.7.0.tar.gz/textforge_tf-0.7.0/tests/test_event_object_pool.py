"""Tests for event object pooling functionality."""

import threading
import time

from textforge.events.object_pool import (
    EventObjectPool,
    EventPoolConfig,
    get_event_object_pool,
    pooled_component_event,
    pooled_event,
    pooled_key_event,
    pooled_mouse_event,
)
from textforge.events.types import EventType


class TestEventObjectPool:
    """Test event object pool functionality."""

    def test_pool_creation(self):
        """Test pool creation and basic functionality."""
        pool = EventObjectPool()

        # Test acquiring events
        event = pool.acquire_event()
        assert event is not None
        assert isinstance(event.type, EventType)

        key_event = pool.acquire_key_event()
        assert key_event is not None
        assert hasattr(key_event, 'key')

        mouse_event = pool.acquire_mouse_event()
        assert mouse_event is not None
        assert hasattr(mouse_event, 'x')
        assert hasattr(mouse_event, 'y')

        component_event = pool.acquire_component_event()
        assert component_event is not None
        assert hasattr(component_event, 'component_id')

    def test_pool_reuse(self):
        """Test that objects are properly reused from the pool."""
        pool = EventObjectPool()

        # Acquire and release multiple events
        events = []
        for i in range(10):
            event = pool.acquire_event()
            event.type = EventType.KEY_DOWN
            event.data = f"test_data_{i}"
            events.append(event)

        # Release them back to pool
        for event in events:
            pool.release_event(event)

        # Acquire again and verify reuse
        stats = pool.get_stats()
        assert stats.returned > 0

        # Acquire new events - should get reused ones
        new_events = []
        for i in range(5):
            event = pool.acquire_event()
            new_events.append(event)

        new_stats = pool.get_stats()
        assert new_stats.reused > 0

    def test_pool_thread_safety(self):
        """Test that the pool is thread-safe."""
        pool = EventObjectPool()
        results = []

        def worker(worker_id):
            """Worker function for thread testing."""
            for i in range(100):
                event = pool.acquire_event()
                event.data = f"worker_{worker_id}_event_{i}"
                time.sleep(0.001)  # Small delay to increase chance of race conditions
                pool.release_event(event)
                results.append(f"worker_{worker_id}_completed_{i}")

        # Start multiple threads
        threads = []
        for i in range(5):
            thread = threading.Thread(target=worker, args=(i,))
            threads.append(thread)
            thread.start()

        # Wait for all threads to complete
        for thread in threads:
            thread.join()

        # Verify all operations completed
        assert len(results) == 500  # 5 workers * 100 operations each

        # Verify pool stats
        stats = pool.get_stats()
        assert stats.created > 0
        assert stats.returned > 0

    def test_pool_cleanup(self):
        """Test pool cleanup functionality."""
        config = EventPoolConfig(max_pool_size=5, cleanup_interval=0.1)
        pool = EventObjectPool(config)

        # Fill the pool
        events = []
        for i in range(10):
            event = pool.acquire_event()
            events.append(event)

        # Release them
        for event in events:
            pool.release_event(event)

        # Force cleanup
        pool.cleanup()

        stats = pool.get_stats()
        assert stats.pool_size <= config.max_pool_size

    def test_context_managers(self):
        """Test context manager functionality."""
        from textforge.events.object_pool import get_event_object_pool

        pool = get_event_object_pool()

        # Test pooled_event context manager
        with pooled_event() as event:
            assert event is not None
            event.type = EventType.KEY_UP
            event.data = "context_test"

        # Test pooled_key_event context manager
        with pooled_key_event() as key_event:
            assert key_event is not None
            key_event.key = "a"
            key_event.modifiers.add("shift")

        # Test pooled_mouse_event context manager
        with pooled_mouse_event() as mouse_event:
            assert mouse_event is not None
            mouse_event.x = 100
            mouse_event.y = 200
            mouse_event.button = "left"

        # Test pooled_component_event context manager
        with pooled_component_event() as comp_event:
            assert comp_event is not None
            comp_event.component_id = "test_comp"
            comp_event.component_type = "button"

        # Verify pool stats show proper reuse
        stats = pool.get_stats()
        assert stats.returned >= 4  # All context managers should have returned events

    def test_pool_statistics(self):
        """Test pool statistics tracking."""
        pool = EventObjectPool()

        # Initial stats should be zero
        stats = pool.get_stats()
        assert stats.created == 0
        assert stats.reused == 0
        assert stats.returned == 0
        assert stats.hit_rate == 0.0

        # Create some events
        events = []
        for i in range(5):
            event = pool.acquire_event()
            events.append(event)

        stats = pool.get_stats()
        assert stats.created == 5
        assert stats.reused == 0

        # Release and reuse
        for event in events:
            pool.release_event(event)

        for i in range(3):
            event = pool.acquire_event()
            events.append(event)

        stats = pool.get_stats()
        assert stats.returned == 5
        assert stats.reused == 3
        assert stats.hit_rate == 3 / (5 + 3)  # reused / total_requests

    def test_pool_limits(self):
        """Test pool size limits."""
        config = EventPoolConfig(max_pool_size=3)
        pool = EventObjectPool(config)

        # Acquire more events than pool limit
        events = []
        for i in range(10):
            event = pool.acquire_event()
            events.append(event)

        # Release all
        for event in events:
            pool.release_event(event)

        # Pool should be limited
        pool.cleanup()
        stats = pool.get_stats()
        assert stats.pool_size <= config.max_pool_size

    def test_event_reset_functionality(self):
        """Test that events are properly reset when reused."""
        pool = EventObjectPool()

        # Get an event and modify it
        event1 = pool.acquire_event()
        event1.type = EventType.MOUSE_DOWN
        event1.data = {"test": "data"}
        event1.source = "test_source"
        event1.target = "test_target"

        # Release it
        pool.release_event(event1)

        # Get it back
        event2 = pool.acquire_event()

        # Should be reset (same object but cleared fields)
        assert event2.type == EventType.TICK  # Reset to default
        assert event2.data is None
        assert event2.source is None
        assert event2.target is None


class TestGlobalEventPool:
    """Test the global event pool instance."""

    def test_global_pool_singleton(self):
        """Test that get_event_object_pool returns a singleton."""
        pool1 = get_event_object_pool()
        pool2 = get_event_object_pool()

        assert pool1 is pool2

    def test_global_pool_functionality(self):
        """Test that the global pool works correctly."""
        pool = get_event_object_pool()

        event = pool.acquire_event()
        assert event is not None

        pool.release_event(event)

        stats = pool.get_stats()
        assert stats.returned >= 1
