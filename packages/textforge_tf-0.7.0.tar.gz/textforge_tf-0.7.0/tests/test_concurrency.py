"""Tests for concurrency enhancements."""

import threading
import time
from typing import Any
from unittest.mock import MagicMock

import pytest

from src.textforge.core.concurrency import (
    AtomicCounter,
    LockFreeQueue,
    MemoryManager,
    ParallelProcessor,
    ReadWriteLock,
    ThreadLocalStorage,
    WorkStealingScheduler,
    get_memory_manager,
    get_processor,
    get_scheduler,
)


class TestReadWriteLock:
    """Test the ReadWriteLock class."""

    def test_read_write_lock(self) -> None:
        """Test basic read/write lock functionality."""
        lock = ReadWriteLock()
        shared_data = {"value": 0}

        def reader():
            lock.acquire_read()
            try:
                # Simulate reading
                time.sleep(0.01)
                return shared_data["value"]
            finally:
                lock.release_read()

        def writer():
            lock.acquire_write()
            try:
                # Simulate writing
                shared_data["value"] += 1
                time.sleep(0.01)
            finally:
                lock.release_write()

        # Test multiple readers
        results: list[int] = []
        threads: list[threading.Thread] = []

        # Start multiple readers
        for _ in range(3):
            thread = threading.Thread(target=lambda: results.append(reader()))
            threads.append(thread)
            thread.start()

        # Wait for readers
        for thread in threads:
            thread.join()

        assert len(results) == 3
        assert all(r == 0 for r in results)  # All should read 0

        # Test writer
        writer_thread = threading.Thread(target=writer)
        writer_thread.start()
        writer_thread.join()

        assert shared_data["value"] == 1


class TestLockFreeQueue:
    """Test the LockFreeQueue class."""

    def test_queue_operations(self):
        """Test basic queue operations."""
        queue = LockFreeQueue[int](max_size=5)

        # Test put and get
        assert queue.put(1)
        assert queue.put(2)
        assert queue.put(3)

        assert queue.get() == 1
        assert queue.get() == 2
        assert queue.get() == 3
        assert queue.get() is None  # Empty

    def test_queue_size_limits(self):
        """Test queue size limits."""
        queue = LockFreeQueue[int](max_size=2)

        assert queue.put(1)
        assert queue.put(2)
        assert not queue.put(3)  # Should fail due to size limit

        assert queue.size() == 2

    def test_queue_thread_safety(self):
        """Test queue thread safety."""
        queue = LockFreeQueue[int](max_size=100)
        results: list[int] = []

        def producer():
            for i in range(5):  # Reduced to 5 items per producer
                queue.put(i)
                time.sleep(0.001)

        def consumer():
            for _ in range(5):  # Try to consume 5 items
                item = queue.get()
                if item is not None:
                    results.append(item)
                time.sleep(0.001)

        threads: list[threading.Thread] = []
        for _ in range(2):
            threads.append(threading.Thread(target=producer))
            threads.append(threading.Thread(target=consumer))

        for thread in threads:
            thread.start()

        for thread in threads:
            thread.join()

        # Should have consumed at least some items (allowing for race conditions)
        assert len(results) > 0
        # All consumed items should be valid
        assert all(isinstance(item, int) and 0 <= item <= 4 for item in results)


class TestAtomicCounter:
    """Test the AtomicCounter class."""

    def test_counter_operations(self):
        """Test atomic counter operations."""
        counter = AtomicCounter(10)

        assert counter.get() == 10
        assert counter.increment() == 11
        assert counter.get() == 11
        assert counter.decrement() == 10
        assert counter.get() == 10
        assert counter.add(5) == 15
        assert counter.get() == 15

        counter.set(0)
        assert counter.get() == 0

    def test_counter_thread_safety(self):
        """Test counter thread safety."""
        counter = AtomicCounter(0)
        _ = []

        def incrementer():
            for _ in range(100):
                counter.increment()
                time.sleep(0.001)

        threads: list[threading.Thread] = []
        for _ in range(5):
            thread = threading.Thread(target=incrementer)
            threads.append(thread)
            thread.start()

        for thread in threads:
            thread.join()

        assert counter.get() == 500  # 5 threads * 100 increments each


class TestThreadLocalStorage:
    """Test the ThreadLocalStorage class."""

    def test_tls_operations(self):
        """Test thread-local storage operations."""
        tls = ThreadLocalStorage()

        # Test basic operations
        tls.set("key1", "value1")
        assert tls.get("key1") == "value1"
        assert tls.has("key1")
        assert not tls.has("key2")
        assert tls.get("key2") is None
        assert tls.get("key2", "default") == "default"

        tls.delete("key1")
        assert not tls.has("key1")
        assert tls.get("key1") is None

    def test_tls_thread_isolation(self) -> None:
        """Test that TLS is isolated per thread."""
        tls = ThreadLocalStorage()
        results: list[int] = []

        def worker(thread_id: int) -> None:
            tls.set("thread_id", thread_id)
            time.sleep(0.01)  # Allow other threads to run
            results.append(tls.get("thread_id"))

        threads: list[threading.Thread] = []
        for i in range(3):
            thread = threading.Thread(target=worker, args=(i,))
            threads.append(thread)
            thread.start()

        for thread in threads:
            thread.join()

        # Each thread should have seen its own value
        assert set(results) == {0, 1, 2}


class TestWorkStealingScheduler:
    """Test the WorkStealingScheduler class."""

    def test_scheduler_creation(self) -> None:
        """Test scheduler creation and basic functionality."""
        scheduler = WorkStealingScheduler(num_threads=2)

        assert scheduler._num_threads == 2
        assert len(scheduler._task_queues) == 2

    def test_task_submission(self) -> None:
        """Test task submission and execution."""
        scheduler = WorkStealingScheduler(num_threads=1)

        results: list[int] = []

        def test_task(x: int) -> int:
            results.append(x * 2)
            return x * 2

        scheduler.submit_task("test1", test_task, 5)

        # Wait for task completion
        time.sleep(0.1)

        assert 10 in results

    def test_scheduler_shutdown(self) -> None:
        """Test scheduler shutdown."""
        scheduler = WorkStealingScheduler(num_threads=1)

        scheduler.shutdown(wait=True)

        # Should not accept new tasks after shutdown
        with pytest.raises(RuntimeError):
            scheduler.submit_task("test", lambda: None)


class TestMemoryManager:
    """Test the MemoryManager class."""

    def test_thread_local_pools(self) -> None:
        """Test thread-local pool management."""
        manager = MemoryManager()

        def test_factory() -> list[Any]:
            return []

        pool = manager.get_thread_local_pool("test", test_factory)
        assert pool is not None

        # Should return the same pool for the same thread
        pool2 = manager.get_thread_local_pool("test", test_factory)
        assert pool is pool2

    def test_global_pools(self):
        """Test global pool management."""
        manager = MemoryManager()

        pool1 = manager.get_global_pool("test")
        pool2 = manager.get_global_pool("test")

        # Should return the same pool
        assert pool1 is pool2

    def test_memory_manager_thread_safety(self):
        """Test memory manager thread safety."""
        manager = MemoryManager()
        results: list[int] = []

        def worker(thread_id: int) -> None:
            # Use a simple factory function
            def list_factory() -> list[int]:
                return []

            pool = manager.get_thread_local_pool(f"thread_{thread_id}", list_factory)
            obj = pool.acquire()
            obj.append(thread_id)
            pool.release(obj)
            results.append(thread_id)

        threads: list[threading.Thread] = []
        for i in range(3):
            thread = threading.Thread(target=worker, args=(i,))
            threads.append(thread)
            thread.start()

        for thread in threads:
            thread.join()

        assert set(results) == {0, 1, 2}


class TestParallelProcessor:
    """Test the ParallelProcessor class."""

    def test_processor_creation(self) -> None:
        """Test parallel processor creation."""
        processor = ParallelProcessor()
        assert processor is not None

    def test_parallel_layout_calculation(self) -> None:
        """Test parallel layout calculation (mocked)."""
        processor = ParallelProcessor()

        # Mock layout tasks
        _ = [
            {"component": MagicMock(), "container_bounds": MagicMock(), "renderer_type": "cli"}
        ]

        # This would normally require actual layout components
        # For now, just test that the method exists and can be called
        # In a real scenario, this would be tested with actual layout data
        assert hasattr(processor, "parallelize_layout_calculation")


class TestGlobalInstances:
    """Test global concurrency instances."""

    def test_global_scheduler(self) -> None:
        """Test global scheduler instance."""
        scheduler = get_scheduler()
        assert scheduler is not None
        assert isinstance(scheduler, WorkStealingScheduler)

    def test_global_processor(self):
        """Test global processor instance."""
        processor = get_processor()
        assert processor is not None
        assert isinstance(processor, ParallelProcessor)

    def test_global_memory_manager(self):
        """Test global memory manager instance."""
        manager = get_memory_manager()
        assert manager is not None
        assert isinstance(manager, MemoryManager)


if __name__ == "__main__":
    pytest.main([__file__])
