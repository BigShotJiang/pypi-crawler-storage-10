"""Tests for the optimization subsystem."""

import threading
import time
from unittest.mock import MagicMock, patch

import pytest

from src.textforge.optimization import OptimizationManager
from src.textforge.optimization.cache.lru_cache import LRUCache


class TestOptimizationManager:
    """Test the OptimizationManager class."""

    def test_initialization(self):
        """Test that OptimizationManager initializes correctly."""
        manager = OptimizationManager()
        assert manager is not None
        assert hasattr(manager, "_cython_enabled")
        assert hasattr(manager, "_memory_pools")
        assert hasattr(manager, "_lock")

    def test_memory_pool_creation(self):
        """Test memory pool creation and usage."""
        manager = OptimizationManager()

        # Test pool creation
        pool = manager.get_memory_pool("test_pool", list, max_size=10)
        assert pool is not None
        assert pool.object_type is list
        assert pool.max_size == 10

        # Test pool reuse
        pool2 = manager.get_memory_pool("test_pool", list, max_size=10)
        assert pool is pool2  # Should return the same pool

    def test_memory_pool_operations(self):
        """Test memory pool acquire/release operations."""
        manager = OptimizationManager()
        pool = manager.get_memory_pool("test_pool", list)

        # Acquire object
        obj1 = pool.acquire()
        assert isinstance(obj1, list)

        # Release object
        pool.release(obj1)

        # Acquire again (should get the same object)
        obj2 = pool.acquire()
        assert obj2 is obj1

    def test_function_optimization_without_cython(self):
        """Test function optimization when Cython is not available."""
        manager = OptimizationManager()

        def test_func(x: int) -> int:
            return x * 2

        # Mock Cython as unavailable
        with patch.object(manager, "_cython_enabled", False):
            optimized = manager.optimize_function(test_func)
            assert optimized is test_func  # Should return original function

    def test_function_optimization_with_cython(self):
        """Test function optimization when Cython is available."""
        manager = OptimizationManager()

        def test_func(x: int) -> int:
            return x * 2

        # Mock Cython as available and mock the optimization process
        with patch.object(manager, "_cython_enabled", True), \
             patch.object(manager, "_cython_optimize") as mock_optimize:

            mock_optimized_func = MagicMock()
            mock_optimize.return_value = mock_optimized_func

            optimized = manager.optimize_function(test_func)
            assert optimized is mock_optimized_func
            mock_optimize.assert_called_once_with(test_func)

    def test_cython_module_selection(self):
        """Test Cython module selection based on function names."""
        manager = OptimizationManager()

        # Test text-related function
        def calculate_text_width(text: str) -> int:
            return len(text)

        module = manager._select_cython_module(calculate_text_width)
        assert module == "text_ops"

        # Test layout-related function
        def calculate_layout_position() -> int:
            return 0

        module = manager._select_cython_module(calculate_layout_position)
        assert module == "layout_ops"

        # Test color-related function
        def blend_colors() -> str:
            return "#000000"

        module = manager._select_cython_module(blend_colors)
        assert module == "color_ops"

        # Test unknown function
        def unknown_function() -> None:
            return None

        module = manager._select_cython_module(unknown_function)
        assert module is None

    def test_profiling_function(self):
        """Test function profiling capabilities."""
        manager = OptimizationManager()

        def test_func(delay: float = 0.01) -> str:
            time.sleep(delay)
            return "result"

        # Profile the function
        result = manager.profile_function(test_func, delay=0.001)

        assert result is not None
        assert hasattr(result, "execution_time")
        assert hasattr(result, "memory_usage")
        assert hasattr(result, "call_count")
        assert result.call_count == 10  # Should run 10 times
        assert result.execution_time > 0
        assert result.memory_usage >= 0

    def test_thread_safety(self):
        """Test thread safety of optimization operations."""
        manager = OptimizationManager()
        results: list[int] = []

        def worker(thread_id: int) -> None:
            # Test memory pool operations
            pool = manager.get_memory_pool(f"thread_{thread_id}_pool", dict)
            obj = pool.acquire()
            obj["thread"] = thread_id
            pool.release(obj)
            results.append(thread_id)

        # Run multiple threads
        threads = []
        for i in range(5):
            thread = threading.Thread(target=worker, args=(i,))
            threads.append(thread)
            thread.start()

        # Wait for all threads
        for thread in threads:
            thread.join()

        assert len(results) == 5
        assert set(results) == {0, 1, 2, 3, 4}

    def test_cython_not_available_error(self):
        """Test handling when Cython optimization is requested but unavailable."""
        from src.textforge.optimization.manager import CythonNotAvailableError

        manager = OptimizationManager()

        def test_func():
            return 42

        # Mock Cython as unavailable
        with patch.object(manager, "_cython_enabled", False):
            with pytest.raises(CythonNotAvailableError):
                manager._cython_optimize(test_func)


class TestLRUCache:
    """Test the LRUCache class."""

    def test_cache_initialization(self):
        """Test LRU cache initialization."""
        cache = LRUCache(max_size=10)
        assert cache.max_size == 10
        assert cache.size() == 0

    def test_cache_put_and_get(self):
        """Test basic cache put and get operations."""
        cache = LRUCache(max_size=3)

        # Put items
        cache.put("key1", "value1")
        cache.put("key2", "value2")
        cache.put("key3", "value3")

        # Get items
        assert cache.get("key1") == "value1"
        assert cache.get("key2") == "value2"
        assert cache.get("key3") == "value3"
        assert cache.get("key4") is None  # Non-existent key

    def test_cache_eviction(self):
        """Test LRU eviction when cache is full."""
        cache = LRUCache(max_size=2)

        cache.put("key1", "value1")
        cache.put("key2", "value2")
        cache.put("key3", "value3")  # Should evict key1

        assert cache.get("key1") is None  # Evicted
        assert cache.get("key2") == "value2"
        assert cache.get("key3") == "value3"

    def test_cache_lru_ordering(self):
        """Test that access updates LRU ordering."""
        cache = LRUCache(max_size=3)

        cache.put("key1", "value1")
        cache.put("key2", "value2")
        cache.put("key3", "value3")

        # Access key1, making it most recently used
        cache.get("key1")

        # Add another item, should evict key2 (least recently used)
        cache.put("key4", "value4")

        assert cache.get("key1") == "value1"  # Still there
        assert cache.get("key2") is None  # Evicted
        assert cache.get("key3") == "value3"
        assert cache.get("key4") == "value4"

    def test_cache_remove(self):
        """Test cache item removal."""
        cache = LRUCache(max_size=10)

        cache.put("key1", "value1")
        cache.put("key2", "value2")

        assert cache.remove("key1") is True
        assert cache.get("key1") is None
        assert cache.remove("nonexistent") is False

    def test_cache_clear(self):
        """Test cache clearing."""
        cache = LRUCache(max_size=10)

        cache.put("key1", "value1")
        cache.put("key2", "value2")

        cache.clear()

        assert cache.size() == 0
        assert cache.get("key1") is None
        assert cache.get("key2") is None

    def test_cache_statistics(self):
        """Test cache statistics and hit rate."""
        cache = LRUCache(max_size=10)

        # Initial state
        stats = cache.stats()
        assert stats["hits"] == 0
        assert stats["misses"] == 0
        assert stats["hit_rate"] == 0.0

        # Add item and access it
        cache.put("key1", "value1")
        cache.get("key1")  # Hit

        stats = cache.stats()
        assert stats["hits"] == 1
        assert stats["misses"] == 0
        assert stats["hit_rate"] == 1.0

        # Try to get non-existent key
        cache.get("key2")  # Miss

        stats = cache.stats()
        assert stats["hits"] == 1
        assert stats["misses"] == 1
        assert stats["hit_rate"] == 0.5

    def test_cache_thread_safety(self):
        """Test thread safety of LRU cache operations."""
        cache = LRUCache(max_size=100)
        results: list[tuple[int, str]] = []

        def worker(thread_id: int) -> None:
            # Perform various cache operations
            cache.put(f"key_{thread_id}", f"value_{thread_id}")
            value = cache.get(f"key_{thread_id}")
            results.append((thread_id, value))

        # Run multiple threads
        threads = []
        for i in range(10):
            thread = threading.Thread(target=worker, args=(i,))
            threads.append(thread)
            thread.start()

        # Wait for all threads
        for thread in threads:
            thread.join()

        # Verify results
        assert len(results) == 10
        for thread_id, value in results:
            assert value == f"value_{thread_id}"


if __name__ == "__main__":
    pytest.main([__file__])
