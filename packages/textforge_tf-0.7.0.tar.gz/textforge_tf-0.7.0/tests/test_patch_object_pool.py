"""Tests for patch object pooling functionality."""

import threading
import time

from textforge.core.diffing.object_pool import (
    PatchObjectPool,
    PatchPoolConfig,
    get_patch_object_pool,
    pooled_patch,
)
from textforge.core.diffing.patches import PatchType


class TestPatchObjectPool:
    """Test patch object pool functionality."""

    def test_pool_creation(self):
        """Test pool creation and basic functionality."""
        pool = PatchObjectPool()

        # Test acquiring patches
        patch = pool.acquire_patch()
        assert patch is not None
        assert isinstance(patch.patch_type, PatchType)

    def test_pool_reuse(self):
        """Test that patches are properly reused from the pool."""
        pool = PatchObjectPool()

        # Acquire and release multiple patches
        patches = []
        for i in range(10):
            patch = pool.acquire_patch()
            patch.patch_type = PatchType.UPDATE_PROPS
            patch.key = f"test_key_{i}"
            patch.data = {"test": f"data_{i}"}
            patches.append(patch)

        # Release them back to pool
        for patch in patches:
            pool.release_patch(patch)

        # Acquire again and verify reuse
        stats = pool.get_stats()
        assert stats.returned > 0

        # Acquire new patches - should get reused ones
        new_patches = []
        for i in range(5):
            patch = pool.acquire_patch()
            new_patches.append(patch)

        new_stats = pool.get_stats()
        assert new_stats.reused > 0

    def test_pool_thread_safety(self):
        """Test that the pool is thread-safe."""
        pool = PatchObjectPool()
        results = []

        def worker(worker_id):
            """Worker function for thread testing."""
            for i in range(100):
                patch = pool.acquire_patch()
                patch.key = f"worker_{worker_id}_patch_{i}"
                patch.data = f"test_data_{i}"
                time.sleep(0.001)  # Small delay to increase chance of race conditions
                pool.release_patch(patch)
                results.append(f"worker_{worker_id}_completed_{i}")

        # Start multiple threads
        threads = []
        for i in range(5):
            thread = threading.Thread(target=worker, args=(i,))
            threads.append(thread)
            thread.start()

        # Wait for all threads to complete
        for thread in threads:
            thread.join()

        # Verify all operations completed
        assert len(results) == 500  # 5 workers * 100 operations each

        # Verify pool stats
        stats = pool.get_stats()
        assert stats.created > 0
        assert stats.returned > 0

    def test_pool_cleanup(self):
        """Test pool cleanup functionality."""
        config = PatchPoolConfig(max_pool_size=5, cleanup_interval=0.1)
        pool = PatchObjectPool(config)

        # Fill the pool
        patches = []
        for i in range(10):
            patch = pool.acquire_patch()
            patches.append(patch)

        # Release them
        for patch in patches:
            pool.release_patch(patch)

        # Force cleanup
        pool.cleanup()

        stats = pool.get_stats()
        assert stats.pool_size <= config.max_pool_size

    def test_context_managers(self):
        """Test context manager functionality."""
        from textforge.core.diffing.object_pool import get_patch_object_pool

        pool = get_patch_object_pool()

        # Test pooled_patch context manager
        with pooled_patch() as patch:
            assert patch is not None
            patch.patch_type = PatchType.REMOVE_NODE
            patch.key = "test_key"
            patch.data = "test_data"

        # Verify pool stats show proper reuse
        stats = pool.get_stats()
        assert stats.returned >= 1

    def test_pool_statistics(self):
        """Test pool statistics tracking."""
        pool = PatchObjectPool()

        # Initial stats should be zero
        stats = pool.get_stats()
        assert stats.created == 0
        assert stats.reused == 0
        assert stats.returned == 0
        assert stats.hit_rate == 0.0

        # Create some patches
        patches = []
        for i in range(5):
            patch = pool.acquire_patch()
            patches.append(patch)

        stats = pool.get_stats()
        assert stats.created == 5
        assert stats.reused == 0

        # Release and reuse
        for patch in patches:
            pool.release_patch(patch)

        for i in range(3):
            patch = pool.acquire_patch()
            patches.append(patch)

        stats = pool.get_stats()
        assert stats.returned == 5
        assert stats.reused == 3
        assert stats.hit_rate == 3 / (5 + 3)  # reused / total_requests

    def test_pool_limits(self):
        """Test pool size limits."""
        config = PatchPoolConfig(max_pool_size=3)
        pool = PatchObjectPool(config)

        # Acquire more patches than pool limit
        patches = []
        for i in range(10):
            patch = pool.acquire_patch()
            patches.append(patch)

        # Release all
        for patch in patches:
            pool.release_patch(patch)

        # Pool should be limited
        pool.cleanup()
        stats = pool.get_stats()
        assert stats.pool_size <= config.max_pool_size

    def test_patch_reset_functionality(self):
        """Test that patches are properly reset when reused."""
        pool = PatchObjectPool()

        # Get a patch and modify it
        patch1 = pool.acquire_patch()
        patch1.patch_type = PatchType.ADD_NODE
        patch1.key = "test_key"
        patch1.data = {"test": "data"}

        # Release it
        pool.release_patch(patch1)

        # Get it back
        patch2 = pool.acquire_patch()

        # Should be reset (same object but cleared fields)
        assert patch2.patch_type == PatchType.ADD_NODE  # Default type
        assert patch2.key is None
        assert patch2.data is None


class TestGlobalPatchPool:
    """Test the global patch pool instance."""

    def test_global_pool_singleton(self):
        """Test that get_patch_object_pool returns a singleton."""
        pool1 = get_patch_object_pool()
        pool2 = get_patch_object_pool()

        assert pool1 is pool2

    def test_global_pool_functionality(self):
        """Test that the global pool works correctly."""
        pool = get_patch_object_pool()

        patch = pool.acquire_patch()
        assert patch is not None

        pool.release_patch(patch)

        stats = pool.get_stats()
        assert stats.returned >= 1
