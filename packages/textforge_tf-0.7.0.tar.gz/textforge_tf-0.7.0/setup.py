#!/usr/bin/env python3
"""
Setup script for Textforge with Cython extensions.
"""

import sys

from Cython.Build.Dependencies import cythonize
from setuptools import Extension, setup

# Cython extensions to build
extensions = [
    Extension(
        "textforge.optimization.cython.text_ops",
        sources=["src/textforge/optimization/cython/text_ops.pyx"],
        include_dirs=[],
        define_macros=[("CYTHON_TRACE", "0")],
    ),
    Extension(
        "textforge.optimization.cython.layout_ops",
        sources=["src/textforge/optimization/cython/layout_ops.pyx"],
        include_dirs=[],
        define_macros=[("CYTHON_TRACE", "0")],
    ),
    Extension(
        "textforge.optimization.cython.rendering_ops",
        sources=["src/textforge/optimization/cython/rendering_ops.pyx"],
        include_dirs=[],
        define_macros=[("CYTHON_TRACE", "0")],
    ),
    Extension(
        "textforge.optimization.cython.diffing_ops",
        sources=["src/textforge/optimization/cython/diffing_ops.pyx"],
        include_dirs=[],
        define_macros=[("CYTHON_TRACE", "0")],
    ),
    Extension(
        "textforge.optimization.cython.color_ops",
        sources=["src/textforge/optimization/cython/color_ops.pyx"],
        include_dirs=[],
        define_macros=[("CYTHON_TRACE", "0")],
    ),
]

# Platform-specific optimizations
if sys.platform == "win32":
    # Windows-specific optimizations (DirectX-ready)
    for ext in extensions:
        ext.extra_compile_args = ["/O2", "/GL"]
        ext.extra_link_args = ["/LTCG"]
elif sys.platform == "darwin":
    # macOS-specific optimizations (Metal-ready)
    for ext in extensions:
        ext.extra_compile_args = ["-O3", "-march=native"]
        ext.extra_link_args = []
else:
    # Linux/Unix optimizations (Vulkan-ready)
    for ext in extensions:
        ext.extra_compile_args = ["-O3", "-march=native"]
        ext.extra_link_args = []

# Cythonize extensions with optimizations
cython_extensions = cythonize(
    extensions,
    compiler_directives={
        "language_level": 3,
        "boundscheck": False,
        "wraparound": False,
        "initializedcheck": False,
        "nonecheck": False,
        "overflowcheck": False,
        "embedsignature": True,
        "freethreading_compatible": True,  # Enable free-threading support
    },
    build_dir="build",
)

if __name__ == "__main__":
    setup(
        ext_modules=cython_extensions,
    )
