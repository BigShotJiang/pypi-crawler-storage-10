"""AioSQLite extension integration tests."""
