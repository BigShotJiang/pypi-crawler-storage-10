# mi_paquete

Un paquete de ejemplo para aprender a crear y publicar librerías en PyPI.

## Descripción
Este paquete incluye funciones y clases sencillas para practicar el empaquetado,
documentación y distribución de proyectos Python.

## Instalación
```bash
pip install EjemploClasePyPiMatematicas