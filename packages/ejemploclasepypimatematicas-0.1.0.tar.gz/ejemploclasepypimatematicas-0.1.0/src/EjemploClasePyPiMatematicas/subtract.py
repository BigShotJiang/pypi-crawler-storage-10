def subtract_nums(num1, num2):
    """Resta num1 de num2.

    Args:
        num1 (int): El primer número.
        num2 (int): El segundo número.

    Returns:
        int: El resultado de la resta (num2 - num1).
    """
    answer = num2 - num1
    return answer