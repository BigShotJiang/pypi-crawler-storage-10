def add_nums(num1, num2):
    """Suma dos números.

    Args:
        num1 (int): El primer número.
        num2 (int): El segundo número.

    Returns:
        int: La suma de los dos números.
    """
    answer = num1 + num2
    return answer
