def divide_nums(num1, num2):
    """Divide num1 entre num2.

    Args:
        num1 (int): El primer número.
        num2 (int): El segundo número.

    Returns:
        float: El resultado de la división.
    """
    answer = num1 / num2
    return answer
