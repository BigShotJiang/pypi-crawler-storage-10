def multiply_nums(num1, num2):
    """Multiplica dos números.

    Args:
        num1 (int): El primer número.
        num2 (int): El segundo número.

    Returns:
        int: El producto de los dos números.
    """
    answer = num1 * num2
    return answer