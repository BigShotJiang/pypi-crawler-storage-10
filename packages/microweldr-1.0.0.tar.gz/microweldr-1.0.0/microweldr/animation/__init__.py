"""Animation generation functionality."""
