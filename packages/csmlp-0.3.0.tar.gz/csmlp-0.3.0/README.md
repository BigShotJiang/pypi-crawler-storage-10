# csmlp

A simple Python package that provides a CSV dataset (`best.csv`) for easy use in data analysis and ML projects.

## Installation
```bash
pip install csmlp
```