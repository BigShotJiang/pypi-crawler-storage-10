import pandas as pd
import pkg_resources
import io
from importlib import resources

def get_data():
    """Load and return the CSV as a pandas DataFrame (works on Python 3.7+)."""
    try:
        # Try modern API (Python 3.9+)
        if hasattr(resources, "files"):
            data = resources.files("csmlp.data").joinpath("best.csv").read_bytes()
            return pd.read_csv(io.BytesIO(data))
        else:
            # Fallback for older Pythons (3.7, 3.8)
            data_path = pkg_resources.resource_filename("csmlp", "data/best.csv")
            return pd.read_csv(data_path)
    except Exception as e:
        raise FileNotFoundError("Could not load best.csv from csmlp package") from e
