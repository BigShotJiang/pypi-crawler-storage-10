"""Unit tests for SDK clients."""
import pytest
import requests_mock

from openquantum_sdk.clients import (
    JobPreparationCreate, JobCreate, PaginatedOrganizations, PaginatedBackendClasses,
    SchedulerClient, ManagementClient
)
from openquantum_sdk.utils import poll_for_status


@pytest.fixture
def mock_scheduler():
    with requests_mock.Mocker() as m:
        # Mock for test_prepare_job: POST /v1/jobs/prepare
        m.post(
            "https://scheduler.openquantum.com/v1/jobs/prepare",
            json={"id": "prep-123"}
        )
        # Mock for test_create_job: POST /v1/jobs
        m.post(
            "https://scheduler.openquantum.com/v1/jobs",
            json={
                "id": "job-123",
                "status": "Created",
                "job_preparation_id": "prep-123",
                "execution_plan_id": "plan-1",
                "queue_priority_id": "prio-1",
                "input_data_url": "input-url-123"
            }
        )
        # Mock for test_get_job: GET /v1/jobs/job-123
        m.get(
            "https://scheduler.openquantum.com/v1/jobs/job-123",
            json={
                "id": "job-123",
                "status": "Completed",
                "job_preparation_id": "prep-123",
                "execution_plan_id": "plan-1",
                "queue_priority_id": "prio-1",
                "input_data_url": "input-url-123"
            }
        )
        client = SchedulerClient()
        yield client


@pytest.fixture
def mock_management():
    with requests_mock.Mocker() as m:
        # Mock for test_list_user_organizations: GET /v1/users/organizations?limit=20
        m.get(
            "https://management.openquantum.com/v1/users/organizations?limit=20",
            json={
                "organizations": [
                    {"id": "org-123", "name": "Test Org"}
                ],
                "pagination": {"next_cursor": None}
            }
        )
        # Mock for test_list_backend_classes: GET /v1/backends/classes?limit=20
        m.get(
            "https://management.openquantum.com/v1/backends/classes?limit=20",
            json={
                "backend_classes": [
                    {
                        "id": "backend-123",
                        "name": "Test Backend",
                        "type": "QPU",
                        "queue_depth": 1,
                        "status": "Online",
                        "accepting_jobs": True
                    }
                ],
                "pagination": {"next_cursor": None}
            }
        )
        client = ManagementClient()
        yield client


def test_prepare_job(mock_scheduler):
    """Test job preparation."""
    prep = JobPreparationCreate(
        organization_id="org-123",
        backend_class_id="backend-123",
        name="Test Job",
        configuration_data={"test": "data"},
        job_category_id="cat-123",
        job_subcategory_id="sub-123",
        shots=1024
    )
    response = mock_scheduler.prepare_job(prep)
    assert response.id == "prep-123"


def test_create_job(mock_scheduler):
    """Test job creation."""
    job = JobCreate(
        organization_id="org-123",
        job_preparation_id="prep-123",
        execution_plan_id="plan-1",
        queue_priority_id="prio-1"
    )
    response = mock_scheduler.create_job(job)
    assert response.id == "job-123"
    assert response.status == "Created"


def test_get_job(mock_scheduler):
    """Test getting job status."""
    response = mock_scheduler.get_job("job-123")
    assert response.status == "Completed"


def test_list_user_organizations(mock_management):
    """Test listing organizations."""
    orgs = mock_management.list_user_organizations()
    assert isinstance(orgs, PaginatedOrganizations)
    assert len(orgs.organizations) == 1
    assert orgs.organizations[0].id == "org-123"


def test_list_backend_classes(mock_management):
    """Test listing backends."""
    backends = mock_management.list_backend_classes()
    assert isinstance(backends, PaginatedBackendClasses)
    assert len(backends.backend_classes) == 1
    assert backends.backend_classes[0].id == "backend-123"


def test_poll_for_status():
    """Test polling utility with a mock function."""
    calls = []

    def mock_get_status(id):
        calls.append(id)
        if len(calls) == 1:
            return False, None  # First poll: not done
        return True, {"status": "Completed"}  # Second: done
    result = poll_for_status(mock_get_status, "test-id", interval=0.1, timeout=1)
    assert result["status"] == "Completed"
    assert len(calls) == 2
