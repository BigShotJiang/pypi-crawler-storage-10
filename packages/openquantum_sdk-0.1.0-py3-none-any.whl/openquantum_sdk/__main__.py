#!/usr/bin/env python
"""CLI entry point for running the full job example."""
import sys
import os
import json
import argparse
import requests
from .auth import ClientCredentials, ClientCredentialsAuth
from .clients import APIError, SchedulerClient, ManagementClient, JobPreparationCreate, JobCreate
from .utils import poll_for_status


def load_creds_from_file(path: str) -> ClientCredentials:
    with open(path, "r", encoding="utf-8") as f:
        data = json.load(f)
    try:
        return ClientCredentials(client_id=data["client_id"], client_secret=data["client_secret"])
    except KeyError as e:
        raise ValueError(f"SDK key file missing field: {e}")


def resolve_credentials(args: argparse.Namespace) -> ClientCredentials:
    # 1) explicit file flag
    if args.sdk_key:
        return load_creds_from_file(args.sdk_key)

    # 2) env var file path
    sdk_key_env = os.getenv("OPENQUANTUM_SDK_KEY")
    if sdk_key_env and os.path.exists(sdk_key_env):
        return load_creds_from_file(sdk_key_env)

    # 3) direct args
    if args.client_id and args.client_secret:
        return ClientCredentials(client_id=args.client_id, client_secret=args.client_secret)

    # 4) env direct
    env_id = os.getenv("OPENQUANTUM_CLIENT_ID")
    env_secret = os.getenv("OPENQUANTUM_CLIENT_SECRET")
    if env_id and env_secret:
        return ClientCredentials(client_id=env_id, client_secret=env_secret)

    raise SystemExit(
        "Missing credentials. Provide --sdk-key <file.json> or --client-id/--client-secret "
        "or set OPENQUANTUM_SDK_KEY or OPENQUANTUM_CLIENT_ID/OPENQUANTUM_CLIENT_SECRET."
    )


def build_arg_parser() -> argparse.ArgumentParser:
    p = argparse.ArgumentParser(description="Run an example job via Open Quantum SDK")
    p.add_argument("--sdk-key", help="Path to SDK key JSON containing client_id and client_secret")
    p.add_argument("--client-id", help="OAuth2 client_id (alternative to --sdk-key)")
    p.add_argument("--client-secret", help="OAuth2 client_secret (alternative to --sdk-key)")

    # Keycloak config (defaults from your message)
    p.add_argument("--keycloak-base", default="https://id.openquantum.com", help="Keycloak base URL")
    p.add_argument("--realm", default="platform", help="Keycloak realm")

    # API bases (keep overrideable)
    p.add_argument("--scheduler-base", default="https://scheduler.openquantum.com", help="Scheduler API base URL")
    p.add_argument("--management-base", default="https://management.openquantum.com", help="Management API base URL")

    # Poll intervals/timeouts
    p.add_argument("--prep-interval", type=int, default=5)
    p.add_argument("--prep-timeout", type=int, default=300)
    p.add_argument("--job-interval", type=int, default=10)
    p.add_argument("--job-timeout", type=int, default=600)
    return p


def main():
    args = build_arg_parser().parse_args()

    # Resolve creds
    creds = resolve_credentials(args)

    # Build auth provider (scope optional)
    auth = ClientCredentialsAuth(
        keycloak_base=args.keycloak_base,
        realm=args.realm,
        creds=creds,
        scope=None,
        leeway_seconds=30,
    )

    # Wire clients using auth provider (no fixed token needed)
    scheduler = SchedulerClient(base_url=args.scheduler_base, auth=auth)
    management = ManagementClient(base_url=args.management_base, auth=auth)

    try:
        # Step 1: Fetch user's organization (assume first one)
        orgs = management.list_user_organizations()
        if not orgs.organizations:
            raise ValueError("No organizations found for user.")
        organization_id = orgs.organizations[0].id
        print(f"Using organization: {organization_id}")

        # Step 2: Fetch available backend classes (filter for QPU if desired)
        backends = management.list_backend_classes()
        if not backends.backend_classes:
            raise ValueError("No backend classes available.")
        backend_class = next(
            (b for b in backends.backend_classes if b.type == "QPU" and b.accepting_jobs),
            backends.backend_classes[0],
        )
        backend_class_id = backend_class.id
        print(f"Using backend class: {backend_class.name} ({backend_class_id})")

        # Step 3: Job categories and subcategories
        categories = scheduler.get_job_categories()
        if not categories.categories:
            raise ValueError("No job categories available.")
        category = categories.categories[0]
        category_id = category.id
        print(f"Using category: {category.name} ({category_id})")

        subcategories = scheduler.get_job_subcategories(category_id)
        if not subcategories.categories:
            raise ValueError("No subcategories available.")
        subcategory = subcategories.categories[0]
        subcategory_id = subcategory.id
        print(f"Using subcategory: {subcategory.name} ({subcategory_id})")

        # Step 4: (Optional) Upload endpoint — skipping in this example
        upload_endpoint_id = None

        # Step 5: Example configuration_data
        configuration_data = {
            "qreg": {"name": "q", "size": 2},
            "creg": {"name": "c", "size": 2},
            "instructions": [
                {"name": "h", "qubits": [0]},
                {"name": "cx", "qubits": [0, 1]},
                {"name": "measure", "qubits": [0, 1], "clbits": [0, 1]},
            ],
        }

        preparation = JobPreparationCreate(
            organization_id=organization_id,
            backend_class_id=backend_class_id,
            name="Example Bell State Job",
            upload_endpoint_id=upload_endpoint_id,
            configuration_data=configuration_data,
            job_category_id=category_id,
            job_subcategory_id=subcategory_id,
            shots=1024,
        )
        prep_resp = scheduler.prepare_job(preparation)
        preparation_id = prep_resp.id
        print(f"Job preparation ID: {preparation_id}")

        # Step 6: Poll for preparation result
        target_statuses = ["Completed", "Failed"]

        def get_prep_status(prep_id):
            result = scheduler.get_preparation_result(prep_id)
            print(f"Preparation status: {result.status}")
            return result.status in target_statuses, result

        result = poll_for_status(get_prep_status, preparation_id, interval=args.prep_interval, timeout=args.prep_timeout)
        if result.status != "Completed":
            raise ValueError(f"Preparation failed: {result.status}")

        # Step 7: Pick a quote option
        if not result.quote:
            raise ValueError("No quotes available.")
        execution_plan = result.quote[0]
        queue_priority = execution_plan.queue_priorities[0]
        print(f"Selected plan: {execution_plan.name} at ${execution_plan.price}")
        print(f"Selected priority: {queue_priority.name} (+${queue_priority.price_increase})")

        # Step 8: Create job
        job = JobCreate(
            organization_id=organization_id,
            job_preparation_id=preparation_id,
            execution_plan_id=execution_plan.execution_plan_id,
            queue_priority_id=queue_priority.queue_priority_id,
        )
        job_response = scheduler.create_job(job)
        job_id = job_response.id
        print(f"Job created: {job_id} (initial status: {job_response.status})")

        # Step 9: Monitor
        done_statuses = ["Completed", "Failed", "Canceled"]

        def get_job_status(job_id):
            job_status_obj = scheduler.get_job(job_id)
            print(f"Job status: {job_status_obj.status}")
            return job_status_obj.status in done_statuses, job_status_obj

        job_status = poll_for_status(get_job_status, job_id, interval=args.job_interval, timeout=args.job_timeout)

        # Step 10: List jobs for org
        all_jobs = scheduler.list_jobs(organization_id, status=job_status.status)
        print(f"Found {len(all_jobs.jobs)} jobs with status {job_status.status}")

        # Step 11: Optional delete if still queued
        if job_status.status in ["Created", "Pending"]:
            scheduler.delete_job(job_id)
            print("Job deleted.")

        print("Job workflow completed successfully!")

    except requests.exceptions.HTTPError as e:
        print(f"API error: {e.response.status_code} - {e.response.text}", file=sys.stderr)
        sys.exit(1)
    except APIError as e:
        print(f"API Error: {e}", file=sys.stderr)
        sys.exit(1)
    except Exception as e:
        print(f"Error: {e}", file=sys.stderr)
        sys.exit(1)
    finally:
        scheduler.close()
        management.close()


if __name__ == "__main__":
    main()
