from dataclasses import dataclass, asdict, field
from typing import Optional, Dict, Any, List
import requests
from urllib.parse import urljoin
from .auth import ClientCredentialsAuth


@dataclass
class PaginationInfo:
    next_cursor: Optional[str] = None


@dataclass
class BackendClassRead:
    id: str
    name: str
    type: str  # 'QPU' or 'Simulator'
    description: Optional[str] = None
    queue_depth: Optional[int] = None
    status: Optional[str] = None
    accepting_jobs: Optional[bool] = None
    provider_id: Optional[str] = None


@dataclass
class PaginatedBackendClasses:
    backend_classes: List[BackendClassRead] = field(default_factory=list)
    pagination: PaginationInfo = field(default_factory=PaginationInfo)


@dataclass
class JobCategoryRead:
    id: str
    name: str


@dataclass
class PaginatedJobCategories:
    categories: List[JobCategoryRead] = field(default_factory=list)
    pagination: PaginationInfo = field(default_factory=PaginationInfo)


@dataclass
class OrganizationRead:
    id: str
    name: str


@dataclass
class PaginatedOrganizations:
    organizations: List[OrganizationRead] = field(default_factory=list)
    pagination: PaginationInfo = field(default_factory=PaginationInfo)


@dataclass
class JobPreparationCreate:
    organization_id: str
    backend_class_id: str
    name: str
    job_category_id: str
    job_subcategory_id: str
    shots: int
    upload_endpoint_id: Optional[str] = None
    configuration_data: Dict[str, Any] = field(default_factory=dict)


@dataclass
class JobPreparationUploadResponse:
    id: str
    url: str


@dataclass
class JobPreparationResponse:
    id: str


@dataclass
class QueuePriority:
    queue_priority_id: str
    name: str
    price_increase: float
    description: Optional[str] = None


@dataclass
class ExecutionPlan:
    execution_plan_id: str
    name: str
    price: float
    description: Optional[str] = None
    queue_priorities: List[QueuePriority] = field(default_factory=list)


@dataclass
class JobPreparationResultResponse:
    organization_id: str
    backend_class_id: str
    status: str
    name: str
    job_category_id: str
    job_subcategory_id: str
    shots: int
    input_data_url: Optional[str] = None
    configuration_data: Dict[str, Any] = field(default_factory=dict)
    quote: List[ExecutionPlan] = field(default_factory=list)


@dataclass
class JobCreate:
    organization_id: str
    job_preparation_id: str
    execution_plan_id: str
    queue_priority_id: str


@dataclass
class JobRead:
    id: str
    status: str
    job_preparation_id: str
    execution_plan_id: str
    queue_priority_id: str
    input_data_url: str
    output_data_url: Optional[str] = None
    transaction_id: Optional[str] = None


@dataclass
class JobList:
    id: str
    backend_class_id: str
    name: str
    status: str


@dataclass
class PaginatedJobs:
    jobs: List[JobList] = field(default_factory=list)
    pagination: PaginationInfo = field(default_factory=PaginationInfo)


@dataclass
class ErrorResponse:
    """Dataclass for API error responses."""
    status_code: int
    message: List[str]
    error_code: Optional[str] = None


class APIError(Exception):
    """Custom exception for API errors, wrapping ErrorResponse."""
    def __init__(self, error_response: ErrorResponse):
        self.error_response = error_response
        messages = "; ".join(error_response.message)
        super().__init__(f"API Error {error_response.status_code}: {messages} (Request ID: {error_response.error_code})")


class BaseClient:
    """Base HTTP client for Open Quantum APIs."""

    def __init__(
        self,
        base_url: str,
        token: Optional[str] = None,
        auth: Optional[ClientCredentialsAuth] = None,
        session: Optional[requests.Session] = None,
    ):
        if token and auth:
            raise ValueError("Provide either 'token' or 'auth', not both.")
        self.base_url = base_url.rstrip("/")
        self._fixed_token = token
        self._auth = auth
        self.session = session or requests.Session()
        # Do NOT pin an Authorization header permanently if using auth provider
        if token:
            self.session.headers.update({"Authorization": f"Bearer {token}"})

    def _authorized_headers(self, extra: Optional[Dict[str, str]] = None) -> Dict[str, str]:
        headers = dict(self.session.headers)
        if self._auth:
            headers = self._auth.apply_auth_header(headers)
        # when using fixed token, headers already include Authorization
        if extra:
            headers.update(extra)
        return headers

    def _do_request(self, method: str, url: str, **kwargs) -> requests.Response:
        return self.session.request(method, url, **kwargs)

    def _request(
        self,
        method: str,
        endpoint: str,
        params: Optional[Dict[str, Any]] = None,
        json: Optional[Dict[str, Any]] = None,
        **kwargs,
    ) -> Dict[str, Any]:
        url = urljoin(self.base_url + "/", endpoint.lstrip("/"))
        # first attempt (with current token or fixed token)
        headers = self._authorized_headers(kwargs.pop("headers", None))
        resp = self._do_request(method, url, params=params, json=json, headers=headers, **kwargs)
        # If unauthorized and we have an auth provider, force refresh once and retry
        if resp.status_code == 401 and self._auth:
            # force refresh
            headers = self._authorized_headers()
            headers = self._auth.apply_auth_header(
                {k: v for k, v in headers.items() if k.lower() != "authorization"}
            )
            resp = self._do_request(method, url, params=params, json=json, headers=headers, **kwargs)

        # Parse response: Check for ErrorResponse structure before raising
        if resp.status_code >= 400:
            try:
                error_data = resp.json()
                # Check if it matches ErrorResponse shape (has 'status_code' and 'message')
                if "status_code" in error_data and "message" in error_data:
                    error = ErrorResponse(
                        status_code=error_data.get("status_code", resp.status_code),
                        message=error_data.get("message", []),
                        error_code=error_data.get("error_code")
                    )
                    raise APIError(error)
            except ValueError:
                pass  # Not JSON or not ErrorResponse; fall through to HTTPError
            resp.raise_for_status()  # Raise standard HTTPError if not custom

        if resp.status_code == 204:
            return {}
        return resp.json()

    def close(self):
        self.session.close()


class SchedulerClient(BaseClient):
    """Client for job-related operations in the Open Quantum Scheduler API."""

    def __init__(
        self,
        base_url: str = "https://scheduler.openquantum.com",
        token: Optional[str] = None,
        auth: Optional[ClientCredentialsAuth] = None,
    ):
        super().__init__(base_url, token=token, auth=auth)

    def get_job_categories(self, limit: int = 20, cursor: Optional[str] = None) -> PaginatedJobCategories:
        params = {"limit": limit}
        if cursor:
            params["cursor"] = cursor
        data = self._request("GET", "/v1/jobs/categories", params=params)
        categories = [JobCategoryRead(**cat) for cat in data.get("categories", [])]
        pagination = PaginationInfo(**data.get("pagination", {}))
        return PaginatedJobCategories(categories=categories, pagination=pagination)

    def get_job_subcategories(self, category_id: str, limit: int = 20, cursor: Optional[str] = None) -> PaginatedJobCategories:
        params = {"limit": limit}
        if cursor:
            params["cursor"] = cursor
        data = self._request("GET", f"/v1/jobs/categories/{category_id}/subcategories", params=params)
        categories = [JobCategoryRead(**cat) for cat in data.get("categories", [])]
        pagination = PaginationInfo(**data.get("pagination", {}))
        return PaginatedJobCategories(categories=categories, pagination=pagination)

    def upload_job_input(self, file_content: Optional[bytes] = None, file_path: Optional[str] = None) -> str:
        """Gets an upload endpoint, uploads file content, and returns the upload ID.

        This method streamlines the two-step process of preparing an upload
        and then uploading the file. Provide either byte content or a file path.

        Args:
            file_content: The raw byte content of the file to upload.
            file_path: The local path to the file to upload.
                       Provide either file_content or file_path, not both.

        Returns:
            str: The unique upload ID to be used in 'JobPreparationCreate'.

        Raises:
            ValueError: If neither or both file_content and file_path are provided.
            TypeError: If file_content is provided as 'str' instead of 'bytes'.
            APIError: If the API call to get the upload URL fails.
            requests.exceptions.HTTPError: If the file upload to storage fails.
        """
        if file_content is None and file_path is None:
            raise ValueError("Either file_content (bytes) or file_path (str) must be provided.")
        if file_content is not None and file_path is not None:
            raise ValueError("Provide either file_content or file_path, not both.")

        data_to_upload: bytes
        if file_path:
            with open(file_path, "rb") as f:
                data_to_upload = f.read()
        else:
            if isinstance(file_content, str):
                raise TypeError(
                    "file_content must be bytes, not str. "
                    "Encode your string using .encode('utf-8')."
                )
            data_to_upload = file_content  # type: ignore

        data = self._request("POST", "/v1/jobs/upload")
        upload_details = JobPreparationUploadResponse(**data)

        # We use requests.put() directly to avoid sending session auth.
        upload_resp = requests.put(upload_details.url, data=data_to_upload)

        # Raise an error if the file upload itself failed
        upload_resp.raise_for_status()

        # 3. Return the upload ID for use in job preparation
        return upload_details.id

    def prepare_job(self, preparation: JobPreparationCreate) -> JobPreparationResponse:
        data = self._request("POST", "/v1/jobs/prepare", json=asdict(preparation))
        return JobPreparationResponse(**data)

    def get_preparation_result(self, preparation_id: str) -> JobPreparationResultResponse:
        data = self._request("GET", f"/v1/jobs/prepare/{preparation_id}")
        return JobPreparationResultResponse(**data)

    def create_job(self, job: JobCreate) -> JobRead:
        data = self._request("POST", "/v1/jobs", json=asdict(job))
        return JobRead(**data)

    def get_job(self, job_id: str) -> JobRead:
        data = self._request("GET", f"/v1/jobs/{job_id}")
        return JobRead(**data)

    def delete_job(self, job_id: str) -> None:
        self._request("DELETE", f"/v1/jobs/{job_id}")

    def list_jobs(self, organization_id: str, limit: int = 20, cursor: Optional[str] = None, status: Optional[str] = None) -> PaginatedJobs:
        params = {"limit": limit}
        if cursor:
            params["cursor"] = cursor
        if status:
            params["status"] = status
        data = self._request("GET", f"/v1/organizations/{organization_id}/jobs", params=params)
        jobs = [JobList(**job) for job in data.get("jobs", [])]
        pagination = PaginationInfo(**data.get("pagination", {}))
        return PaginatedJobs(jobs=jobs, pagination=pagination)


class ManagementClient(BaseClient):
    """Minimal client for fetching prerequisites like organizations and backends."""

    def __init__(
        self,
        base_url: str = "https://management.openquantum.com",
        token: Optional[str] = None,
        auth: Optional[ClientCredentialsAuth] = None,
    ):
        super().__init__(base_url, token=token, auth=auth)

    def list_user_organizations(
        self, limit: int = 20, cursor: Optional[str] = None
    ) -> PaginatedOrganizations:
        params = {"limit": limit}
        if cursor:
            params["cursor"] = cursor
        data = self._request("GET", "/v1/users/organizations", params=params)
        organizations = [OrganizationRead(**org) for org in data.get("organizations", [])]
        pagination = PaginationInfo(**data.get("pagination", {}))
        return PaginatedOrganizations(organizations=organizations, pagination=pagination)

    def list_backend_classes(self, limit: int = 20, cursor: Optional[str] = None, provider_id: Optional[str] = None) -> PaginatedBackendClasses:
        params = {"limit": limit}
        if cursor:
            params["cursor"] = cursor
        if provider_id:
            params["provider_id"] = provider_id
        data = self._request("GET", "/v1/backends/classes", params=params)
        backend_classes = [BackendClassRead(**bc) for bc in data.get("backend_classes", [])]
        pagination = PaginationInfo(**data.get("pagination", {}))
        return PaginatedBackendClasses(backend_classes=backend_classes, pagination=pagination)
