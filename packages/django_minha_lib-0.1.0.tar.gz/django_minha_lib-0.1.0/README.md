# django-minha-lib

Este projeto é um teste de criação de uma biblioteca Django.
