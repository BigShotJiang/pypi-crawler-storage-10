import { JupyterFrontEnd, JupyterFrontEndPlugin } from '@jupyterlab/application';
import { INotebookTracker } from '@jupyterlab/notebook';

/**
 * jupyterlab-nbpath
 * Frontend-only JupyterLab extension that injects NBPATH
 * into the kernel of each opened notebook and keeps it updated
 * when kernels restart or notebooks are renamed.
 */
function activate(app: JupyterFrontEnd, tracker: INotebookTracker): void {
  console.log('✅ jupyterlab-nbpath: activated');

  const injectPath = (context: any) => {
    const kernel = context.sessionContext.session?.kernel;
    if (!kernel) return;

    const path = context.path;
    const code = `NBPATH = ${JSON.stringify(path)}`;
    kernel.requestExecute({ code, silent: true });
    console.log(`💡 jupyterlab-nbpath: injected NBPATH → ${path}`);
  };

  const bindToNotebook = (panel: any) => {
    if (!panel) return;
    const { context } = panel;

    // Inject when kernel becomes ready
    context.sessionContext.ready.then(() => injectPath(context));

    // Re-inject on kernel restart or switch
    context.sessionContext.kernelChanged.connect(() => {
      console.log('🔁 jupyterlab-nbpath: kernel changed — reinjecting NBPATH');
      injectPath(context);
    });

    // Re-inject on rename or move
    context.pathChanged.connect(() => {
      console.log('📁 jupyterlab-nbpath: path changed — reinjecting NBPATH');
      injectPath(context);
    });
  };

  // Attach to already-open notebooks
  tracker.forEach(panel => bindToNotebook(panel));

  // Attach to newly opened notebooks
  tracker.widgetAdded.connect((_, panel) => bindToNotebook(panel));
}

const plugin: JupyterFrontEndPlugin<void> = {
  id: 'jupyterlab-nbpath',
  autoStart: true,
  requires: [INotebookTracker],
  activate
};

export default plugin;
