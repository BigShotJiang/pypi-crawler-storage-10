
from denario import Denario

# Instantiate the Denario class
den = Denario(project_dir="project")

input_description = """
Analyze the Hipparcos stellar catalog included in the folder /project/data.
You can make use of libraries such as scipy, pandas or numpy.
Make plots for comparing and showing the results.
You have access to 1 GPU and 8 CPUs.
"""

# Set the input description of the problem
den.set_data_description(input_description)


# Generate an idea using the faster Langgraph backend
den.get_idea(mode="fast",llm='gpt-4.1') 

# # Check literature to assess the novelty of the generated idea
# den.check_idea() 

# exit()

# Generate the methodology to be employed
den.get_method(mode="fast",llm='gpt-4.1-mini') 

# Or alternatively, set a manually created methodology
den.set_method("method.md")

# Carry out the analysis
den.get_results(engineer_model='gpt-4.1',
                researcher_model='o3-mini',
                )

# from denario import Journal

# # Get the paper
# den.get_paper(journal=Journal.AAS, add_citations=True) 

# # Referee the paper
# den.referee(llm='gpt-4.1-mini')
