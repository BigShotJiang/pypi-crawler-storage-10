# Compiler Warnings Analysis - 286 Total

## Summary by Category

| Category | Count | % of Total | Severity | Action |
|----------|-------|------------|----------|--------|
| **Unused Variables** | 186 | 65% | Low | Safe to fix with `#[allow(unused)]` or remove |
| **Unused Imports** | 24 | 8% | Low | Safe to remove |
| **Unused Struct Fields** | 34 | 12% | Medium | May indicate incomplete implementation |
| **Unused Functions/Methods** | 18 | 6% | Medium | Dead code or WIP features |
| **Unused Structs** | 2 | 1% | Medium | Dead code |
| **Unused Constants** | 3 | 1% | Low | Safe to remove |
| **Deprecated Dependencies** | 6 | 2% | Medium | Upgrade `generic-array` to v1.x |
| **Mutable Not Needed** | 3 | 1% | Low | Remove `mut` keyword |
| **Non-local impl** | 1 | <1% | Low | PyO3 macro issue (ignore) |
| **Other** | 9 | 3% | Low | Various |

## Detailed Breakdown

### 1. Unused Variables (186 warnings, 65%)

**Most Common Offenders:**
- `path` (11 occurrences) - Mostly in unimplemented stub functions
- `vectors` (10) - DiskANN/HNSW implementation stubs
- `text` (9) - Text processing stubs
- `db` (8) - Database parameter in stubs
- `storage` (7) - Storage layer parameters
- `py` (7) - Python GIL parameters
- `tenant_id` (6) - Multi-tenancy parameters
- `query` (6) - Search query parameters

**Where They Appear:**
- `src/index/diskann/*.rs` - DiskANN implementation (WIP)
- `src/index/bm25/*.rs` - BM25 search (WIP)
- `src/storage/worker.rs` - Background worker (stub)
- `src/embeddings/batch.rs` - Batch embeddings (stub)
- `src/llm/query_builder.rs` - NL query (stub)
- `src/schema/registry.rs` - Schema operations (stub)

**Fix Strategy:**
```rust
// Option 1: Prefix with underscore (keeps for future use)
fn my_function(_path: &str) { }

// Option 2: Add allow attribute
#[allow(unused_variables)]
fn my_function(path: &str) { }
```

### 2. Unused Imports (24 warnings, 8%)

**Examples:**
- `use crate::types::Result` - Imported but not used
- `use std::collections::HashMap` - Imported for future use
- `use csv::Writer` - CSV export uses WriterBuilder instead
- `use rocksdb::IteratorMode` - Iterator uses different API
- `use pyo3::exceptions::PyException` - Error handling uses other types

**Files Affected:**
- `src/query/executor.rs` - `BinaryOperator`, `Value`, `OrderByExpr`
- `src/storage/iterator.rs` - `IteratorMode`, `Arc`
- `src/index/diskann/*.rs` - Various unused imports
- `src/embeddings/batch.rs` - `Result` import
- `src/crypto/kdf.rs` - `PasswordHash`, `PasswordVerifier`

**Fix Strategy:**
```bash
# Cargo can auto-fix many of these
cargo fix --lib -p percolate-rocks --allow-dirty
```

### 3. Unused Struct Fields (34 warnings, 12%)

**Critical Ones (indicate incomplete features):**
- `BM25Index` fields: `inverted_index`, `scorer`, `tokenizer`, `doc_lengths`, `avg_doc_length` (5 fields)
- `DiskANNGraph` fields: `graph`, `medoid`, `max_degree`, `dim` (4 fields)
- `BackupManager` fields: `bucket`, `temp_dir`, `compression_level`, `chunk_size_bytes` (4 fields)
- `EmbeddingBatcher` fields: `provider`, `batch_size` (2 fields)
- `PrefixIterator` fields: `iter`, `prefix` (2 fields)

**Why They're Unused:**
- Features are stubbed out but not implemented yet
- Struct created with fields for future use
- Implementation deferred to v0.3.0 or later

**Fix Strategy:**
```rust
// Temporary fix - allow unused
#[allow(dead_code)]
struct BM25Index {
    inverted_index: InvertedIndex,
    scorer: BM25Scorer,
    // ...
}

// Or remove if truly not needed
```

### 4. Unused Functions/Methods (18 warnings, 6%)

**Functions:**
- `euclidean_distance`, `compute_distance`, `squared_distance` - Distance metrics
- `add_reverse_edge` - Graph operations
- `is_diverse` - Diversity sampling

**Methods:**
- `BM25Index`: `split`, `stem`, `is_stopword`, `term_score` (tokenization methods)
- `DiskANNWriter`: `write_header`, `write_graph`, `write_vectors` (serialization)
- `DiskANNReader`: `parse_header`, `parse_graph` (deserialization)
- `BackgroundWorker`: `process_tasks`, `execute_task` (async operations)
- `BoundedPriorityQueue`: `new`, `push`, `pop`, `is_empty`, `len`, `into_sorted_vec` (priority queue ops)
- `DiskANNHeader`: `new`, `validate`, `to_bytes`, `from_bytes` (header serialization)

**Why They're Unused:**
- Supporting functions for unimplemented features
- Helper methods that will be used when feature is complete
- Alternative implementations not yet integrated

### 5. Deprecated Dependencies (6 warnings, 2%)

**Issue:**
```
warning: use of deprecated associated function
`chacha20poly1305::aead::generic_array::GenericArray::<T, N>::from_slice`:
please upgrade to generic-array 1.x
```

**Locations:**
- `src/crypto/keypair.rs:182` - Nonce creation
- `src/crypto/keypair.rs:234` - Nonce creation
- `src/crypto/kdf.rs:86` - Key derivation
- `src/crypto/kdf.rs:90` - Nonce creation
- `src/crypto/kdf.rs:146` - Key derivation
- `src/crypto/kdf.rs:148` - Nonce creation

**Fix:**
```toml
# Cargo.toml
[dependencies]
generic-array = "1.0"  # Upgrade from 0.x
```

### 6. Unused Structs (2 warnings, 1%)

- `SearchCandidate` - DiskANN search result type
- `BoundedPriorityQueue` - Priority queue for search

Both are part of unimplemented DiskANN features.

### 7. Unused Constants (3 warnings, 1%)

- `MAGIC` - DiskANN file magic number
- `VERSION` - DiskANN file version
- `HEADER_SIZE` - DiskANN header size

All related to DiskANN file format (not implemented).

## Recommendations by Priority

### High Priority (v0.2.1 - Hot Fixes)

1. **Fix Deprecated Dependencies** (6 warnings)
   - Upgrade `generic-array` to v1.x
   - Update crypto code to use new API
   - Estimated time: 30 minutes

2. **Remove Unused Imports** (24 warnings)
   - Run `cargo fix --lib -p percolate-rocks --allow-dirty`
   - Manual review for complex cases
   - Estimated time: 15 minutes

3. **Fix Unnecessary Mutability** (3 warnings)
   - Remove `mut` keyword where not needed
   - Estimated time: 5 minutes

### Medium Priority (v0.3.0)

4. **Add #[allow(unused)] to WIP Code** (186 + 34 warnings)
   - Annotate stub implementations
   - Indicates "intentionally unused for now"
   - Estimated time: 1 hour

5. **Document Incomplete Features**
   - Add TODO comments explaining what's missing
   - Link to GitHub issues/roadmap
   - Estimated time: 30 minutes

### Low Priority (v1.0.0)

6. **Complete or Remove Stub Code**
   - Implement DiskANN features OR remove entirely
   - Implement BM25 search OR remove
   - Implement Background worker OR remove
   - Decision required: Which features are actually needed?

## Quick Win - Auto-Fixable Warnings

Run this to automatically fix ~29 warnings:

```bash
cargo fix --lib -p percolate-rocks --allow-dirty
```

This will:
- Remove unused imports
- Remove unnecessary `mut` keywords
- Other simple fixes

**After running:** Review changes and commit.

## Module-by-Module Status

| Module | Warnings | Status | Priority |
|--------|----------|--------|----------|
| `src/index/diskann/` | ~80 | Unimplemented | Low - May remove |
| `src/index/bm25/` | ~40 | Unimplemented | Low - May remove |
| `src/storage/worker.rs` | ~15 | Stub | Medium - Needed for async |
| `src/embeddings/batch.rs` | ~10 | Stub | Medium - Needed for perf |
| `src/crypto/*.rs` | 6 | Deprecated API | **High** - Fix now |
| `src/llm/query_builder.rs` | ~8 | Stub | Low - NL queries |
| `src/schema/registry.rs` | ~12 | Partial | Medium - Core feature |
| `src/storage/iterator.rs` | ~8 | Partial | Medium - Core feature |
| Other | ~107 | Mixed | Various |

## Impact on Users

**Current Impact: ZERO**

- All warnings are compile-time only
- No runtime errors or performance issues
- Library functions correctly despite warnings
- PyPI package works fine

**Why Fix Them:**

1. **Code Quality** - Clean code is maintainable code
2. **Signal to Noise** - Real warnings get lost in 286 warnings
3. **Contributor Experience** - New contributors get confused
4. **CI/CD** - Want to enable `deny(warnings)` eventually

## Proposed v0.2.1 Actions

**Quick wins (1 hour total):**

1. Run `cargo fix` (auto-fix 29 warnings)
2. Upgrade `generic-array` to v1.x (6 warnings)
3. Add `#[allow(unused)]` to major stub modules:
   ```rust
   #[cfg(feature = "diskann")]
   #[allow(unused)]
   pub mod diskann;

   #[cfg(feature = "bm25")]
   #[allow(unused)]
   pub mod bm25;
   ```

**Result:** Reduce from 286 → ~150 warnings

**Full cleanup (4 hours):** Reduce to < 50 warnings by v0.3.0
