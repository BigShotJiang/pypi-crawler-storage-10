//! Peer replication with WAL and gRPC streaming.
//!
//! NOTE: Replication disabled for v0.1.0/v0.2.0 - will be implemented separately

pub mod wal;
// TODO(v0.3.0): Re-enable replication modules when protobuf is configured
// pub mod primary;
// pub mod replica;
// pub mod protocol;
pub mod sync;

pub use wal::{WriteAheadLog, WalEntry, WalOperation};
// pub use primary::PrimaryNode;
// pub use replica::ReplicaNode;
pub use sync::SyncStateMachine;
