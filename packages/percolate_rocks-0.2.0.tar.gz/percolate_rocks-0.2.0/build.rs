fn main() -> Result<(), Box<dyn std::error::Error>> {
    // Replication disabled for v0.1.0 - will be implemented separately
    // TODO(v0.2.0): Re-enable when implementing replication feature
    //
    // #[cfg(feature = "python")]
    // {
    //     tonic_build::configure()
    //         .build_server(true)
    //         .build_client(true)
    //         .compile(&["proto/replication.proto"], &["proto"])?;
    // }

    Ok(())
}
