# Summary

- [README](./index.md)
- [DEVELOPMENT](./development.md)
- [ACKNOWLEDGEMENTS](./acknowledgements.md)

---

- [ARCHIVES](./archives.md)
- [CHANGELOG](./CHANGELOG.md)

---

- [EXAMPLES](./examples.md)

---

- [API](./api.md)
- [DEP-GRAPH](./dep-graph.md)

---

- [food-4-thought](./food-4-thought.md)
  - [jiff](./jiff.md)
