# `ryo3-glob`

python + `glob` crate.

`glob`:

- [crates.io](https://crates.io/crates/glob)
- [docs.rs](https://docs.rs/glob)
