Synonym
=======

.. currentmodule:: fastobo.syn
.. automodule:: fastobo.syn


.. autoclass:: Synonym
   :members:
   :special-members:

