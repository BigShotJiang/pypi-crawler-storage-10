"""Test package for neurodatahub-cli."""
