"""Dataset configuration data for neurodatahub-cli."""
