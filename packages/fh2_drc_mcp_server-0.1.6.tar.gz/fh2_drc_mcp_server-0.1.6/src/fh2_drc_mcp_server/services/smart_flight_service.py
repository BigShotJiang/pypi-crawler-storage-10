# -*- coding: utf-8 -*-
"""
智能飞行服务 - 自动判断飞行器状态的智能封装函数
"""
import asyncio
from typing import Any, Dict, Optional
from mcp.server.fastmcp import FastMCP
from ..core.http_client import post_json, put_json
from ..config.settings import (
    USER_TOKEN_FIXED, 
    DEFAULT_MAX_SPEED, 
    DEFAULT_RTH_ALTITUDE, 
    DEFAULT_SECURITY_TAKEOFF_HEIGHT,
    TAKEOFF_WAIT_TIME
)
from ..utils.helpers import auto_fill_device_sn, auto_fill_uuid
from .device_service import cloud_controls_create
from .status_service import get_flight_status
from .flight_service import drone_takeoff

# 获取全局MCP实例
mcp: Optional[FastMCP] = None


def set_mcp_instance(mcp_instance: FastMCP) -> None:
    """设置MCP实例"""
    global mcp
    mcp = mcp_instance


## 智能飞向目标点 - 自动判断状态
async def fly_to_point_smart(
    proj_uuid: str,
    target_latitude: float,
    target_longitude: float,
    target_height: float,
    gateway_sn: Optional[str] = None,
    drone_sn: Optional[str] = None,
    max_speed: int = DEFAULT_MAX_SPEED,
    media_folder_name: Optional[str] = None,
    security_takeoff_height: int = DEFAULT_SECURITY_TAKEOFF_HEIGHT,
    rth_altitude: int = DEFAULT_RTH_ALTITUDE,
    out_of_control_action: str = "ReturnHome",
    commander_flight_mode: int = 1,
    commander_flight_height: float = 100.0,
    rth_mode: int = 1,
    token: str = USER_TOKEN_FIXED,
    auto_acquire_control: bool = True,
) -> Dict[str, Any] | str:
    """
    【智能飞向目标点】自动判断飞行器状态并执行正确操作
    
    🎯 核心功能：无需关心飞行器当前状态，直接说"飞到某个点"即可
    
    ✨ 自动化处理：
       1. 自动查询当前飞行状态
       2. 根据状态自动选择正确的接口：
          • 地面状态 → 自动起飞并飞向目标点
          • 飞行中   → 更新飞行目标点
          • 悬停中   → 创建新的飞行任务
       3. 自动获取飞行控制权
    
    📍 使用场景：
       - "让无人机飞到经纬度(22.793, 114.358)，高度100米"
       - "飞到新的目标点" （无需关心是否已经起飞）
       - AI助手自动控制无人机导航
    
    ⏱️ 执行时间说明：
       - 地面起飞场景：需等待约30秒（设备开机+起飞过程）
       - 空中飞行场景：3-5秒（指令下发时间）
       - 函数会自动处理等待逻辑，确保后续操作安全
    
    🔍 状态判断逻辑：
       情况1 - 地面状态（无飞行任务）
         判断：查询in-flight返回空数据或无flight_task_data
         操作：调用 POST drone-take-off（一键起飞）
         等待：30秒（等待设备开机和起飞）
       
       情况2 - 飞行中（有执行中的fly_to任务）
         判断：fly_to_task存在且status=1（执行中）
         操作：调用 PUT fly-to-points（更新目标点）
         等待：3秒（指令下发确认）
       
       情况3 - 空中悬停（在空中但无fly_to任务）
         判断：flight_task_data存在但fly_to_task为null或已完成
         操作：调用 POST fly-to-points（创建新任务）
         等待：3秒（指令下发确认）
    
    Args:
        proj_uuid: 项目 UUID
        target_latitude: 目标纬度
        target_longitude: 目标经度
        target_height: 目标高度（米）
        gateway_sn: **网关SN/机场SN**；默认取缓存
        drone_sn: **无人机SN**（用于申请控制权）；默认取缓存
        max_speed: 最大飞行速度 (m/s)，默认14
        media_folder_name: 媒体文件夹名称（仅起飞时使用）
        security_takeoff_height: 安全起飞高度（仅起飞时使用）
        rth_altitude: 返航高度（仅起飞时使用）
        out_of_control_action: 失控动作（仅起飞时使用）
        commander_flight_mode: 指点飞行模式（仅起飞时使用）
        commander_flight_height: 指点飞行高度（仅起飞时使用）
        rth_mode: 返航模式（仅起飞时使用）
        token: x-auth-token
        auto_acquire_control: 是否自动获取飞行控制权，默认True
    
    Returns:
        {
            "code": 0,
            "message": "success",
            "data": {
                "action": "takeoff|create_flyto|update_flyto",  # 实际执行的操作
                "flight_id": "...",
                "fly_to_id": "...",
                "status_before": "..."  # 执行前的状态描述
            }
        }
        或错误信息字符串
    
    使用示例：
        # 简单调用，无需关心飞行器状态
        result = await fly_to_point_smart(
            proj_uuid="xxx",
            target_latitude=22.793,
            target_longitude=114.358,
            target_height=100.0
        )
        
        # 如果是地面状态，会自动起飞（等待30秒）
        # 如果在空中，会直接飞向目标点（3秒）
    """
    print("\n" + "=" * 60)
    print("🤖 智能飞向目标点 - 开始执行")
    print("=" * 60)
    
    # 自动填充设备SN
    filled_gateway_sn = auto_fill_device_sn(gateway_sn, use_gateway=True)
    filled_drone_sn = auto_fill_device_sn(drone_sn, use_gateway=False)
    
    if filled_gateway_sn is None:
        return "❌ gateway_sn is required (no previous recommendation found)"
    
    # 步骤1: 查询当前飞行状态
    print("\n📡 步骤1: 查询当前飞行状态...")
    status_result = await get_flight_status(
        proj_uuid=proj_uuid,
        gateway_sn=filled_gateway_sn,
        token=token,
        raw_data=True  # 获取原始数据用于判断
    )
    
    # 解析状态数据
    flight_data = None
    if isinstance(status_result, dict) and status_result.get("code") == 0:
        flight_data = status_result.get("data")
    
    # 步骤2: 根据状态判断并执行相应操作
    action = None
    status_description = None
    result = None
    
    # 情况1: 无飞行任务（地面状态）
    if flight_data is None or not flight_data:
        status_description = "地面状态（无飞行任务）"
        action = "takeoff"
        print(f"📊 当前状态: {status_description}")
        print("🛫 操作: 执行一键起飞...")
        print(f"⏱️  预计耗时: 约{TAKEOFF_WAIT_TIME}秒（设备开机+起飞）")
        
        # 生成媒体文件夹名称
        if media_folder_name is None:
            from datetime import datetime
            timestamp = datetime.now().strftime("%Y%m%d_%H%M")
            media_folder_name = f"{timestamp}_{filled_gateway_sn[-6:]}_MCP"
        
        # 调用一键起飞
        result = await drone_takeoff(
            proj_uuid=proj_uuid,
            media_folder_name=media_folder_name,
            target_height=target_height,
            gateway_sn=filled_gateway_sn,
            drone_sn=filled_drone_sn,
            target_latitude=target_latitude,
            target_longitude=target_longitude,
            security_takeoff_height=security_takeoff_height,
            max_speed=max_speed,
            out_of_control_action=out_of_control_action,
            rth_altitude=rth_altitude,
            commander_flight_mode=commander_flight_mode,
            commander_flight_height=commander_flight_height,
            rth_mode=rth_mode,
            token=token,
            auto_acquire_control=auto_acquire_control,
        )
    
    else:
        # 有飞行任务数据
        flight_task_data = flight_data.get("flight_task_data", {})
        fly_to_task = flight_data.get("fly_to_task")
        flight_id = flight_data.get("flight_id", "")
        task_status = flight_task_data.get("status", -1)
        
        # 情况2: 有执行中的fly_to任务
        if fly_to_task is not None and fly_to_task.get("status") == 1:
            status_description = "飞行中（有执行中的fly_to任务）"
            action = "update_flyto"
            fly_to_id = fly_to_task.get("uuid", "")
            
            print(f"📊 当前状态: {status_description}")
            print(f"🆔 Flight ID: {flight_id}")
            print(f"🆔 FlyTo ID: {fly_to_id}")
            print("✈️  操作: 更新飞行目标点...")
            print("⏱️  预计耗时: 约3秒（指令下发）")
            
            # 步骤2.1: 自动获取飞行控制权
            if auto_acquire_control:
                print("\n🔓 获取飞行控制权...")
                control_result = await cloud_controls_create(
                    proj_uuid=proj_uuid,
                    control_keys=["flight"],
                    drone_sn=filled_drone_sn,
                    token=token
                )
                if isinstance(control_result, str) or (isinstance(control_result, dict) and control_result.get("code") != 0):
                    return f"❌ 获取飞行控制权失败: {control_result}"
                print("✅ 飞行控制权获取成功")
            
            # 调用更新fly_to接口
            body = {
                "fly_to_id": fly_to_id,
                "max_speed": max_speed,
                "start_point": {
                    "latitude": target_latitude,
                    "longitude": target_longitude,
                    "height": target_height,
                },
                "points": [
                    {
                        "latitude": target_latitude,
                        "longitude": target_longitude,
                        "height": target_height,
                    }
                ],
            }
            
            result = await put_json(
                f"/task/api/v1/workspaces/{proj_uuid}/flight-tasks/fly-to-points",
                token,
                body,
            )
            
            # 等待指令下发确认
            if isinstance(result, dict) and result.get("code") == 0:
                print("✅ 目标点更新指令已发送，等待确认（3秒）...")
                await asyncio.sleep(3)
                print("✅ 指令确认完成")
        
        # 情况3: 在空中但无fly_to任务（悬停状态）
        elif task_status == 1:  # status=1表示飞行任务执行中
            status_description = "空中悬停（无fly_to任务）"
            action = "create_flyto"
            
            print(f"📊 当前状态: {status_description}")
            print(f"🆔 Flight ID: {flight_id}")
            print("🚁 操作: 创建新的飞行任务...")
            print("⏱️  预计耗时: 约3秒（指令下发）")
            
            # 步骤3.1: 自动获取飞行控制权
            if auto_acquire_control:
                print("\n🔓 获取飞行控制权...")
                control_result = await cloud_controls_create(
                    proj_uuid=proj_uuid,
                    control_keys=["flight"],
                    drone_sn=filled_drone_sn,
                    token=token
                )
                if isinstance(control_result, str) or (isinstance(control_result, dict) and control_result.get("code") != 0):
                    return f"❌ 获取飞行控制权失败: {control_result}"
                print("✅ 飞行控制权获取成功")
            
            # 调用创建fly_to接口
            body = {
                "device_sn": filled_gateway_sn,
                "max_speed": max_speed,
                "start_point": {
                    "latitude": target_latitude,
                    "longitude": target_longitude,
                    "height": target_height,
                },
                "points": [
                    {
                        "latitude": target_latitude,
                        "longitude": target_longitude,
                        "height": target_height,
                    }
                ],
            }
            
            result = await post_json(
                f"/task/api/v1/workspaces/{proj_uuid}/flight-tasks/fly-to-points",
                token,
                body,
            )
            
            # 等待指令下发确认
            if isinstance(result, dict) and result.get("code") == 0:
                print("✅ 飞行任务已创建，等待确认（3秒）...")
                await asyncio.sleep(3)
                print("✅ 指令确认完成")
        
        else:
            # 其他状态（任务已完成、失败等）
            return f"❌ 飞行器状态异常，无法执行飞行操作\n当前任务状态: {task_status}\n💡 建议: 检查飞行器状态或重新发起任务"
    
    # 步骤3: 返回结果
    print("\n" + "=" * 60)
    if isinstance(result, dict) and result.get("code") == 0:
        print("✅ 智能飞向目标点 - 执行成功")
        print("=" * 60)
        
        # 构造统一的返回格式
        original_data = result.get("data", {})
        enhanced_data = {
            "action": action,
            "status_before": status_description,
            "flight_id": original_data.get("flight_id", original_data.get("fly_to_id", "")),
            "fly_to_id": original_data.get("fly_to_id", ""),
            "target": {
                "latitude": target_latitude,
                "longitude": target_longitude,
                "height": target_height,
            }
        }
        
        return {
            "code": 0,
            "message": "success",
            "data": enhanced_data
        }
    else:
        print("❌ 智能飞向目标点 - 执行失败")
        print("=" * 60)
        return result

