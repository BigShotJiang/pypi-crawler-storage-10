import scrapy
from scrapy.linkextractors import LinkExtractor

from gynews3.model import LinkType
from gynews3.spider.jp import CommonSpider


class Spider(CommonSpider):
    name = "chiebukuro"
    allowed_domains = ["chiebukuro.yahoo.co.jp"]
    start_urls = ["https://chiebukuro.yahoo.co.jp/"]

    link_extractor = LinkExtractor(
        allow_domains=["chiebukuro.yahoo.co.jp"],
        allow=r"/question_detail/",
        unique=True,
    )

    def parse(self, response):
        for link in self.link_extractor.extract_links(response):
            yield scrapy.Request(
                url=link.url,
                callback=self.parse_article,
                cb_kwargs={"linkType": LinkType.ARTICLE},
            )
