import scrapy

from gynews3.model import Link, LinkType
from gynews3.content import create_jp_goose, extract_content


class CommonSpider(scrapy.Spider):
    g = create_jp_goose()

    def parse_article(self, response, linkType: LinkType):
        article = extract_content(self.g, response.text)

        if not article.cleaned_text:
            self.logger.warning(f"No content extracted from {response.url}")
            return

        yield Link(
            type=linkType,
            url=response.url,
            title=article.title,
            content=article.cleaned_text,
        )
