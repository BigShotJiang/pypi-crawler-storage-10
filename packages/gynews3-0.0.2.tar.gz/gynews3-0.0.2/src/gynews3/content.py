import goose3


def create_goose() -> goose3.Goose:
    return goose3.Goose()


def create_jp_goose() -> goose3.Goose:
    import unicodedata
    from goose3.text import StopWords

    class StopWordsJapanese(StopWords):
        _tagger = None

        def __init__(self, language="ja"):
            super().__init__(language)

        @classmethod
        def candidate_words(cls, stripped_input):
            from fugashi import Tagger

            if cls._tagger is None:
                cls._tagger = Tagger()

            s = unicodedata.normalize("NFKC", stripped_input)
            return [el.surface for el in cls._tagger(s)]

    return goose3.Goose({"stopwords_class": StopWordsJapanese})


def extract_content_from_url(g: goose3.Goose, url: str) -> goose3.Article:
    # TODO: handle http proxy
    article = g.extract(url=url)
    return article


def extract_content(g: goose3.Goose, html: str) -> goose3.Article:
    article = g.extract(raw_html=html)
    return article
