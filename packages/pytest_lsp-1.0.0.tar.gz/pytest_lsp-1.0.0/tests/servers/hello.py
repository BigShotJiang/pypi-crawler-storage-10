# Not actually a server, but a script that prints hello world.
print("Hello, world!")
