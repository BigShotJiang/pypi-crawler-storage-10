from django.apps import AppConfig


class BaseModelsTestsConfig(AppConfig):
    name = 'django_basemodels.test_app'
    label = 'django_basemodels_tests'
