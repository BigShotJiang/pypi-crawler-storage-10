default_app_config = "django_basemodels.test_app.apps.BaseModelsTestsConfig"
