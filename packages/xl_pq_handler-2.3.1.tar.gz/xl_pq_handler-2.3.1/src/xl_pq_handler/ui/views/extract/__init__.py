from .view import ExtractView
