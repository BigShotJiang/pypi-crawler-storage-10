# extendedstim

ExtendedStim is a Python package providing tools around circuits, codes, math and physics for stimulation modelling and related research.

Install (from PyPI once published):

    pip install extendedstim

Install locally (build wheel first):

    python -m pip install --upgrade build
    python -m build
    python -m pip install dist\extendedstim-0.1.0-py3-none-any.whl

Quick usage example

```python
import extendstim
print(extendstim.__version__)
# Re-exported subpackages are available:
# from extendstim import Circuit, Code, Math, Physics, Platform
```

License: MIT

