"""
Initialization for the Platform subpackage.
"""

from .Platform import Platform

__all__ = ["Platform"]