import numpy as np

from ..Physics.MajoranaOperator import MajoranaOperator
from ..Physics.PauliOperator import PauliOperator
from ..Math.BinaryArray import BinaryArray as ba


class Platform:
    def __init__(self):
        self.pauli_number = 0
        self.majorana_number = 0
        self.stabilizers_pauli=[]
        self.stabilizers_majorana=[]

    def initialize(self, majorana_number,pauli_number,*args):
        self.pauli_number = pauli_number
        self.majorana_number = majorana_number
        if len(args)==0:
            for i in range(majorana_number):
                self.stabilizers_majorana.append(MajoranaOperator([i],[i],1j))
                self.stabilizers_pauli.append(PauliOperator([], [], 1))
            for i in range(pauli_number):
                self.stabilizers_majorana.append(MajoranaOperator([], [], 1))
                self.stabilizers_pauli.append(PauliOperator([], [i], 1))
        elif len(args)==2:
            self.stabilizers_majorana=args[0]
            self.stabilizers_pauli=args[1]

    def measure(self, op):
        if isinstance(op, PauliOperator):
            stabilizers_now=self.stabilizers_pauli
        elif isinstance(op, MajoranaOperator):
            stabilizers_now=self.stabilizers_majorana
        else:
            raise NotImplementedError
        assert op.is_hermitian

        first_pauli=None
        first_index=-1
        for i in range(len(stabilizers_now)):
            commute_pauli=PauliOperator.commute(op, stabilizers_now[i])
            if not commute_pauli:
                if first_index==-1:
                    first_pauli=stabilizers_now[i]
                    first_index=i
                else:
                    stabilizers_now[i]=stabilizers_now[i]@first_pauli
        if first_index==-1:
            matrix_pauli=PauliOperator.get_matrix(self.stabilizers_pauli,self.pauli_number)
            matrix_majorana=PauliOperator.get_matrix(self.stabilizers_majorana,self.majorana_number)
            matrix=ba.hstack(matrix_majorana,matrix_pauli)
            if isinstance(op,MajoranaOperator):
                vector_majorana=op.get_vector(self.majorana_number)
                vector_pauli=ba.zeros(self.pauli_number*2)
                vector=ba.hstack(vector_majorana,vector_pauli)
            else:
                vector_majorana=ba.zeros(self.majorana_number*2)
                vector_pauli = op.get_vector(self.pauli_number)
                vector=ba.hstack(vector_majorana,vector_pauli)
            result=ba.solve(matrix,vector)
            op_mul_pauli=None
            op_mul_majorana=None
            for i in range(len(result)):
                if result[i]==1:
                    if op_mul_pauli is None:
                        op_mul_pauli=self.stabilizers_pauli[i]
                        op_mul_majorana=self.stabilizers_majorana[i]
                    else:
                        op_mul_pauli=op_mul_pauli@self.stabilizers_pauli[i]
                        op_mul_majorana=op_mul_majorana@self.stabilizers_majorana[i]
            if op_mul_pauli.coff*op_mul_majorana.coff==op.coff:
                return False
            else:
                return True
        else:
            if np.random.rand()<0.5:
                stabilizers_now[first_index]=op
                return False
            else:
                stabilizers_now[first_index]=-op
                return True

    def X(self,qubit_index: int):
        for i in range(len(self.stabilizers_pauli)):
            if self.stabilizers_pauli[i].is_exist_occupy_z(qubit_index) is not None:
                self.stabilizers_pauli[i].coff=-self.stabilizers_pauli[i].coff

    def Y(self,qubit_index: int):
        for i in range(len(self.stabilizers_pauli)):
            if self.stabilizers_pauli[i].is_exist_occupy_x(qubit_index) is not None:
                self.stabilizers_pauli[i].coff=-self.stabilizers_pauli[i].coff
            if self.stabilizers_pauli[i].is_exist_occupy_z(qubit_index) is not None:
                self.stabilizers_pauli[i].coff=-self.stabilizers_pauli[i].coff

    def Z(self,qubit_index: int):
        for i in range(len(self.stabilizers_pauli)):
            if self.stabilizers_pauli[i].is_exist_occupy_x(qubit_index) is not None:
                self.stabilizers_pauli[i].coff=-self.stabilizers_pauli[i].coff

    def H(self,qubit_index: int):
        for i,stabilizer in enumerate(self.stabilizers_pauli):
            assert isinstance(stabilizer, PauliOperator)
            left,middle,right=stabilizer.split(qubit_index)
            if len(middle.occupy_x)==0 and len(middle.occupy_z)==0:
                continue
            elif len(middle.occupy_x)==1 and len(middle.occupy_z)==1:
                continue
            elif len(middle.occupy_x)==0 and len(middle.occupy_z)==1:
                middle.occupy_x=[qubit_index]
                middle.occupy_z=[]
            elif len(middle.occupy_x)==1 and len(middle.occupy_z)==0:
                middle.occupy_x=[]
                middle.occupy_z=[qubit_index]
            else:
                raise ValueError
            self.stabilizers_pauli[i]=left@middle@right

    def U(self,majorana_index: int):
        op=MajoranaOperator([majorana_index],[],1)
        for i,stabilizer in enumerate(self.stabilizers_majorana):
            if MajoranaOperator.commute(stabilizer,op):
                stabilizer.coff=-stabilizer.coff

    def V(self,majorana_index: int):
        op=MajoranaOperator([],[majorana_index],1)
        for i,stabilizer in enumerate(self.stabilizers_majorana):
            if MajoranaOperator.commute(stabilizer,op):
                stabilizer.coff=-stabilizer.coff

    def N(self,majorana_index: int):
        op=MajoranaOperator([majorana_index],[majorana_index],1j)
        for i,stabilizer in enumerate(self.stabilizers_majorana):
            if MajoranaOperator.commute(stabilizer,op):
                stabilizer.coff=-stabilizer.coff

    def P(self,majorana_index: int):
        pass

    def S(self,pauli_index: int):
        for i,stabilizer in enumerate(self.stabilizers_pauli):
            assert isinstance(stabilizer, PauliOperator)
            left,middle,right=stabilizer.split(pauli_index)
            if len(middle.occupy_x)==0:
                continue
            elif len(middle.occupy_x)==1 and len(middle.occupy_z)==0:
                middle.occupy_z=[pauli_index]
                middle.coff=1j
            elif len(middle.occupy_x)==1 and len(middle.occupy_z)==1:
                middle.occupy_z=[]
                middle.coff=1j
            else:
                raise ValueError
            self.stabilizers_pauli[i]=left@middle@right

    def CX(self,control_index,target_index):
        for i,stabilizer in enumerate(self.stabilizers_pauli):
            assert isinstance(stabilizer, PauliOperator)
            left,middle,right=stabilizer.split(control_index)
            if len(middle.occupy_x)==1:
                middle=PauliOperator([control_index,target_index],[],1)
            if target_index>control_index:
                right_left,right_middle,right_right=right.split(target_index)
                if len(right_middle.occupy_z)==1:
                    right_middle=PauliOperator([],[control_index,target_index],1)
                self.stabilizers_pauli[i]=left@middle@right_left@right_middle@right_right
            elif target_index<control_index:
                left_left,left_middle,left_right=left.split(target_index)
                if len(left_middle.occupy_z)==1:
                    left_middle=PauliOperator([],[control_index,target_index],1)
                self.stabilizers_pauli[i]=left_left@left_middle@left_right@middle@right
            else:
                raise ValueError

    def CNX(self,control_index,target_index):
        for i in range(len(self.stabilizers_pauli)):
            stabilizer_pauli=self.stabilizers_pauli[i]
            stabilizer_majorana=self.stabilizers_majorana[i]
            left_control, middle_control, right_control = stabilizer_majorana.split(control_index)
            left_target, middle_target, right_target = stabilizer_pauli.split(target_index)
            majorana_product=PauliOperator([],[], 1)
            pauli_product = MajoranaOperator([], [], 1)
            if len(middle_control.occupy_x)==1:
                majorana_product=PauliOperator([target_index],[], 1)
            if len(middle_control.occupy_z)==1:
                majorana_product=majorana_product@PauliOperator([target_index],[], 1)
            if len(middle_target.occupy_z)==1:
                pauli_product=MajoranaOperator([target_index],[target_index],1j)
            self.stabilizers_pauli[i]=majorana_product@left_target@middle_target@right_target
            self.stabilizers_majorana[i]=left_control@middle_control@right_control@pauli_product

    def CUX(self,control_index,target_index):
        for i in range(len(self.stabilizers_pauli)):
            stabilizer_pauli=self.stabilizers_pauli[i]
            stabilizer_majorana=self.stabilizers_majorana[i]
            left_control, middle_control, right_control = stabilizer_majorana.split(control_index)
            left_target, middle_target, right_target = stabilizer_pauli.split(target_index)
            majorana_product=PauliOperator([],[], 1)
            pauli_product = MajoranaOperator([], [], 1)
            if len(middle_control.occupy_z)==1:
                majorana_product=PauliOperator([target_index],[], 1)
            if len(middle_target.occupy_z)==1:
                pauli_product=MajoranaOperator([control_index],[],1)
            self.stabilizers_pauli[i]=majorana_product@left_target@middle_target@right_target
            self.stabilizers_majorana[i]=left_control@middle_control@right_control@pauli_product

    def CVX(self,control_index,target_index):
        for i in range(len(self.stabilizers_pauli)):
            stabilizer_pauli=self.stabilizers_pauli[i]
            stabilizer_majorana=self.stabilizers_majorana[i]
            left_control, middle_control, right_control = stabilizer_majorana.split(control_index)
            left_target, middle_target, right_target = stabilizer_pauli.split(target_index)
            majorana_product=PauliOperator([],[], 1)
            pauli_product = MajoranaOperator([], [], 1)
            if len(middle_control.occupy_x)==1:
                majorana_product=PauliOperator([target_index],[], 1)
            if len(middle_target.occupy_z)==1:
                pauli_product=MajoranaOperator([],[control_index],1)
            self.stabilizers_pauli[i]=majorana_product@left_target@middle_target@right_target
            self.stabilizers_majorana[i]=left_control@middle_control@right_control@pauli_product

    def x_error(self,pauli_index,p):
        if np.random.rand()<p:
            self.X(pauli_index)

    def y_error(self,pauli_index,p):
        if np.random.rand()<p:
            self.Y(pauli_index)

    def z_error(self,pauli_index,p):
        if np.random.rand()<p:
            self.Z(pauli_index)

    def u_error(self,majorana_index,p):
        if np.random.rand()<p:
            self.U(majorana_index)

    def v_error(self,majorana_index,p):
        if np.random.rand()<p:
            self.V(majorana_index)

    def n_error(self,majorana_index,p):
        if np.random.rand()<p:
            self.N(majorana_index)

    def fermionic_depolarize(self,majorana_index,p):
        if np.random.rand()<p/3:
            self.U(majorana_index)
        if np.random.rand()<p/3:
            self.V(majorana_index)
        if np.random.rand()<p/3:
            self.N(majorana_index)

    def clear(self,op):
        if isinstance(op, PauliOperator):
            stabilizers_now = self.stabilizers_pauli
        elif isinstance(op, MajoranaOperator):
            stabilizers_now = self.stabilizers_majorana
        else:
            raise NotImplementedError
        assert op.is_hermitian

        first_pauli = None
        first_index = -1
        for i in range(len(stabilizers_now)):
            commute_pauli = PauliOperator.commute(op, stabilizers_now[i])
            if not commute_pauli:
                if first_index == -1:
                    first_pauli = stabilizers_now[i]
                    first_index = i
                else:
                    stabilizers_now[i] = stabilizers_now[i] @ first_pauli
        if first_index == -1:
            matrix_pauli = PauliOperator.get_matrix(self.stabilizers_pauli, self.pauli_number)
            matrix_majorana = MajoranaOperator.get_matrix(self.stabilizers_majorana, self.majorana_number)
            if self.pauli_number == 0 and self.majorana_number != 0:
                matrix = matrix_majorana
            elif self.majorana_number == 0 and self.pauli_number != 0:
                matrix = matrix_pauli
            elif self.pauli_number !=0 and self.majorana_number != 0:
                matrix = ba.hstack(matrix_majorana, matrix_pauli)
            else:
                raise NotImplementedError

            if isinstance(op, MajoranaOperator):
                vector_majorana = op.get_vector(self.majorana_number)
                vector_pauli = ba.zeros(self.pauli_number * 2)
                vector = ba.hstack(vector_majorana, vector_pauli)
            else:
                vector_majorana = ba.zeros(self.majorana_number * 2)
                vector_pauli = op.get_vector(self.pauli_number)
                vector = ba.hstack(vector_majorana, vector_pauli)
            result = ba.solve(matrix, vector)
            op_mul_pauli = None
            op_mul_majorana = None
            flag=None
            for i in range(len(result)):
                if result[i] == 1:
                    if op_mul_pauli is None:
                        flag=i
                        op_mul_pauli = self.stabilizers_pauli[i]
                        op_mul_majorana = self.stabilizers_majorana[i]
                    else:
                        op_mul_pauli = op_mul_pauli @ self.stabilizers_pauli[i]
                        op_mul_majorana = op_mul_majorana @ self.stabilizers_majorana[i]
            if op_mul_pauli.coff * op_mul_majorana.coff == op.coff:
                pass
            else:
                assert flag is not None
                self.stabilizers_pauli[flag].coff=-self.stabilizers_pauli[flag].coff
        else:
            stabilizers_now[first_index] = op

    def reset(self,pauli_index):
        op=PauliOperator([],[pauli_index],1)
        self.clear(op)

    def fermionic_reset(self,majorana_index):
        op=MajoranaOperator([majorana_index],[majorana_index],1j)
        self.clear(op)


if __name__ == '__main__':
    from qutip import *
    gamma=tensor(fcreate(1,0)+fdestroy(1,0),identity(2))
    gamma_prime=tensor(1j*fdestroy(1,0)-1j*fcreate(1,0),identity(2))
    X=tensor(identity(2),sigmax())
    Z=tensor(identity(2),sigmaz())
    state00=tensor(basis(2,0),basis(2,0))
    state10=tensor(basis(2,1),basis(2,0))
    state01=tensor(basis(2,0),basis(2,1))
    state11=tensor(basis(2,1),basis(2,1))
    CUX=(state10+state00)@((state10+state00).dag())/2
    CUX+=(state11+state01)@((state11+state01).dag())/2
    CUX+=(state10-state00)@((state11-state01).dag())/2
    CUX+=(state11-state01)@((state10-state00).dag())/2
    CVX=(state00-1j*state10)@((state00-1j*state10).dag())/2
    CVX+=(state01-1j*state11)@((state01-1j*state11).dag())/2
    CVX+=(state00+1j*state10)@((state01+1j*state11).dag())/2
    CVX+=(state01+1j*state11)@((state00+1j*state10).dag())/2
    CNX= state00 @ state00.dag()
    CNX+=state01@state01.dag()
    CNX+=state10@state11.dag()
    CNX+=state11@state10.dag()
    all_list=[gamma,gamma_prime,X,Z,gamma@gamma_prime,gamma@X,gamma@Z,gamma_prime@X,gamma_prime@Z,X@Z,1j*gamma@gamma_prime@Z]
    name=['gamma','gamma_prime','X','Z','gamma@gamma_prime','gamma@X','gamma@Z','gamma_prime@X','gamma_prime@Z','X@Z','gamma@gamma_prime@Z']
    target=CNX@Z@CNX.dag()
    for i in range(len(all_list)):
        if (all_list[i]-target).norm()<1e-5:
            print(name[i],1)
        elif (-all_list[i]-target).norm()<1e-5:
            print(name[i],-1)
