import copy

import qiskit
import numpy as np
import stim
from qiskit.circuit import CircuitError
from qiskit.circuit.library import XGate

from ..Physics.MajoranaOperator import MajoranaOperator
from ..Physics.PauliOperator import PauliOperator
from ..Platform.Platform import Platform


class Circuit:
    gate_dictionary = {
        'R': None,
        'FR': None,
        'X': None,
        'Y': None,
        'Z': None,
        'U': None,
        'V': None,
        'N': None,
        'H': None,
        'S': None,
        'P': None,
        'CX': None,
        'CUX': None,
        'CVX': None,
        'CNX': None,
        'DEPOLARIZE1': None,
        'FDEPOLARIZE1': None,
        'MZ': None,
        'MN': None,
        'MPP': None,
        'FMPP': None,
        'DETECTOR': None,
        'OBSERVABLE_INCLUDE': None,
    }

    gate_hide_dictionary = {
        'R': None,
        'FR': None,
        'X': None,
        'Y': None,
        'Z': None,
        'U': None,
        'V': None,
        'N': None,
        'H': None,
        'S': None,
        'P': None,
        'CX': None,
        'CUX': None,
        'CVX': None,
        'CNX': None,
        'X_ERROR': None,
        'Y_ERROR': None,
        'Z_ERROR': None,
        'U_ERROR': None,
        'V_ERROR': None,
        'N_ERROR': None,
        'M_ERROR': None,
        'MPP': None,
        'DETECTOR': None,
        'OBSERVABLE_INCLUDE': None,
    }

    def __init__(self):
        self.majorana_number = 0
        self.pauli_number = 0
        self.sequence = []
        self.noise = []
        self.measurements = []
        self.detectors = []
        self.observables = []

    def __getitem__(self, item):
        return self.sequence[item]

    def __setitem__(self, key, value):
        self.sequence[key] = value

    def append(self, name, target, *args):
        if name == 'X' or name == 'Y' or name == 'Z' or name == 'H' or name == 'S':
            assert len(args) == 0
            self.sequence.append({'name': name, 'target': target})

        elif name == 'U' or name == 'V' or name == 'N' or name == 'P':
            assert len(args) == 0
            self.sequence.append({'name': name, 'target': target})

        elif name == 'CX' or name == 'CUX' or name == 'CVX' or name == 'CNX':
            assert len(args) == 0
            assert len(target) == 2
            self.sequence.append({'name': name, 'target': target})

        elif name == 'MZ' or name == 'MN':
            assert len(args) == 0 or len(args) == 1
            if name == 'MZ':
                self.sequence.append({'name': 'MPP', 'target': PauliOperator([], [target], 1)})
            else:
                self.sequence.append({'name': 'MPP', 'target': MajoranaOperator([target], [target], 1j)})
            self.measurements.append(len(self.sequence) - 1)
            if len(args) == 1:
                self.sequence.append({'name': 'M_ERROR', 'p': args[0]})
                self.noise.append(len(self.sequence) - 1)

        elif name == 'DEPOLARIZE1':
            assert len(args) == 1
            self.sequence.append({'name': 'X_ERROR', 'target': target, 'p': args[0] / 3})
            self.noise.append(len(self.sequence) - 1)
            self.sequence.append({'name': 'Y_ERROR', 'target': target, 'p': args[0] / 3})
            self.noise.append(len(self.sequence) - 1)
            self.sequence.append({'name': 'Z_ERROR', 'target': target, 'p': args[0] / 3})
            self.noise.append(len(self.sequence) - 1)

        elif name == 'FDEPOLARIZE1':
            assert len(args) == 1
            self.sequence.append({'name': 'U_ERROR', 'target': target, 'p': args[0] / 3})
            self.noise.append(len(self.sequence) - 1)
            self.sequence.append({'name': 'V_ERROR', 'target': target, 'p': args[0] / 3})
            self.noise.append(len(self.sequence) - 1)
            self.sequence.append({'name': 'N_ERROR', 'target': target, 'p': args[0] / 3})
            self.noise.append(len(self.sequence) - 1)

        elif name == 'MPP':
            self.sequence.append((name, target))
            self.measurements.append(len(self.sequence) - 1)
            if len(args) == 1:
                self.sequence.append({'name': 'M_ERROR', 'p': args[0]})
                self.noise.append(len(self.sequence) - 1)

        elif name == 'DETECTOR':
            assert all(target[i] < 0 for i in range(len(target)))
            together = [len(self.measurements) + temp for temp in target]
            self.detectors.append(together)

        elif name == 'OBSERVABLE_INCLUDE':
            assert all(target[i] < 0 for i in range(len(target)))
            together = [len(self.measurements) + temp for temp in target]
            self.observables.append(together)

        elif name == 'R':
            if isinstance(target, int):
                self.sequence.append({'name': name, 'target': target})
                if target == self.pauli_number:
                    self.pauli_number += 1
                elif target > self.pauli_number or target < 0:
                    raise ValueError("R gate target must be consecutive")
                else:
                    pass

        elif name == 'FR':
            if isinstance(target, int):
                self.sequence.append({'name': name, 'target': target})
                if target == self.majorana_number :
                    self.majorana_number = target+1
                elif target > self.majorana_number or target < 0:
                    raise ValueError("FR gate target must be consecutive")
                else:
                    pass
        else:
            raise NotImplementedError

    def ideal_circuit(self):
        sequence = copy.deepcopy(self.sequence)
        for i in range(len(self.noise)):
            gate = sequence[self.noise[i]]
            assert isinstance(gate, dict)
            gate['p'] = 0
        ideal_circuit = Circuit()
        ideal_circuit.majorana_number = self.majorana_number
        ideal_circuit.pauli_number = self.pauli_number
        ideal_circuit.sequence = sequence
        ideal_circuit.measurements = self.measurements
        ideal_circuit.detectors = self.detectors
        ideal_circuit.observables = self.observables
        ideal_circuit.noise = self.noise
        return ideal_circuit

    def execute(self):
        platform = Platform()
        platform.initialize(self.majorana_number, self.pauli_number)
        measurement_sample = np.empty(len(self.measurements), dtype=bool)
        flag_measurement = 0
        for i, gate in enumerate(self.sequence):
            p = None
            name = gate['name']
            target = gate['target']
            if 'p' in gate:
                p = gate['p']
            if name == 'X':
                platform.X(target)
            elif name == 'Y':
                platform.Y(target)
            elif name == 'Z':
                platform.Z(target)
            elif name == 'H':
                platform.H(target)
            elif name == 'S':
                platform.S(target)
            elif name == 'U':
                platform.U(target)
            elif name == 'V':
                platform.V(target)
            elif name == 'N':
                platform.N(target)
            elif name == 'R':
                platform.reset(target)
            elif name == 'FR':
                platform.fermionic_reset(target)
            elif name == 'X_ERROR':
                assert p is not None
                platform.x_error(target, p)
            elif name == 'Y_ERROR':
                assert p is not None
                platform.y_error(target, p)
            elif name == 'Z_ERROR':
                assert p is not None
                platform.z_error(target, p)
            elif name == 'U_ERROR':
                platform.u_error(target, p)
            elif name == 'V_ERROR':
                platform.v_error(target, p)
            elif name == 'N_ERROR':
                platform.n_error(target, p)
            elif name == 'CX':
                platform.CX(target[0], target[1])
            elif name == 'CUX':
                platform.CUX(target[0], target[1])
            elif name == 'CVX':
                platform.CVX(target[0], target[1])
            elif name == 'CNX':
                platform.CNX(target[0], target[1])
            elif name == 'MPP':
                measurement_sample[flag_measurement] = platform.measure(target)
                flag_measurement += 1
            elif name == 'M_ERROR':
                assert p is not None
                if np.random.rand() < p:
                    measurement_sample[i] = -measurement_sample[i]
            else:
                raise NotImplementedError

        detector_sample = np.empty(len(self.detectors), dtype=bool)
        flag_detector = 0
        for i, detector in enumerate(self.detectors):
            value = None
            for temp in measurement_sample[detector]:
                if value is None:
                    value = temp
                else:
                    value = value ^ temp
            detector_sample[flag_detector] = value
            flag_detector += 1

        observable_sample = np.empty(len(self.observables), dtype=bool)
        flag_observable = 0
        for i, observable in enumerate(self.observables):
            value = None
            for temp in measurement_sample[observable]:
                if value is None:
                    value = temp
                else:
                    value = value ^ temp
            observable_sample[flag_observable] = value
            flag_observable += 1
        return measurement_sample, detector_sample, observable_sample

    def detector_error_model(self) -> stim.DetectorErrorModel:
        ideal_circuit = self.ideal_circuit()
        measurement_sample_origin, detector_sample_origin, observable_sample_origin = ideal_circuit.execute()
        errors = []
        dem_str = ''
        for i in range(len(ideal_circuit.noise)):
            order = ideal_circuit.noise[i]
            gate_ideal = ideal_circuit.sequence[order]
            assert isinstance(gate_ideal, dict)
            gate_ideal['p'] = 1
            gate = self.sequence[order]
            assert isinstance(gate, dict)
            p = gate['p']
            measurement_sample, detector_sample, observable_sample = ideal_circuit.execute()
            detector_sample_diff = [detector_sample_origin[j] ^ detector_sample[j] for j in range(len(detector_sample))]
            observable_sample_diff = [observable_sample_origin[j] ^ observable_sample[j] for j in range(len(observable_sample))]
            errors.append(len(errors))
            detectors_trigger = np.where(np.array(detector_sample_diff) == True)[0]
            observables_trigger = np.where(np.array(observable_sample_diff) == True)[0]
            if len(detectors_trigger) > 0 or len(observables_trigger) > 0:
                temp = f'error({p})'
                for index in detectors_trigger:
                    temp = temp + f' D{index}'
                for index in observables_trigger:
                    temp = temp + f' L{index}'
                dem_str += ('\n' + temp)
            gate_ideal['p'] = 0
        dem = stim.DetectorErrorModel(dem_str)
        return dem

    def compiler_sampler(self):
        dem = self.detector_error_model()
        return dem.compile_sampler()

    def decoder(self, method):
        dem = self.detector_error_model()

    def draw(self, filename):
        # 绘制一个带有barriers和更多寄存器中，绘制一个新的电路
        F = qiskit.QuantumRegister(self.majorana_number, name='F')
        Q = qiskit.QuantumRegister(self.pauli_number, name='Q')
        C = qiskit.ClassicalRegister(1, name='C')
        circuit_qiskit = qiskit.QuantumCircuit(F, Q, C)
        cux = qiskit.circuit.ControlledGate(name='CUX', num_qubits=2, params=[], label=None, num_ctrl_qubits=1, base_gate=XGate())
        cvx = qiskit.circuit.ControlledGate(name='CVX', num_qubits=2, params=[], label=None, num_ctrl_qubits=1, base_gate=XGate())
        cnx = qiskit.circuit.ControlledGate(name='CNX', num_qubits=2, params=[], label=None, num_ctrl_qubits=1, base_gate=XGate())
        x_error = qiskit.circuit.Gate('X', 1, label=None, params=[])
        y_error = qiskit.circuit.Gate('Y', 1, label=None, params=[])
        z_error = qiskit.circuit.Gate('Z', 1, label=None, params=[])
        u_error = qiskit.circuit.Gate('U', 1, label=None, params=[])
        v_error = qiskit.circuit.Gate('V', 1, label=None, params=[])
        n_error = qiskit.circuit.Gate('N', 1, label=None, params=[])
        m_error = qiskit.circuit.Gate('M', 1, label=None, params=[])
        rreset = qiskit.circuit.Gate('R', 1, label=None, params=[])
        for gate in self.sequence:
            if gate['name'] == 'R':
                circuit_qiskit.append(rreset, [Q[gate['target']]])
            elif gate['name'] == 'FR':
                circuit_qiskit.append(rreset, [F[gate['target']]])
            elif gate['name'] == 'X':
                circuit_qiskit.x(Q[gate['target']])
            elif gate['name'] == 'Y':
                circuit_qiskit.y(Q[gate['target']])
            elif gate['name'] == 'Z':
                circuit_qiskit.z(Q[gate['target']])
            elif gate['name'] == 'H':
                circuit_qiskit.h(Q[gate['target']])
            elif gate['name'] == 'S':
                circuit_qiskit.s(Q[gate['target']])
            elif gate['name'] == 'CX':
                circuit_qiskit.cx(Q[gate['target'][0]], Q[gate['target'][1]])
            elif gate['name'] == 'CUX':
                circuit_qiskit.append(cux, [F[gate['target'][0]],Q[gate['target'][1]]])
            elif gate['name'] == 'CVX':
                circuit_qiskit.append(cvx, [F[gate['target'][0]],Q[gate['target'][1]]])
            elif gate['name'] == 'CNX':
                circuit_qiskit.append(cnx, [F[gate['target'][0]],Q[gate['target'][1]]])
            elif gate['name'] == 'MPP':
                op = gate['target']
                if isinstance(op, MajoranaOperator):
                    f_flag_x = op.occupy_x
                    f_flag_z = op.occupy_z
                    f_flag_n = np.intersect1d(f_flag_x, f_flag_z)
                    f_flag_x = np.setdiff1d(f_flag_x, f_flag_n)
                    f_flag_z = np.setdiff1d(f_flag_z, f_flag_n)
                    f = np.concatenate([f_flag_x, f_flag_z, f_flag_n])
                    circuit_qiskit.measure(F[f.tolist()], C[0])
                elif isinstance(op, PauliOperator):
                    p_flag_x = op.occupy_x
                    p_flag_z = op.occupy_z
                    p_flag_y = np.intersect1d(p_flag_x, p_flag_z)
                    p_flag_x = np.setdiff1d(p_flag_x, p_flag_y)
                    p_flag_z = np.setdiff1d(p_flag_z, p_flag_y)
                    p = np.concatenate([p_flag_x, p_flag_y, p_flag_z])
                    circuit_qiskit.measure(Q[p.tolist()], C[0])
                else:
                    raise CircuitError("cannot set parameters on immutable base gate")
            elif gate['name'] == 'M_ERROR':
                circuit_qiskit.append(m_error, [Q[gate['target']]])
            elif gate['name'] == 'X_ERROR':
                circuit_qiskit.append(x_error, [Q[gate['target']]])
            elif gate['name'] == 'Y_ERROR':
                circuit_qiskit.append(y_error, [Q[gate['target']]])
            elif gate['name'] == 'Z_ERROR':
                circuit_qiskit.append(z_error, [Q[gate['target']]])
            elif gate['name'] == 'U_ERROR':
                circuit_qiskit.append(u_error, [Q[gate['target']]])
            elif gate['name'] == 'V_ERROR':
                circuit_qiskit.append(v_error, [Q[gate['target']]])
            elif gate['name'] == 'N_ERROR':
                circuit_qiskit.append(n_error, [Q[gate['target']]])
        red='#E77081'
        blue='#5375CD'
        green='#00857B'
        grey='#8C92AC'
        purple='#5D548C'
        orange='#F15D22'
        pink='#FFACC5'
        cyan='#C9DCC4'
        circuit_qiskit.draw(output='mpl', filename=filename, style={
            'displaycolor': {'X': red, 'Y': red, 'Z': red,
                             'U': red, 'V': red, 'N': red,
                             'M': red, 'R': cyan,'measure':grey,
                             'x':blue, 'y':blue, 'z':blue,'s':blue,
                             'CNX':blue,'CUX':purple,'CVX':pink,
                             'cx':None
                             },
            'fontsize': 15
        })