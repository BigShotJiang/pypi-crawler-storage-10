from abc import abstractmethod
import numpy as np
from .QuantumCode import QuantumCode
from ...Physics.Operator import Operator


class QuantumCSSCode(QuantumCode):
    def __init__(self, generators_x, generators_z, physical_number):
        self.generators_x = np.array(generators_x,dtype=Operator)
        self.generators_z = np.array(generators_z,dtype=Operator)
        self.checker_number_x=len(generators_x)
        self.checker_number_z = len(generators_z)
        super().__init__(generators_x+generators_z, physical_number)

    #%%  USER：属性方法
    @property
    @abstractmethod
    def logical_operators_x(self):
        pass

    @property
    @abstractmethod
    def logical_operators_z(self):
        pass

    @property
    def rank_x(self):
        return self.check_matrix_x.rank

    @property
    def rank_z(self):
        return self.check_matrix_z.rank

    @property
    def check_matrix_x(self):
        matrix=Operator.get_matrix(self.generators_x,self.physical_number)
        return matrix

    @property
    def check_matrix_z(self):
        matrix=Operator.get_matrix(self.generators_z,self.physical_number)
        return matrix

    @property
    @abstractmethod
    def distance_x(self):
        pass

    @property
    @abstractmethod
    def distance_z(self):
        return 1
