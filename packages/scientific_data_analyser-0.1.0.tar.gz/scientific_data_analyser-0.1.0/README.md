# scientific_data_analyser

Outils d'analyse et de traitement de données pour projets scientifiques.

## Installation locale
```bash
pip install -e .