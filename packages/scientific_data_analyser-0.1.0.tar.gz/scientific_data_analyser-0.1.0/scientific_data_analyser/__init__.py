# scientific_data_analyser/__init__.py

from .scientific_analysis import ScientificAnalysis
from .data_utils import get_info_from_data, read_csv, save_csv
from .numeric_ops import fit_data, derivee, integrale_cumulee, lissage_explicite, secante, solve_system_newton, euler_explicit, mask_valid, linear, exp_func, log_func, power_func, root_func, inverse_func

all = [
    "ScientificAnalysis",
    "get_info_from_data", "read_csv", "save_csv",
    "fit_data", "derivee", "integrale_cumulee", "lissage_explicite", "secante", "solve_system_newton", "euler_explicit",
    "mask_valid", "linear", "exp_func", "log_func", "power_func", "root_func", "inverse_func"
]