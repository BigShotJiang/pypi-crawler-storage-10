from scipy.optimize import curve_fit
import numpy as np
# ------------------------------------------------------------
# RÉGRESSION / FIT
# ------------------------------------------------------------
# Masquage NaN
def mask_valid(x, y):
    """Renvoie x et y filtrés pour enlever les NaN"""
    x, y = np.asarray(x), np.asarray(y)
    mask = ~np.isnan(x) & ~np.isnan(y)
    return x[mask], y[mask]

# Modèles non-linéaires
def linear(x, a, b):
    return a * x + b

def exp_func(x, a, b, c):
    return a * np.exp(b * x) + c

def log_func(x, a, b):
    return a * np.log(x) + b

def power_func(x, a, b):
    return a * x ** b

def root_func(x, a, b, n=2):
    return a * x ** (1 / n) + b

def inverse_func(x, a, b, n=1):
    return a * x ** (-n) + b


# Dictionnaire global des modèles
MODEL_DICT = {
    'linear': (linear, [1, 0]),
    'exp': (exp_func, [1, 0.1, 0]),
    'log': (log_func, [1, 0]),
    'power': (power_func, [1, 1]),
    'root': (lambda x, a, b, n=2: root_func(x, a, b, n), [1, 0]),
    'inverse': (lambda x, a, b, n=1: inverse_func(x, a, b, n), [1, 0]),
}


# FIT OPTIMISÉ
def fit_data(x, y, model='linear', degree=None):
    """
    Ajuste un modèle choisi sur les données (avec NaN filtrés).

    Parameters
    ----------
    x : np.ndarray
        Vecteur abscisse
    y : np.ndarray
        Vecteur ordonnée
    model : str
        Type de modèle : 'linear', 'poly', 'exp', 'log', 'power', 'root', 'inverse'
    degree : int, optionnel
        Degré du polynôme si model='poly' ou puissance fractionnaire

    Returns
    -------
    popt : array
        Paramètres ajustés
    r2 : float
        Coefficient de détermination
    y_pred : array
        Valeurs prédites
    """
    x, y = mask_valid(x, y)
    if len(x) < 2:
        raise ValueError("Pas assez de points valides pour le fit.")

    # ------------------------------
    # Polynôme
    # ------------------------------
    if model == 'poly':
        if degree is None or degree < 1:
            raise ValueError("Spécifie un degré >= 1 pour poly.")
        coeffs = np.polyfit(x, y, degree)
        y_pred = np.polyval(coeffs, x)
        ss_res = np.sum((y - y_pred) ** 2)
        ss_tot = np.sum((y - np.mean(y)) ** 2)
        r2 = 1 - ss_res / ss_tot
        return coeffs, r2, y_pred

    # ------------------------------
    # Modèles non-linéaires
    # ------------------------------
    if model not in MODEL_DICT:
        raise ValueError(f"Modèle '{model}' inconnu. Choisir parmi {list(MODEL_DICT.keys()) + ['poly']}")

    func, p0 = MODEL_DICT[model]

    # Pour root et inverse : utiliser degree comme paramètre optionnel
    if model in ['root', 'inverse'] and degree is not None:
        func = lambda x, a, b: MODEL_DICT[model][0](x, a, b, degree)

    popt, _ = curve_fit(func, x, y, p0=p0, maxfev=10000)
    y_pred = func(x, *popt)
    ss_res = np.sum((y - y_pred) ** 2)
    ss_tot = np.sum((y - np.mean(y)) ** 2)
    r2 = 1 - ss_res / ss_tot
    return popt, r2, y_pred

# ------------------------------------------------------------
# DÉRIVÉE / INTÉGRALE / LISSAGE
# ------------------------------------------------------------
def derivee(x, y):
    """Dérivée première par différences centrées."""
    dydx = np.zeros_like(y)
    dydx[0] = (y[1] - y[0]) / (x[1] - x[0])
    dydx[-1] = (y[-1] - y[-2]) / (x[-1] - x[-2])
    dydx[1:-1] = (y[2:] - y[:-2]) / (x[2:] - x[:-2])
    return dydx

def integrale_cumulee(x, y):
    """Intégrale cumulative (méthode des trapèzes)."""
    integral = np.zeros_like(y)
    for i in range(1, len(x)):
        integral[i] = integral[i-1] + 0.5 * (y[i] + y[i-1]) * (x[i] - x[i-1])
    return integral

def lissage_explicite(y, n_iter=5, alpha=0.25):
    """Lissage explicite simple (moyenne pondérée)."""
    y_smooth = np.copy(y)
    for _ in range(n_iter):
        y_smooth[1:-1] = (1 - alpha) * y_smooth[1:-1] + alpha * 0.5 * (y_smooth[:-2] + y_smooth[2:])
    return y_smooth


# ------------------------------------------------------------
# RÉSOLUTION D'ÉQUATIONS
# ------------------------------------------------------------

def secante(f, x0, x1, tol=1e-6, max_iter=100):
    """
    Résout f(x) = 0 par la méthode de la sécante.

    Parameters
    ----------
    f : callable
        Fonction à résoudre
    x0, x1 : float
        Points de départ
    tol : float
        Tolérance sur |x_n+1 - x_n|
    max_iter : int
        Nombre maximal d'itérations

    Returns
    -------
    x : float
        Racine approchée
    """
    for i in range(max_iter):
        f0, f1 = f(x0), f(x1)
        if abs(f1 - f0) < 1e-14:  # évite division par zéro
            raise ZeroDivisionError("Différence f(x1)-f(x0) trop petite")

        x2 = x1 - f1 * (x1 - x0) / (f1 - f0)
        if abs(x2 - x1) < tol:
            return x2
        x0, x1 = x1, x2

    raise ValueError("Méthode de la sécante non convergée après {} itérations".format(max_iter))

def solve_system_newton(F, X0, tol=1e-6, max_iter=50):
    """Résout F(X)=0 par Newton-Raphson matriciel"""
    X = np.array(X0, dtype=float)
    for _ in range(max_iter):
        F_val = np.array(F(X))
        if np.linalg.norm(F_val) < tol:
            return X
        # Jacobienne approximée numériquement
        J = np.zeros((len(X), len(X)))
        h = 1e-8
        for i in range(len(X)):
            X_eps = X.copy()
            X_eps[i] += h
            J[:, i] = (F(X_eps) - F_val)/h
        delta = np.linalg.solve(J, -F_val)
        X += delta
    raise ValueError("Newton-Raphson non convergé")

def euler_explicit(f, t0, tf, y0, dt):
    t = [t0]
    y = [np.array(y0)]
    while t[-1] < tf:
        y_next = y[-1] + dt * f(t[-1], y[-1])
        t.append(t[-1]+dt)
        y.append(y_next)
    return np.array(t), np.array(y)

