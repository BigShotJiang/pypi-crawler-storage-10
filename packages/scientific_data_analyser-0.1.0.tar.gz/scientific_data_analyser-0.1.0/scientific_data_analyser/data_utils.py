import numpy as np

def get_info_from_data(dico, key, data_list, key_infos):
    data_list = np.ravel(data_list)
    for i, col in enumerate(dico[key].T):
        mask = ~np.isnan(col) & ~np.isnan(data_list)
        if np.allclose(col[mask], data_list[mask], rtol=1e-6, atol=1e-8):
            return dico[key_infos[0]][i], dico[key_infos[1]][i]
    return None, None

def read_csv(file, delimiter=","):
    """Lit un fichier CSV structuré (entêtes + unités + données)."""
    with open(file, 'r', encoding='utf-8') as f:
        header = [h.strip() for h in f.readline().strip().split(delimiter) if h.strip()]
        units = [u.strip() for u in f.readline().strip().split(delimiter) if u.strip()]

    datas = np.genfromtxt(file, delimiter=delimiter, skip_header=2,
                          dtype=float, filling_values=np.nan)
    if datas.shape[0] == len(header):
        datas = datas.T
    if datas.shape[1] > len(header):
        datas = datas[:, :len(header)]

    return {"header": header, "units": units, "datas": datas}

def save_csv(file, header, units, datas, delimiter=","):
    """Sauvegarde les données dans un CSV."""
    with open(file, 'w', encoding='utf-8') as f:
        f.write(delimiter.join(header) + "\n")
        f.write(delimiter.join(units) + "\n")
        np.savetxt(f, datas, delimiter=delimiter, fmt="%.6f", newline='\n')
    print(f"💾 Données sauvegardées dans {file}")
