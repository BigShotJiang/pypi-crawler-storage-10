import numpy as np
import matplotlib.pyplot as plt
from .data_utils import read_csv, save_csv, get_info_from_data
from .numeric_ops import derivee, integrale_cumulee, lissage_explicite, fit_data, secante, solve_system_newton, euler_explicit

class ScientificAnalysis:
    def __init__(self, file, delimiter=","):
        self.file = file
        self.delimiter = delimiter
        self.datas_dict = read_csv(file, delimiter)
        self.header = self.datas_dict["header"]
        self.units = self.datas_dict["units"]
        self.datas = self.datas_dict["datas"]

    # ------------------------------------------------------------
    # ACCÈS AUX DONNÉES
    # ------------------------------------------------------------
    def get_data(self, index):
        return self.datas[:, index]

    # ------------------------------------------------------------
    # MÉTHODES D'ANALYSE NUMÉRIQUE DIRECTES
    # ------------------------------------------------------------
    def fit(self, x, y, model='linear', degree=None):
        """Ajuste un modèle et renvoie (params, R², valeurs ajustées)."""
        return fit_data(x, y, model, degree)

    def derivee(self, x, y):
        """Renvoie la dérivée numérique dy/dx."""
        return derivee(x, y)

    def integrale(self, x, y):
        """Renvoie l’intégrale cumulative."""
        return integrale_cumulee(x, y)

    def lissage(self, y, n_iter=5, alpha=0.25):
        """Renvoie la série lissée (moyenne explicite)."""
        return lissage_explicite(y, n_iter, alpha)

    def secante(self, f, x0, x1, tol=1e-6, max_iter=100):
        return secante(f, x0, x1, tol=1e-6, max_iter=max_iter)

    def solve_system_newton(self, F, X0, tol=1e-6, max_iter=50):
        return solve_system_newton(F, X0, tol=tol, max_iter=max_iter)

    def euler_explicit(self, f, t0, tf, y0, dt):
        return euler_explicit(f, t0, tf, y0, dt)
    # ------------------------------------------------------------
    # VISUALISATION
    # ------------------------------------------------------------
    def plot_datas(self, data_x, array_y, title, plot_type='exp', x_label=None, y_label=None, styles_list=None,
                   xscale='linear', yscale='linear'):

        array_y = np.atleast_2d(np.array(array_y, dtype=float))
        x_title, x_unit = get_info_from_data(self.datas_dict, 'datas', data_x, ['header', 'units'])
        if x_title is None:
            raise ValueError("Colonne d'abscisse non reconnue.")

        plt.close('all')
        plt.figure(figsize=(8, 5))

        default_styles = {
            'exp': {'marker': '+', 'linewidth': 3, 'linestyle': 'none', 'markersize': 12, 'alpha': 1},
            'theo': {'marker': None, 'linestyle': '-.', 'linewidth': 1.8, 'alpha': 0.9},
            'both': {'marker': 'o', 'linestyle': '-', 'linewidth': 1.2, 'alpha': 0.8}
        }
        colors = plt.rcParams['axes.prop_cycle'].by_key()['color']

        for i, y_data in enumerate(array_y):
            y_title, y_unit = get_info_from_data(self.datas_dict, 'datas', y_data, ['header', 'units'])
            if y_title is None:
                raise ValueError("Colonne d'ordonnée non reconnue.")

            if styles_list and i < len(styles_list):
                style_input = styles_list[i]
                style = default_styles.get(style_input, style_input if isinstance(style_input, dict)
                                           else default_styles['exp'])
            else:
                style = default_styles.get(plot_type, default_styles['exp'])

            plt.plot(data_x, y_data, color=colors[i % len(colors)],
                     label=f"{y_title} ({y_unit})", **style)

        plt.xlabel(x_label or f"{x_title} [{x_unit}]")
        plt.ylabel(y_label or f"{y_title} [{y_unit}]")
        plt.title(title)
        plt.xscale(xscale)
        plt.yscale(yscale)
        plt.legend()
        plt.grid(True, which='both', linestyle='--', linewidth=0.5)
        plt.tight_layout()
        plt.show(block=True)

    # ------------------------------------------------------------
    # AJOUT / SAUVEGARDE
    # ------------------------------------------------------------
    def new_data(self, data_infos, f, *args, save=True):
        header, unit = data_infos
        mask_valid = ~np.all(np.isnan(self.datas), axis=0)
        self.datas = self.datas[:, mask_valid]
        self.header = [h for i, h in enumerate(self.header) if mask_valid[i]]
        self.units = [u for i, u in enumerate(self.units) if mask_valid[i]]

        n = len(args[0])
        if not all(len(a) == n for a in args):
            raise ValueError("Colonnes de longueurs différentes.")

        new_col = np.asarray(f(*args), dtype=float)
        if len(new_col) != n:
            raise ValueError("Nouvelle colonne incompatible.")
        if header in self.header:
            raise ValueError(f"Colonne '{header}' existe déjà.")

        self.header.append(header)
        self.units.append(unit)
        self.datas = np.column_stack((self.datas, new_col))
        self.datas_dict = {'header': self.header, 'units': self.units, 'datas': self.datas}

        if save:
            self.save()

    def save(self):
        save_csv(self.file, self.header, self.units, self.datas, self.delimiter)
