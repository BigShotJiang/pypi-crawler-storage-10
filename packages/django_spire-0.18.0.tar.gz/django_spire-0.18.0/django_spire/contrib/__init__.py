from django_spire.contrib.breadcrumb.breadcrumbs import Breadcrumbs

__all__ = [
    'Breadcrumbs'
]