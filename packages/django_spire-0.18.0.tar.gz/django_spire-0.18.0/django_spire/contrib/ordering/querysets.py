from django.db.models import QuerySet, F


class OrderingQuerySetMixin(QuerySet):
    pass
