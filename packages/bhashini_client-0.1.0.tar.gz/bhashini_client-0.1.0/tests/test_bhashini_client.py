from bhashini_client import BhashiniClient

def test_client_init():
    client = BhashiniClient(api_key="test-key")
    assert client is not None
