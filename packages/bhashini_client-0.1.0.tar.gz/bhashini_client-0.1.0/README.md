# bhashini-client

A simple Python client library for interacting with [Bhashini](https://bhashini.gov.in/) inference APIs.  
Currently supports:
- **ASR** (Automatic Speech Recognition)
- **NMT** (Machine Translation)
- **TTS** (Text-to-Speech)

---

## 🚀 Installation

```bash
pip install bhashini-client
