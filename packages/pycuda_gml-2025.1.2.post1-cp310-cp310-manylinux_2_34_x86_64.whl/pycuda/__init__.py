from __future__ import annotations


VERSION = (2025, 1, 2)
VERSION_STATUS = "-post1"
VERSION_TEXT = ".".join(str(x) for x in VERSION) + VERSION_STATUS
