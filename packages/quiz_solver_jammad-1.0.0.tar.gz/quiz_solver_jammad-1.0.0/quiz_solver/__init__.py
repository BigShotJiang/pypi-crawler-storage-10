"""
Quiz Solver - A library to automatically solve online quizzes
"""

from .core import QuizSolver
from .parsers import QuizParser
from .search import AnswerSearcher
from .database import AnswerDatabase

__version__ = "1.0.0"
__author__ = "Your Name"
__description__ = "Automated quiz solver using web scraping and search"

__all__ = ['QuizSolver', 'QuizParser', 'AnswerSearcher', 'AnswerDatabase']