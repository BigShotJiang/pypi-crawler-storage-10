# Quiz Solver 🎯

A Python library that automatically extracts questions from educational websites and finds answers using web search.

## Features

- 🔍 **Web Scraping**: Extracts questions and options from quiz pages
- 🤖 **Auto-Search**: Automatically searches for answers online
- 📊 **Multiple Formats**: Supports multiple choice and open-ended questions
- 💾 **Local Database**: Caches answers for faster retrieval
- ⚡ **Easy to Use**: Simple API and command-line interface

## Installation

```bash
pip install quiz-solver