"""
Documentation package for quiz-solver library.

This package contains usage examples and documentation.
"""

__version__ = "1.0.0"