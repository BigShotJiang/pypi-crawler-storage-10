import sys
import os

sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), '..')))

from quiz_solver import QuizSolver
from unittest.mock import patch, MagicMock


def test_quiz_solver_initialization():
    """Test that QuizSolver initializes correctly"""
    solver = QuizSolver()
    assert solver is not None
    assert hasattr(solver, 'parser')
    assert hasattr(solver, 'searcher')
    print("✅ QuizSolver initialization test passed!")


def test_url_fetching():
    """Test URL fetching functionality"""
    solver = QuizSolver()

    # Test with a mock to avoid network issues
    with patch('quiz_solver.core.requests.get') as mock_get:
        # Mock a successful response
        mock_response = MagicMock()
        mock_response.text = "<html><body>Test content</body></html>"
        mock_response.raise_for_status.return_value = None
        mock_get.return_value = mock_response

        content = solver._fetch_url("https://example.com")
        assert content is not None
        assert "Test content" in content
        print("✅ URL fetching test passed!")


def test_url_fetching_failure():
    """Test URL fetching error handling"""
    solver = QuizSolver()

    with patch('quiz_solver.core.requests.get') as mock_get:
        # Mock a failed request
        mock_get.side_effect = Exception("Network error")

        content = solver._fetch_url("https://invalid-url.com")
        assert content is None
        print("✅ URL fetching error handling test passed!")


if __name__ == "__main__":
    test_quiz_solver_initialization()
    test_url_fetching()
    test_url_fetching_failure()
    print("All core tests passed! 🎉")