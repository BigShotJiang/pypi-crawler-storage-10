import sys
import os

sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), '..')))

from quiz_solver.search import AnswerSearcher


def test_searcher_initialization():
    """Test that AnswerSearcher initializes correctly"""
    searcher = AnswerSearcher()
    assert searcher is not None
    assert hasattr(searcher, 'cache')
    assert isinstance(searcher.cache, dict)
    print("✅ Searcher initialization test passed!")


def test_build_search_query():
    """Test search query building"""
    searcher = AnswerSearcher()

    # Test with question only
    question = "What is the capital of France?"
    query = searcher._build_search_query(question, None)
    assert "What is the capital of France?" in query
    assert "answer" in query
    print("✅ Search query with question only passed!")

    # Test with question and options
    options = ["A) Paris", "B) London", "C) Berlin"]
    query_with_options = searcher._build_search_query(question, options)
    assert "Paris" in query_with_options
    assert "London" in query_with_options
    print("✅ Search query with options passed!")


def test_cache_functionality():
    """Test caching mechanism"""
    searcher = AnswerSearcher()

    question = "Test question?"
    options = ["A) Test1", "B) Test2"]

    # First call should not be in cache
    cache_key = question + str(options)
    assert cache_key not in searcher.cache

    # After calling find_answer, it should be cached
    # Note: We're not actually performing search in tests to avoid network calls
    print("✅ Cache functionality structure test passed!")


def test_extract_potential_answers():
    """Test answer extraction from content"""
    searcher = AnswerSearcher()

    # Test content with answer patterns
    test_content = """
    The correct answer is B. Paris is the capital of France.
    Option A is incorrect, Option C is also wrong.
    The answer is definitely B.
    """

    question = "What is the capital of France?"
    options = ["A) London", "B) Paris", "C) Berlin"]

    answers = searcher._extract_potential_answers(test_content, question, options)

    assert "B) Paris" in answers
    assert len(answers) > 0
    print("✅ Answer extraction from content passed!")


def test_answer_pattern_matching():
    """Test various answer pattern matching"""
    searcher = AnswerSearcher()

    test_cases = [
        ("The answer is A", ["A) Correct", "B) Wrong"], ["A) Correct"]),
        ("Correct option: B", ["A) Wrong", "B) Right"], ["B) Right"]),
        ("Option C is correct", ["A) No", "B) No", "C) Yes"], ["C) Yes"]),
    ]

    for content, options, expected in test_cases:
        answers = searcher._extract_potential_answers(content, "Test question?", options)
        for exp in expected:
            if exp in answers:
                print(f"✅ Pattern matching for '{exp}' passed!")

    print("✅ All answer pattern matching tests passed!")


if __name__ == "__main__":
    test_searcher_initialization()
    test_build_search_query()
    test_cache_functionality()
    test_extract_potential_answers()
    test_answer_pattern_matching()
    print("\n🎉 All search tests passed!")