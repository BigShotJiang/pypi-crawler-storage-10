"""
Test package for quiz-solver library.

This package contains all unit tests for the quiz-solver components.
"""

__version__ = "1.0.0"