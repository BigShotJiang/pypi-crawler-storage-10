"""允许通过 `python -m vibego_cli` 直接调用 CLI。"""

from __future__ import annotations

from . import main

if __name__ == "__main__":
    main()

