def available_codecs():
    return "mp3", "aac"


def available_formats():
    return "mp3", "aac"
