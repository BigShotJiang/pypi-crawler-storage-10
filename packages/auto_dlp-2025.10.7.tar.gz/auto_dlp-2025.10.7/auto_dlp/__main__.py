from auto_dlp import command_entry_point

if __name__ == "__main__":
    command_entry_point()
