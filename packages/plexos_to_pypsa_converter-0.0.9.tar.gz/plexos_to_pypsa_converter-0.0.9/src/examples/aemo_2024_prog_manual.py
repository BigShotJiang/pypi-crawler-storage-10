"""AEMO 2024 Progressive Change example (manual workflow).

This script demonstrates both chronological and investment-period setup paths.
Set ``USE_INVESTMENT_PERIODS`` below to switch between modes.
"""

import sys
from pathlib import Path

from pypsa import Network

from network.conversion import create_model
from network.generators_csv import (
    apply_generator_units_timeseries_csv,
    load_data_file_profiles_csv,
)
from network.investment import (
    configure_investment_periods,
    get_snapshot_timestamps,
    load_manifest,
)
from network.outages import (
    apply_outage_schedule,
    build_outage_schedule,
    generate_stochastic_outages_csv,
)
from network.storage_csv import add_storage_inflows_csv
from workflow.steps import prepare_investment_periods_step

MODEL_ID = "aemo-2024-isp-progressive-change"
SOLVER_CONFIG = {
    "solver_name": "gurobi",
    "solver_options": {
        "Threads": 6,
        "Method": 2,
        "Crossover": 0,
        "BarConvTol": 1.0e-5,
        "Seed": 123,
        "AggFill": 0,
        "PreDual": 0,
        "GURO_PAR_BARDENSETHRESH": 200,
    },
}
XML_CSV_DIR = "src/examples/data/aemo-2024-isp-progressive-change/csvs_from_xml/NEM"
MODEL_PATH = "src/examples/data/aemo-2024-isp-progressive-change"

_INVESTMENT_PERIODS = [
    {"label": "2025", "start_year": 2024, "end_year": 2029},
    {"label": "2030", "start_year": 2030, "end_year": 2034},
    {"label": "2035", "start_year": 2035, "end_year": 2039},
    {"label": "2040", "start_year": 2040, "end_year": 2044},
    {"label": "2045", "start_year": 2045, "end_year": 2049},
    {"label": "2050", "start_year": 2050, "end_year": 2053},
]

_REPRESENTATIVE_PATTERNS = {
    "Hot Day": ["Hot Day"],
    "Typical Summer": ["Typical Summer"],
    "Winter": ["Winter"],
}

# Toggle to switch between chronological and investment-period flows
USE_INVESTMENT_PERIODS = True
# Toggle representative-day aggregation within investment-period workflows
USE_REPRESENTATIVE_DAYS = True


def run_investment_period_demo() -> None:
    """Generate manifest, inspect weights, and build investment-period network."""
    summary = prepare_investment_periods_step(
        model_dir=MODEL_PATH,
        timeslice_csv="Traces/timeslice/timeslice_RefYear4006.csv",
        trace_groups=_build_trace_groups(use_representative_days=True),
        periods=_INVESTMENT_PERIODS,
        group_patterns=_REPRESENTATIVE_PATTERNS,
        default_group="Typical Summer",
        unique_day_labels=False,
    )

    manifest_path = summary["prepare_investment_periods"]["metadata_file"]
    print("Investment period manifest:", manifest_path)
    print("Group weight totals:")
    for group, weights in summary["prepare_investment_periods"]["group_totals"].items():
        print(f"  {group}: {weights}")

    manifest = load_manifest(manifest_path)
    preview_network = Network()
    (
        snapshots,
        period_weights,
        snapshot_weights,
        _,
        period_base_dates,
    ) = configure_investment_periods(
        preview_network,
        manifest,
        Path(manifest_path).parent,
    )

    print(f"\nConstructed MultiIndex with {len(snapshots)} snapshots")
    print("Period weights (years):")
    print(period_weights)
    print("Total snapshot weight (years):", snapshot_weights.sum())
    print("\nPeriod base timestamps (preserved from chronology):")
    meta_periods = manifest.get("_meta", {}).get("period_bases", {})
    for label in sorted(period_base_dates):
        ts = period_base_dates[label]
        meta = meta_periods.get(label, "n/a")
        print(f"  {label}: base={ts}  manifest_meta={meta}")
    print("\nFirst 8 snapshots with real calendar timestamps:")
    print(snapshots[:8])

    network, setup_summary = create_model(
        MODEL_ID,
        use_csv=True,
        use_investment_periods=True,
        investment_manifest=manifest_path,
    )

    print("\nInvestment-period network summary:")
    print("  Loads:", len(network.loads))
    print("  Snapshots:", len(network.snapshots))
    print("  Snapshot mode:", setup_summary.get("snapshots_mode"))
    print("  Summary keys:", list(setup_summary.keys()))

    inflow_summary = add_storage_inflows_csv(
        network=network,
        csv_dir=XML_CSV_DIR,
        inflow_path=MODEL_PATH,
        use_investment_periods=True,
        investment_manifest=manifest_path,
        investment_group="storage_inflows",
    )
    print(
        f"\nStorage inflows (investment-period mode): "
        f"{inflow_summary.get('storage_units_with_inflows', 0)} units updated"
    )

    if "storage_units_without_inflows" in inflow_summary:
        print(
            f"  Units without investment-period inflow match: "
            f"{inflow_summary['storage_units_without_inflows']}"
        )

    print(
        "\nVRE and outage loaders can now accept investment-period manifests via "
        "use_investment_periods=True; they will fall back to chronological data "
        "when representative-day files are unavailable."
    )


def run_chronological_workflow() -> None:
    """Run the original chronological example workflow end-to-end."""
    network_chron, summary_chron = create_model(MODEL_ID, use_csv=True)
    print("Chronological network summary:")
    print("  Loads:", len(network_chron.loads))
    print("  Generators:", len(network_chron.generators))
    print("  Snapshots:", len(network_chron.snapshots))
    print("  Snapshot mode:", summary_chron.get("snapshots_mode"))

    # Load VRE profiles from CSVs, allowing curtailment (p_min_pu = 0)
    load_data_file_profiles_csv(
        network=network_chron,
        csv_dir=XML_CSV_DIR,
        profiles_path=MODEL_PATH,
        property_name="Rating",
        target_property="p_max_pu",
        target_type="generators_t",
        apply_mode="replace",
        scenario=1,
        generator_filter=None,
        carrier_mapping={"Wind": "wind", "Solar": "solar"},
        value_scaling=1.0,
    )

    # Add hydrological inflows to storage units
    add_storage_inflows_csv(
        network=network_chron,
        csv_dir=XML_CSV_DIR,
        inflow_path=MODEL_PATH,
    )

    # Apply generator Units time series (retirements, new builds, capacity scaling)
    apply_generator_units_timeseries_csv(network_chron, XML_CSV_DIR)

    try:
        demand = network_chron.loads_t.p_set.sum(axis=1)
        print(
            f"\nDemand profile: peak={demand.max():.1f} MW, min={demand.min():.1f} MW"
        )
        has_demand = True
    except Exception:  # pragma: no cover - diagnostic path
        print("\nNo demand profile available; maintenance will be uniform")
        demand = None
        has_demand = False

    stochastic_events = generate_stochastic_outages_csv(
        csv_dir=XML_CSV_DIR,
        network=network_chron,
        include_forced=True,
        include_maintenance=True,
        demand_profile=demand if has_demand else None,
        random_seed=42,
        existing_outage_events=None,
        generator_filter=lambda gen: network_chron.generators.at[gen, "carrier"] != "",
    )

    schedule = build_outage_schedule(stochastic_events, network_chron.snapshots)
    apply_outage_schedule(network_chron, schedule)

    network_chron.consistency_check()

    target_year = 2025
    timestamps = get_snapshot_timestamps(network_chron.snapshots)
    snapshots = network_chron.snapshots[timestamps.year == target_year]
    print(
        f"Running optimisation for year {target_year} with {len(snapshots)} snapshots..."
    )
    network_chron.optimize(snapshots=snapshots, **SOLVER_CONFIG)


def run_investment_period_demo_without_representatives() -> None:
    """Demonstrate investment-period run using full chronology (no aggregation)."""
    print(
        "\n=== Investment-period demo without representative days "
        "(full chronological traces) ==="
    )
    summary = prepare_investment_periods_step(
        model_dir=MODEL_PATH,
        timeslice_csv="Traces/timeslice/timeslice_RefYear4006.csv",
        trace_groups=_build_trace_groups(use_representative_days=False),
        periods=_INVESTMENT_PERIODS,
        group_patterns={},
        default_group="base",
        output_subdir="investment_periods_full",
        unique_day_labels=True,
    )

    manifest_path = summary["prepare_investment_periods"]["metadata_file"]
    manifest = load_manifest(manifest_path)
    preview_network = Network()
    (
        snapshots,
        period_weights,
        snapshot_weights,
        _,
        period_base_dates,
    ) = configure_investment_periods(
        preview_network,
        manifest,
        Path(manifest_path).parent,
    )

    print(f"\nConstructed full chronology MultiIndex with {len(snapshots)} snapshots")
    print("Period weights (years):")
    print(period_weights)
    print("Total snapshot weight (years):", snapshot_weights.sum())
    print("First 8 snapshots (no aggregation):")
    print(snapshots[:8])

    network_full, summary_full = create_model(
        MODEL_ID,
        use_csv=True,
        use_investment_periods=True,
        investment_manifest=manifest_path,
    )
    print("\nFull chronology investment-period network summary:")
    print("  Loads:", len(network_full.loads))
    print("  Snapshots:", len(network_full.snapshots))
    print("  Snapshot mode:", summary_full.get("snapshots_mode"))
    print("  Start:", network_full.snapshots[0], "End:", network_full.snapshots[-1])

    add_storage_inflows_csv(
        network=network_full,
        csv_dir=XML_CSV_DIR,
        inflow_path=MODEL_PATH,
        use_investment_periods=True,
        investment_manifest=manifest_path,
        investment_group="storage_inflows",
    )
    apply_generator_units_timeseries_csv(network_full, XML_CSV_DIR)

    print(
        "\nThis path preserves every 30-minute timestep inside each investment period "
        "(no representative-day compression)."
    )


def _build_trace_groups(use_representative_days: bool) -> dict:
    base_groups: dict[str, str | dict[str, str]] = {
        "demand": "Traces/demand",
        "solar": "Traces/solar",
        "wind": "Traces/wind",
        "storage_inflows": {
            "path": "Traces/hydro",
            "pattern": "MonthlyNaturalInflow_*.csv",
        },
        "hydro_rating": {
            "path": "Traces/hydro",
            "pattern": "HydroRating_*.csv",
        },
        "hydro_min_stable": {
            "path": "Traces/hydro",
            "pattern": "HydroMinStable_*.csv",
        },
    }
    return base_groups


if __name__ == "__main__":
    if USE_INVESTMENT_PERIODS:
        if USE_REPRESENTATIVE_DAYS:
            run_investment_period_demo()
        else:
            run_investment_period_demo_without_representatives()
        sys.exit(0)

    run_chronological_workflow()
