"""
Release Version.

Created on 2 Oct 2020

:author: semuadmin (Steve Smith)
:copyright: semuadmin © 2020
:license: BSD 3-Clause
"""

__version__ = "1.0.4"
