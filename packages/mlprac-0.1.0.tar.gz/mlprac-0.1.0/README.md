# mlprac - Machine Learning Practice Notebooks

A comprehensive collection of Jupyter notebooks for practicing machine learning concepts with Python, NumPy, Pandas, and Scikit-learn.

## Installation

Install the package using pip:

```bash
pip install mlprac
```

## Usage

### Download Notebooks

After installation, you can download all practice notebooks to your current working directory:

```bash
mlprac download
```

Or specify a custom destination:

```bash
mlprac download --dest my-notebooks
```

### List Available Notebooks

To see all available notebooks without downloading:

```bash
mlprac download --list
```

### Package Information

Get information about the package:

```bash
mlprac info
```

## Notebook Contents

This package includes 30+ Jupyter notebooks covering:

- **NumPy Basics** (2.ipynb, 2a-2d.ipynb)
  - Array creation and manipulation
  - Indexing and slicing
  - Mathematical operations
  - Broadcasting

- **Linear Regression** (3.ipynb, 3a-3b.ipynb, 3multi.ipynb)
  - Simple linear regression
  - Multiple linear regression
  - Model evaluation

- **Classification Algorithms** (4.ipynb - 7.ipynb series)
  - Logistic regression
  - K-Nearest Neighbors (KNN)
  - Support Vector Machines (SVM)
  - Decision Trees

- **Clustering** (8.ipynb series)
  - K-Means clustering
  - Hierarchical clustering

- **Neural Networks** (9.ipynb series)
  - Basic neural network implementations
  - Deep learning concepts

- **Advanced Topics** (10.ipynb series)
  - Ensemble methods
  - Model optimization

## Requirements

The notebooks use the following Python libraries:
- NumPy
- Pandas
- Matplotlib
- Seaborn
- Scikit-learn

Install them separately:

```bash
pip install numpy pandas matplotlib seaborn scikit-learn jupyter
```

## Python API

You can also use the package programmatically in Python:

```python
import mlprac

# Get the path to notebooks
notebooks_path = mlprac.get_notebooks_path()

# List all available notebooks
notebooks = mlprac.list_notebooks()
for nb in notebooks:
    print(nb)
```

## License

MIT License