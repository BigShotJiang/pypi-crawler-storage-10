"""
mlprac - Machine Learning Practice Notebooks
A collection of Jupyter notebooks for machine learning practice.
"""

__version__ = '0.1.0'
__author__ = 'Yash'
__email__ = '22102074.yash@gmail.com'

from pathlib import Path

# Get the package directory
PACKAGE_DIR = Path(__file__).parent
NOTEBOOKS_DIR = PACKAGE_DIR / 'notebooks'

def get_notebooks_path():
    """Return the path to the notebooks directory."""
    return NOTEBOOKS_DIR

def list_notebooks():
    """List all available notebooks."""
    if NOTEBOOKS_DIR.exists():
        return sorted([nb.name for nb in NOTEBOOKS_DIR.glob('*.ipynb')])
    return []
