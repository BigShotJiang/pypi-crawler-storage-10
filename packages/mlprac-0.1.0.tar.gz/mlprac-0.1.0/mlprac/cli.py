"""Command-line interface for mlprac package."""
import click
import shutil
from pathlib import Path
from . import get_notebooks_path, list_notebooks, __version__


@click.group()
@click.version_option(version=__version__)
def main():
    """mlprac - Machine Learning Practice Notebooks
    
    A collection of Jupyter notebooks for machine learning practice.
    Use 'mlprac download' to save notebooks to your current directory.
    """
    pass


@main.command()
@click.option('--dest', '-d', default='.',
              help='Destination directory (default: current directory)')
@click.option('--list', '-l', 'list_only', is_flag=True,
              help='List available notebooks without downloading')
def download(dest, list_only):
    """Download all ML practice notebooks to the specified directory.
    
    Examples:
        mlprac download              # Download to current directory
        mlprac download -d notebooks # Download to 'notebooks' directory
        mlprac download --list       # List available notebooks
    """
    notebooks = list_notebooks()
    
    if not notebooks:
        click.echo("No notebooks found in the package.", err=True)
        return
    
    if list_only:
        click.echo(f"Available notebooks ({len(notebooks)}):")
        for nb in notebooks:
            click.echo(f"  • {nb}")
        return
    
    # Create destination directory
    dest_path = Path(dest).resolve()
    dest_path.mkdir(parents=True, exist_ok=True)
    
    # Get source directory
    source_path = get_notebooks_path()
    
    click.echo(f"Downloading {len(notebooks)} notebooks to {dest_path}...")
    
    success_count = 0
    for notebook in notebooks:
        src = source_path / notebook
        dst = dest_path / notebook
        
        try:
            shutil.copy2(src, dst)
            click.echo(f"  ✓ {notebook}")
            success_count += 1
        except Exception as e:
            click.echo(f"  ✗ {notebook} - Error: {e}", err=True)
    
    click.echo(f"\nSuccessfully downloaded {success_count}/{len(notebooks)} notebooks!")


@main.command()
def info():
    """Display information about the mlprac package."""
    notebooks = list_notebooks()
    click.echo(f"mlprac version: {__version__}")
    click.echo(f"Total notebooks: {len(notebooks)}")
    click.echo(f"Notebooks location: {get_notebooks_path()}")
    click.echo("\nTo download notebooks, run:")
    click.echo("  mlprac download")


if __name__ == '__main__':
    main()
