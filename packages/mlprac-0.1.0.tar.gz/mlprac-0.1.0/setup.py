"""Setup configuration for mlprac package."""
from setuptools import setup, find_packages
from pathlib import Path

# Read the contents of README file
this_directory = Path(__file__).parent
long_description = (this_directory / "README.md").read_text(encoding='utf-8')

setup(
    name='mlprac',
    version='0.1.0',
    author='Yash',
    author_email='22102074.yash@gmail.com',
    description='A collection of Machine Learning practice notebooks',
    long_description=long_description,
    long_description_content_type='text/markdown',
    # url='https://github.com/agrawal-yash/mlprac',
    packages=find_packages(),
    package_data={
        'mlprac': ['notebooks/*.ipynb'],
    },
    include_package_data=True,
    install_requires=[
        'click>=8.0.0',
    ],
    entry_points={
        'console_scripts': [
            'mlprac=mlprac.cli:main',
        ],
    },
    classifiers=[
        'Development Status :: 3 - Alpha',
        'Intended Audience :: Education',
        'Intended Audience :: Developers',
        'Topic :: Scientific/Engineering :: Artificial Intelligence',
        'License :: OSI Approved :: MIT License',
        'Programming Language :: Python :: 3',
        'Programming Language :: Python :: 3.7',
        'Programming Language :: Python :: 3.8',
        'Programming Language :: Python :: 3.9',
        'Programming Language :: Python :: 3.10',
        'Programming Language :: Python :: 3.11',
    ],
    python_requires='>=3.7',
    keywords='machine-learning jupyter notebooks education',
)
