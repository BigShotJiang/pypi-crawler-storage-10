"""Configuration settings for Brainet."""

import os

# AI Provider Selection
AI_PROVIDER = os.getenv("BRAINET_AI_PROVIDER", "groq")  # "groq" or "ollama"

# Groq API settings (FAST & FREE cloud API - recommended!)
GROQ_CONFIG = {
    "api_key": "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",
    "model": "llama-3.3-70b-versatile",  # FREE tier, 500+ tokens/sec
    "temperature": 0.3
}

# Ollama API settings (Local inference - fallback)
OLLAMA_CONFIG = {
    "model": "llama3.2:1b",  # Fast, small model - good for local inference
    "temperature": 0.3,
    "context_window": 2048
}

# File monitoring settings
WATCH_PATTERNS = ["*.py", "*.js", "*.ts", "*.json"]
IGNORE_PATTERNS = ["*/.git/*", "*/__pycache__/*", "*/node_modules/*", "*/.brainet/*"]

# Performance settings
MAX_FILES_TO_ANALYZE = 50  # Limit file diff analysis for speed
MAX_DIFF_SIZE = 10000  # Max characters per diff

# Context analysis settings
ANALYSIS_CONFIG = {
    "focus_threshold": 15,  # minutes
    "session_gap": 30,     # minutes
    "max_insights": 50,
    "min_confidence": 0.7
}