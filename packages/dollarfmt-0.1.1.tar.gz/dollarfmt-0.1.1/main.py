def main():
    print("Hello from dollarfmt!")


if __name__ == "__main__":
    main()
