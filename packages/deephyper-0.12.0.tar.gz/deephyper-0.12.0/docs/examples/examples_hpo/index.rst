

.. _sphx_glr_examples_examples_hpo:

.. _hpo-examples:

Hyperparameter optimization
---------------------------



.. raw:: html

    <div class="sphx-glr-thumbnails">

.. thumbnail-parent-div-open

.. raw:: html

    <div class="sphx-glr-thumbcontainer" tooltip="Author(s): Romain Egele, Brett Eiffert.">

.. only:: html

  .. image:: /examples/examples_hpo/images/thumb/sphx_glr_plot_hpo_text_classification_thumb.png
    :alt:

  :ref:`sphx_glr_examples_examples_hpo_plot_hpo_text_classification.py`

.. raw:: html

      <div class="sphx-glr-thumbnail-title">Hyperparameter search for text classification</div>
    </div>


.. raw:: html

    <div class="sphx-glr-thumbcontainer" tooltip="Author(s): Romain Egele, Brett Eiffert.">

.. only:: html

  .. image:: /examples/examples_hpo/images/thumb/sphx_glr_plot_hpo_text_classification_with_stopper_thumb.png
    :alt:

  :ref:`sphx_glr_examples_examples_hpo_plot_hpo_text_classification_with_stopper.py`

.. raw:: html

      <div class="sphx-glr-thumbnail-title">Hyperparameter Optimization for Text Classification with Early Discarding</div>
    </div>


.. raw:: html

    <div class="sphx-glr-thumbcontainer" tooltip="In this example, you will learn how to treat the choice of a learning method as just another hyperparameter. We consider the Random Forest (RF) and Gradient Boosting (GB) classifiers from Scikit-Learn on the Airlines dataset.">

.. only:: html

  .. image:: /examples/examples_hpo/images/thumb/sphx_glr_plot_hpo_for_rf_and_overfitting_thumb.png
    :alt:

  :ref:`sphx_glr_examples_examples_hpo_plot_hpo_for_rf_and_overfitting.py`

.. raw:: html

      <div class="sphx-glr-thumbnail-title">Hyperparameter optimization and overfitting</div>
    </div>


.. thumbnail-parent-div-close

.. raw:: html

    </div>


.. toctree::
   :hidden:

   /examples/examples_hpo/plot_hpo_text_classification
   /examples/examples_hpo/plot_hpo_text_classification_with_stopper
   /examples/examples_hpo/plot_hpo_for_rf_and_overfitting

