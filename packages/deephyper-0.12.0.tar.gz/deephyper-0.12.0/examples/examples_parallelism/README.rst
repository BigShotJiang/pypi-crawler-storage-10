.. _parallelism-examples:

Parallelism
-----------
