
{
    "version": "2025.10.29",
    "target": "default",
    "variant": "cpu"
}
