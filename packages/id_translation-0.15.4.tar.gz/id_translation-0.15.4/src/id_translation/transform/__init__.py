"""User-defined transformations of IDs and translations."""

from ._impl.bitmask import BitmaskTransformer

__all__ = [
    "BitmaskTransformer",
]
