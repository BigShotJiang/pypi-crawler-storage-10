__author__ = 'labx'

MENU = "XOPPY MENUS"
