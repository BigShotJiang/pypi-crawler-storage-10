"""
Deprecated worker entrypoint.

This module is no longer used by generated projects. Use your project's
workers/<agent>_worker.py entrypoints instead.
"""

import sys

def main():  # pragma: no cover
    sys.stderr.write(
        "evenage.worker.main is deprecated. Use project-specific workers (workers/<agent>_worker.py).\n"
    )
    raise SystemExit(1)


if __name__ == "__main__":  # pragma: no cover
    main()
