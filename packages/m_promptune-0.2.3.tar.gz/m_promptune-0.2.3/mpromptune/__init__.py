from mpromptune import qEI
