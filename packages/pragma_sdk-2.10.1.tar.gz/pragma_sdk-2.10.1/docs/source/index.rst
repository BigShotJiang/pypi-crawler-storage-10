.. figure:: _static/pragma-logo.png
   :class: pragma-logo


.. rst-class:: description-cls

Pragma SDK for Python


.. rst-class:: get-started-cls

:doc:`Get Started<quickstart>`

.. toctree::
   :hidden:

   installation
   quickstart
   migration
   api
