.. expect: Found an asterisk glued to the left of an inline literal. (emphasis-glued-to-inline-literal)

some words *foo*``backtick-words``.
