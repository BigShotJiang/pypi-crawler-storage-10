Par exemple, traduisez ``:code:`dictionary``` en ``:code:`dictionnaire```.
