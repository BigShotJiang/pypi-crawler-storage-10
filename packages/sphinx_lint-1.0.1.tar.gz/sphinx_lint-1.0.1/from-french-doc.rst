.. expect: found an unbalanced inline literal markup
It also gets this "false positive":
.. expect: default role used

In the following inline literal, one of the backticks is composed with
a grave accent. This is highly subtle, almost invisible, but invalid
rst.

`̀`Parameter.KEYWORD_ONLY``
