import regex as re
from sphinxlint import rst

pat = re.compile(
    r"""
    (?<!\x00) # Both inline markup start-string and end-string must not be preceded by
              # an unescaped backslash

    (?<=             # Inline markup start-strings must:
        ^|           # start a text block
        \s          # or be immediately preceded by whitespace,
    )

    (?P<inline_markup>
        ` # Inline markup start
        \S             # Inline markup start-strings must be immediately followed by
                       # non-whitespace.
                       # The inline markup end-string must be separated by at least one
                       # character from the start-string.
        .*?
        (?<=a |\S) # Inline markup end-strings must be immediately preceded
                      # by non-whitespace.
        `
    )

    (?=       # Inline markup end-strings must
        $|    # end a text block or
        \s|   # be immediately followed by whitespace,
        \x00
    )
    """,
    flags=re.VERBOSE | re.DOTALL,
)

pat = re.compile(
    r"""`.*?(?<=a |\S)`
    """,
    flags=re.VERBOSE | re.DOTALL,
)

# print(re.search(pat, ":literal:`findfa `"))  # Match pas
print(re.search(rst.NORMAL_ROLE_RE, ":literal:`findfa `"))  # Match pas

# print(re.search(r"(?<=a |\S)XX", "a XX"))  # Match

# print(re.search(r"(?<=a |\S)`", "a `"))  # Match
# print(re.search(r"`.*?(?<=a |\S)`", ":literal:`findfa `"))  # Match


# skip = "()+*?[|"
#
# for i in range(127):
#     if chr(i) in skip:
#         continue
#     pattern = rf"(?<=\x{i:02x} |.\S)`$"
#     text = f"foo{chr(i)} `"
#     print(i, chr(i), repr(pattern), repr(text), re.search(pattern, text))
