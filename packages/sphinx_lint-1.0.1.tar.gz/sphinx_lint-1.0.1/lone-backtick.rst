Cependant, les arguments originels d'*args` sont toujours passés au programme.
