# API Reference

```{eval-rst}
.. automodule:: semnet
   :members:
   :undoc-members:
   :show-inheritance:
```