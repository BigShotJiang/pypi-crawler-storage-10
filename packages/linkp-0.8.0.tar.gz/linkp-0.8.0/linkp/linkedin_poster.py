"""LinkedIn posting functionality."""

import requests
import json
import base64


class LinkedInPoster:
    """Post to LinkedIn using the new REST API endpoints."""
    def __init__(self, client_id, client_secret, access_token, owner_urn=None, linkedin_version="202310"):
        self.client_id = client_id
        self.client_secret = client_secret
        self.access_token = access_token
        self.owner_urn = owner_urn  # Can be person or org URN
        self.linkedin_version = linkedin_version
        self.rest_api_base = "https://api.linkedin.com/rest"

    def _get_headers(self, content_type="application/json"):
        return {
            "Authorization": f"Bearer {self.access_token}",
            "Linkedin-Version": self.linkedin_version,
            "X-Restli-Protocol-Version": "2.0.0",
            "Content-Type": content_type,
        }

    def _is_org_urn(self, urn):
        return urn and urn.startswith("urn:li:organization:")

    def initialize_upload(self, image_owner_urn=None):
        # If owner not specified, use the default
        owner_urn = image_owner_urn or self.owner_urn
        if not owner_urn:
            raise RuntimeError("No owner URN specified for image upload.")
        url = f"{self.rest_api_base}/images?action=initializeUpload"
        payload = {"initializeUploadRequest": {"owner": owner_urn}}
        headers = self._get_headers()
        resp = requests.post(url, headers=headers, json=payload)
        resp.raise_for_status()
        data = resp.json()
        upload_url = data["value"]["uploadUrl"]
        image_urn = data["value"]["image"]
        return upload_url, image_urn

    def upload_image(self, image_path, image_owner_urn=None):
        upload_url, image_urn = self.initialize_upload(image_owner_urn)
        headers = {"Authorization": f"Bearer {self.access_token}"}
        with open(image_path, "rb") as f:
            put_resp = requests.put(upload_url, data=f, headers=headers)
            put_resp.raise_for_status()
        return image_urn

    def create_post(self, commentary, image_urn=None, visibility="PUBLIC", owner_urn=None):
        author_urn = owner_urn or self.owner_urn
        if not author_urn:
            raise RuntimeError("No author URN specified for post.")
        url = f"{self.rest_api_base}/posts"
        headers = self._get_headers()
        payload = {
            "author": author_urn,
            "commentary": commentary,
            "visibility": visibility,
            "distribution": {
                "feedDistribution": "MAIN_FEED",
                "targetEntities": [],
                "thirdPartyDistributionChannels": []
            },
            "lifecycleState": "PUBLISHED",
            "isReshareDisabledByAuthor": False,
        }
        if image_urn:
            payload["content"] = {
                "media": [{"id": image_urn}]
            }
        resp = requests.post(url, headers=headers, json=payload)
        resp.raise_for_status()
        return resp.json()

    # Modern replacement for post_with_image
    def post_with_image(self, commentary, image_path, visibility="PUBLIC"):
        image_urn = self.upload_image(image_path)
        return self.create_post(commentary, image_urn=image_urn, visibility=visibility)

    # Modern replacement for post_text_update
    def post_text_update(self, commentary, visibility="PUBLIC"):
        return self.create_post(commentary, visibility=visibility)
