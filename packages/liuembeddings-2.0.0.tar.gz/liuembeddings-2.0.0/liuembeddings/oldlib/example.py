#from liuembeddings import LiuEmbeddings, LiuVectorStore, split_text -> using this
from __init__ import LiuEmbeddings, LiuVectorStore, split_text   #-> delete this line after


# ---------- Step 1: Chunk your text ----------
long_text = "LangChain is an open-source framework." * 50
chunks = split_text(long_text, chunk_size=41, chunk_overlap=2)

# ---------- Step 2: Load embedding model ----------
emb_model = LiuEmbeddings()

# ---------- Step 3: Create Chroma vector store ----------
vectorstore = LiuVectorStore(embedding_model=emb_model, collection_name="my_collection")

# ---------- Step 4: Add chunks to vector store ----------
vectorstore.add_texts(chunks)

# ---------- Step 5: Query ----------
query = "What is LangChain used for?"
results = vectorstore.query(query, n_results=3)

for i, r in enumerate(results, 1):
    print(f"Result {i}:", r[:300])
