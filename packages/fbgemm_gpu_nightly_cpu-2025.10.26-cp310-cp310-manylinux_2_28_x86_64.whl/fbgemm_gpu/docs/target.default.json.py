
{
    "version": "2025.10.26",
    "target": "default",
    "variant": "cpu"
}
