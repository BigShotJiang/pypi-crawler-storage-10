from __future__ import annotations

from module_qc_analysis_tools.cli.main import app

app()
