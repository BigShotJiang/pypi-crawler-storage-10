"""The root of the Mouse Tracking Runtime Python package."""

from importlib import metadata

__version__ = metadata.version("mouse-tracking")
