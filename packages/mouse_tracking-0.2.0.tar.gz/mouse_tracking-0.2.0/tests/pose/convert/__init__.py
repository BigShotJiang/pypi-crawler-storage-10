"""Tests for the pose convert module."""
