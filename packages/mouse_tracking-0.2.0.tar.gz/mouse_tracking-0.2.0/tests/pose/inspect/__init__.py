"""Tests for the post inspect module."""
