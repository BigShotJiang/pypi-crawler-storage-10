"""Tests for the CLI infer module."""
