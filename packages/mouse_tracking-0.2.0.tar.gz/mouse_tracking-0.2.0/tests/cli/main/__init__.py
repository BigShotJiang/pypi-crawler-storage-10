"""Tests for the main cli module."""
