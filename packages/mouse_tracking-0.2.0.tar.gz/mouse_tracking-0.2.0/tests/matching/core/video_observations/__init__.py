"""Tests for the VideoObservations class."""
