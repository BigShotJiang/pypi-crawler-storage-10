"""
WL Commands - Command line interface for project management
"""

__version__ = "0.1.12"

from .commands import Command, register_command
