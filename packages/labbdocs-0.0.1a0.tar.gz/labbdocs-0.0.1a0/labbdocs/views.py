from pathlib import Path

from django.conf import settings
from django.http import Http404, HttpResponse
from django.shortcuts import render
from django.template import Context, Template
from django.urls import reverse

from .doc_parser import DocRender


def _build_docs_context(
    config, topnav_title, doc_name, request, doc_info=None, doc_layout=None
):
    """
    Build common context for documentation views.

    Args:
        config: Configuration data from docs.yaml
        topnav_title: Title for the top navigation
        doc_name: Name of the documentation
        doc_info: Optional document info for specific page rendering
        doc_layout: Optional layout override

    Returns:
        dict: Context dictionary for template rendering
    """
    context = {
        "config": config,
        "topnavTitle": topnav_title,
        "showDrawerToggle": True,
        "doc_name": doc_name,
        "doc_url": request.build_absolute_uri(),
        "llms_txt_url": request.build_absolute_uri(reverse("llms_txt")),
    }

    if doc_info:
        context["doc_info"] = doc_info
        layout = doc_layout or doc_info.get("doc_layout") or "base"
        context["layout_component"] = f"lbdocs.layout.docs.{layout}"
    else:
        context["layout_component"] = "lbdocs.layout.docs.base"

    return context


def docs_view(request, doc_name, path=""):
    """
    Generic documentation view that handles documentation based on LABB_DOCS settings.

    Args:
        request: Django request object
        doc_name: Name of the documentation (must be configured in LABB_DOCS)
        path: Optional path within the documentation
    """
    # Get LABB_DOCS configuration from Django settings
    labb_docs = getattr(settings, "LABB_DOCS", {})

    if doc_name not in labb_docs:
        raise Http404(
            f"Documentation type '{doc_name}' not found in LABB_DOCS configuration"
        )

    doc_config = labb_docs[doc_name]

    # Get the YAML file path from the configuration
    yaml_file_path = doc_config.get("config")
    if not yaml_file_path:
        raise Http404(f"No config path specified for documentation '{doc_name}'")

    # Initialize the DocRender with the YAML file path
    renderer = DocRender(yaml_file_path)

    # Load the docs.yaml file for menu
    docs_data = renderer.docs_data

    path = path or "index"

    # Check if this is a request for raw markdown (.md suffix)
    serve_raw_markdown = path.endswith(".md")
    if serve_raw_markdown:
        # Remove .md suffix for path processing
        path = path[:-3]

    # Get URL prefix from configuration or use default
    url_prefix = doc_config.get("url_prefix", f"/docs/{doc_name}")

    # Construct the full URL path
    url_path = f"{url_prefix}/{path}/"

    # Get document info (without rendering)
    doc_info = renderer.get_doc_info(url_path)

    # If there's an error loading the document, raise 404
    if doc_info.get("error"):
        raise Http404(f"Document not found: {doc_info['error']}")

    # If requesting raw markdown, serve the markdown content rendered with context
    if serve_raw_markdown:
        file_path = Path(doc_info.get("file_path", ""))
        if not file_path.exists():
            raise Http404("Markdown file not found")

        # Read the original markdown content
        with open(file_path, "r", encoding="utf-8") as f:
            markdown_content = f.read()

        # Get title from configuration or use doc_name
        title = doc_config.get("title", doc_name.title())

        context = Context(
            {
                "request": request,
                "doc_info": doc_info,
                "config": docs_data,
                "topnavTitle": title,
            }
        )

        # Render the markdown content as a Django template
        template = Template(markdown_content)
        rendered_markdown = template.render(context)

        return HttpResponse(
            rendered_markdown, content_type="text/markdown; charset=utf-8"
        )

    # Get title and name from configuration or use defaults
    title = doc_config.get("title", doc_name.title())
    name = doc_config.get("name", doc_name)

    # Create context with the document info
    context = _build_docs_context(docs_data, title, name, request, doc_info)

    return render(request, "lbdocs/pages/docs.html", context)


def ui_docs(request, path=""):
    """UI documentation view."""
    return docs_view(request, "ui", path)


def icons_docs(request, path=""):
    """Icons documentation view."""
    return docs_view(request, "icons", path)
