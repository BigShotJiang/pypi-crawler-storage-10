from django import template
from django.template.loader import get_template

from labb.components.registry import ComponentRegistry, load_component_spec
from labbicons.metadata import remix

from ..doc_parser import resolve_file_path_to_url

register = template.Library()


@register.filter
def get_component_spec(component_name):
    """
    Get component specification from the labb registry.
    Usage: {{ "button"|get_component_spec }}
    """
    return load_component_spec(component_name)


@register.simple_tag
def show_component_example(path, style="tab", previewStyle="flex-center"):
    """
    Show a component example by reading from a template file and rendering it.

    Args:
        path (str): Path to the example template relative to lb-examples/
        style (str): Style to display the example (default: "tab")

    Returns:
        str: Rendered component example
    """
    # Get the template for rendering
    template = get_template(f"lb-examples/{path}.html")
    rendered_content = template.render({})

    # Get raw content from the registry
    registry = ComponentRegistry()
    raw_content = registry.get_example_raw_content(path)
    if raw_content is None:
        raise ValueError(f"Template does not exist: {path}")

    # Load the component_example template
    component_example_template = get_template(
        f"cotton/lbdocs/component_example/style/{style}.html"
    )

    # Create context for the component_example template
    context = {
        "slot": rendered_content,
        "code": raw_content,
        "title": path.replace("/", "_").replace("-", "_"),
        "previewStyle": previewStyle,
    }

    # Render the component_example template with the context
    return component_example_template.render(context)


@register.simple_tag
def load_icon_metadata():
    """
    Load icon metadata from the labbicons metadata module and return as a dictionary.
    Usage: {% load_icon_metadata as icons_data %}
    """
    return remix()


@register.simple_tag(takes_context=True)
def doc_url(context, file_path, doc_name=None):
    """
    Resolve a markdown file path to its corresponding URL path.
    Uses the doc_name from context to determine the appropriate URL prefix.

    Args:
        context: Django template context
        file_path (str): Relative path to the markdown file (e.g., "1_getting_started/2_installation.md")

    Usage:
        {% doc_url "1_getting_started/2_installation.md" %}

    Returns:
        str: URL path (e.g., "/docs/ui/getting-started/installation/")
    """
    # Get the doc_name from context to determine URL prefix
    doc_name = doc_name or context.get("doc_name")

    # Map view names to URL prefixes
    url_prefix_map = {
        "ui": "/docs/ui",
        "icons": "/docs/icons",
    }

    if doc_name not in url_prefix_map:
        raise ValueError(
            f"Invalid doc_name: {doc_name} when resolving doc_url for {file_path}"
        )

    url_prefix = url_prefix_map[doc_name]

    # Use the extracted function from doc_parser
    return resolve_file_path_to_url(file_path, url_prefix)


@register.simple_tag
def doc_github_url(component_name):
    """
    Get the GitHub URL for a component.
    Usage: {% doc_github_url "button" %}
    """
    component_name = component_name.replace("c-lb.", "")
    return f"https://github.com/labbhq/labb/tree/main/labb/templates/cotton/lb/{component_name}"
