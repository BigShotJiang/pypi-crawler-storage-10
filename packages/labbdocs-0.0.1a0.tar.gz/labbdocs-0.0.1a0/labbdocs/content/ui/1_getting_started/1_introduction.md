---
title: Introduction
description: Beautiful, accessible, and customizable UI components for your Django projects.
doc_show_toc: False
---

<c-lbdocs.component_example path="introduction/welcome-card" style="stacked" />

The labb Component library provides a comprehensive set of reusable components that combine the power of [Django Cotton](https://django-cotton.com/) with the beautiful styling of [daisyUI 5](https://daisyui.com/docs/intro/). Whether you're building a simple form or a complex dashboard, these components will help you create consistent, professional interfaces quickly.

labb components allow you to write templates using familiar HTML tag structure. Instead of complex template tags or verbose syntax, you can use simple, intuitive component tags that look and feel like regular HTML elements. This makes your templates more readable and maintainable while providing powerful functionality under the hood.

All template tags are rendered on the backend, ensuring fast page loads and excellent SEO. Components work without JavaScript by default, making them accessible and performant out of the box.

## What is labb Component?

labb Component is a Django component library that provides beautiful, accessible, and customizable UI components. Built on top of Django Cotton and styled with Tailwind CSS and daisyUI 5, it offers a modern approach to building Django frontends.

## Key Features

- **Django Cotton Integration**: Components are built using Django Cotton for seamless template composition and reusability. Use familiar HTML tags and attributes to build your components.
- **daisyUI 5 Styling**: Beautiful, consistent styling powered by daisyUI 5 and Tailwind CSS.
- **No JavaScript by Default**: Components work without JavaScript, ensuring accessibility and performance.
- **Backend Rendered**: All template tags are rendered on the server for fast page loads and better SEO.
- **Customizable**: Easy theming and customization through Tailwind 4 CSS variables.
- **CLI Tool**: Built-in CLI for project setup, component inspection, and development workflows.
- **AI and LLM Friendly**: accessible documentation and code examples for AI and LLM use cases.
