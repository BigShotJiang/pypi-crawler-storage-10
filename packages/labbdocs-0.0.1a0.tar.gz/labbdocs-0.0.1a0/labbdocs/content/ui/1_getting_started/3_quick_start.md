---
title: Quick Start
description: Get up and running with labb components in minutes
---

{% load docs_tags %}


Get familiar with labb components through practical examples. This guide assumes you've already completed the <a href="{% doc_url '1_getting_started/2_installation.md' 'ui' %}">installation</a> steps.

## Your First Component

Let's start with a simple button component:

<c-lbdocs.codeblock_title title="templates/hello.html">
{% verbatim %}
```html
{% load lb_tags %}

<!DOCTYPE html>
<html lang="en" {% labb_theme %}>
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Hello labb</title>

    <c-lb.m.dependencies
        setThemeEndpoint="{% url 'set_theme' %}"
    />
</head>
<body class="p-8">
    <c-lb.button variant="primary">Hello, labb!</c-lb.button>
</body>
</html>
```
{% endverbatim %}
</c-lbdocs.codeblock_title>

## Component Variants

Most labb components support different variants for styling:

<c-lbdocs.codeblock_title title="templates/button_variants.html">
```html
<!-- Color variants -->
<c-lb.button variant="primary">Primary</c-lb.button>
<c-lb.button variant="secondary">Secondary</c-lb.button>
<c-lb.button variant="accent">Accent</c-lb.button>
<c-lb.button variant="neutral">Neutral</c-lb.button>

<!-- Style variants -->
<c-lb.button variant="primary" style="outline">Outline</c-lb.button>
<c-lb.button variant="primary" style="ghost">Ghost</c-lb.button>
<c-lb.button variant="primary" style="link">Link</c-lb.button>

<!-- Sizes -->
<c-lb.button variant="primary" size="xs">Extra Small</c-lb.button>
<c-lb.button variant="primary" size="sm">Small</c-lb.button>
<c-lb.button variant="primary" size="md">Medium</c-lb.button>
<c-lb.button variant="primary" size="lg">Large</c-lb.button>
```
</c-lbdocs.codeblock_title>

## Building a Simple Card

Cards are perfect for displaying content with structure:

<c-lbdocs.codeblock_title title="templates/welcome_card.html">
```html
<c-lb.card class="w-96">
    <c-lb.card.body>
        <c-lb.card.title>Getting Started with labb</c-lb.card.title>
        <p>labb provides beautiful, accessible UI components for Django projects.</p>
        <c-lb.card.actions>
            <c-lb.button variant="primary">Learn More</c-lb.button>
            <c-lb.button variant="ghost">Documentation</c-lb.button>
        </c-lb.card.actions>
    </c-lb.card.body>
</c-lb.card>
```
</c-lbdocs.codeblock_title>

## Theme Integration

labb includes built-in theme support:

<c-lbdocs.codeblock_title title="templates/base.html">
{% verbatim %}
```html
{% load lb_tags %}

<!DOCTYPE html>
<html lang="en" {% labb_theme %}>
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>My App</title>

    <c-lb.m.dependencies
        setThemeEndpoint="{% url 'set_theme' %}"
    />
</head>
<body>
    <!-- Theme toggle -->
    <c-lb.toggle
        class="theme-controller"
        value="labb-dark"
        size="sm"
        title="Toggle theme"
    />

    <!-- Your content -->
</body>
</html>
```
{% endverbatim %}
</c-lbdocs.codeblock_title>

The `data-theme` attribute in your base template (as shown in "Your First Component") automatically applies the current theme to all components. For complete theming customization, see <a href="{% doc_url '1_getting_started/4_theming.md' 'ui' %}">Theming</a>.

## Development Workflow

1. **Keep `labb dev` running** in your terminal to watch for changes
2. **Use semantic attributes** like `variant`, `size`, `style` instead of CSS classes when possible
3. **Combine with Tailwind and daisyUI classes** for custom spacing and layout
4. **Check the component documentation** for all available options

## Next Steps

- Learn about <a href="{% doc_url '1_getting_started/5_building_css.md' 'ui' %}">Building CSS</a> to learn how the labb cli builds your CSS
- Check out <a href="{% doc_url '1_getting_started/4_theming.md' 'ui' %}">Theming</a> to customize your design system


You're now ready to build beautiful Django applications with labb components!
