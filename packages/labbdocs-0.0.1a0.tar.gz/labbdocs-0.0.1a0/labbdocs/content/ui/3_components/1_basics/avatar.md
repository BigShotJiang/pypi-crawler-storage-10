---
doc_layout: component
component: c-lb.avatar
title: Avatar
description: Display user thumbnails and profile pictures with various shapes, sizes, and status indicators.
---

## Basic Avatar
<c-lbdocs.component_example path="avatar/basic" />

## Sizes
<c-lbdocs.component_example path="avatar/sizes" />

## Rounded
<c-lbdocs.component_example path="avatar/rounded" />

## Mask Shapes
<c-lbdocs.component_example path="avatar/masks" />

## Status Indicators
<c-lbdocs.component_example path="avatar/status" />

## Placeholder Avatars
<c-lbdocs.component_example path="avatar/placeholders" />

## With Rings
<c-lbdocs.component_example path="avatar/rings" />

## Avatar Groups
<c-lbdocs.component_example path="avatar/groups" />

## Group Spacing
<c-lbdocs.component_example path="avatar/group-spacing" />

## Group with Counter
<c-lbdocs.component_example path="avatar/group-with-counter" />

## Custom Content
<c-lbdocs.component_example path="avatar/custom-content" />

## API Reference
### `c-lb.avatar`
<c-lbdocs.api_table component_name="avatar" />

### `c-lb.avatar.group`
<c-lbdocs.api_table component_name="avatar.group" />
