---
title: Introduction
description: Beautiful, accessible, and customizable icon components for your Django projects.
doc_show_toc: False
---

<c-lbdocs.component_example path="introduction/welcome-card" style="stacked" />

The labb Icons library provides a comprehensive set of reusable icon components that integrate seamlessly with Django Cotton. Whether you need simple interface icons or complex illustrations, these components will help you create consistent, professional designs quickly.

labb Icons allow you to use icons with familiar HTML tag structure. Instead of complex SVG markup or external icon libraries, you can use simple, intuitive component tags that look and feel like regular HTML elements. This makes your templates more readable and maintainable while providing powerful functionality under the hood.

All icons are rendered on the backend, ensuring fast page loads and excellent SEO. Icons work without JavaScript by default, making them accessible and performant out of the box.

## What is labb Icons?

labb Icons is a Django icon component library that provides beautiful, accessible, and customizable icon components. Built on top of Django Cotton and integrated with popular icon sets like Remix Icons, it offers a modern approach to using icons in Django projects.

## Key Features

- **Django Cotton Integration**: Icons are built using Django Cotton for seamless template composition and reusability.
- **Multiple Icon Packs**: Support for popular icon sets like Remix Icons, with more packs coming soon.
- **Fill & Line Variants**: Most icons support both filled and outlined variants for design flexibility.
- **No JavaScript Required**: Icons work without JavaScript, ensuring accessibility and performance.
- **Backend Rendered**: All icon components are rendered on the server for fast page loads and better SEO.
- **Customizable**: Easy sizing and styling through CSS classes and attributes.
- **Smart Defaults**: Line variants are the default, with easy switching to fill variants.
- **AI and LLM Friendly**: Accessible documentation and code examples for AI and LLM use cases.
