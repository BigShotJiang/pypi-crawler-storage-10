

def add_personal_information(data, personal_info_list):
    try:
        print("Personal Info List:", personal_info_list)
        # Create a quick lookup dict for personal info by memberId
        personal_lookup = {p['memberId']: p for p in personal_info_list}

        new_data = {}

        for estd, estd_data in data.items():
            new_data[estd] = {}
            # if estd_data == "No Data found":
            #     new_data[estd] = "No Data found"
            #     continue
            for memberid, member_data in estd_data.items():
                if memberid == 'START_END_DATES':
                    # Just copy start_end_dates as is
                    new_data[estd][memberid] = member_data
                    continue

                # Copy member data
                new_data[estd][memberid] = member_data.copy()

                # Get personal info by memberid if exists
                p_info = personal_lookup.get(memberid)
                if p_info:
                    # Add only required fields in personal_information key
                    new_data[estd]['personal_information'] = {
                        'establishmentid': estd[:15],
                        'memberid': memberid,
                        'establishmentname': p_info.get('company'),
                        'membername': p_info.get('name'),
                    }

        return new_data
    except Exception as e:
        print("Error in add_personal_information: "+str(e))
        return data

