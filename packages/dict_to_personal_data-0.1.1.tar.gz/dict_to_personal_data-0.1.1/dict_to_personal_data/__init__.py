from .core import add_personal_information as peronsonal_data_coverter

__all__ = ["peronsonal_data_coverter"]
__version__ = "0.1.0"
