"""Unit tests for SOLLOL components."""
