"""print_dog package."""

__all__ = ["main"]

from .cli import main
