# Copyright (c) 2025 CNES
#
# All rights reserved. Use of this source code is governed by a
# BSD-style license that can be found in the LICENSE file.
"""Statistics module."""
from .descriptive_descriptive import DescriptiveStatistics
from .streaming_histogram import StreamingHistogram

__all__ = [
    'DescriptiveStatistics',
    'StreamingHistogram',
]
