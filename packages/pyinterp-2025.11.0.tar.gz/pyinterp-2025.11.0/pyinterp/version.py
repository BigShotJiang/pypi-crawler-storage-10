# Copyright (c) 2025 CNES
#
# All rights reserved. Use of this source code is governed by a
# BSD-style license that can be found in the LICENSE file.
"""Get software version information"""


def release() -> str:
    """Return the software version number"""
    return "2025.11.0"


def date() -> str:
    """Return the creation date of this release"""
    return "31 October 2025"
