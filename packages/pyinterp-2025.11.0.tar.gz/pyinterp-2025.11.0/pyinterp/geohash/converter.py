"""Geohash converters."""
from __future__ import annotations

from typing import TYPE_CHECKING

import numpy
import xarray

from .. import core
from ..core import geohash

if TYPE_CHECKING:
    from ..typing import NDArray


def to_xarray(hashes: NDArray, data: NDArray) -> xarray.DataArray:
    """Get the XArray grid representing the GeoHash grid.

    Args:
        hashes: Geohash codes.
        data: The data associated with the codes provided.

    Returns:
        The XArray grid representing the GeoHash grid.

    """
    if hashes.shape != data.shape:
        raise ValueError(
            'hashes, data could not be broadcast together with shape '
            f'{hashes.shape}, f{data.shape}')
    if hashes.dtype.kind != 'S':
        raise TypeError('hashes must be a string array')
    lon, lat = geohash.decode(
        geohash.bounding_boxes(precision=hashes.dtype.itemsize))
    x_axis = core.Axis(
        numpy.unique(lon),  # type: ignore[arg-type]
        is_circle=True,
    )
    y_axis = core.Axis(numpy.unique(lat))  # type: ignore[arg-type]

    dtype = data.dtype
    if numpy.issubdtype(dtype, numpy.dtype('object')):
        grid = numpy.empty((len(y_axis), len(x_axis)), dtype)
    else:
        grid = numpy.zeros((len(y_axis), len(x_axis)), dtype)

    lon, lat = geohash.decode(hashes)
    grid[y_axis.find_index(lat), x_axis.find_index(lon)] = data

    return xarray.DataArray(
        grid,
        dims=('lat', 'lon'),
        coords={
            'lon':
            xarray.DataArray(x_axis,
                             dims=('lon', ),
                             attrs={'units': 'degrees_north'}),
            'lat':
            xarray.DataArray(y_axis,
                             dims=('lat', ),
                             attrs={'units': 'degrees_east'})
        })
