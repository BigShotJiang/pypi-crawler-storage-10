# Copyright (c) 2025 CNES
#
# All rights reserved. Use of this source code is governed by a
# BSD-style license that can be found in the LICENSE file.
"""Tests for 1D interpolation."""
import numpy
import pytest

from ... import core


def test_interpolate1d() -> None:
    """Test 1D interpolation."""
    xi = numpy.linspace(0, 100, num=200, endpoint=True)
    x = numpy.concatenate((xi[::4], xi[-1:]))
    y = numpy.cos(-x**2 / 9.0)
    yi = core.interpolate1d(core.Axis(x), y, xi, half_window_size=20)
    index = numpy.searchsorted(xi, x)

    assert pytest.approx(numpy.cos(-x**2 / 9.0), rel=1e-6) == yi[index]

    yi = core.interpolate1d(core.Axis(x), y, xi, half_window_size=1)
    assert numpy.all(numpy.isnan(yi))
