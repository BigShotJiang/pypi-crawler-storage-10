"""SFEOS Tools - Utilities for managing stac-fastapi-elasticsearch-opensearch deployments."""

__version__ = "0.1.0"
