from setuptools import setup, find_packages
from pathlib import Path

# Paths
HERE = Path(__file__).parent

# Read README.md
long_description = (HERE / "README.md").read_text(encoding="utf-8")

# Read requirements.txt safely
requirements_file = HERE / "requirements.txt"
requirements = []
if requirements_file.exists():
    requirements = [
        line.strip() for line in requirements_file.read_text(encoding="utf-8").splitlines()
        if line.strip() and not line.startswith("#")
    ]

setup(
    name="laax",
    version="1.0.0",
    author="Dr. Kanaka K. K., PhD, ARS",
    author_email="kkokay07@gmail.com",
    description="Local Ancestry Analysis in Crossbred Populations",
    long_description=long_description,
    long_description_content_type="text/markdown",
    url="https://github.com/kkokay07/pq-genetics/tree/main/Local%20ancestry%20analysis",
    packages=find_packages(),
    python_requires=">=3.7",
    install_requires=requirements,
    include_package_data=True,
    classifiers=[
        "Development Status :: 4 - Beta",
        "Intended Audience :: Science/Research",
        "Topic :: Scientific/Engineering :: Bio-Informatics",
        "License :: OSI Approved :: MIT License",
        "Programming Language :: Python :: 3",
        "Programming Language :: Python :: 3.7",
        "Programming Language :: Python :: 3.8",
        "Programming Language :: Python :: 3.9",
        "Programming Language :: Python :: 3.10",
        "Programming Language :: Python :: 3.11",
    ],
    keywords="bioinformatics, genomics, ancestry, admixture, population-genetics",
    
    # ✅ CLI entry point
    entry_points={
        "console_scripts": [
            "laax=laax.cli:main",
        ],
    },
)
