---
editor_options: 
  markdown: 
    wrap: 72
---

# README

## 🧬 Local Ancestry Analysis Notebook

**LAAX** (Local Ancestry Analysis in Crossbred Populations) is a
comprehensive Python package for genome-wide local ancestry inference in
crossbred populations. It integrates **PLINK**, **ADMIXTURE**,
and **LAMP** into a streamlined, automated pipeline.

### 🚀 Features

-   **Automated Pipeline**: End-to-end local ancestry analysis

-   **Quality Control**: Robust filtering and preprocessing with PLINK

-   **Global Ancestry**: Population structure analysis using ADMIXTURE

-   **Local Ancestry**: Fine-scale ancestry segments with LAMP

-   **Interactive Notebook**: Original Colab notebook for exploratory
    analysis

-   **Visualization**: Comprehensive plots and summary statistics

-   **Dual Usage**: Available as both Python package and Google Colab
    notebook

### 📦 Installation

### From PyPI

pip install laax

### ⚙️ Dependencies

LAAX requires these external tools to be installed and available in your
system **PATH**:

-   **PLINK** (v1.9+): For genotype data processing

-   **ADMIXTURE**: For global ancestry estimation

-   **LAMP**: For local ancestry inference

### 🏁 Quick Start

### Basic Usage:

laax --target MyBreed\
--ancestors Anc1 Anc2\
--input genotypes\
--chr-set 30\
--output my_results

### Advanced Usage:

laax --target MyBreed\
--ancestors Anc1 Anc2\
--input genotypes\
--chr-set 30\
--output my_results\
--maf 0.05\
--hwe 1e-6\
--geno 0.1\
--mind 0.1

### 💡 Command Line Usage

laax --target TARGET --ancestors ANCESTOR1 ANCESTOR2 --input INPUT
[options]

### Required Arguments:

-   `--target TARGET`: Target population name

-   `--ancestors ANCESTORS ANCESTORS`: Two ancestral population names

-   `--input INPUT`: PLINK file prefix (without .bed/.bim/.fam
    extension)

-   `--chr-set:` Number of chromosomes (default: 26)

### Optional Arguments:

-   `--output OUTPUT`: Output directory (default: laax_results)

-   `--maf MAF`: Minor allele frequency threshold (default: 0.05)

-   `--hwe HWE`: HWE threshold (default: 1e-6)

-   `--geno GENO`: SNP missingness threshold (default: 0.1)

-   `--mind MIND`: Individual missingness threshold (default: 0.1)

-   `--plink-path PLINK_PATH`: Path to PLINK executable (auto-detected)

-   `--admixture-path ADMIXTURE_PATH`: Path to ADMIXTURE executable
    (auto-detected)

-   `--lamp-path LAMP_PATH`: Path to LAMP executable (auto-detected)

### 📊 Output

The pipeline generates the following outputs in the specified output
directory:

-   ✅ **Quality-controlled genotype data** (PLINK format)

-   🌍 **Global ancestry proportions** (ADMIXTURE Q-files)

-   🧬 **Local ancestry segments** (LAMP output)

-   📈 **Ancestry visualization plots**

-   📋 **Summary statistics and composition reports**

-   🔍 **Significant genomic regions**

-   📝 **Pipeline execution logs and configuration**

### 🛠 Troubleshooting

### Common Issues:

-   **Tool not found**: Ensure PLINK, ADMIXTURE, LAMP are in system PATH
    or specify paths explicitly

-   **Memory errors**: Use smaller datasets or increase system memory

-   **Installation fails**: Try `pip install --upgrade laax`

-   **File format errors**: Verify PLINK binary format (.bed, .bim,
    .fam) exists

-   **Chromosome set mismatch**: Adjust `--chr-set` parameter for your
    organism

## 👨‍🔬 About the Author

**Dr. Kanaka K. K., PhD, ARS**\
Scientist\
School of Bioinformatics and Computational Biology [ICAR-Indian
Institute of Agricultural Biotechnology,
Ranchi](https://iiab.icar.gov.in/) \> [Be like
IIAB!:](https://www.researchgate.net/publication/379512649_ICAR-IIAB_Annual_Report-_2023)
IIAB is like yogic center where all the sciences (Plant, Animal,
Aquatic,Mibrobiology, IT) meet to address emerging issues in food
production.

## 🔎 Spy on me

-   [Google
    Scholar](https://scholar.google.com/citations?hl=en&user=0dQ7Sf8AAAAJ&view_op=list_works&sortby=pubdate)
-   [GitHub: kkokay07](https://github.com/kkokay07)
-   [ResearchGate](https://www.researchgate.net/profile/Kanaka-K-K/research)
-   [Institute Website](https://iiab.icar.gov.in/staff/dr-kanaka-k-k/)
