#!/usr/bin/env python3
"""
Command Line Interface for LAAX
"""

import argparse
import sys
from pathlib import Path

# Fix import path - since cli.py is at root level
try:
    from laax.pipeline import LAAX
    from laax.config import Config
except ImportError:
    # For development when running directly
    import sys
    from pathlib import Path
    sys.path.insert(0, str(Path(__file__).parent))
    from laax.pipeline import LAAX
    from laax.config import Config

def main():
    """Command-line entry point for LAAX"""
    parser = argparse.ArgumentParser(
        description='LAAX: Local Ancestry Analysis in Crossbred Populations',
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
Examples:
  laax --target Ggg --ancestors Ggj Ggd --input my_data
  laax --target MyBreed --ancestors Anc1 Anc2 --input genotypes --chr-set 30 --output my_results
        """
    )
    
    # Required arguments
    parser.add_argument('--target', required=True, help='Target population name')
    parser.add_argument('--ancestors', required=True, nargs=2, help='Ancestral populations (two names)')
    parser.add_argument('--input', required=True, help='PLINK file prefix (without .bed/.bim/.fam extension)')
    
    # Optional arguments
    parser.add_argument('--output', default='laax_results', help='Output directory (default: laax_results)')
    parser.add_argument('--chr-set', type=int, default=26, help='Number of chromosomes (default: 26)')
    
    # Filtering parameters
    parser.add_argument('--maf', type=float, default=0.05, help='Minor allele frequency threshold (default: 0.05)')
    parser.add_argument('--hwe', type=float, default=1e-6, help='HWE threshold (default: 1e-6)')
    parser.add_argument('--geno', type=float, default=0.1, help='SNP missingness threshold (default: 0.1)')
    parser.add_argument('--mind', type=float, default=0.1, help='Individual missingness threshold (default: 0.1)')
    
    # Tool paths (optional)
    parser.add_argument('--plink-path', help='Path to PLINK executable (auto-detected if not specified)')
    parser.add_argument('--admixture-path', help='Path to ADMIXTURE executable (auto-detected if not specified)')
    parser.add_argument('--lamp-path', help='Path to LAMP executable (auto-detected if not specified)')
    
    args = parser.parse_args()
    
    # Create configuration
    config = Config(
        target=args.target,
        ancestors=args.ancestors,
        file_prefix=args.input,
        chr_set=args.chr_set,
        output_dir=args.output,
        maf_threshold=args.maf,
        hwe_threshold=args.hwe,
        geno_threshold=args.geno,
        mind_threshold=args.mind,
        plink_path=args.plink_path,
        admixture_path=args.admixture_path,
        lamp_path=args.lamp_path
    )
    
    # Create and run LAAX analysis
    try:
        analysis = LAAX(config)
        analysis.run()
    except Exception as e:
        print(f"❌ Error: {e}", file=sys.stderr)
        sys.exit(1)

if __name__ == "__main__":
    main()