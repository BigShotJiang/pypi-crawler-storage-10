"""
LAAX: Local Ancestry Analysis in Crossbred Populations
"""

__version__ = "1.0.0"
__author__ = "Dr. Kanaka K. K., PhD, ARS"
__email__ = "kkokay07@gmail.com"

from .pipeline import LAAX
from .config import Config

__all__ = ['LAAX', 'Config']