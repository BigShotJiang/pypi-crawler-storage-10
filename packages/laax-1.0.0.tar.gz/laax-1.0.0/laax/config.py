import os
from dataclasses import dataclass
from typing import Dict, Any

@dataclass
class Config:
    """Configuration for LAAX analysis"""
    # Population parameters
    target: str
    ancestors: list
    file_prefix: str
    chr_set: int = 26
    
    # Filtering thresholds
    maf_threshold: float = 0.05
    hwe_threshold: float = 1e-6
    geno_threshold: float = 0.1
    mind_threshold: float = 0.1
    
    # Admixture thresholds
    anc_threshold: float = 0.75
    target_threshold: float = 0.90
    
    # Tool paths (optional - will auto-detect if None)
    plink_path: str = None
    admixture_path: str = None
    lamp_path: str = None
    
    # Output directory
    output_dir: str = "laax_results"
    
    def validate(self):
        """Validate configuration parameters"""
        if len(self.ancestors) != 2:
            raise ValueError("Exactly two ancestral populations must be specified")
        if not self.target:
            raise ValueError("Target population must be specified")
        if not self.file_prefix:
            raise ValueError("File prefix must be specified")