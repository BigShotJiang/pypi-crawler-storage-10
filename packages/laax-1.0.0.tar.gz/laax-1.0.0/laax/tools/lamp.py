import subprocess
import shutil

class LAMPWrapper:
    def __init__(self, binary_path=None):
        self.binary_path = binary_path or self._find_lamp()
        print(f"✅ LAMP found at: {self.binary_path}")
    
    def _find_lamp(self):
        """Find LAMP in system PATH"""
        path = shutil.which('lamp')
        if not path:
            raise RuntimeError(
                "❌ LAMP not found!\n\n"
                "Please install LAMP from the LAMP project website.\n"
                "Make sure the binary is executable and in your PATH."
            )
        return path
    
    def run(self, args, check=True):
        """Run LAMP with given arguments"""
        cmd = [self.binary_path] + args
        print(f"📊 Running: {' '.join(cmd)}")
        
        result = subprocess.run(cmd, capture_output=True, text=True)
        
        if check and result.returncode != 0:
            raise RuntimeError(f"LAMP failed:\n{result.stderr}")
        
        return result