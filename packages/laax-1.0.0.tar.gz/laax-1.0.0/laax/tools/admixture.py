import subprocess
import shutil

class AdmixtureWrapper:
    def __init__(self, binary_path=None):
        self.binary_path = binary_path or self._find_admixture()
        print(f"✅ ADMIXTURE found at: {self.binary_path}")
    
    def _find_admixture(self):
        """Find ADMIXTURE in system PATH"""
        path = shutil.which('admixture')
        if not path:
            raise RuntimeError(
                "❌ ADMIXTURE not found!\n\n"
                "Please install ADMIXTURE:\n"
                "📥 Download: http://dalexander.github.io/admixture/\n"
                "📦 Package managers:\n"
                "   Ubuntu: sudo apt-get install admixture\n"
                "   Conda: conda install -c bioconda admixture\n"
            )
        return path
    
    def run(self, args, check=True):
        """Run ADMIXTURE with given arguments"""
        cmd = [self.binary_path] + args
        print(f"🧬 Running: {' '.join(cmd)}")
        
        result = subprocess.run(cmd, capture_output=True, text=True)
        
        if check and result.returncode != 0:
            raise RuntimeError(f"ADMIXTURE failed:\n{result.stderr}")
        
        return result