import subprocess
import shutil
import os

class PLINKWrapper:
    def __init__(self, binary_path=None):
        self.binary_path = binary_path or self._find_plink()
        print(f"✅ PLINK found at: {self.binary_path}")
    
    def _find_plink(self):
        """Find PLINK in system PATH"""
        path = shutil.which('plink')
        if not path:
            raise RuntimeError(
                "❌ PLINK not found!\n\n"
                "Please install PLINK:\n"
                "📥 Download: https://www.cog-genomics.org/plink/\n"
                "📦 Package managers:\n"
                "   Ubuntu: sudo apt-get install plink\n"
                "   macOS: brew install plink\n"
                "   Conda: conda install -c bioconda plink\n\n"
                "Or specify path in Config(plink_path='/path/to/plink')"
            )
        return path
    
    def run(self, args, check=True):
        """Run PLINK with given arguments"""
        cmd = [self.binary_path] + args
        print(f"🔧 Running: {' '.join(cmd)}")
        
        result = subprocess.run(cmd, capture_output=True, text=True)
        
        if check and result.returncode != 0:
            raise RuntimeError(f"PLINK failed:\n{result.stderr}")
        
        return result
    
    def filter_samples(self, input_prefix, output_prefix, config):
        """Run quality control filtering"""
        cmd = [
            '--bfile', input_prefix,
            '--chr-set', str(config.chr_set),
            '--maf', str(config.maf_threshold),
            '--hwe', str(config.hwe_threshold),
            '--geno', str(config.geno_threshold),
            '--mind', str(config.mind_threshold),
            '--make-bed',
            '--out', output_prefix
        ]
        return self.run(cmd)