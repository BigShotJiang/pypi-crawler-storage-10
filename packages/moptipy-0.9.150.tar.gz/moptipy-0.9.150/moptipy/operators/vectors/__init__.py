"""Operators for vector spaces."""
