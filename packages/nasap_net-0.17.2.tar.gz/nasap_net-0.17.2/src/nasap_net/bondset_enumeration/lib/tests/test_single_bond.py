import pytest

from nasap_net.bondset_enumeration import enum_single_bond_subsets


def test_enum_single_bond_subsets():
    pass


if __name__ == '__main__':
    pytest.main(['-vv', __file__])
