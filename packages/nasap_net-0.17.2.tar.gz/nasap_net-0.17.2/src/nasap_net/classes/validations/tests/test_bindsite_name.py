import pytest

from nasap_net.classes.validations import validate_name_of_binding_site


def test_validate_name_of_binding_site():
    pass


if __name__ == '__main__':
    pytest.main(['-vv', __file__])
