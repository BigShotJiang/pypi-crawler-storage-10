from ....Internal.Core import Core
from ....Internal.CommandsGroup import CommandsGroup
from ....Internal import Conversions
from .... import repcap


# noinspection PyPep8Naming,PyAttributeOutsideInit,SpellCheckingInspection
class ScaleCls:
	"""Scale commands group definition. 1 total commands, 0 Subgroups, 1 group commands"""

	def __init__(self, core: Core, parent):
		self._core = core
		self._cmd_group = CommandsGroup("scale", core, parent)

	def set(self, vertical_scale: float, refCurve=repcap.RefCurve.Default) -> None:
		"""FRANalysis:REFCurve<*>:SCALe \n
		Snippet: driver.franalysis.refCurve.scale.set(vertical_scale = 1.0, refCurve = repcap.RefCurve.Default) \n
		Sets the vertical scale, which defines the displayed amplitude of the selected waveform. \n
			:param vertical_scale: No help available
			:param refCurve: optional repeated capability selector. Default value: Nr1 (settable in the interface 'RefCurve')
		"""
		param = Conversions.decimal_value_to_str(vertical_scale)
		refCurve_cmd_val = self._cmd_group.get_repcap_cmd_value(refCurve, repcap.RefCurve)
		self._core.io.write(f'FRANalysis:REFCurve{refCurve_cmd_val}:SCALe {param}')

	def get(self, refCurve=repcap.RefCurve.Default) -> float:
		"""FRANalysis:REFCurve<*>:SCALe \n
		Snippet: value: float = driver.franalysis.refCurve.scale.get(refCurve = repcap.RefCurve.Default) \n
		Sets the vertical scale, which defines the displayed amplitude of the selected waveform. \n
			:param refCurve: optional repeated capability selector. Default value: Nr1 (settable in the interface 'RefCurve')
			:return: vertical_scale: No help available"""
		refCurve_cmd_val = self._cmd_group.get_repcap_cmd_value(refCurve, repcap.RefCurve)
		response = self._core.io.query_str(f'FRANalysis:REFCurve{refCurve_cmd_val}:SCALe?')
		return Conversions.str_to_float(response)
