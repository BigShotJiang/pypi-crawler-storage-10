__title__ = "Exposure Time estimators"

from .exptime import ExpTimeEstimator
from .star import StarExpTimeEstimator
