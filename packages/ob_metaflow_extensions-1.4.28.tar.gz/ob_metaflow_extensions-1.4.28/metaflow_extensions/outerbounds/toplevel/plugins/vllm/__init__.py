__mf_promote_submodules__ = ["plugins.vllm"]
