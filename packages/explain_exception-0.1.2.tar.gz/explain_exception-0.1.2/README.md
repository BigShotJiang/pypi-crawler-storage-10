# Explain-Exception

**Explain-Exception** is a Python library that explains Python errors in **clear English**, making it easier for beginners and developers to understand what went wrong in their code.

---

## Features

- Explains common Python exceptions in simple English
- Provides beginner-friendly explanations
- Shows the full traceback for debugging
- Optional `safe_run` wrapper to automatically explain errors
- Works with any Python function or code block

---

## Installation

- git clone https://github.com/touremahalmadane250@gmail.com/explain-exception.git
- cd explain-exception
- pip install -e .

### From PyPI 

```bash
pip install explain-exception

