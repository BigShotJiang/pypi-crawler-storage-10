"""Kirin Web UI - HTMX + FastAPI interface for Kirin datasets."""
