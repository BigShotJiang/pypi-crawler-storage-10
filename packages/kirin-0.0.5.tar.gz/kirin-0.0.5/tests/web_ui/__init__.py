"""Web UI test package.

This package contains tests for the Kirin web UI functionality.
"""

# Web UI test package
