"""Tests for gitdata."""
