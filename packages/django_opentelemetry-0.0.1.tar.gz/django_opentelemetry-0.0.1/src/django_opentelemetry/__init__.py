"""Django reusable application to collect OpenTelemetry metrics."""
