import argparse
from arcturus.arcturus_buildkit import arcturusNLP

def main():
    print("Arcturus BuildKit CLI — running successfully!")

if __name__ == "__main__":
    main()
