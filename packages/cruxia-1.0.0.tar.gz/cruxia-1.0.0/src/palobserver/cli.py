import click
import json
import sqlite3
import pathlib
import datetime
from palobserver.crypto import verify as verify_sig
from palobserver.crypto import digest

LEDGER = pathlib.Path.home() / ".pal_ledger.db"

@click.group()
def crux():
    """Cruxia command-line utility for signed context bundles."""
    pass

@crux.group()
def ledger():
    """Ledger sub-commands."""
    pass

@crux.command()
@click.argument("bundle_file", type=click.Path(exists=True))
@click.option("--pubkey", default="observer.pem.pub", help="Path to public key")
def verify(bundle_file, pubkey):
    """Verify signature and integrity of a bundle."""
    try:
        with open(bundle_file, 'rb') as f:
            bundle_data = json.load(f)
        
        # Extract signature and key
        sig_hex = bundle_data.pop("sig")
        key_id = bundle_data.pop("sig_key_id")
        
        # Read public key
        pub_bytes = bytes.fromhex(open(pubkey, 'r').read())
        
        # Reconstruct the signed blob
        header_json = json.dumps(bundle_data, sort_keys=True)
        body_hex = bundle_data.get("body", "")
        blob = header_json.encode() + bytes.fromhex(body_hex)
        
        # Verify signature
        sig_bytes = bytes.fromhex(sig_hex)
        is_valid = verify_sig(blob, sig_bytes, pub_bytes)
        
        if is_valid:
            click.echo(f"✓ Bundle {bundle_data.get('bundle_id', 'unknown')[:8]} verified")
            if bundle_data.get("bundle_flags"):
                click.echo(f"⚠ Flags: {', '.join(bundle_data['bundle_flags'])}")
        else:
            click.echo("✗ Signature verification failed")
            raise click.Abort()
    except Exception as e:
        click.echo(f"Error: {e}", err=True)
        raise click.Abort()

@ledger.command(name="ls")
@click.option("--limit", default=5, help="Rows to display")
def ls_cmd(limit):
    conn = sqlite3.connect(LEDGER)
    rows = conn.execute(
        "SELECT bundle_id, created, conflict_ct FROM ledger "
        "ORDER BY created DESC LIMIT ?", (limit,)
    )
    for b, ts, ct in rows.fetchall():
        ts = datetime.datetime.fromisoformat(ts).strftime("%Y-%m-%d %H:%M:%S")
        print(f"{ts}  {b[:8]}…  conflicts={ct}")

@ledger.command(name="show")
@click.argument("bundle_id")
def show_cmd(bundle_id):
    conn = sqlite3.connect(LEDGER)
    row = conn.execute(
        "SELECT bundle_json FROM ledger WHERE bundle_id=?",
        (bundle_id,),
    ).fetchone()
    if not row:
        click.echo("Bundle not found")
        return
    print(json.dumps(json.loads(row[0]), indent=2)[:1000])

@ledger.command(name="export")
@click.option("--format", type=click.Choice(['json', 'csv']), default='json')
@click.option("--output", type=click.Path(), help="Output file path")
def export_cmd(format, output):
    """Export ledger data to file."""
    conn = sqlite3.connect(LEDGER)
    rows = conn.execute(
        "SELECT bundle_id, created, conflict_ct, bundle_json FROM ledger ORDER BY created DESC"
    ).fetchall()
    
    if not rows:
        click.echo("No bundles in ledger")
        return
    
    if format == 'json':
        data = []
        for bid, created, ct, bundle_json in rows:
            bundle = json.loads(bundle_json)
            data.append(bundle)
        
        output_json = json.dumps(data, indent=2)
        
        if output:
            with open(output, 'w') as f:
                f.write(output_json)
            click.echo(f"Exported {len(data)} bundles to {output}")
        else:
            print(output_json)
    else:  # CSV
        import csv
        import io
        
        csv_file = io.StringIO()
        writer = csv.writer(csv_file)
        writer.writerow(['bundle_id', 'created', 'conflict_count', 'tokens', 'shards'])
        
        for bid, created, ct, bundle_json in rows:
            bundle = json.loads(bundle_json)
            writer.writerow([
                bid,
                created,
                ct,
                bundle.get('window_tokens', 0),
                len(bundle.get('shards', []))
            ])
        
        if output:
            with open(output, 'w') as f:
                f.write(csv_file.getvalue())
            click.echo(f"Exported {len(rows)} bundles to {output}")
        else:
            print(csv_file.getvalue())

@ledger.command(name="stats")
def stats_cmd():
    """Show statistics about the ledger."""
    conn = sqlite3.connect(LEDGER)
    
    # Total bundles
    total = conn.execute("SELECT COUNT(*) FROM ledger").fetchone()[0]
    
    # Total conflicts
    conflict_sum = conn.execute("SELECT SUM(conflict_ct) FROM ledger").fetchone()[0] or 0
    
    # Bundles with conflicts
    with_conflicts = conn.execute(
        "SELECT COUNT(*) FROM ledger WHERE conflict_ct > 0"
    ).fetchone()[0]
    
    # Average tokens
    avg_tokens = conn.execute("""
        SELECT AVG(window_tokens) 
        FROM (
            SELECT json_extract(bundle_json, '$.window_tokens') as window_tokens
            FROM ledger
        )
    """).fetchone()[0]
    
    print(f"Total bundles: {total}")
    print(f"Bundles with conflicts: {with_conflicts}")
    print(f"Total conflicts detected: {conflict_sum}")
    if avg_tokens:
        print(f"Average tokens per bundle: {avg_tokens:.0f}")

@crux.command(name="search")
@click.argument("query")
@click.option("--limit", default=10, help="Max results to return")
def search_cmd(query, limit):
    """Search bundles by content."""
    conn = sqlite3.connect(LEDGER)
    rows = conn.execute(
        "SELECT bundle_id, created, bundle_json FROM ledger ORDER BY created DESC"
    ).fetchall()
    
    results = []
    for bid, created, bundle_json in rows:
        bundle = json.loads(bundle_json)
        # Simple text search in bundle JSON
        if query.lower() in str(bundle).lower():
            results.append((bid, created, bundle))
            if len(results) >= limit:
                break
    
    if results:
        click.echo(f"Found {len(results)} matching bundles:")
        for bid, created, bundle in results:
            ts = datetime.datetime.fromisoformat(created).strftime("%Y-%m-%d %H:%M:%S")
            print(f"{ts}  {bid[:8]}…  conflicts={sum(len(s['flags']) for s in bundle.get('shards', []))}")
    else:
        click.echo("No matching bundles found")

