# SPDX-FileCopyrightText: 2025-present Marshall Miller <marshall_miller3@outlook.com>
#
# SPDX-License-Identifier: MIT
__version__ = "1.0.0"
