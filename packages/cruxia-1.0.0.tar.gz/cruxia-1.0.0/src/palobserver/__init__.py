# SPDX-FileCopyrightText: 2025-present Marshall Miller <marshall_miller3@outlook.com>
#
# SPDX-License-Identifier: MIT

"""Cruxia: Signed Context Bundle observer for LLM pipelines."""

from palobserver.__about__ import __version__
from palobserver.bundle import build_bundle
from palobserver.crypto import generate_key, sign, verify, digest
from palobserver.rules import flags, extracts
from palobserver.ledger import write as write_ledger

# Optional LangChain integration
try:
    from palobserver.callback import PalObserverCallback
    __all__ = [
        "__version__",
        "build_bundle",
        "generate_key",
        "sign",
        "verify",
        "digest",
        "flags",
        "extracts",
        "write_ledger",
        "PalObserverCallback",
    ]
except ImportError:
    __all__ = [
        "__version__",
        "build_bundle",
        "generate_key",
        "sign",
        "verify",
        "digest",
        "flags",
        "extracts",
        "write_ledger",
    ]
