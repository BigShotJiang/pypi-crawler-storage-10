import re
import yaml
import functools
import pathlib
from collections import defaultdict

# Global cache
_CACHE = None

def _get_rules_path():
    """Find rules/core.yaml relative to the package or cwd."""
    # Try package-relative path first
    try:
        import palobserver
        package_dir = pathlib.Path(palobserver.__file__).parent.parent
        rules_path = package_dir / "rules" / "core.yaml"
        if rules_path.exists():
            return rules_path
    except Exception:
        pass
    # Fall back to cwd-based path (for installed package or dev)
    cwd_rules = pathlib.Path("rules/core.yaml")
    if cwd_rules.exists():
        return cwd_rules
    # Last resort: relative to __file__
    here = pathlib.Path(__file__).parent
    return here.parent.parent / "rules" / "core.yaml"

def _load_rules():
    global _CACHE
    if _CACHE is None:
        rules_path = _get_rules_path()
        raw = rules_path.read_text()
        _CACHE = yaml.safe_load(raw)
    return _CACHE

@functools.lru_cache(maxsize=None)
def flags(text: str) -> list[str]:
    """
    Return shard-level flags (rule['code']) for rules without 'extract'.
    """
    rules = _load_rules()
    out = []
    for rule in rules:
        if rule.get("extract"):
            continue
        if re.search(rule["pattern"], text, flags=re.IGNORECASE):
            out.append(rule["code"])
    return out

@functools.lru_cache(maxsize=None)
def extracts(text: str) -> dict[str, list[str]]:
    """
    Return a dict mapping extract names to lists of captured groups.
    E.g. {'net_days': ['30', '45']}
    """
    rules = _load_rules()
    extras = defaultdict(list)
    for rule in rules:
        if not rule.get("extract"):
            continue
        m = re.search(rule["pattern"], text, flags=re.IGNORECASE)
        if m:
            extras[rule["extract"]].append(m.group(1))
    return dict(extras)

