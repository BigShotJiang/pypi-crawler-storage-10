from .raspigpio import GPIO


__all__ = ["GPIO"]


VERSION = "0.0.0"
