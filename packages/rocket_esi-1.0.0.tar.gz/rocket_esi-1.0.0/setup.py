from setuptools import setup, find_packages

setup(
    name='rocket-esi',                         # nom de ton package (doit être unique sur PyPI)
    version='1.0.0',                       # numéro de version (incrémente à chaque release)
    author='Riham Messaoudi',              # ton nom complet
    author_email='r.messaoudi@esi-sba.dz', # ton adresse email
    packages=find_packages(),              # trouve automatiquement le dossier 'rocket'
    url='https://pypi.org/project/rocket/',# lien vers la page PyPI (ou ton repo GitHub)
    license='LICENSE.txt',                 # licence utilisée
    description='A demo rocket package for Python modularity and OOP training.',
    long_description=open('README.md', encoding='utf-8').read(),
    long_description_content_type='text/markdown',
    install_requires=['numpy', 'matplotlib'],
    python_requires='>=3.8',               # version minimale de Python supportée
)
