# rocket

Simple OOP demo with `Rocket` and `Shuttle` classes.

## Install
```bash
pip install rocket
