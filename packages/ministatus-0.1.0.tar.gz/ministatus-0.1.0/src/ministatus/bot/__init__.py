# NOTE: Avoid eagerly importing discord.py, submodules might not need it
