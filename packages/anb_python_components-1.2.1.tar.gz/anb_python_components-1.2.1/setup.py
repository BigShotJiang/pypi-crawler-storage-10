# setup.py
from setuptools import find_packages, setup

setup(
        # Имя пакета
        name = 'anb_python_components',
        # Версия пакета
        version = '1.2.1',
        # Описание пакета
        summary = 'Набор компонентов Python, которые упрощают разработку / A set of Python components that simplify development',
        # Автор пакета
        author = 'Александр Бабаев',
        author_email = 'contact_with_us@babaev-an.ru',
        # Автоматически находит пакеты внутри текущего каталога
        packages = find_packages(),
        
        # Обязательные зависимости
        install_requires = [],
        
        classifiers = [
                # Язык программирования (минимальная версия Python)
                'Programming Language :: Python :: 3.14',
                # Лицензия
                'License :: OSI Approved :: MIT License'
                ]
        )