def custom_func():
    output_data = []
    for row in input_data:
        # yield row
        output_data.append(row)
    return output_data