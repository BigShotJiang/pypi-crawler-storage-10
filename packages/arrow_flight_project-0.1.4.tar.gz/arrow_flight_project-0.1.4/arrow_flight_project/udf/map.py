def map_value_squre_10():
    id = input_data.get(0)
    value = input_data.get(1)
    new_row = [id, value*100]
    output_data = new_row
    # print(output_data)
    return output_data