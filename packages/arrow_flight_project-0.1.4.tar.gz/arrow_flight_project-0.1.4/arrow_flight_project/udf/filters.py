def filter_id_less_than_10():
    id = input_data.get(0)
    # value = input_data.get(1)
    if id < 10:
        output_data = True
    else:
        output_data = False
    return output_data
