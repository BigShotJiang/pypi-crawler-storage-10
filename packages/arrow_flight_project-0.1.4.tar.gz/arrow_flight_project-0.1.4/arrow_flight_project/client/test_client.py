from arrow_flight_project.client import DftpClient

client = DftpClient.connect("10.0.82.143:3101", "Admin", "Admin")

datasets = client.get("dftp://10.0.82.143:3101/")
print("Datasets:", datasets)

client.close()