from .arrow_flight_client import ArrowFlightClient


class DftpClient:
    """
    DFTP 高层封装客户端
    简化 ArrowFlightClient 的调用
    """

    def __init__(self, client: ArrowFlightClient):
        self._client = client

    @classmethod
    def connect(cls, host: str, username: str, password: str, **kwargs):
        """
        建立连接
        示例:
            client = DftpClient.connect("10.0.82.143:3101", "Admin", "Admin")
        """
        client = ArrowFlightClient.connect(host, username, password, **kwargs)
        return cls(client)

    def get(self, path: str):
        """
        从远程服务器获取数据集或数据帧
        示例:
            data = client.get("dftp://10.0.82.143:3101/")
        """
        return self._client.get(path)

    def close(self):
        """关闭连接"""
        if self._client:
            self._client.close()
