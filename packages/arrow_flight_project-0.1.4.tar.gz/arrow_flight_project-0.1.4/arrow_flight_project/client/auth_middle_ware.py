import pyarrow.flight as flight

class AuthMiddleware(flight.ClientMiddleware):
    def __init__(self, token):
        self._token = token

    def sending_headers(self):
        return {"authorization": f"Bearer {self._token}"}

class AuthMiddlewareFactory(flight.ClientMiddlewareFactory):
    def __init__(self, token):
        self._token = token

    def start_call(self, _info):
        return AuthMiddleware(self._token)
