from abc import ABC, abstractmethod
import struct
from typing import ByteString

class DftpTicket(ABC):
    @property
    @abstractmethod
    def type_id(self) -> int:
        pass

    @property
    @abstractmethod
    def ticket_content(self) -> str:
        pass

    def encode_ticket(self) -> ByteString:
        """
        Encodes the ticket into a byte array with format:
        [type_id:1B][content_len:4B][content_bytes]
        """
        b = self.ticket_content.encode('utf-8')
        # b = self.ticket_content

        len_b = len(b)
        print(len(b))

        return (
            struct.pack('<B', self.type_id) +
            struct.pack('>I', len(b)) +
            b
        )

class LoginTicket(DftpTicket):
    def __init__(self, username: str):
        self._username = username

    @property
    def type_id(self) -> int:
        return 2  # 假设 1 表示登录类型

    @property
    def ticket_content(self) -> str:
        return self._username