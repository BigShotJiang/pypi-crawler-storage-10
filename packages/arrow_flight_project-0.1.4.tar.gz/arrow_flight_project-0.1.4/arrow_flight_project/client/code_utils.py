import json
import struct

def encode_with_map(data: bytes, params: dict) -> bytes:
    """
    将原始数据和 Map（dict）编码成字节数组，格式与 Scala CodecUtils.encodeWithMap 对应。

    Args:
        data (bytes): 原始数据，通常可能是空 bytes b''。
        params (dict): 参数字典，会被转成 JSON bytes。

    Returns:
        bytes: 编码后的字节数组
    """
    if data is None:
        data = b''
    map_bytes = json.dumps(params).encode('utf-8')

    encoded = bytearray()
    # 写 data 长度
    encoded += struct.pack('>i', len(data))  # '>i' 表示 big-endian 4字节 int
    encoded += data
    # 写 map 长度
    encoded += struct.pack('>i', len(map_bytes))
    encoded += map_bytes

    return bytes(encoded)


def decode_with_map(encoded: bytes):
    """
    将 encode_with_map 编码的 bytes 解码成 (data: bytes, params: dict)
    """
    offset = 0
    # 读 data 长度
    data_len = struct.unpack('>i', encoded[offset:offset+4])[0]
    offset += 4
    data_bytes = encoded[offset:offset+data_len]
    offset += data_len

    # 读 map 长度
    map_len = struct.unpack('>i', encoded[offset:offset+4])[0]
    offset += 4
    map_bytes = encoded[offset:offset+map_len]
    params = json.loads(map_bytes.decode('utf-8'))

    return data_bytes, params
