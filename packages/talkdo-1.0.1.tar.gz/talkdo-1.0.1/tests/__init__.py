"""
Test suite for the CLI Task Manager.

This module contains all tests for the CLI Task Manager application.
"""
