import creabot
import time

IP_id="192.168.46.144"
IP = creabot.Creabot(IP_id)
map_id='testmop2'
charger_name='充电桩1'
set_speak='电量低，请充电'
pointlist=None


def set_map(name):
    global pointlist
    maplist = IP.list_map()
    targetmap = next((f for f in maplist if f["name"] == name), None)
    if targetmap:
        print("###########")
        mapid = targetmap["id"]
        IP.set_map(mapid)
        pointlist = IP.list_map_point(mapid)
        print(f"'初始化成功,成功设置地图：'{name}")
        init()
    else:
        print("目标地图未找到")
        exit()

def init():
    dst = next((f for f in pointlist if f["type"] ==  "anchor_point"), None)
    if dst:
        IP.tts_sync("开始重定位")
        IP.relocate_sync(dst["x"], dst["y"], dst["theta"])
    else:
        print("不存在定位点")

def speak(sk):
    IP.tts_sync("请给我下达下一步指令")
    while  True:
        res = IP.asr_sync(3)
        print('识别结果：',res)
        if sk in res:
            IP.tts_sync('好的，我要去充电了，请不要拦住我')
            return 1
        else:
            IP.tts_sync("我听到你说：{res},未识别指令")

def mov_charge(name):
    dst = next((f for f in pointlist if f["name"] == name), None)
    print(f"充电桩名称={dst["name"]},坐标={dst['x']},{dst["y"]},角度={dst["theta"]}")
    if not dst:
        raise Exception("未在地图点位列表中找到充电桩（类型为'charge'的点位），无法执行充电任务")
    print("开始向充电桩移动")
    IP.start_navigation_sync(dst['x'], dst['y'], dst['theta'], 0.5)

    print('开始上桩')
    dock_on =IP.dock_charge_on_sync(map_id,dst['x'],dst['y'],dst['theta'])
    if not dock_on:
        raise Exception(f"上桩失败，错误码：{dock_on['code']}（0=成功，6016=未检测到充电桩）")
    IP.tts_sync("正在充电")
    time.sleep(10)
    IP.tts_sync("开始下桩")
    IP.dock_charge_off_sync()
    IP.tts_sync("下桩成功")


if __name__ == '__main__':
    IP.tts_sync("孔尼基哇")
    set_map(map_id)
    while  not step:
        step=speak(set_speak)
    mov_charge(charger_name)    