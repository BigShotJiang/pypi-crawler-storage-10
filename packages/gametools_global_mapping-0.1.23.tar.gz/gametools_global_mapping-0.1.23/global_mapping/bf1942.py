MODE = {
    "conquest": "Conquest",
    "coop": "Co-op",
    "ctf": "Capture the Flag",
    "objectivemode": "Objective Mode",
    "tdm": "Team Deathmatch",
}
SMALLMODE = {
    "conquest": "CQ",
    "coop": "COOP",
    "ctf": "CTF",
    "objectivemode": "OBJ",
    "tdm": "TDM",
}