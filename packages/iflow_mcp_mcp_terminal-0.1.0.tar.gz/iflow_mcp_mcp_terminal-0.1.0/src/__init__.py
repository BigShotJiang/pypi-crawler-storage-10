"""MCP Terminal package."""
