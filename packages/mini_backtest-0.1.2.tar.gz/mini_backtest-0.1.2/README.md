Mini Backtest
==============

A lightweight, pandas‑first toolkit for quick backtesting experiments. It focuses on the essentials: generating reproducible sample OHLCV data, transforming data into analysis‑friendly shapes, and computing core performance metrics such as CAGR and Maximum Drawdown. The API is intentionally small, composable, and easy to integrate with your own research code.

Features
--------

- Simple, pandas‑centric API for inputs and outputs.
- Deterministic sample data generation for demos and tests.
- Core metrics: CAGR and Maximum Drawdown.
- Minimal `Backtester` wrapper that computes metrics from close‑price DataFrames.

Installation
------------

```
pip install mini_backtest
```

Quick Start
-----------

```python
from mini_backtest import load_sample_prices, Backtester

# Load a reproducible wide close‑price DataFrame (index=date, columns=symbol)
prices = load_sample_prices(n_symbols=10, start="2020-01-01", end="2022-12-31", seed=42)

# Compute per‑symbol metrics
res = Backtester(prices).run()
print(res.head())
```

API Overview
------------

- `mini_backtest.data`
  - `load_sample_dataset(n_symbols=10, start="2020-01-01", end="2022-12-31", seed=42) -> pd.DataFrame`
    - Returns a reproducible tidy OHLCV DataFrame without writing to disk.
  - `load_sample_prices(n_symbols=10, start="2020-01-01", end="2022-12-31", seed=42) -> pd.DataFrame`
    - Returns a reproducible wide close-price DataFrame.
  - `generate_sample_data(file_path, symbols=None, start="2020-01-01", end="2022-12-31", seed=42) -> Path`
    - Writes the simulated dataset to a JSON file for offline use.
  - `load_data(file_path) -> pd.DataFrame`
    - Loads the JSON dataset into a tidy DataFrame with columns: `date, symbol, open, high, low, close, volume`.
  - `pivot_close(df) -> pd.DataFrame`
    - Pivots the tidy data to a wide close‑price DataFrame (index = date, columns = symbols).

- `mini_backtest.metrics`
  - `compute_cagr(prices, periods_per_year=252) -> pd.Series`
  - `compute_max_drawdown(prices) -> pd.Series`
  - `compute_metrics(prices, periods_per_year=252) -> pd.DataFrame`

- `mini_backtest.backtester`
  - `Backtester(prices: pd.DataFrame, periods_per_year: int = 252)`
  - `Backtester.run() -> pd.DataFrame`

Design Notes
------------

- This project is intentionally minimal and metric‑oriented. It does not attempt to be an event‑driven engine or a full execution simulator.
- Inputs and outputs are pandas DataFrames to maximize composability with your own research pipeline.

Requirements
------------

- Python 3.8+
- `pandas>=1.4`, `numpy>=1.22`

Testing (optional)
------------------

If you clone the repository and want to run the tests:

```
pytest -q
```

Versioning
----------

This package follows semantic versioning for public APIs exposed in `mini_backtest`.

Security & Privacy
------------------

The published distribution includes only the `mini_backtest` package and this README. It does not ship any credentials, local configuration, or example datasets.
