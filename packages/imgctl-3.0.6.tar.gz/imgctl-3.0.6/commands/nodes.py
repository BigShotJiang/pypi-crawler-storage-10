"""
Команды для управления нодами
"""

import click
from rich.console import Console
from core.api_client import ImagenariumAPIError
from utils.formatters import format_table, format_output, show_console_header

console = Console()


def _get_api_client(verbose: bool = False, ctx=None):
    """Создает API клиент с заданными параметрами"""
    from cli.main import get_api_client

    # Получаем параметры из контекста если доступен
    if ctx and hasattr(ctx, "obj"):
        server = ctx.obj.get("server")
        username = ctx.obj.get("username")
        password = ctx.obj.get("password")
        config = ctx.obj.get("config")
        return get_api_client(
            verbose=verbose,
            server=server,
            username=username,
            password=password,
            config=config,
        )
    else:
        return get_api_client(verbose=verbose)


@click.group()
def cli():
    """Управление нодами кластера"""
    pass


@cli.command("list")
@click.option(
    "--columns",
    help='Столбцы для отображения. Форматы: "NAME,STATUS" или "+TOTAL_MEMORY,-ID". Доступные: NAME, IP, ROLE, AVAILABILITY, STATUS, DC, DOCKER_VERSION, TOTAL_MEMORY, SSH_PORT, SSH_USER, EXTERNAL_URL, ID',
)
@click.option(
    "--filter",
    multiple=True,
    help="Фильтрация данных. Формат: COLUMN=value, COLUMN!=value, COLUMN~pattern. Примеры: STATUS=READY, ROLE=manager, IP~10.9",
)
@click.option("--no-cache", is_flag=True, help="Отключить кэширование")
@click.option("--no-headers", is_flag=True, help="Не показывать заголовок консоли")
@click.option(
    "--output",
    "-o",
    help='Формат вывода данных: json, yaml, tsv, или template (например: "{NAME} - {STATUS}")',
)
@click.option("--verbose", "-v", is_flag=True, help="Подробный вывод HTTP запросов")
@click.pass_context
def list_nodes(ctx, columns, filter, no_cache, no_headers, output, verbose):
    """Показывает список нод

    По умолчанию: NAME, IP, ROLE, AVAILABILITY, STATUS. Дополнительные: DC, DOCKER_VERSION, TOTAL_MEMORY, SSH_PORT, SSH_USER, EXTERNAL_URL, ID
    """
    try:
        # Создаем API клиент с нужными параметрами
        api = _get_api_client(verbose=verbose, ctx=ctx)

        # Показываем заголовок консоли (скрываем при --no-headers или --output)
        show_console_header(api, show_header=not (no_headers or output))

        # Показываем прогресс-бар для длительных запросов
        from rich.progress import Progress, SpinnerColumn, TextColumn, TimeElapsedColumn

        with Progress(
            SpinnerColumn(),
            TextColumn("[progress.description]{task.description}"),
            TimeElapsedColumn(),
            console=console,
            transient=True,
        ) as progress:
            task = progress.add_task("Загрузка списка нод...", total=None)

            nodes = api.get_nodes(no_cache=no_cache)

            progress.update(task, description="Обработка данных...")

        if not nodes:
            console.print("Ноды не найдены")
            return

        # Подготавливаем данные для таблицы
        data = []
        for node in nodes:
            # Преобразуем статус в UPPERCASE
            status = node.get("status", "").upper()
            availability = node.get("availability", "").upper()

            data.append(
                {
                    "NAME": node.get("hostname", ""),
                    "IP": node.get("ip", ""),
                    "ROLE": node.get("role", ""),
                    "AVAILABILITY": availability,
                    "STATUS": status,
                    "DC": node.get("dc", ""),
                    "DOCKER_VERSION": node.get("dockerVersion", ""),
                    "TOTAL_MEMORY": (
                        f"{node.get('totalMemory', '')} GB"
                        if node.get("totalMemory")
                        else ""
                    ),
                    "SSH_PORT": node.get("sshPort", ""),
                    "SSH_USER": node.get("sshUser", ""),
                    "EXTERNAL_URL": node.get("externalUrl", ""),
                    "ID": node.get("id", ""),  # ID в конце для возможности исключения
                }
            )

        # Определяем колонки для отображения
        from utils.formatters import parse_columns_spec

        default_columns = ["NAME", "IP", "ROLE", "AVAILABILITY", "STATUS"]
        all_columns = [
            "NAME",
            "IP",
            "ROLE",
            "AVAILABILITY",
            "STATUS",
            "DC",
            "DOCKER_VERSION",
            "TOTAL_MEMORY",
            "SSH_PORT",
            "SSH_USER",
            "EXTERNAL_URL",
            "ID",
        ]

        columns = parse_columns_spec(columns, default_columns, all_columns)

        # Применяем фильтры данных
        if filter:
            from utils.formatters import parse_filters, apply_filters

            parsed_filters = parse_filters(list(filter))
            data = apply_filters(data, parsed_filters)

        # Отображаем данные в указанном формате
        if not output or output == "table":
            # Передаем фильтры для подсветки совпадений
            highlight_filters = parse_filters(list(filter)) if filter else None
            format_table(
                data,
                columns=columns,
                no_headers=no_headers,
                highlight_filters=highlight_filters,
            )
        else:
            format_output(data, output, columns=columns)

    except ImagenariumAPIError as e:
        console.print(f"[red]Ошибка получения списка нод: {e}[/red]")
        raise click.Abort()


@cli.command("get")
@click.argument("node_name")
@click.option("--verbose", "-v", is_flag=True, help="Подробный вывод HTTP запросов")
@click.pass_context
def get_node(ctx, node_name, verbose):
    """Показывает информацию о конкретной ноде"""
    try:
        api = _get_api_client(verbose=verbose, ctx=ctx)

        # Показываем заголовок консоли
        show_console_header(api)

        # Показываем прогресс-бар для длительных запросов
        from rich.progress import Progress, SpinnerColumn, TextColumn, TimeElapsedColumn

        with Progress(
            SpinnerColumn(),
            TextColumn("[progress.description]{task.description}"),
            TimeElapsedColumn(),
            console=console,
            transient=True,
        ) as progress:
            task = progress.add_task("Загрузка информации о ноде...", total=None)

            nodes = api.get_nodes()

            progress.update(task, description="Поиск ноды...")

        node = next((n for n in nodes if n.get("hostname") == node_name), None)
        if not node:
            console.print(f"[red]Нода с именем {node_name} не найдена[/red]")
            return

        # Выводим детальную информацию о ноде в стиле components get

        # Основные параметры
        console.print(f"[bold white]NAME:[/bold white] {node.get('hostname', 'N/A')}")
        console.print(f"[bold white]IP:[/bold white] {node.get('ip', 'N/A')}")
        console.print(f"[bold white]ROLE:[/bold white] {node.get('role', 'N/A')}")
        console.print(f"[bold white]DC:[/bold white] {node.get('dc', 'N/A')}")

        # Статус с цветовым кодированием
        status = node.get("status", "N/A").upper()
        if status in ["READY", "ACTIVE", "HEALTHY"]:
            styled_status = f"[bold green]{status}[/bold green]"
        elif status in ["UNHEALTHY", "DOWN", "ERROR"]:
            styled_status = f"[bold red]{status}[/bold red]"
        elif status in ["PENDING", "STARTING"]:
            styled_status = f"[bold yellow]{status}[/bold yellow]"
        else:
            styled_status = status
        console.print(f"[bold white]STATUS:[/bold white] {styled_status}")

        # Доступность с цветовым кодированием
        availability = node.get("availability", "N/A").upper()
        if availability in ["ACTIVE", "READY", "AVAILABLE"]:
            styled_availability = f"[bold green]{availability}[/bold green]"
        elif availability in ["DRAIN", "DRAINING", "UNAVAILABLE"]:
            styled_availability = f"[bold red]{availability}[/bold red]"
        elif availability in ["PAUSE", "PAUSED"]:
            styled_availability = f"[bold yellow]{availability}[/bold yellow]"
        else:
            styled_availability = availability
        console.print(f"[bold white]AVAILABILITY:[/bold white] {styled_availability}")

        # Системная информация
        console.print(
            f"[bold white]DOCKER_VERSION:[/bold white] {node.get('dockerVersion', 'N/A')}"
        )
        console.print(
            f"[bold white]TOTAL_MEMORY:[/bold white] {node.get('totalMemory', 'N/A')} GB"
        )
        console.print(
            f"[bold white]SSH_PORT:[/bold white] {node.get('sshPort', 'N/A')}"
        )
        console.print(
            f"[bold white]SSH_USER:[/bold white] {node.get('sshUser', 'N/A')}"
        )
        console.print(
            f"[bold white]EXTERNAL_URL:[/bold white] {node.get('externalUrl', 'N/A')}"
        )

        # Labels
        if node.get("labels"):
            console.print(f"[bold white]LABELS:[/bold white]")
            for key, value in node["labels"].items():
                console.print(f"  {key}: {value}")

    except ImagenariumAPIError as e:
        console.print(f"[red]Ошибка получения информации о ноде: {e}[/red]")
        raise click.Abort()


@cli.command("update")
@click.argument("node_name")
@click.option("--hostname", help="Новое имя хоста")
@click.option("--role", help="Новая роль")
@click.option("--availability", help="Новая доступность")
@click.option("--external-url", help="Новый внешний URL")
@click.option("--ssh-port", help="Новый SSH порт")
@click.option("--ssh-user", help="Новый SSH пользователь")
@click.option(
    "--label", multiple=True, help="Добавить/обновить label (формат: key=value)"
)
@click.option("--verbose", "-v", is_flag=True, help="Подробный вывод HTTP запросов")
@click.pass_context
def update_node(
    ctx,
    node_name,
    hostname,
    role,
    availability,
    external_url,
    ssh_port,
    ssh_user,
    label,
    verbose,
):
    """Обновляет информацию о ноде"""
    try:
        api = _get_api_client(verbose=verbose, ctx=ctx)

        # Показываем прогресс-бар для длительных запросов
        from rich.progress import Progress, SpinnerColumn, TextColumn, TimeElapsedColumn

        with Progress(
            SpinnerColumn(),
            TextColumn("[progress.description]{task.description}"),
            TimeElapsedColumn(),
            console=console,
            transient=True,
        ) as progress:
            task = progress.add_task("Загрузка информации о ноде...", total=None)

            nodes = api.get_nodes()

            progress.update(task, description="Поиск ноды...")

        # Находим ноду по имени
        node = next((n for n in nodes if n.get("hostname") == node_name), None)
        if not node:
            console.print(f"[red]Нода с именем {node_name} не найдена[/red]")
            return

        node_id = node.get("id")

        # Собираем данные для обновления
        update_data = {}

        if hostname:
            update_data["hostname"] = hostname
        if role:
            update_data["role"] = role
        if availability:
            update_data["availability"] = availability
        if external_url:
            update_data["externalUrl"] = external_url
        if ssh_port:
            update_data["sshPort"] = ssh_port
        if ssh_user:
            update_data["sshUser"] = ssh_user

        # Обрабатываем labels
        if label:
            labels = {}
            for l in label:
                if "=" in l:
                    key, value = l.split("=", 1)
                    labels[key] = value
                else:
                    console.print(
                        f"[yellow]Пропускаем неправильный label: {l}[/yellow]"
                    )
            if labels:
                update_data["labels"] = labels

        if not update_data:
            console.print("[yellow]Нет данных для обновления[/yellow]")
            return

        api.update_node(node_id, update_data)
        console.print(f"[green]Нода {node_name} успешно обновлена[/green]")

    except ImagenariumAPIError as e:
        console.print(f"[red]Ошибка обновления ноды: {e}[/red]")
        raise click.Abort()
