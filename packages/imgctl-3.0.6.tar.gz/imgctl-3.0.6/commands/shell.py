"""
Интерактивная оболочка для imgctl (REPL режим)

Предоставляет интерактивный режим работы с imgctl с поддержкой:
- Автодополнения команд
- История команд
- Сохранение контекста между командами
"""

import os
import shlex
import sys
import threading
from pathlib import Path
from typing import List

import click
from rich.console import Console
from rich.markdown import Markdown

# Проверяем доступность prompt-toolkit
try:
    import prompt_toolkit

    PROMPT_TOOLKIT_AVAILABLE = True
except ImportError:
    PROMPT_TOOLKIT_AVAILABLE = False

from core.completion import CompletionManager

console = Console()

# Глобальная переменная для фонового потока
_cache_update_thread = None
_stop_cache_updates = threading.Event()

# Состояние фонового обновления кэша
_cache_update_in_progress = threading.Event()
_cache_update_lock = threading.Lock()


def create_imgctl_completer(ctx, completion_manager):
    """
    Создает комплетер для imgctl команд используя Click API
    """
    from prompt_toolkit.completion import Completer, Completion, NestedCompleter
    from cli.main import main

    # Получаем список команд из Click динамически
    commands_dict = {}
    for cmd_name, cmd in main.commands.items():
        if hasattr(cmd, 'list_commands'):
            try:
                # Создаем контекст для команды
                with main.make_context('imgctl', [cmd_name]) as sub_ctx:
                    subcommands = cmd.list_commands(sub_ctx)
                    commands_dict[cmd_name] = {sub: None for sub in subcommands}
            except Exception:
                # Fallback: используем get_short_help_str для определения подкоманд
                commands_dict[cmd_name] = None
        else:
            commands_dict[cmd_name] = None

    # Добавляем специальные команды REPL
    commands_dict["exit"] = None
    commands_dict["quit"] = None
    commands_dict["help"] = None
    commands_dict["clear"] = None

    class ImgctlCompleter(Completer):
        """Комплетер для imgctl команд"""

        def __init__(self, completion_manager, commands_dict):
            self.completion_manager = completion_manager
            self.commands_dict = commands_dict
            # Статический completer для команд из Click
            self.static_completer = NestedCompleter.from_nested_dict(commands_dict)

        def get_completions(self, document, complete_event):
            text = document.text_before_cursor
            words = text.split()

            # Если это первое слово, используем статический completer
            if len(words) <= 1:
                for item in self.static_completer.get_completions(document, complete_event):
                    yield item
                return

            # Для команд с аргументами пытаемся получить динамические completions
            command = words[0]

            # components команды
            if command == "components":
                if len(words) >= 2 and words[1] == "list":
                    # components list → показываем опции
                    word_before_cursor = document.get_word_before_cursor(WORD=True)
                    if not word_before_cursor or word_before_cursor.startswith("-"):
                        options = ["--columns", "--filter", "--limit", "--output", "--no-headers", "--no-cache"]
                        prefix = word_before_cursor if word_before_cursor else ""
                        for opt in options:
                            if opt.startswith(prefix):
                                yield Completion(opt, start_position=-len(prefix))
                elif len(words) >= 2 and words[1] in ["get", "start", "stop", "upgrade", "tags"]:
                    # Для команд с аргументами - автодополнение имен компонентов
                    components = self.completion_manager.get_components()
                    word_before_cursor = document.get_word_before_cursor(WORD=True)
                    for comp in components:
                        if comp.startswith(word_before_cursor):
                            yield Completion(comp, start_position=-len(word_before_cursor))

            # nodes команды
            elif command == "nodes" and len(words) >= 2 and words[1] == "list":
                # nodes list → показываем опции
                word_before_cursor = document.get_word_before_cursor(WORD=True)
                if not word_before_cursor or word_before_cursor.startswith("-"):
                    options = ["--columns", "--filter", "--limit", "--output", "--no-headers", "--no-cache"]
                    prefix = word_before_cursor if word_before_cursor else ""
                    for opt in options:
                        if opt.startswith(prefix):
                            yield Completion(opt, start_position=-len(prefix))
            elif command == "nodes" and len(words) >= 2 and words[1] in ["get", "update"]:
                # nodes get/update → показываем имена нод
                nodes = self.completion_manager.get_nodes()
                word_before_cursor = document.get_word_before_cursor(WORD=True)
                for node in nodes:
                    if node.startswith(word_before_cursor):
                        yield Completion(node, start_position=-len(word_before_cursor))

            # stacks команды
            elif command == "stacks" and len(words) >= 2 and words[1] == "list":
                # stacks list → показываем опции
                word_before_cursor = document.get_word_before_cursor(WORD=True)
                if not word_before_cursor or word_before_cursor.startswith("-"):
                    options = ["--columns", "--filter", "--limit", "--output", "--no-headers", "--no-cache"]
                    prefix = word_before_cursor if word_before_cursor else ""
                    for opt in options:
                        if opt.startswith(prefix):
                            yield Completion(opt, start_position=-len(prefix))
            elif command == "stacks" and len(words) >= 2 and words[1] in ["get", "undeploy"]:
                # stacks get/undeploy → показываем имена стеков
                stacks = self.completion_manager.get_stacks()
                word_before_cursor = document.get_word_before_cursor(WORD=True)
                for stack in stacks:
                    if stack.startswith(word_before_cursor):
                        yield Completion(stack, start_position=-len(word_before_cursor))

            # logs команды
            elif command == "logs" and len(words) == 1:
                components = self.completion_manager.get_components()
                word_before_cursor = document.get_word_before_cursor(WORD=True)
                for comp in components:
                    if comp.startswith(word_before_cursor):
                        yield Completion(comp, start_position=-len(word_before_cursor))

            # Используем статический completer как fallback
            for item in self.static_completer.get_completions(document, complete_event):
                yield item

    return ImgctlCompleter(completion_manager, commands_dict)


def create_prompt_session(ctx, completion_manager: CompletionManager):
    """Создает сессию REPL с автодополнением и историей"""
    if not PROMPT_TOOLKIT_AVAILABLE:
        console.print("[red]prompt-toolkit не установлен. Установите: pip install prompt-toolkit[/red]")
        return None

    from prompt_toolkit import PromptSession
    from prompt_toolkit.history import FileHistory
    from prompt_toolkit.auto_suggest import AutoSuggestFromHistory
    from prompt_toolkit.key_binding import KeyBindings

    # Создаем историю в домашней директории
    history_file = Path.home() / ".imgctl_history"
    history = FileHistory(str(history_file))

    # Создаем completer используя контекст
    from cli.main import main
    ctx_copy = click.Context(main)
    completer = create_imgctl_completer(ctx_copy, completion_manager)

    # Key bindings для удобства
    kb = KeyBindings()

    @kb.add("c-c")
    def _(event):
        """Ctrl+C для выхода"""
        event.app.exit()

    # Получаем цвета из конфига для промпта
    try:
        from cli.main import get_api_client
        server = ctx.obj.get('server') if ctx and hasattr(ctx, 'obj') else None
        username = ctx.obj.get('username') if ctx and hasattr(ctx, 'obj') else None
        password = ctx.obj.get('password') if ctx and hasattr(ctx, 'obj') else None
        config = ctx.obj.get('config') if ctx and hasattr(ctx, 'obj') else None

        api = get_api_client(
            verbose=False,
            server=server,
            username=username,
            password=password,
            config=config,
        )

        console_config = api.get_console_config()
        console_name = console_config.get("consoleName", "imgctl")
        console_color = console_config.get("consoleColor", "#00D9FF")
    except Exception:
        console_name = "imgctl"
        console_color = "#00D9FF"

    # Создаем промпт с цветом фона в стиле zsh
    # hex цвет конвертируем в RGB для правильного отображения
    hex_color = console_color.lstrip('#')
    rgb = tuple(int(hex_color[i:i + 2], 16) for i in (0, 2, 4))

    # Определяем цвет фона и текста на основе яркости
    r, g, b = rgb
    # Вычисляем яркость для определения цвета текста
    brightness = (r * 299 + g * 587 + b * 114) / 1000

    def create_prompt():
        """Динамически создает промпт с именем стенда через Rich"""
        # Формат: "imgctl (имя стенда)> "
        from rich.text import Text
        from rich.console import Console

        # Создаем цветной текст с заливкой через Rich
        prompt_text = Text(f"{console_name}> ", style=f"bold white on {console_color}")

        # Конвертируем в ANSI через Rich
        console_temp = Console(force_terminal=False, legacy_windows=False, color_system="auto")
        with console_temp.capture() as capture:
            console_temp.print(prompt_text, end="")
        ansi_str = capture.get()

        # Rich генерирует правильные ANSI коды
        return ansi_str

    # Создаем сессию с автодополнением, но без выпадающего меню
    session = PromptSession(
        history=history,
        completer=completer,
        auto_suggest=AutoSuggestFromHistory(),
        key_bindings=kb,
        message=create_prompt,
        refresh_interval=0.1,
        rprompt='',
        complete_while_typing=False,  # Автодополнение только по Tab
        complete_style='readline',  # Стиль Readline без выпадающего списка
        enable_open_in_editor=True,
        enable_suspend=True,
    )

    return session


def process_command(ctx, command_text: str) -> bool:
    """
    Обрабатывает команду в REPL режиме

    Returns:
        bool: True если нужно выйти из REPL
    """
    # Проверяем что текст не None и не пустой
    if not command_text:
        return False

    command_text = command_text.strip()
    if not command_text:
        return False

    # Специальные команды REPL
    if command_text.lower() in ["exit", "quit"]:
        return True
    elif command_text.lower() == "help":
        show_repl_help(ctx)
        return False
    elif command_text.lower() == "clear":
        click.clear()
        return False

    # Парсим команду через shlex для правильной обработки кавычек
    try:
        parts = shlex.split(command_text)
        if not parts:
            return False

        # Вызываем Click команду через context
        return invoke_command(ctx, parts)

    except Exception as e:
        console.print(f"[red]Ошибка выполнения команды: {e}[/red]")
        import traceback

        traceback.print_exc()
        return False


def invoke_command(ctx, parts: List[str]) -> bool:
    """
    Вызывает Click команду из REPL

    Args:
        ctx: Click контекст
        parts: Разобранные части команды

    Returns:
        bool: True если нужно выйти
    """
    # Сохраняем оригинальный sys.argv
    old_argv = sys.argv[:]

    try:
        # Устанавливаем новый argv
        # Устанавливаем флаг shell-mode в переменной окружения
        # чтобы команды знали что нужно использовать кэш и не показывать заголовок
        os.environ["IMGCTL_SHELL_MODE"] = "1"

        # Добавляем параметры командной строки из ctx.obj если они есть
        argv_parts = ["imgctl"]

        # Добавляем параметры из ctx.obj если они установлены при запуске shell
        if ctx and hasattr(ctx, 'obj'):
            server = ctx.obj.get('server')
            if server:
                argv_parts.extend(['--server', server])
            username = ctx.obj.get('username')
            password = ctx.obj.get('password')
            if username and password:
                argv_parts.extend(['--username', username, '--password', password])

        # Добавляем части команды пользователя
        argv_parts.extend(parts)

        sys.argv = argv_parts

        # Получаем главную функцию
        from cli.main import main

        # Вызываем main напрямую
        # Click сам разберет аргументы из sys.argv
        main()

        return False

    except SystemExit:
        # Click может вызывать SystemExit для выхода
        # Это нормально
        pass
    except KeyboardInterrupt:
        console.print("\n[yellow]Прервано пользователем[/yellow]")
    except Exception as e:
        console.print(f"[red]Ошибка: {e}[/red]")
        import traceback

        traceback.print_exc()
    finally:
        sys.argv = old_argv
        # Убираем флаг после выполнения команды
        os.environ.pop("IMGCTL_SHELL_MODE", None)

    return False


def show_repl_help(ctx):
    """Показывает справку по REPL используя Click"""
    from cli.main import main

    help_text = """## imgctl REPL - Интерактивная оболочка

### Доступные команды:

"""

    # Получаем список команд из Click
    commands_list = []
    for cmd_name, cmd in main.commands.items():
        cmd_help = cmd.get_short_help_str() if hasattr(cmd, 'get_short_help_str') else ""
        commands_list.append(f"**{cmd_name}** - {cmd_help}")

    help_text += "\n".join(commands_list)
    help_text += """

### Специальные команды:
- `help` - Показать эту справку
- `clear` - Очистить экран  
- `exit` или `quit` - Выйти из REPL

### Примеры:
```bash
imgctl> components list
imgctl> components get web-api-staging
imgctl> servers list
imgctl> exit
```

### Советы:
- Используйте TAB для автодополнения
- Используйте стрелки для истории команд
- Введите `команда --help` для справки по команде
"""

    console.print(Markdown(help_text))


def background_cache_updater(ctx):
    """
    Фоновый поток для обновления кэша компонентов каждые 5 секунд
    Временно убираем IMGCTL_SHELL_MODE чтобы фоновая загрузка могла обновить кэш
    """
    while not _stop_cache_updates.wait(timeout=5):
        try:
            # Помечаем что загрузка началась
            with _cache_update_lock:
                _cache_update_in_progress.set()

            # Временно убираем shell mode чтобы загрузка могла обновить кэш
            old_shell_mode = os.environ.get("IMGCTL_SHELL_MODE")
            os.environ.pop("IMGCTL_SHELL_MODE", None)

            try:
                # Вызываем components list для обновления кэша (force_refresh=True для фона)
                invoke_cache_update(ctx, force_refresh=True)
            finally:
                # Восстанавливаем shell mode
                if old_shell_mode:
                    os.environ["IMGCTL_SHELL_MODE"] = old_shell_mode

            # Помечаем что загрузка завершена
            with _cache_update_lock:
                _cache_update_in_progress.clear()
        except Exception:
            # Игнорируем ошибки в фоновом потоке
            with _cache_update_lock:
                _cache_update_in_progress.clear()
            pass


def invoke_cache_update(ctx, force_refresh=True):
    """
    Выполняет обновление кэша компонентов в фоне через API клиент

    Args:
        ctx: Click контекст
        force_refresh: Если True, игнорирует кэш и загружает свежие данные
    """
    try:
        # Получаем API клиент из контекста
        from cli.main import get_api_client

        # Создаем или получаем API клиент
        if ctx and hasattr(ctx, 'obj') and ctx.obj.get('api'):
            api = ctx.obj['api']
        else:
            # Создаем API клиент из контекста
            server = ctx.obj.get('server') if ctx and hasattr(ctx, 'obj') else None
            username = ctx.obj.get('username') if ctx and hasattr(ctx, 'obj') else None
            password = ctx.obj.get('password') if ctx and hasattr(ctx, 'obj') else None
            config = ctx.obj.get('config') if ctx and hasattr(ctx, 'obj') else None
            verbose = ctx.obj.get('verbose', False) if ctx and hasattr(ctx, 'obj') else False

            api = get_api_client(
                verbose=verbose,
                server=server,
                username=username,
                password=password,
                config=config,
            )

        # Вызываем API метод
        # force_refresh=True для фонового потока (всегда обновляем)
        api.get_components(no_cache=force_refresh)

    except Exception:
        # Игнорируем ошибки в фоновом потоке
        pass


def get_cache_aware_data(ctx):
    """
    Получает данные с поддержкой stale-while-revalidate:
    - Если идет фоновая загрузка - возвращает старые данные из кэша
    - Если нет фоновой загрузки и кэш истек - запускает свою загрузку
    """
    try:
        # Проверяем идет ли фоновая загрузка
        with _cache_update_lock:
            is_loading = _cache_update_in_progress.is_set()

        if is_loading:
            # Фоновая загрузка идет - возвращаем старые данные из кэша
            return invoke_cache_update(ctx, force_refresh=False)
        else:
            # Фоновой загрузки нет - используем обычную логику кэширования
            return invoke_cache_update(ctx, force_refresh=False)
    except Exception:
        # В случае ошибки пробуем обычный способ
        return invoke_cache_update(ctx, force_refresh=False)


def start_background_cache_updater(ctx):
    """
    Запускает фоновый поток для обновления кэша
    """
    global _cache_update_thread
    global _stop_cache_updates

    if _cache_update_thread is None or not _cache_update_thread.is_alive():
        _stop_cache_updates.clear()
        _cache_update_thread = threading.Thread(
            target=background_cache_updater,
            args=(ctx,),
            daemon=True,
            name="imgctl_cache_updater"
        )
        _cache_update_thread.start()


def stop_background_cache_updater():
    """
    Останавливает фоновый поток для обновления кэша
    """
    global _stop_cache_updates
    _stop_cache_updates.set()


def show_welcome(ctx):
    """Показывает стандартный заголовок консоли"""
    try:
        from utils.formatters import show_console_header
        from cli.main import get_api_client

        # Получаем API клиент из контекста или создаем новый
        if ctx and hasattr(ctx, 'obj') and ctx.obj.get('api'):
            api = ctx.obj['api']
        else:
            # Создаем API клиент из контекста
            server = ctx.obj.get('server') if ctx and hasattr(ctx, 'obj') else None
            username = ctx.obj.get('username') if ctx and hasattr(ctx, 'obj') else None
            password = ctx.obj.get('password') if ctx and hasattr(ctx, 'obj') else None
            config = ctx.obj.get('config') if ctx and hasattr(ctx, 'obj') else None
            verbose = ctx.obj.get('verbose', False) if ctx and hasattr(ctx, 'obj') else False

            api = get_api_client(
                verbose=verbose,
                server=server,
                username=username,
                password=password,
                config=config,
            )

        show_console_header(api, show_header=True)
    except Exception as e:
        # Fallback: заголовок по умолчанию
        try:
            from utils.formatters import display_console_header
            display_console_header("Imagenarium")
        except:
            pass


@click.command("shell")
@click.argument("server", required=False)
@click.pass_context
def shell(ctx, server):
    """
    Запускает интерактивную оболочку imgctl (REPL режим)

    Позволяет выполнять команды imgctl в интерактивном режиме
    с поддержкой автодополнения и истории команд.

    Пример использования:

    \b
        $ imgctl shell
        imgctl> components list
        imgctl> components get web-api-staging
        imgctl> exit

        $ imgctl shell dev
        $ imgctl shell stage
    """
    # Если указан сервер, сохраняем его в контекст
    if server:
        if ctx.obj is None:
            ctx.obj = {}
        ctx.obj['server'] = server

    if not PROMPT_TOOLKIT_AVAILABLE:
        console.print("[red]Ошибка: prompt-toolkit не установлен[/red]")
        console.print("[yellow]Установите: pip install prompt-toolkit[/yellow]")
        return

    # Инициализируем CompletionManager для автодополнения
    # Передаем указанный сервер или None для использования текущего сервера
    completion_manager = CompletionManager(server_name=server)

    # Показываем стандартный заголовок
    # Временно сбрасываем IMGCTL_SHELL_MODE чтобы показать заголовок при входе
    shell_mode_was_set = os.environ.pop("IMGCTL_SHELL_MODE", None)
    show_welcome(ctx)
    if shell_mode_was_set:
        os.environ["IMGCTL_SHELL_MODE"] = shell_mode_was_set
    else:
        # Устанавливаем флаг shell-mode для команд внутри shell
        os.environ["IMGCTL_SHELL_MODE"] = "1"

    # Запускаем фоновое обновление кэша
    start_background_cache_updater(ctx)

    # НЕ предзагружаем данные сразу - пусть фоновое обновление делает это
    # Автодополнение будет использовать данные из кэша когда они появятся

    # Создаем сессию
    session = create_prompt_session(ctx, completion_manager)
    if session is None:
        return

    # Основной цикл REPL
    while True:
        try:
            # Получаем команду от пользователя (промпт берется из message функции)
            text = session.prompt()

            # Обрабатываем команду только если текст не пустой
            if text:
                should_exit = process_command(ctx, text)

                if should_exit:
                    break
            else:
                # Если text is None (EOF), выходим
                break

        except KeyboardInterrupt:
            # Ctrl+C - показываем сообщение
            console.print("\n[yellow]Нажмите Ctrl+C еще раз для выхода или введите exit[/yellow]")
            try:
                text = session.prompt()
                should_exit = process_command(ctx, text)
                if should_exit:
                    break
            except (KeyboardInterrupt, EOFError):
                break
        except EOFError:
            # Ctrl+D - выход
            break

    # Останавливаем фоновое обновление кэша
    stop_background_cache_updater()
