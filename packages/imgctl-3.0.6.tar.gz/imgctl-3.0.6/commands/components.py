"""
Команды для управления компонентами
"""

import os
from typing import Optional

import click
from rich.console import Console
from rich.progress import Progress, SpinnerColumn, TextColumn, TimeElapsedColumn

from core.api_client import ImagenariumAPIError
from utils.formatters import format_table, format_output, show_console_header
from utils.verbose import verbose_print, set_verbose

console = Console()


def _get_api_client(verbose: bool = False, ctx=None):
    """Создает API клиент с заданными параметрами"""
    from cli.main import get_api_client

    # Получаем параметры из контекста если доступен
    if ctx and hasattr(ctx, "obj"):
        server = ctx.obj.get("server")
        username = ctx.obj.get("username")
        password = ctx.obj.get("password")
        config = ctx.obj.get("config")
        return get_api_client(
            verbose=verbose,
            server=server,
            username=username,
            password=password,
            config=config,
        )
    else:
        return get_api_client(verbose=verbose)


def _extract_tag_from_task(comp):
    """
    Извлекает тег из task'а, у которого image совпадает с компонентом

    Логика:
    - Для .DeployedService: ищем task с совпадающим базовым образом
    - Для .DeployedRunner: ищем task с совпадающим childContainer.image

    Args:
        comp: Словарь с данными компонента

    Returns:
        str: Тег из task или None если не найден
    """
    # Получаем тип компонента
    component_type = comp.get("@c", "")

    # Получаем tasks из компонента
    tasks = comp.get("tasks", [])
    if not tasks or len(tasks) == 0:
        return None

    # Определяем базовый образ для сравнения
    if component_type == ".DeployedRunner":
        # Для .DeployedRunner сравниваем с childContainer.image
        child_container = comp.get("childContainer")
        if not child_container or not child_container.get("image"):
            return None
        component_image = child_container.get("image")
    else:
        # Для .DeployedService сравниваем с image компонента
        component_image = comp.get("image", "")

    # Получаем базовое имя образа компонента (без тега)
    component_base = _get_image_without_tag(component_image)

    # Для .DeployedRunner возвращаем тег из childContainer.image
    if component_type == ".DeployedRunner":
        # Извлекаем тег из childContainer.image
        _, tag = component_image.rsplit(":", 1)
        return tag if tag else None

    # Для .DeployedService ищем task с совпадающим образом
    for task in tasks:
        task_image = task.get("image", "")
        if not task_image or ":" not in task_image:
            continue

        # Получаем базовое имя образа task
        task_base = _get_image_without_tag(task_image)

        # Если образы совпадают, используем этот task
        if task_base and component_base and task_base == component_base:
            # Извлекаем тег
            _, task_tag = task_image.rsplit(":", 1)
            # Возвращаем тег только если он не пустой
            return task_tag if task_tag else None

    # Если не нашли совпадающий task, берем первый
    task = tasks[0]
    task_image = task.get("image", "")
    if not task_image or ":" not in task_image:
        return None

    # Извлекаем тег
    _, task_tag = task_image.rsplit(":", 1)
    # Возвращаем тег только если он не пустой
    return task_tag if task_tag else None


def _extract_tag_from_component(comp):
    """
    Извлекает тег из компонента (image или childContainer)

    Args:
        comp: Словарь с данными компонента

    Returns:
        str: Тег компонента
    """
    # Получаем правильный образ - если есть childContainer, используем его образ
    image = comp.get("image", "")
    child_container = comp.get("childContainer")
    if child_container and child_container.get("image"):
        image = child_container.get("image")

    # Разделяем образ на имя и тег
    if ":" in image:
        image_name, image_tag = image.rsplit(":", 1)
    else:
        image_name = image
        image_tag = "latest"

    return image_tag


def _get_image_without_tag(image_full):
    """
    Извлекает образ без тега (базовый image)

    Args:
        image_full: Полное имя образа с тегом

    Returns:
        str: Образ без тега
    """
    if ":" in image_full:
        return image_full.rsplit(":", 1)[0]
    return image_full


def _determine_component_status(comp):
    """
    Определяет статус компонента на основе его полей

    Args:
        comp: Словарь с данными компонента

    Returns:
        str: Статус компонента
    """
    # Проверяем, выключен ли компонент
    if comp.get("off", False):
        return "OFF"

    # Получаем тип компонента
    component_type = comp.get("@c", "")

    # Определяем базовый образ для сравнения
    if component_type == ".DeployedRunner":
        # Для .DeployedRunner сравниваем с childContainer.image
        child_container = comp.get("childContainer")
        if not child_container or not child_container.get("image"):
            # Нет childContainer, пропускаем проверку на BROKEN
            pass
        else:
            comp_image = child_container.get("image")
            comp_base_image = _get_image_without_tag(comp_image)

            # Получаем tasks
            tasks = comp.get("tasks", [])
            if tasks and len(tasks) > 0:
                task_image = tasks[0].get("image", "")
                task_base_image = _get_image_without_tag(task_image)

                # Сравниваем базовые образы - если совпадают, проверяем на BROKEN
                if task_base_image and comp_base_image and task_base_image == comp_base_image:
                    # Извлекаем теги
                    component_tag = _extract_tag_from_component(comp)
                    task_tag = _extract_tag_from_task(comp)

                    # Если теги не совпадают, устанавливаем BROKEN
                    if task_tag and component_tag and component_tag != task_tag:
                        return "BROKEN"
    else:
        # Для .DeployedService сравниваем с image компонента
        comp_image = comp.get("image", "")
        comp_base_image = _get_image_without_tag(comp_image)

        # Получаем tasks
        tasks = comp.get("tasks", [])
        if tasks and len(tasks) > 0:
            task_image = tasks[0].get("image", "")
            task_base_image = _get_image_without_tag(task_image)

            # Сравниваем базовые образы - если совпадают, проверяем на BROKEN
            if task_base_image and comp_base_image and task_base_image == comp_base_image:
                # Извлекаем теги
                component_tag = _extract_tag_from_component(comp)
                task_tag = _extract_tag_from_task(comp)

                # Если теги не совпадают, устанавливаем BROKEN
                if task_tag and component_tag and component_tag != task_tag:
                    return "BROKEN"

    # Получаем информацию о репликах
    desired_replicas = comp.get("desiredReplicas", None)
    running_replicas = comp.get("runningReplicas", None)

    # Если поля реплик отсутствуют, используем fallback
    if desired_replicas is None or running_replicas is None:
        return comp.get("stackStatus", "UNKNOWN")

    # Если нет желаемых реплик, компонент остановлен
    if desired_replicas == 0:
        return "STOPPED"

    # Если есть желаемые реплики, но нет запущенных
    if desired_replicas > 0 and running_replicas == 0:
        return "STARTING"

    # Если все реплики запущены
    if running_replicas == desired_replicas:
        return "RUNNING"

    # Если запущено меньше реплик, чем желается
    if running_replicas < desired_replicas:
        return f"PARTIAL ({running_replicas}/{desired_replicas})"

    # Fallback на stackStatus
    return comp.get("stackStatus", "UNKNOWN")


def _truncate_image_name(image_name, max_length=50):
    """Обрезает длинные имена образов для лучшего отображения"""
    if len(image_name) <= max_length:
        return image_name

    # Если образ начинается с registry, оставляем его и обрезаем путь
    if "/" in image_name:
        parts = image_name.split("/")
        if len(parts) >= 2:
            registry = parts[0]
            path = "/".join(parts[1:])

            # Если registry + часть пути помещается, используем это
            if len(registry) + 1 + 20 <= max_length:
                return f"{registry}/...{path[-15:]}"
            else:
                # Иначе обрезаем с начала
                return f"...{image_name[-(max_length - 3):]}"

    # Для простых имен обрезаем с начала
    return f"...{image_name[-(max_length - 3):]}"


def _highlight_component_name(name, namespace):
    """Подсвечивает имя компонента: все что до namespace обычным белым, namespace серым"""
    if "-" in name and namespace:
        # Ищем namespace в конце имени компонента
        namespace_suffix = f"-{namespace}"
        if name.endswith(namespace_suffix):
            component_part = name[: -len(namespace_suffix)]
            # Возвращаем строку с Rich markup
            return f"{component_part}[dim]{namespace_suffix}[/dim]"
        else:
            # Если namespace не найден в конце, ищем его в середине
            # Например: oms-suzlet-suz5 с namespace suzlet-suz5
            if namespace in name:
                # Находим позицию namespace в имени
                namespace_pos = name.find(namespace)
                if namespace_pos > 0 and name[namespace_pos - 1] == "-":
                    # Namespace найден после дефиса
                    component_part = name[: namespace_pos - 1]
                    namespace_part = name[namespace_pos - 1:]
                    return f"{component_part}[dim]{namespace_part}[/dim]"

    return name


def _highlight_tag(tag):
    """Подсвечивает тег: дату серым, хеш обычным белым"""
    if "__" in tag:
        # Разделяем на дату и хеш
        parts = tag.split("__", 1)
        if len(parts) == 2:
            date_part = parts[0] + "__"
            hash_part = parts[1]
            return f"[dim]{date_part}[/dim]{hash_part}"

    return tag


def _create_highlighted_tag_text(tag):
    """Создает Text объект с правильной раскраской тега"""
    from rich.text import Text

    text = Text()

    if "__" in tag:
        parts = tag.split("__", 1)
        if len(parts) == 2:
            date_part = parts[0] + "__"
            hash_part = parts[1]
            text.append(date_part, style="dim")
            text.append(hash_part)
        else:
            text.append(tag)
    else:
        text.append(tag)

    return text


def _filter_columns(data, columns_spec):
    """Фильтрует столбцы данных согласно пользовательским настройкам"""
    from utils.dynamic_columns import parse_columns_with_env_support

    # Столбцы по умолчанию
    default_columns = ["NAME", "NAMESPACE", "IMAGE", "TAG", "UPDATED", "STATUS"]

    # Все доступные столбцы (базовые)
    all_columns = [
        "NAME",
        "NAMESPACE",
        "STACK",
        "IMAGE",
        "TAG",
        "STACK_VERSION",
        "STATUS",
        "REPLICAS",
        "PORTS",
        "UPDATED",
        "CREATED",
        "REPO",
        "COMMIT",
        "ADMIN_MODE",
        "RUN_APP",
        "SHOW_ADMIN_MODE",
        "OFF",
        "NETWORKS",
        "ENV",
    ]

    # Собираем все доступные столбцы включая динамические ENV.<переменная>
    if data:
        all_available_columns = set(all_columns)
        for row in data:
            all_available_columns.update(row.keys())
        all_columns = list(all_available_columns)

    # Парсим спецификацию столбцов с поддержкой ENV
    requested_columns = parse_columns_with_env_support(
        columns_spec, default_columns, all_columns
    )

    # Фильтруем данные
    filtered_data = []
    for row in data:
        filtered_row = {}
        for col in requested_columns:
            if col in row:
                filtered_row[col] = row[col]
        if filtered_row:  # Добавляем только если есть хотя бы один столбец
            filtered_data.append(filtered_row)

    return filtered_data, requested_columns


@click.group()
def cli():
    """Управление компонентами приложений"""
    pass


@cli.command("list")
@click.option("--limit", "-l", type=int, help="Ограничить количество записей")
@click.option("--no-cache", is_flag=True, help="Отключить кэширование")
@click.option(
    "--columns",
    help='Столбцы для отображения. Форматы: "NAME,STATUS" или "+REPLICAS,-NAMESPACE". Доступные: NAME, NAMESPACE, STACK, IMAGE, TAG, STACK_VERSION, STATUS, REPLICAS, PORTS, UPDATED, CREATED, REPO, COMMIT, ADMIN_MODE, RUN_APP, SHOW_ADMIN_MODE, OFF, NETWORKS, ENV, ENV.<переменная>',
)
@click.option(
    "--filter",
    multiple=True,
    help="Фильтрация данных. Формат: COLUMN=value, COLUMN!=value, COLUMN~pattern. Примеры: STATUS=RUNNING, NAMESPACE!=test, NAME~postgres, ENV~database, ENV.DB_HOST=localhost",
)
@click.option("--no-headers", is_flag=True, help="Не показывать заголовок консоли")
@click.option(
    "--output",
    "-o",
    help='Формат вывода данных: json, yaml, tsv, или template (например: "{NAME} - {STATUS}")',
)
@click.option("--verbose", "-v", is_flag=True, help="Подробный вывод HTTP запросов")
@click.pass_context
def list_components(ctx, limit, no_cache, columns, filter, no_headers, output, verbose):
    """Показывает список развернутых компонентов

    По умолчанию: NAME, NAMESPACE, IMAGE, TAG, UPDATED, STATUS. Дополнительные: STACK, STACK_VERSION, REPLICAS, PORTS, CREATED, REPO, COMMIT, ADMIN_MODE, RUN_APP, SHOW_ADMIN_MODE, OFF, NETWORKS, ENV, ENV.<переменная>
    """
    try:
        # Устанавливаем режим verbose для логирования
        set_verbose(verbose)

        # Создаем API клиент с нужными параметрами
        api = _get_api_client(verbose=verbose, ctx=ctx)

        # Показываем заголовок консоли (скрываем при --no-headers или --output)
        show_console_header(api, show_header=not (no_headers or output))

        # Показываем прогресс-бар для длительных запросов
        with Progress(
                SpinnerColumn(),
                TextColumn("[progress.description]{task.description}"),
                TimeElapsedColumn(),
                console=console,
                transient=True,
        ) as progress:
            task = progress.add_task(
                "Получение информации о компонентах...", total=None
            )

            # Используем UI API (быстрее) - получаем все данные
            components = api.get_components(no_cache=no_cache)

            progress.update(task, description="Обработка данных...")

        if not components:
            console.print("Компоненты не найдены")
            return

        # Собираем все компоненты в единую таблицу
        all_components_data = []

        for group in components:
            group_namespace = group.get("namespace", "Unknown")
            stacks = group.get("stacks", [])

            for stack_item in stacks:
                stack_id = stack_item.get("stackId", "")
                stack_version = stack_item.get("version", "")
                stack_status = stack_item.get("status", "")

                stack_components = stack_item.get("components", [])
                for comp in stack_components:
                    name = comp.get("name", "")

                    # Исключаем компоненты, начинающиеся с "checker-"
                    if name.startswith("checker-"):
                        continue

                    # Получаем тег из task (предпочтительно) или из component
                    task_tag = _extract_tag_from_task(comp)
                    component_tag = _extract_tag_from_component(comp)

                    # Используем тег из task, если он есть, иначе из component
                    image_tag = task_tag if task_tag else component_tag

                    # Получаем правильный образ для имени
                    image = comp.get("image", "")
                    child_container = comp.get("childContainer")
                    if child_container and child_container.get("image"):
                        image = child_container.get("image")

                    # Разделяем образ на имя и тег
                    if ":" in image:
                        image_name, _ = image.rsplit(":", 1)
                    else:
                        image_name = image

                    # Обрезаем длинные имена образов
                    image_name = _truncate_image_name(image_name)

                    # Получаем информацию о портах
                    published_ports = comp.get("publishedPorts", [])
                    if published_ports:
                        ports_info = []
                        for port in published_ports:
                            published_port = port.get("publishedPort", "")
                            target_port = port.get("targetPort", "")
                            protocol = port.get("protocol", "tcp")
                            if published_port and target_port:
                                ports_info.append(
                                    f"{published_port}:{target_port}/{protocol}"
                                )
                        ports = ", ".join(ports_info)
                    else:
                        ports = ""

                    # Определяем статус компонента на основе его полей
                    status = _determine_component_status(comp)

                    # Применяем цветовое кодирование к статусу
                    if status.upper() in ["RUNNING", "ACTIVE", "READY", "HEALTHY", "DEPLOYED"]:
                        colored_status = f"[green]{status}[/green]"
                    elif status.upper() in ["STOPPED", "INACTIVE", "TERMINATED", "FAILED", "ERROR", "OFF", "CANCELED"]:
                        colored_status = f"[red]{status}[/red]"
                    elif status.upper() in ["PENDING", "WAITING", "STARTING", "BROKEN"]:
                        colored_status = f"[yellow]{status}[/yellow]"
                    elif status.upper().startswith("PARTIAL"):
                        colored_status = f"[orange3]{status}[/orange3]"
                    else:
                        colored_status = status

                    replicas = comp.get("replicas", "")

                    # Получаем дату обновления
                    updated_timestamp = comp.get("updated", 0)
                    if updated_timestamp:
                        from datetime import datetime

                        updated_date = datetime.fromtimestamp(
                            updated_timestamp / 1000
                        ).strftime("%Y-%m-%d %H:%M")
                    else:
                        updated_date = ""

                    # Получаем дату создания
                    created_timestamp = comp.get("created", 0)
                    if created_timestamp:
                        from datetime import datetime

                        created_date = datetime.fromtimestamp(
                            created_timestamp / 1000
                        ).strftime("%Y-%m-%d %H:%M:%S")
                    else:
                        created_date = ""

                    # Получаем информацию о репозитории
                    repo = comp.get("repo", "")
                    commit = comp.get("commit", "")

                    # Получаем дополнительные флаги
                    admin_mode = comp.get("adminMode", False)
                    run_app = comp.get("runApp", False)
                    show_admin_mode = comp.get("showAdminMode", False)
                    off = comp.get("off", False)

                    # Получаем информацию о сетях
                    networks = comp.get("networks", [])
                    if networks:
                        network_info = []
                        for network in networks:
                            network_name = network.get("name", "")
                            driver = network.get("driver", "")
                            subnet = network.get("subnet", "")
                            network_info.append(f"{network_name} ({driver}) - {subnet}")
                        networks_str = ", ".join(network_info)
                    else:
                        networks_str = ""

                    # Получаем переменные окружения
                    env_vars = comp.get("environmentVariables", [])
                    env_data = {}  # Для отображения (с маскированием)
                    env_data_raw = {}  # Для фильтрации (исходные значения)
                    env_str = ""
                    if env_vars:
                        env_pairs = []
                        for env_var in env_vars:
                            for key, value in env_var.items():
                                # Сохраняем исходное значение для фильтрации
                                env_data_raw[key] = value

                                # Скрываем чувствительные данные для отображения
                                if any(
                                        sensitive in key.lower()
                                        for sensitive in [
                                            "password",
                                            "secret",
                                            "key",
                                            "token",
                                        ]
                                ):
                                    value = "***"
                                env_data[key] = value
                                env_pairs.append(f"{key}={value}")
                        env_str = ", ".join(env_pairs)

                    # Формируем имя стека с подсветкой
                    stack_name_with_namespace = f"{stack_id}@{group_namespace}"
                    if "@" in stack_name_with_namespace:
                        stack_name, namespace = stack_name_with_namespace.split("@", 1)
                        highlighted_stack = f"{stack_name}[dim]@{namespace}[/dim]"
                    else:
                        highlighted_stack = stack_name_with_namespace

                    # Подсвечиваем имя компонента
                    highlighted_name = _highlight_component_name(name, group_namespace)

                    # Создаем базовый словарь данных компонента
                    component_data = {
                        "NAME": highlighted_name,
                        "NAMESPACE": group_namespace,
                        "STACK": highlighted_stack,
                        "IMAGE": image_name,
                        "TAG": image_tag,
                        "STACK_VERSION": stack_version,
                        "STATUS": colored_status,
                        "REPLICAS": str(replicas),
                        "PORTS": ports,
                        "UPDATED": updated_date,
                        "CREATED": created_date,
                        "REPO": repo,
                        "COMMIT": commit,
                        "ADMIN_MODE": admin_mode,
                        "RUN_APP": run_app,
                        "SHOW_ADMIN_MODE": show_admin_mode,
                        "OFF": off,
                        "NETWORKS": networks_str,
                        "ENV": env_str,
                    }

                    # Создаем строку для фильтрации с исходными значениями
                    env_str_raw = ""
                    if env_vars:
                        env_pairs_raw = []
                        for env_var in env_vars:
                            for key, value in env_var.items():
                                env_pairs_raw.append(f"{key}={value}")
                        env_str_raw = ", ".join(env_pairs_raw)

                    # Всегда добавляем столбец ENV для фильтрации с исходными значениями
                    component_data["ENV"] = env_str_raw

                    # Добавляем динамические столбцы для каждой переменной окружения (для отображения)
                    for key, value in env_data.items():
                        component_data[f"ENV.{key}"] = value

                    # Добавляем динамические столбцы с исходными значениями для фильтрации
                    for key, value in env_data_raw.items():
                        component_data[f"ENV.{key}_RAW"] = value

                    all_components_data.append(component_data)

        # Применяем лимит
        if limit:
            all_components_data = all_components_data[:limit]

        if not all_components_data:
            console.print("Компоненты не найдены")
            return

        # Применяем фильтры данных
        from utils.formatters import apply_filters
        from utils.dynamic_columns import (
            parse_filters_with_env_support,
            convert_env_filters_to_raw,
        )

        if filter:
            parsed_filters = parse_filters_with_env_support(list(filter))
            # Преобразуем фильтры ENV в фильтры по исходным значениям
            converted_filters = convert_env_filters_to_raw(parsed_filters)
            all_components_data = apply_filters(all_components_data, converted_filters)

        # Применяем фильтрацию столбцов
        filtered_data, requested_columns = _filter_columns(all_components_data, columns)

        # Выводим данные в указанном формате
        if not output or output == "table":
            # Передаем фильтры для подсветки совпадений
            highlight_filters = (
                parse_filters_with_env_support(list(filter)) if filter else None
            )

            format_table(
                filtered_data,
                columns=requested_columns,
                no_headers=no_headers,
                highlight_filters=highlight_filters,
            )
        else:
            format_output(filtered_data, output, columns=requested_columns)

    except ImagenariumAPIError as e:
        console.print(f"[red]Ошибка получения списка компонентов: {e}[/red]")
        raise click.Abort()


@cli.command("stop")
@click.argument("name")
@click.option("--no-headers", is_flag=True, help="Не показывать заголовок консоли")
@click.pass_context
def stop_component(ctx, name, no_headers):
    """Останавливает компонент"""
    try:
        # Создаем API клиент с нужными параметрами
        api = _get_api_client(verbose=False, ctx=ctx)

        # Показываем заголовок консоли
        show_console_header(api, show_header=not no_headers)

        console.print(f"[blue]Остановка компонента {name}...[/blue]")
        api.stop_component(name)
        console.print(f"[green]Компонент {name} успешно остановлен[/green]")

    except ImagenariumAPIError as e:
        console.print(f"[red]Ошибка остановки компонента: {e}[/red]")
        raise click.Abort()


@cli.command("start")
@click.argument("name")
@click.option("--logs", is_flag=True, help="Показать логи компонента после запуска")
@click.option("--no-cache", is_flag=True, help="Отключить кэширование")
@click.option("--no-headers", is_flag=True, help="Не показывать заголовок консоли")
@click.pass_context
def start_component(ctx, name, logs, no_cache, no_headers):
    """Запускает компонент"""
    try:
        # Создаем API клиент с нужными параметрами
        api = _get_api_client(verbose=False, ctx=ctx)

        # Показываем заголовок консоли
        show_console_header(api, show_header=not no_headers)

        # Запускаем компонент (как в stop - без лишних проверок)
        console.print(f"[blue]Запуск компонента {name}...[/blue]")
        api.start_component(name)
        console.print(f"[green]Компонент {name} успешно запущен[/green]")

        # Если запрошены логи, показываем их
        if logs:
            import time
            from commands.logs import stream_logs, get_component_info

            console.print(f"[blue]Показ логов компонента {name}...[/blue]")

            # Небольшая задержка, чтобы компонент успел запуститься
            time.sleep(2)

            try:
                # Получаем информацию о компоненте для получения ID
                # Сначала пробуем использовать кеш
                component_info = get_component_info(api, name, use_cache=True)
                if component_info:
                    # Получаем ID компонента
                    component_id = component_info.get("id")

                    if component_id:
                        try:
                            stream_logs(
                                api,
                                component_id,
                                lines=5,
                                follow=False,
                                level_filter=None,
                                show_pings=False,
                            )
                        except Exception as e:
                            error_msg = str(e)
                            # Перехватываем любые ошибки при получении логов (включая timeout)
                            if (
                                    "There is no container, service or task with ID"
                                    in error_msg
                                    or "Read timed out" in error_msg
                                    or "Connection" in error_msg
                            ):
                                console.print(
                                    f"[yellow]Task ID {component_id} не найден, обновляем кеш...[/yellow]"
                                )

                                # Инвалидируем кеш для этого компонента
                                cache_key = f"component_info:{name}"
                                if api.cache:
                                    api.cache.invalidate(cache_key)
                                    console.print(
                                        f"[dim]Кеш для {name} инвалидирован[/dim]"
                                    )

                                # Получаем свежую информацию о компоненте
                                console.print(
                                    f"[blue]Повторный поиск компонента {name}...[/blue]"
                                )
                                component_info = get_component_info(
                                    api, name, use_cache=False
                                )

                                if not component_info:
                                    console.print(
                                        f"[red]Компонент {name} не найден после обновления кеша[/red]"
                                    )
                                    return

                                # Получаем новый ID компонента
                                new_component_id = component_info.get("id")

                                if not new_component_id:
                                    console.print(
                                        f"[red]Не удалось получить новый ID компонента {name}[/red]"
                                    )
                                    return

                                console.print(
                                    f"[green]Найден компонент: {name} (ID: {new_component_id})[/green]"
                                )

                                # Повторяем попытку с новым ID
                                stream_logs(
                                    api,
                                    new_component_id,
                                    lines=5,
                                    follow=False,
                                    level_filter=None,
                                    show_pings=False,
                                )
                            else:
                                # Если это другая ошибка, просто пробрасываем её
                                raise
                    else:
                        console.print(
                            f"[red]Не удалось получить ID компонента {name}[/red]"
                        )
                else:
                    console.print(
                        f"[red]Компонент {name} не найден для логирования[/red]"
                    )
            except Exception as e:
                console.print(f"[red]Ошибка показа логов: {e}[/red]")

    except ImagenariumAPIError as e:
        console.print(f"[red]Ошибка запуска компонента: {e}[/red]")
        raise click.Abort()


@cli.command("get")
@click.argument("name")
@click.option("--no-cache", is_flag=True, help="Отключить кэширование")
@click.option("--verbose", "-v", is_flag=True, help="Подробный вывод HTTP запросов")
@click.pass_context
def get_component(ctx, name, no_cache, verbose):
    """Показывает детальную информацию о компоненте"""
    try:
        # Устанавливаем режим verbose для логирования
        set_verbose(verbose)

        # Создаем API клиент с нужными параметрами
        api = _get_api_client(verbose=verbose, ctx=ctx)

        # Показываем заголовок консоли
        show_console_header(api)

        # Показываем прогресс-бар для длительных запросов
        with Progress(
                SpinnerColumn(),
                TextColumn("[progress.description]{task.description}"),
                TimeElapsedColumn(),
                console=console,
                transient=True,
        ) as progress:
            task = progress.add_task(
                "Получение информации о компонентах...", total=None
            )

            # Получаем детальную информацию о компоненте
            component = api.get_component_details(name, no_cache=no_cache)

            progress.update(task, description="Обработка данных...")

        if not component:
            console.print(f"Компонент '{name}' не найден")
            return

        # Выводим основную информацию

        # Основные параметры
        component_name = component.get("name", "")
        component_namespace = component.get("namespace", "")
        highlighted_name = _highlight_component_name(
            component_name, component_namespace
        )
        console.print(f"[bold white]NAME:[/bold white] {highlighted_name}")
        console.print(f"[bold white]NAMESPACE:[/bold white] {component_namespace}")

        # Подсвечиваем имя стека
        stack_id = component.get("stack_id", "")
        if "@" in stack_id:
            stack_name, namespace = stack_id.split("@", 1)
            console.print(
                f"[bold white]STACK:[/bold white] {stack_name}[dim]@{namespace}[/dim]"
            )
        else:
            console.print(f"[bold white]STACK:[/bold white] {stack_id}")

        console.print(
            f"[bold white]STACK_VERSION:[/bold white] {component.get('stack_version', '')}"
        )

        # Получаем тег из task (предпочтительно) или из component
        task_tag = _extract_tag_from_task(component)
        component_tag = _extract_tag_from_component(component)

        # Используем тег из task, если он есть, иначе из component
        image_tag = task_tag if task_tag else component_tag

        # Получаем правильный образ для имени
        image = component.get("image", "")
        child_container = component.get("childContainer")
        if child_container and child_container.get("image"):
            image = child_container.get("image")

        # Разделяем образ на имя
        if ":" in image:
            image_name, _ = image.rsplit(":", 1)
        else:
            image_name = image

        console.print(f"[bold white]IMAGE:[/bold white] {image_name}")
        console.print(f"[bold white]TAG:[/bold white] {image_tag}")

        # Статус
        status = _determine_component_status(component)

        # Цветовое кодирование для статуса (как в components list)
        if status.upper() in ["RUNNING", "ACTIVE", "READY", "HEALTHY", "DEPLOYED"]:
            styled_status = f"[bold green]{status}[/bold green]"
        elif status.upper() in [
            "STOPPED",
            "INACTIVE",
            "TERMINATED",
            "FAILED",
            "ERROR",
            "OFF",
            "CANCELED",
        ]:
            styled_status = f"[bold red]{status}[/bold red]"
        elif status.upper() in ["PENDING", "WAITING", "STARTING", "BROKEN"]:
            styled_status = f"[bold yellow]{status}[/bold yellow]"
        elif status.upper().startswith("PARTIAL"):
            styled_status = f"[bold orange3]{status}[/bold orange3]"
        else:
            styled_status = status

        console.print(f"[bold white]STATUS:[/bold white] {styled_status}")

        # Реплики
        desired_replicas = component.get("desiredReplicas", "")
        running_replicas = component.get("runningReplicas", "")
        if desired_replicas != "" and running_replicas != "":
            console.print(
                f"[bold white]REPLICAS:[/bold white] {running_replicas}/{desired_replicas}"
            )
        else:
            console.print(
                f"[bold white]REPLICAS:[/bold white] {component.get('replicas', '')}"
            )

        # Время создания и обновления
        created_timestamp = component.get("created", 0)
        if created_timestamp:
            from datetime import datetime

            created_date = datetime.fromtimestamp(created_timestamp / 1000).strftime(
                "%Y-%m-%d %H:%M:%S"
            )
            console.print(f"[bold white]CREATED:[/bold white] {created_date}")

        updated_timestamp = component.get("updated", 0)
        if updated_timestamp:
            from datetime import datetime

            updated_date = datetime.fromtimestamp(updated_timestamp / 1000).strftime(
                "%Y-%m-%d %H:%M:%S"
            )
            console.print(f"[bold white]UPDATED:[/bold white] {updated_date}")

        # Информация о репозитории
        if component.get("stack_repo"):
            console.print(
                f"[bold white]REPO:[/bold white] {component.get('stack_repo', '')}"
            )
        if component.get("stack_branch"):
            console.print(
                f"[bold white]BRANCH:[/bold white] {component.get('stack_branch', '')}"
            )
        if component.get("stack_commit"):
            console.print(
                f"[bold white]COMMIT:[/bold white] {component.get('stack_commit', '')}"
            )

        # Дополнительные параметры как обычные поля
        console.print(
            f"[bold white]ADMIN_MODE:[/bold white] {component.get('adminMode', False)}"
        )
        console.print(
            f"[bold white]RUN_APP:[/bold white] {component.get('runApp', False)}"
        )
        console.print(
            f"[bold white]SHOW_ADMIN_MODE:[/bold white] {component.get('showAdminMode', False)}"
        )
        console.print(f"[bold white]OFF:[/bold white] {component.get('off', False)}")

        # Порты
        published_ports = component.get("publishedPorts", [])
        if published_ports:
            console.print(f"[bold white]PORTS:[/bold white]")
            for port in published_ports:
                published_port = port.get("publishedPort", "")
                target_port = port.get("targetPort", "")
                protocol = port.get("protocol", "tcp")
                publish_mode = port.get("publishMode", "")
                console.print(f"  {published_port}:{target_port}/{protocol}")

        # Переменные окружения
        env_vars = component.get("environmentVariables", [])
        if env_vars:
            console.print(f"[bold white]ENV:[/bold white]")
            for env_var in env_vars:
                for key, value in env_var.items():
                    # Скрываем чувствительные данные
                    if any(
                            sensitive in key.lower()
                            for sensitive in ["password", "secret", "key", "token"]
                    ):
                        value = "***"
                    console.print(f"[white]  {key}={value}[/white]")

        # Тома
        volumes = component.get("volumes", [])
        if volumes:
            console.print(f"[bold white]VOLUMES:[/bold white]")
            for volume in volumes:
                source = volume.get("source", "")
                target = volume.get("target", "")
                driver = volume.get("driver", "")
                console.print(f"[white]  {source} -> {target} ({driver})[/white]")

        # Сетевые подключения
        networks = component.get("networks", [])
        if networks:
            console.print(f"[bold white]NETWORKS:[/bold white]")
            for network in networks:
                name = network.get("name", "")
                driver = network.get("driver", "")
                subnet = network.get("subnet", "")
                console.print(f"  {name} ({driver}) - {subnet}")

        # Привязки
        binds = component.get("binds", [])
        if binds:
            console.print(f"[bold white]BINDS:[/bold white]")
            for bind in binds:
                source = bind.get("source", "")
                target = bind.get("target", "")
                console.print(f"  {source} -> {target}")

        # Метки
        labels = component.get("labels", [])
        if labels:
            console.print(f"[bold white]LABELS:[/bold white]")
            for label in labels:
                for key, value in label.items():
                    console.print(f"[white]  {key}={value}[/white]")

    except ImagenariumAPIError as e:
        console.print(f"Ошибка получения информации о компоненте: {e}")
        raise click.Abort()


@cli.command("tags")
@click.argument("name")
@click.option("--limit", "-l", type=int, help="Ограничить количество результатов")
@click.option("--no-cache", is_flag=True, help="Не использовать кеш")
@click.option("--no-headers", is_flag=True, help="Не показывать заголовок консоли")
@click.option("--verbose", "-v", is_flag=True, help="Подробный вывод HTTP запросов")
@click.pass_context
def component_tags(
        ctx,
        name: str,
        limit: Optional[int],
        no_cache: bool,
        no_headers: bool,
        verbose: bool,
):
    """Показывает теги развертываний для компонента"""
    try:
        # Устанавливаем режим verbose для логирования
        set_verbose(verbose)

        # Создаем API клиент с нужными параметрами
        api = _get_api_client(verbose=verbose, ctx=ctx)

        # Показываем заголовок консоли
        show_console_header(api, show_header=not no_headers)

        # Показываем прогресс-бар для длительных запросов
        with Progress(
                SpinnerColumn(),
                TextColumn("[progress.description]{task.description}"),
                TimeElapsedColumn(),
                console=console,
                transient=True,
        ) as progress:
            task = progress.add_task(
                "Получение информации о компонентах...", total=None
            )

            # Получаем детальную информацию о компоненте с кешированием на 1 час
            component = api.get_component_details(name, no_cache=no_cache)

            progress.update(task, description="Обработка данных...")

        if not component:
            console.print(f"Компонент '{name}' не найден")
            return

        # Извлекаем информацию о репозитории и образе
        repo = component.get("repo", "")
        if not repo:
            console.print(
                f"[red]Не удалось получить информацию о репозитории для компонента {name}[/red]"
            )
            return

        # Получаем образ компонента
        image = component.get("image", "")
        child_container = component.get("childContainer")
        if child_container and child_container.get("image"):
            image = child_container.get("image")

        # Разделяем образ на имя и тег
        if ":" in image:
            image_name, image_tag = image.rsplit(":", 1)
        else:
            image_name = image
            image_tag = "latest"

        # Формируем image из TAG до __ включая __
        # ВАЖНО: API принимает формат ":<префикс_тега_до_двойного_подчеркивания_включая_его>"
        # Например: ":dev__" - это ПРАВИЛЬНЫЙ формат, НЕ МЕНЯТЬ!
        if "__" in image_tag:
            # Берем подстроку до __ включая __
            tag_part = image_tag.split("__")[0] + "__"
            # Используем только префикс тега с двоеточием
            search_image = f":{tag_part}"
        else:
            # Если нет __, используем полную версию тега
            tag_part = image_tag  # Для фильтрации
            search_image = f"{image_name}:{image_tag}"

        # Отключаем кеш если нужно
        if no_cache:
            api.cache = None

        # Получаем все теги с прогресс-баром
        with Progress(
                SpinnerColumn(),
                TextColumn("[progress.description]{task.description}"),
                TimeElapsedColumn(),
                console=console,
                transient=True,
        ) as progress:
            task = progress.add_task("Загрузка тегов развертываний...", total=None)

            # Используем кешированный метод с TTL 5 минут
            tags = api.get_deployment_tags(repo, search_image, no_cache)

            progress.update(task, description="Обработка данных...")

        if not tags:
            console.print(f"[yellow]Теги не найдены для {repo}/{search_image}[/yellow]")
            return

        # Фильтруем теги: исключаем тег, который точно соответствует поисковому запросу
        # Например, если ищем по ":dev__", то исключаем тег "dev__"
        filtered_tags = []
        for tag in tags:
            tag_name = tag["name"]
            # Если тег точно соответствует поисковому запросу (без дополнительной части), исключаем его
            if tag_name != tag_part:
                filtered_tags.append(tag)

        tags = filtered_tags

        if not tags:
            console.print(
                f"[yellow]Нет доступных тегов для {repo}/{search_image}[/yellow]"
            )
            return

        # Применяем лимит если указан
        if limit:
            tags = tags[:limit]

        # Подготавливаем данные для таблицы в стиле других list команд
        from utils.formatters import format_table, format_output

        data = []
        for tag in tags:
            data.append({"TAG": tag["name"]})

        format_table(data, no_headers=no_headers)

    except ImagenariumAPIError as e:
        console.print(f"[red]Ошибка API: {e}[/red]")
        raise click.Abort()
    except Exception as e:
        console.print(f"[red]Неожиданная ошибка: {e}[/red]")
        raise click.Abort()


def _parse_component_tag(component_spec):
    """
    Парсит спецификацию компонента в формате 'component:tag' или 'component'

    Args:
        component_spec: Строка в формате 'component:tag' или 'component'

    Returns:
        tuple: (component_name, tag) где tag может быть None для 'latest'
    """
    if ":" in component_spec:
        component_name, tag = component_spec.rsplit(":", 1)
        return component_name.strip(), tag.strip()
    else:
        return component_spec.strip(), "latest"


def _load_upgrades_from_file(file_path):
    """
    Загружает список обновлений из файла в формате tab-separated

    Args:
        file_path: Путь к файлу

    Returns:
        list: Список кортежей (component_name, tag)
    """
    upgrades = []
    try:
        with open(file_path, "r", encoding="utf-8") as f:
            for line_num, line in enumerate(f, 1):
                line = line.strip()

                # Пропускаем пустые строки и комментарии
                if not line or line.startswith("#"):
                    continue

                # Парсим tab-separated формат
                if "\t" in line:
                    parts = line.split("\t", 1)
                    if len(parts) == 2:
                        component_name = parts[0].strip()
                        tag = parts[1].strip()
                        upgrades.append((component_name, tag))
                    else:
                        console.print(
                            f"[yellow]Предупреждение: строка {line_num} в файле {file_path} имеет неверный формат[/yellow]"
                        )
                else:
                    console.print(
                        f"[yellow]Предупреждение: строка {line_num} в файле {file_path} не содержит табуляцию[/yellow]"
                    )

    except FileNotFoundError:
        console.print(f"[red]Файл {file_path} не найден[/red]")
        raise click.Abort()
    except Exception as e:
        console.print(f"[red]Ошибка чтения файла {file_path}: {e}[/red]")
        raise click.Abort()

    return upgrades


def _extract_current_tag_from_component(component):
    """
    Извлекает текущий тег из компонента (из task, если доступен, иначе из component.image)

    Args:
        component: Словарь с информацией о компоненте

    Returns:
        str: Текущий тег или 'latest' если не найден
    """
    try:
        # Сначала пытаемся получить тег из task (если есть)
        task_tag = _extract_tag_from_task(component)
        if task_tag:
            return task_tag

        # Если тега из task нет, получаем из component.image
        image = component.get("image", "")
        child_container = component.get("childContainer")
        if child_container and child_container.get("image"):
            image = child_container.get("image")

        # Разделяем образ на имя и тег
        if ":" in image:
            _, image_tag = image.rsplit(":", 1)
            return image_tag
        else:
            return "latest"

    except Exception:
        return "latest"


def _get_component_current_tag(api, component_name, no_cache=False):
    """
    Получает текущий тег компонента (из task, если доступен, иначе из component.image)

    Args:
        api: API клиент
        component_name: Имя компонента
        no_cache: Игнорировать кеш

    Returns:
        str: Текущий тег или None если компонент не найден
    """
    try:
        component = api.get_component_details(component_name, no_cache)

        if not component:
            return None

        # Сначала пытаемся получить тег из task (если есть)
        task_tag = _extract_tag_from_task(component)
        if task_tag:
            return task_tag

        # Если тега из task нет, получаем из component.image
        image = component.get("image", "")
        child_container = component.get("childContainer")
        if child_container and child_container.get("image"):
            image = child_container.get("image")

        # Извлекаем тег
        if ":" in image:
            _, image_tag = image.rsplit(":", 1)
            return image_tag
        else:
            return "latest"

    except Exception:
        return None


def _validate_tag_availability(api, component_name, target_tag, no_cache=False):
    """
    Проверяет доступность указанного тега в репозитории компонента

    Args:
        api: API клиент
        component_name: Имя компонента
        target_tag: Целевой тег для проверки
        no_cache: Не использовать кеш

    Returns:
        tuple: (is_available, error_message) где is_available - bool, error_message - str или None
    """
    try:
        component = api.get_component_details(component_name, no_cache)
        if not component:
            return False, "Компонент не найден"

        # Извлекаем информацию о репозитории и образе
        repo = component.get("repo", "")
        if not repo:
            return False, "Репозиторий не найден"

        # Получаем образ компонента
        image = component.get("image", "")
        child_container = component.get("childContainer")
        if child_container and child_container.get("image"):
            image = child_container.get("image")

        # Разделяем образ на имя и тег
        if ":" in image:
            image_name, image_tag = image.rsplit(":", 1)
        else:
            image_name = image
            image_tag = "latest"

        # Для тегов с __ проверяем доступность через API
        if "__" in target_tag:
            # Формируем поисковый запрос по префиксу
            tag_part = target_tag.split("__")[0] + "__"
            search_image = f":{tag_part}"

            # Получаем список доступных тегов
            tags = api.get_deployment_tags(repo, search_image, no_cache)
            if not tags:
                return False, f"Не удалось получить теги для {repo}/{search_image}"

            # Проверяем, есть ли целевой тег в списке
            available_tags = [tag["name"] for tag in tags]
            if target_tag not in available_tags:
                return False, f"Тег {target_tag} не найден в репозитории {repo}"

        # Для стабильных тегов (без __) считаем их всегда доступными
        # так как они не запрашиваются через API тегов

        return True, None

    except Exception as e:
        return False, f"Ошибка проверки тега: {str(e)}"


def _get_component_latest_tag(api, component_name, no_cache=False):
    """
    Получает последний доступный тег для компонента

    Args:
        api: API клиент
        component_name: Имя компонента

    Returns:
        str: Последний тег или None если не найден
    """
    try:
        component = api.get_component_details(component_name, no_cache)
        if not component:
            return None

        # Извлекаем информацию о репозитории и образе
        repo = component.get("repo", "")
        if not repo:
            return None

        # Получаем образ компонента
        image = component.get("image", "")
        child_container = component.get("childContainer")
        if child_container and child_container.get("image"):
            image = child_container.get("image")

        # Разделяем образ на имя и тег
        if ":" in image:
            image_name, image_tag = image.rsplit(":", 1)
        else:
            image_name = image
            image_tag = "latest"

        # Формируем image из TAG до __ включая __
        # ВАЖНО: API принимает формат ":<префикс_тега_до_двойного_подчеркивания_включая_его>"
        # Например: ":dev__" - это ПРАВИЛЬНЫЙ формат, НЕ МЕНЯТЬ!
        if "__" in image_tag:
            tag_part = image_tag.split("__")[0] + "__"
            search_image = f":{tag_part}"
        else:
            # Для тегов без __ не запрашиваем список тегов - это стабильные версии
            return None

        # Получаем теги
        if no_cache:
            # Временно отключаем кеш
            original_cache = api.cache
            api.cache = None
            tags = api.get_deployment_tags(repo, search_image, no_cache)
            api.cache = original_cache
        else:
            tags = api.get_deployment_tags(repo, search_image, no_cache)

        if not tags:
            # Если теги не найдены, возвращаем None
            # Это означает, что компонент не может быть обновлен
            return None

        # Фильтруем теги: исключаем тег, который точно соответствует префиксу
        # Например, если ищем по ":dev__", то исключаем тег "dev__"
        filtered_tags = []
        for tag in tags:
            tag_name = tag["name"]
            if tag_name != tag_part:  # Исключаем префикс, а не полный тег
                filtered_tags.append(tag)

        if not filtered_tags:
            return None

        # Дополнительная проверка: если у компонента нет __ в теге,
        # но API возвращает теги с __, то это неправильный репозиторий
        if "__" not in image_tag and filtered_tags:
            # Проверяем, есть ли теги без __ в результате
            non_underscore_tags = [
                tag for tag in filtered_tags if "__" not in tag["name"]
            ]
            if not non_underscore_tags:
                # Если все теги содержат __, а у компонента нет, то это неправильный репозиторий
                return None
            # Используем только теги без __
            filtered_tags = non_underscore_tags

        # Возвращаем первый (самый новый) тег
        return filtered_tags[0]["name"]

    except Exception:
        return None


def _get_components_with_filters(api, filter_specs, no_cache=False):
    """
    Получает список компонентов с применением фильтров

    Args:
        api: API клиент
        filter_specs: Список спецификаций фильтров
        no_cache: Не использовать кеш

    Returns:
        Кортеж (upgrades, components_data) где:
        - upgrades: Список кортежей (component_name, tag)
        - components_data: Исходные данные компонентов
    """
    from rich.progress import Progress, SpinnerColumn, TextColumn, TimeElapsedColumn
    from rich.console import Console

    console = Console()

    # В shell режиме не показываем прогресс-бар
    show_progress = os.environ.get("IMGCTL_SHELL_MODE") != "1"

    if show_progress:
        with Progress(
                SpinnerColumn(),
                TextColumn("[progress.description]{task.description}"),
                TimeElapsedColumn(),
                console=console,
        ) as progress:
            task = progress.add_task("Получение информации о компонентах...", total=None)

            # Получаем все компоненты
            deployments = api.get_components(no_cache=no_cache)
    else:
        # В shell режиме просто получаем компоненты без прогресс-бара
        deployments = api.get_components(no_cache=no_cache)

    all_components_data = []

    for group in deployments:
        group_namespace = group.get("namespace", "Unknown")
        stacks = group.get("stacks", [])

        if not stacks:
            continue

        for stack_item in stacks:
            stack_id = stack_item.get("stackId", "")
            stack_version = stack_item.get("version", "")
            stack_status = stack_item.get("status", "")

            stack_components = stack_item.get("components", [])
            for comp in stack_components:
                name = comp.get("name", "")

                # Исключаем компоненты, начинающиеся с "checker-"
                if name.startswith("checker-"):
                    continue

                # Получаем тег из task (предпочтительно) или из component
                task_tag = _extract_tag_from_task(comp)
                component_tag = _extract_tag_from_component(comp)

                # Используем тег из task, если он есть, иначе из component
                image_tag = task_tag if task_tag else component_tag

                # Получаем правильный образ для имени
                image = comp.get("image", "")
                child_container = comp.get("childContainer")
                if child_container and child_container.get("image"):
                    image = child_container.get("image")

                # Разделяем образ на имя
                if ":" in image:
                    image_name, _ = image.rsplit(":", 1)
                else:
                    image_name = image

                # Определяем статус компонента
                status = _determine_component_status(comp)
                replicas = comp.get("replicas", "")

                # Получаем дату обновления
                updated_timestamp = comp.get("updated", 0)
                if updated_timestamp:
                    from datetime import datetime

                    updated_date = datetime.fromtimestamp(
                        updated_timestamp / 1000
                    ).strftime("%Y-%m-%d %H:%M")
                else:
                    updated_date = ""

                # Получаем дату создания
                created_timestamp = comp.get("created", 0)
                if created_timestamp:
                    from datetime import datetime

                    created_date = datetime.fromtimestamp(
                        created_timestamp / 1000
                    ).strftime("%Y-%m-%d %H:%M:%S")
                else:
                    created_date = ""

                # Получаем информацию о репозитории
                repo = comp.get("repo", "")
                commit = comp.get("commit", "")

                # Получаем дополнительные флаги
                admin_mode = comp.get("adminMode", False)
                run_app = comp.get("runApp", False)
                show_admin_mode = comp.get("showAdminMode", False)
                off = comp.get("off", False)

                # Получаем информацию о портах
                published_ports = comp.get("publishedPorts", [])
                if published_ports:
                    ports_info = []
                    for port in published_ports:
                        published_port = port.get("publishedPort", "")
                        target_port = port.get("targetPort", "")
                        protocol = port.get("protocol", "tcp")
                        if published_port and target_port:
                            ports_info.append(
                                f"{published_port}:{target_port}/{protocol}"
                            )
                    ports = ", ".join(ports_info)
                else:
                    ports = ""

                # Получаем информацию о сетях
                networks = comp.get("networks", [])
                if networks:
                    network_info = []
                    for network in networks:
                        network_name = network.get("name", "")
                        driver = network.get("driver", "")
                        subnet = network.get("subnet", "")
                        network_info.append(f"{network_name} ({driver}) - {subnet}")
                    networks_str = ", ".join(network_info)
                else:
                    networks_str = ""

                # Формируем имя стека с подсветкой
                stack_name_with_namespace = f"{stack_id}@{group_namespace}"
                if "@" in stack_name_with_namespace:
                    stack_name, namespace = stack_name_with_namespace.split("@", 1)
                    highlighted_stack = f"{stack_name}[dim]@{namespace}[/dim]"
                else:
                    highlighted_stack = stack_name_with_namespace

                # Подсвечиваем имя компонента
                highlighted_name = _highlight_component_name(name, group_namespace)

                all_components_data.append(
                    {
                        "NAME": highlighted_name,
                        "NAMESPACE": group_namespace,
                        "STACK": highlighted_stack,
                        "IMAGE": image_name,
                        "TAG": image_tag,
                        "STACK_VERSION": stack_version,
                        "STATUS": status,
                        "REPLICAS": str(replicas),
                        "PORTS": ports,
                        "UPDATED": updated_date,
                        "CREATED": created_date,
                        "REPO": repo,
                        "COMMIT": commit,
                        "ADMIN_MODE": admin_mode,
                        "RUN_APP": run_app,
                        "SHOW_ADMIN_MODE": show_admin_mode,
                        "OFF": off,
                        "NETWORKS": networks_str,
                    }
                )

    # Применяем фильтры если есть
    if filter_specs:
        from utils.formatters import parse_filters, apply_filters

        parsed_filters = parse_filters(list(filter_specs))
        all_components_data = apply_filters(all_components_data, parsed_filters)

    # Преобразуем в список кортежей (component_name, tag)
    upgrades = []
    for comp_data in all_components_data:
        # Извлекаем имя компонента без Rich markup
        import re

        name = re.sub(r"\[[^\]]*\]", "", comp_data["NAME"]).strip()
        tag = comp_data["TAG"]
        upgrades.append((name, tag))

    return upgrades, deployments


def _validate_upgrade_plan(api, upgrades, no_cache=False, components_data=None, force=False):
    """
    Валидирует план обновления с оптимизацией запросов к API

    Args:
        api: API клиент
        force: Пропустить валидацию
        upgrades: Список кортежей (component_name, tag)
        no_cache: Не использовать кеш

    Returns:
        tuple: (valid_upgrades, invalid_upgrades)
    """
    valid_upgrades = []
    invalid_upgrades = []

    # Если force=True, пропускаем валидацию
    if force:
        verbose_print("Force mode: skipping validation")
        # Нужно получить components_index для формирования правильных данных
        if components_data is not None:
            all_deployments = components_data
        else:
            all_deployments = api.get_components(no_cache=no_cache)

        components_index = {}
        for group in all_deployments:
            stacks = group.get("stacks", [])
            for stack in stacks:
                stack_components = stack.get("components", [])
                for comp in stack_components:
                    comp_name = comp.get("name")
                    if comp_name:
                        result = comp.copy()
                        namespace = group.get("namespace")
                        stack_id = stack.get("stackId")
                        result["namespace"] = namespace
                        result["stack_id"] = f"{stack_id}@{namespace}"
                        components_index[comp_name] = result

        # Формируем valid_upgrades напрямую
        for component_name, target_tag in upgrades:
            if component_name in components_index:
                component_data = components_index[component_name]
                current_tag = _extract_current_tag_from_component(component_data)
                component_namespace = component_data.get("namespace", "")
                valid_upgrades.append((component_name, target_tag, current_tag, component_namespace, component_data))

        verbose_print(f"Force mode: {len(valid_upgrades)} components prepared without validation")
        return valid_upgrades, []

    # Шаг 1: Получаем информацию о всех компонентах
    component_info = {}

    # Используем переданные данные или получаем их заново
    if components_data is not None:
        all_deployments = components_data
    else:
        all_deployments = api.get_components(no_cache=no_cache)

    # Создаем индекс компонентов по имени для быстрого поиска
    components_index = {}
    for group in all_deployments:
        stacks = group.get("stacks", [])
        for stack in stacks:
            stack_components = stack.get("components", [])
            for comp in stack_components:
                comp_name = comp.get("name")
                if comp_name:
                    # Добавляем дополнительную информацию о стеке и namespace
                    result = comp.copy()
                    namespace = group.get("namespace")
                    stack_id = stack.get("stackId")
                    result["namespace"] = namespace
                    result["stack_id"] = f"{stack_id}@{namespace}"
                    result["stack_version"] = stack.get("version")
                    result["stack_status"] = stack.get("status")
                    result["stack_repo"] = stack.get("repo")
                    result["stack_branch"] = stack.get("branch")
                    result["stack_commit"] = stack.get("commit")
                    result["stack_tag"] = stack.get("tag")
                    result["stack_timestamp"] = stack.get("timestamp")
                    components_index[comp_name] = result

    for component_name, target_tag in upgrades:
        # Ищем компонент в индексе
        component = components_index.get(component_name)
        if not component:
            invalid_upgrades.append((component_name, target_tag, "Компонент не найден"))
            continue

        # Извлекаем текущий тег из информации о компоненте
        current_tag = _extract_current_tag_from_component(component)

        component_info[component_name] = {
            "current_tag": current_tag,
            "target_tag": target_tag,
            "component": component,
        }

    # Шаг 2: Извлекаем уникальные пары repository + image для тегов с __
    unique_requests = set()
    component_requests = {}  # component_name -> (repository, image)

    for component_name, info in component_info.items():
        if info["target_tag"] != "latest":
            continue  # Пропускаем компоненты с конкретным тегом

        # Получаем информацию о компоненте для извлечения repository и image
        # Используем уже полученную информацию из component_info, если она есть
        component = info.get("component")
        if not component:
            component = api.get_component_details(component_name, no_cache)
            if not component:
                invalid_upgrades.append(
                    (component_name, info["target_tag"], "Компонент не найден")
                )
                continue

        repo = component.get("repo", "")
        if not repo:
            invalid_upgrades.append(
                (component_name, info["target_tag"], "Репозиторий не найден")
            )
            continue

        # Получаем образ компонента
        image = component.get("image", "")
        child_container = component.get("childContainer")
        if child_container and child_container.get("image"):
            image = child_container.get("image")

        # Разделяем образ на имя и тег
        if ":" in image:
            image_name, image_tag = image.rsplit(":", 1)
        else:
            image_name = image
            image_tag = "latest"

        # Проверяем, есть ли __ в теге
        if "__" in image_tag:
            tag_part = image_tag.split("__")[0] + "__"
            search_image = f":{tag_part}"
            unique_requests.add((repo, search_image))
            component_requests[component_name] = (repo, search_image)
        else:
            # Для тегов без __ не запрашиваем теги
            invalid_upgrades.append(
                (
                    component_name,
                    info["current_tag"],
                    "Стабильная версия - обновление недоступно",
                )
            )

    # Шаг 3: Получаем теги для каждой уникальной пары
    tags_cache = {}  # (repository, image) -> list of tags

    if unique_requests:
        from rich.progress import Progress, SpinnerColumn, TextColumn, TimeElapsedColumn
        from rich.console import Console

        console = Console()

        with Progress(
                SpinnerColumn(),
                TextColumn("[progress.description]{task.description}"),
                TimeElapsedColumn(),
                console=console,
        ) as progress:
            task = progress.add_task("Получение актуальных тегов...", total=None)

            for i, (repo, search_image) in enumerate(unique_requests, 1):
                # Формируем понятное описание для пользователя
                display_image = search_image.replace(":", "").replace(
                    "_", " "
                )  # Убираем двоеточие и подчеркивания для отображения
                display_repo = repo.replace(
                    "_", " "
                )  # Убираем подчеркивания для отображения
                progress.update(
                    task,
                    description=f"Получение актуального тега для {display_repo}/{display_image} ({i}/{len(unique_requests)})",
                )

                # Небольшая задержка для видимости прогресса
                import time

                time.sleep(0.1)

                try:
                    if no_cache:
                        # Используем прямой запрос без кеша
                        query_params = {"repository": repo, "image": search_image}
                        response = api.http_client.get(
                            "/deployments/tags", params=query_params, no_cache=True
                        )
                        tags = response.json()
                    else:
                        tags = api.get_deployment_tags(repo, search_image, no_cache)
                    tags_cache[(repo, search_image)] = tags
                except Exception as e:
                    tags_cache[(repo, search_image)] = []

    # Шаг 4: Применяем результаты к компонентам
    for component_name, info in component_info.items():
        if info["target_tag"] != "latest":
            # Для компонентов с конкретным тегом проверяем доступность тега
            if info["current_tag"] != info["target_tag"]:
                # Проверяем доступность целевого тега в репозитории
                is_available, error_msg = _validate_tag_availability(
                    api, component_name, info["target_tag"], no_cache
                )
                if is_available:
                    # Получаем namespace из информации о компоненте
                    component_namespace = info["component"].get("namespace", "")
                    valid_upgrades.append(
                        (
                            component_name,
                            info["target_tag"],
                            info["current_tag"],
                            component_namespace,
                            info["component"],
                        )
                    )
                else:
                    invalid_upgrades.append(
                        (component_name, info["target_tag"], error_msg)
                    )
            continue

        if component_name not in component_requests:
            continue  # Уже обработан выше

        repo, search_image = component_requests[component_name]
        tags = tags_cache.get((repo, search_image), [])

        if not tags:
            invalid_upgrades.append(
                (
                    component_name,
                    info["current_tag"],
                    "Не удалось получить последний тег",
                )
            )
            continue

        # Ищем последний тег (исключая префикс)
        current_tag = info["current_tag"]
        latest_tag = None

        # Определяем префикс для исключения
        if "__" in current_tag:
            tag_part = current_tag.split("__")[0] + "__"
        else:
            tag_part = current_tag

        for tag in tags:
            tag_name = tag.get("name", tag.get("tag", ""))
            if tag_name != tag_part:  # Исключаем префикс, а не полный тег
                latest_tag = tag_name
                break

        if latest_tag is None:
            invalid_upgrades.append(
                (component_name, info["current_tag"], "Нет доступных обновлений")
            )
            continue

        # Проверяем, что теги разные
        if current_tag == latest_tag:
            continue

        # Получаем namespace из информации о компоненте
        component_namespace = info["component"].get("namespace", "")
        valid_upgrades.append(
            (
                component_name,
                latest_tag,
                current_tag,
                component_namespace,
                info["component"],
            )
        )

    return valid_upgrades, invalid_upgrades


@cli.command("upgrade")
@click.argument("components", nargs=-1, metavar="[COMPONENT:TAG]...", required=False)
@click.option(
    "--from-file",
    "upgrade_file",
    help="Загрузить список обновлений из файла (tab-separated)",
)
@click.option(
    "--check", is_flag=True, help="Показать доступные обновления без выполнения"
)
@click.option("--dry-run", is_flag=True, help="Предварительный просмотр без выполнения")
@click.option("--all", is_flag=True, help="Обновить все компоненты до последних тегов")
@click.option("--verbose", "-v", is_flag=True, help="Подробный вывод HTTP запросов")
@click.option(
    "--filter",
    "filter_spec",
    multiple=True,
    help="Фильтр компонентов. Формат: COLUMN=value",
)
@click.option(
    "--to-tag",
    help="Обновить все отфильтрованные компоненты до указанного тега (с проверкой доступности)",
)
@click.option(
    "--confirm", is_flag=True, help="Подтвердить обновления без интерактивного запроса"
)
@click.option("--force", is_flag=True, help="Принудительное обновление без проверки доступности тега")
@click.option("--no-cache", is_flag=True, help="Не использовать кеш при проверке тегов")
@click.option("--no-headers", is_flag=True, help="Не показывать заголовок консоли")
@click.option(
    "--export-current", is_flag=True, help="Экспортировать текущие версии в stdout"
)
@click.option(
    "--export-latest", is_flag=True, help="Экспортировать последние версии в stdout"
)
@click.option(
    "--export-upgradable",
    is_flag=True,
    help="Экспортировать компоненты для обновления в stdout",
)
@click.pass_context
def upgrade_components(
        ctx,
        components,
        upgrade_file,
        check,
        dry_run,
        all,
        filter_spec,
        to_tag,
        confirm,
        force,
        no_cache,
        no_headers,
        export_current,
        export_latest,
        export_upgradable,
        verbose,
):
    """Обновляет компоненты до указанных тегов

    Примеры:
      imgctl components upgrade web-api-staging                    # Обновить до последнего тега
      imgctl components upgrade web-api-staging:v1.2.3            # Обновить до конкретного тега
      imgctl components upgrade web-api-staging db-staging:latest # Несколько компонентов
      imgctl components upgrade --from-file upgrades.txt          # Из файла
      imgctl components upgrade --all                             # Все компоненты
      imgctl components upgrade --filter NAME~^oms-api- --to-tag dev__2025_01_15_10_00-abc123  # Обновить все oms-api компоненты до указанного тега
      imgctl components upgrade --filter NAMESPACE=staging --to-tag latest  # Обновить все компоненты в namespace staging
      imgctl components upgrade --filter STATUS=RUNNING --to-tag dev__2025_01_15_10_00-abc123  # Обновить все запущенные компоненты
      imgctl components upgrade --check                           # Показать доступные обновления
      imgctl components upgrade --dry-run                         # Предварительный просмотр без выполнения
    """
    try:
        # Устанавливаем режим verbose для логирования
        set_verbose(verbose)

        # Создаем API клиент с нужными параметрами
        api = _get_api_client(verbose=verbose, ctx=ctx)

        # Показываем заголовок консоли
        show_console_header(api, show_header=not no_headers)

        # Обработка режимов экспорта
        if export_current or export_latest or export_upgradable:
            # Получаем компоненты с фильтрами
            # В shell режиме не показываем прогресс-бар
            show_progress = os.environ.get("IMGCTL_SHELL_MODE") != "1"

            if show_progress:
                with Progress(
                        SpinnerColumn(),
                        TextColumn("[progress.description]{task.description}"),
                        TimeElapsedColumn(),
                        console=console,
                        transient=True,
                ) as progress:
                    task = progress.add_task("Получение списка компонентов...", total=None)

                    components_list, _ = _get_components_with_filters(
                        api, filter_spec, no_cache
                    )

                    progress.update(task, description="Обработка данных...")
            else:
                components_list, _ = _get_components_with_filters(
                    api, filter_spec, no_cache
                )

            if export_current:
                # Экспортируем текущие версии
                for component_name, current_tag in components_list:
                    print(f"{component_name}\t{current_tag}")
                return

            elif export_latest:
                # Экспортируем последние версии
                for component_name, _ in components_list:
                    latest_tag = _get_component_latest_tag(
                        api, component_name, no_cache
                    )
                    if latest_tag:
                        print(f"{component_name}\t{latest_tag}")
                    else:
                        print(f"{component_name}\t")
                return

            elif export_upgradable:
                # Экспортируем компоненты для обновления
                for component_name, current_tag in components_list:
                    latest_tag = _get_component_latest_tag(
                        api, component_name, no_cache
                    )
                    if latest_tag and latest_tag != current_tag:
                        print(f"{component_name}\t{latest_tag}")
                return

        # Определяем список обновлений
        upgrades = []

        if upgrade_file:
            # Загружаем из файла
            console.print(
                f"[blue]Загрузка обновлений из файла {upgrade_file}...[/blue]"
            )
            upgrades = _load_upgrades_from_file(upgrade_file)
        elif all or (not components and not filter_spec and not upgrade_file):
            # Получаем все компоненты без фильтров
            upgrades, components_data = _get_components_with_filters(
                api, None, no_cache
            )

            # Заменяем теги на 'latest' для обновления до последних версий
            upgrades = [(name, "latest") for name, _ in upgrades]
        elif filter_spec:
            # Получаем компоненты с применением фильтров (используем TTL кеша)
            upgrades, components_data = _get_components_with_filters(
                api, list(filter_spec), no_cache
            )

            if to_tag:
                # Обновляем все отфильтрованные компоненты до указанного тега

                # Пропускаем валидацию если используется --force
                if force:
                    console.print("[yellow]Флаг --force активен: проверка доступности тегов пропущена[/yellow]")
                    upgrades = [(name, to_tag) for name, _ in upgrades]
                    verbose_print(f"Force mode: {len(upgrades)} components will be upgraded without validation")
                else:
                    # Проверяем доступность тега для каждого компонента с прогресс-баром
                    original_count = len(upgrades)
                    validated_upgrades = []

                    with Progress(
                            SpinnerColumn(),
                            TextColumn("[progress.description]{task.description}"),
                            console=console,
                    ) as progress:
                        task = progress.add_task(
                            f"Проверка доступности тега '{to_tag}' для {original_count} компонентов...",
                            total=original_count
                        )

                        for name, _ in upgrades:
                            is_available, error_msg = _validate_tag_availability(
                                api, name, to_tag, no_cache
                            )
                            if is_available:
                                validated_upgrades.append((name, to_tag))
                            else:
                                console.print(f"[yellow]Пропуск {name}: {error_msg}[/yellow]")
                            progress.advance(task)

                    upgrades = validated_upgrades

                    if len(validated_upgrades) < original_count:
                        console.print(
                            f"[blue]Валидных обновлений: {len(validated_upgrades)} из {original_count}[/blue]"
                        )
            else:
                # Заменяем теги на 'latest' для обновления до последних версий
                upgrades = [(name, "latest") for name, _ in upgrades]
        elif components:
            # Парсим аргументы командной строки (используем TTL кеша)
            for component_spec in components:
                component_name, tag = _parse_component_tag(component_spec)
                upgrades.append((component_name, tag))

            # Получаем данные компонентов для валидации
            _, components_data = _get_components_with_filters(api, None, no_cache)

        if not upgrades:
            console.print("[yellow]Нет компонентов для обновления[/yellow]")
            return

        # Валидируем план обновления
        valid_upgrades, invalid_upgrades = _validate_upgrade_plan(
            api, upgrades, no_cache, components_data, force
        )

        # Показываем невалидные обновления
        if invalid_upgrades:
            console.print("[red]Найдены ошибки в плане обновления:[/red]")
            for component_name, target_tag, error in invalid_upgrades:
                # Определяем namespace для подсветки
                component_namespace = None
                if components_data:
                    for group in components_data:
                        for stack in group.get("stacks", []):
                            for comp in stack.get("components", []):
                                if comp.get("name") == component_name:
                                    component_namespace = group.get("namespace", "")
                                    break

                highlighted_name = (
                    _highlight_component_name(component_name, component_namespace)
                    if component_namespace
                    else component_name
                )
                console.print(f"  ❌ {highlighted_name}:{target_tag} - {error}")
            console.print()

        if not valid_upgrades:
            console.print("[red]Нет валидных обновлений для выполнения[/red]")
            return

        # Показываем план обновления
        console.print(
            f"[green]План обновления ({len(valid_upgrades)} компонентов):[/green]"
        )
        for (
                component_name,
                target_tag,
                current_tag,
                component_namespace,
                component_data,
        ) in valid_upgrades:
            if current_tag == target_tag:
                # Создаем Text объект для правильной раскраски
                from rich.text import Text

                text = Text()
                text.append("  ")

                # Подсвечиваем имя компонента
                if "-" in component_name and component_namespace:
                    namespace_suffix = f"-{component_namespace}"
                    if component_name.endswith(namespace_suffix):
                        component_part = component_name[: -len(namespace_suffix)]
                        text.append(component_part)
                        text.append(namespace_suffix, style="dim")
                    else:
                        text.append(component_name)
                else:
                    text.append(component_name)

                text.append(": ")
                text.append("уже актуален", style="green")
                console.print(text)
            else:
                from rich.text import Text

                text = Text()
                text.append("  ")

                # Подсвечиваем имя компонента
                if "-" in component_name and component_namespace:
                    namespace_suffix = f"-{component_namespace}"
                    if component_name.endswith(namespace_suffix):
                        component_part = component_name[: -len(namespace_suffix)]
                        text.append(component_part)
                        text.append(namespace_suffix, style="dim")
                    else:
                        text.append(component_name)
                else:
                    text.append(component_name)

                text.append(": ")
                text.append(current_tag, style="yellow")
                text.append(" → ")
                text.append(target_tag, style="green")
                console.print(text)

        # Если это режим проверки или dry-run, выходим
        if check or dry_run:
            if check:
                console.print(
                    "\n[blue]Режим проверки - обновления не выполняются[/blue]"
                )
            else:
                console.print(
                    "\n[blue]Dry-run режим - обновления не выполняются[/blue]"
                )
            return

        # Подтверждение
        if not confirm:
            if not click.confirm(
                    f"\nВыполнить обновление {len(valid_upgrades)} компонентов?"
            ):
                console.print("[yellow]Обновление отменено[/yellow]")
                return

        # Выполняем обновления с прогресс-барами
        console.print(f"\n[green]Выполнение обновлений...[/green]")
        success_count = 0
        error_count = 0

        # Выполняем обновления с прогресс-барами
        with Progress(
                SpinnerColumn(),
                TextColumn("[progress.description]{task.description}"),
                TimeElapsedColumn(),
                console=console,
                transient=False,
        ) as progress:

            for (
                    component_name,
                    target_tag,
                    current_tag,
                    component_namespace,
                    component_data,
            ) in valid_upgrades:
                # DEBUG: выводим информацию о всех компонентах для обновления
                verbose_print(f"Component: {component_name}, current: {current_tag}, target: {target_tag}")

                # С --force пропускаем проверку "уже актуален"
                if current_tag == target_tag and not force:
                    verbose_print(f"  Skipping {component_name} - already up to date")
                    continue  # Пропускаем уже актуальные (если не force)

                highlighted_name = _highlight_component_name(
                    component_name, component_namespace
                )

                # Создаем простое описание для прогресса (без раскраски)
                description = f"{highlighted_name}: [yellow]{current_tag}[/yellow] → [green]{target_tag}[/green]"

                # Создаем задачу с анимацией и временем
                task_id = progress.add_task(description, total=100)

                try:
                    # Используем уже полученные данные о компоненте
                    component = component_data

                    # Получаем образ компонента
                    image = component.get("image", "")
                    child_container = component.get("childContainer")
                    if child_container and child_container.get("image"):
                        image = child_container.get("image")

                    # Извлекаем имя образа без тега
                    if ":" in image:
                        image_name, _ = image.rsplit(":", 1)
                    else:
                        image_name = image

                    # Формируем новый образ с целевым тегом
                    new_image = f"{image_name}:{target_tag}"

                    # Выполняем обновление
                    # Извлекаем stack из stack_id (формат: stackId@namespace)
                    stack_id = component.get("stack_id", "")
                    stack_name = stack_id.split("@")[0] if "@" in stack_id else ""

                    verbose_print(f"Upgrading {component_name}: {current_tag} -> {target_tag}")
                    verbose_print(f"  namespace: {component_namespace}, stack: {stack_name}")
                    verbose_print(f"  new image: {new_image}")

                    api.update_component(
                        component_name, new_image, component_namespace, stack_name, component_data
                    )

                    # Завершаем прогресс
                    progress.update(task_id, advance=100)
                    progress.remove_task(task_id)

                    success_count += 1

                except Exception as e:
                    # Завершаем прогресс
                    progress.update(task_id, advance=100)
                    progress.remove_task(task_id)

                    error_count += 1
                    # Выводим сообщение об ошибке
                    console.print(
                        f"❌ {highlighted_name}: [yellow]{current_tag}[/yellow] → [green]{target_tag}[/green]: {str(e)[:50]}..."
                    )
                    continue

                # Выводим финальное сообщение об успехе
                console.print(
                    f"✅ {highlighted_name}: [yellow]{current_tag}[/yellow] → [green]{target_tag}[/green]"
                )

        # Выводим итоговую статистику
        if success_count > 0 or error_count > 0:
            console.print()
            if success_count > 0:
                console.print(
                    f"[green]Успешно обновлено: {success_count} компонентов[/green]"
                )
            if error_count > 0:
                console.print(
                    f"[red]Ошибок обновления: {error_count} компонентов[/red]"
                )

    except ImagenariumAPIError as e:
        console.print(f"[red]Ошибка API: {e}[/red]")
        raise click.Abort()
    except Exception as e:
        console.print(f"[red]Неожиданная ошибка: {e}[/red]")
        raise click.Abort()
