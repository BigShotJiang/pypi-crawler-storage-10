"""
Модуль для поддержки bash completion
"""

import os
import json
import time
from typing import List, Dict, Any, Optional
from pathlib import Path
from core.api_client import ImagenariumAPIClient
from core.config import Config
from core.server_manager import ServerManager


class CompletionManager:
    """Менеджер для bash completion с кэшированием"""

    def __init__(
        self, cache_dir: Optional[str] = None, server_name: Optional[str] = None
    ):
        if cache_dir is None:
            cache_dir = os.path.expanduser("~/.cache/imgctl")

        self.cache_dir = Path(cache_dir)
        self.server_name = server_name or self._get_default_server_name()
        self.cache_dir = self.cache_dir / self.server_name
        self.cache_dir.mkdir(parents=True, exist_ok=True)

        # TTL для разных типов данных (в секундах)
        self.ttl = {
            "components": 300,  # 5 минут
            "stacks": 300,  # 5 минут
            "nodes": 300,  # 5 минут
            "registries": 300,  # 5 минут
            "repositories": 300,  # 5 минут
            "servers": 3600,  # 1 час
            "namespaces": 300,  # 5 минут
        }

    def _get_default_server_name(self) -> str:
        """Получает имя сервера по умолчанию"""
        try:
            manager = ServerManager()
            default_server = manager.get_default_server()
            if default_server:
                return default_server.name
            else:
                return "default"
        except Exception:
            return "default"

    def _get_cache_file(self, data_type: str) -> Path:
        """Получает путь к файлу кэша для типа данных"""
        return self.cache_dir / f"{data_type}_completion.json"

    def _is_cache_valid(self, data_type: str) -> bool:
        """Проверяет, валиден ли кэш для типа данных"""
        cache_file = self._get_cache_file(data_type)
        if not cache_file.exists():
            return False

        # Проверяем TTL
        cache_time = cache_file.stat().st_mtime
        return (time.time() - cache_time) < self.ttl.get(data_type, 300)

    def _load_from_cache(self, data_type: str) -> Optional[List[str]]:
        """Загружает данные из кэша"""
        if not self._is_cache_valid(data_type):
            return None

        cache_file = self._get_cache_file(data_type)
        try:
            with open(cache_file, "r", encoding="utf-8") as f:
                data = json.load(f)
                return data.get("items", [])
        except (json.JSONDecodeError, IOError):
            return None

    def _save_to_cache(self, data_type: str, items: List[str]) -> None:
        """Сохраняет данные в кэш"""
        cache_file = self._get_cache_file(data_type)
        try:
            data = {"items": items, "timestamp": time.time()}
            with open(cache_file, "w", encoding="utf-8") as f:
                json.dump(data, f, ensure_ascii=False, indent=2)
        except IOError:
            pass  # Игнорируем ошибки записи кэша

    def _get_api_client(self) -> Optional[ImagenariumAPIClient]:
        """Получает API клиент для запросов"""
        try:
            manager = ServerManager()
            config = manager.get_config_for_server()
            return ImagenariumAPIClient(config)
        except Exception:
            return None

    def get_components(self, use_cache: bool = True) -> List[str]:
        """Получает список имен компонентов"""
        if use_cache:
            cached = self._load_from_cache("components")
            if cached is not None:
                return cached

        api = self._get_api_client()
        if not api:
            return []

        try:
            components = api.get_components()
            names = []
            for component in components:
                stacks = component.get("stacks", [])
                for stack in stacks:
                    stack_components = stack.get("components", [])
                    for comp in stack_components:
                        name = comp.get("name")
                        if name and not name.startswith("checker-"):
                            names.append(name)

            # Убираем дубликаты и сортируем
            names = sorted(list(set(names)))

            if use_cache:
                self._save_to_cache("components", names)

            return names
        except Exception:
            return []

    def get_stacks(self, use_cache: bool = True) -> List[str]:
        """Получает список имен стеков"""
        if use_cache:
            cached = self._load_from_cache("stacks")
            if cached is not None:
                return cached

        api = self._get_api_client()
        if not api:
            return []

        try:
            stacks = api.get_stacks()
            names = [stack.get("name", "") for stack in stacks if stack.get("name")]
            names = sorted(list(set(names)))

            if use_cache:
                self._save_to_cache("stacks", names)

            return names
        except Exception:
            return []

    def get_nodes(self, use_cache: bool = True) -> List[str]:
        """Получает список имен нод"""
        if use_cache:
            cached = self._load_from_cache("nodes")
            if cached is not None:
                return cached

        api = self._get_api_client()
        if not api:
            return []

        try:
            nodes = api.get_nodes()
            names = [node.get("hostname", "") for node in nodes if node.get("hostname")]
            names = sorted(list(set(names)))

            if use_cache:
                self._save_to_cache("nodes", names)

            return names
        except Exception:
            return []

    def get_registries(self, use_cache: bool = True) -> List[str]:
        """Получает список имен реестров"""
        if use_cache:
            cached = self._load_from_cache("registries")
            if cached is not None:
                return cached

        api = self._get_api_client()
        if not api:
            return []

        try:
            registries = api.get_registries()
            names = [reg.get("name", "") for reg in registries if reg.get("name")]
            names = sorted(list(set(names)))

            if use_cache:
                self._save_to_cache("registries", names)

            return names
        except Exception:
            return []

    def get_repositories(self, use_cache: bool = True) -> List[str]:
        """Получает список имен репозиториев"""
        if use_cache:
            cached = self._load_from_cache("repositories")
            if cached is not None:
                return cached

        api = self._get_api_client()
        if not api:
            return []

        try:
            repositories = api.get_repositories()
            names = [repo.get("name", "") for repo in repositories if repo.get("name")]
            names = sorted(list(set(names)))

            if use_cache:
                self._save_to_cache("repositories", names)

            return names
        except Exception:
            return []

    def get_servers(self, use_cache: bool = True) -> List[str]:
        """Получает список имен серверов"""
        if use_cache:
            cached = self._load_from_cache("servers")
            if cached is not None:
                return cached

        try:
            manager = ServerManager()
            servers = manager.list_servers()
            names = [server.name for server in servers]
            names = sorted(list(set(names)))

            if use_cache:
                self._save_to_cache("servers", names)

            return names
        except Exception:
            return []

    def get_namespaces(self, use_cache: bool = True) -> List[str]:
        """Получает список уникальных namespace"""
        if use_cache:
            cached = self._load_from_cache("namespaces")
            if cached is not None:
                return cached

        api = self._get_api_client()
        if not api:
            return []

        try:
            components = api.get_components()
            namespaces = set()
            for component in components:
                stacks = component.get("stacks", [])
                for stack in stacks:
                    namespace = stack.get("namespace")
                    if namespace:
                        namespaces.add(namespace)

            # Сортируем и возвращаем
            namespaces = sorted(list(namespaces))

            if use_cache:
                self._save_to_cache("namespaces", namespaces)

            return namespaces
        except Exception:
            return []

    def get_available_columns(self, command: str) -> List[str]:
        """Получает доступные колонки для команды list"""
        columns_map = {
            "components": [
                "NAME",
                "NAMESPACE",
                "STACK",
                "IMAGE",
                "TAG",
                "STACK_VERSION",
                "STATUS",
                "REPLICAS",
                "PORTS",
                "UPDATED",
                "CREATED",
                "REPO",
                "COMMIT",
                "ADMIN_MODE",
                "RUN_APP",
                "SHOW_ADMIN_MODE",
                "OFF",
                "NETWORKS",
            ],
            "stacks": [
                "NAME",
                "NAMESPACE",
                "VERSION",
                "STATUS",
                "REPO",
                "COMMIT",
                "TIME",
                "TAG",
                "PARAMETERS",
                "COMPONENTS",
            ],
            "nodes": [
                "NAME",
                "IP",
                "ROLE",
                "AVAILABILITY",
                "STATUS",
                "DC",
                "DOCKER_VERSION",
                "TOTAL_MEMORY",
                "SSH_PORT",
                "SSH_USER",
                "EXTERNAL_URL",
                "ID",
            ],
            "registries": ["NAME", "URL", "USERNAME", "STATUS"],
            "repositories": ["NAME", "URL", "STATUS"],
        }

        return columns_map.get(command, [])

    def get_command_options(self, command: str) -> List[str]:
        """Получает доступные опции для команды"""
        options_map = {
            "components": {
                "list": [
                    "--limit",
                    "-l",
                    "--no-cache",
                    "--columns",
                    "--filter",
                    "--no-headers",
                    "--output",
                    "-o",
                    "--help",
                ],
                "get": ["--no-cache", "--help"],
                "start": ["--no-cache", "--help"],
                "upgrade": [
                    "--from-file",
                    "--check",
                    "--dry-run",
                    "--verbose",
                    "-v",
                    "--filter",
                    "--to-tag",
                    "--confirm",
                    "--force",
                    "--no-cache",
                    "--export-current",
                    "--export-latest",
                    "--export-upgradable",
                    "--help",
                ],
            },
            "stacks": {
                "list": [
                    "--columns",
                    "--filter",
                    "--limit",
                    "-l",
                    "--no-headers",
                    "--output",
                    "-o",
                    "--help",
                ],
                "get": ["--help"],
                "deploy": ["--repository", "--git-ref", "--param", "--help"],
                "undeploy": ["--help"],
            },
            "nodes": {
                "list": [
                    "--columns",
                    "--filter",
                    "--no-headers",
                    "--output",
                    "-o",
                    "--help",
                ],
                "get": ["--help"],
            },
            "logs": {
                "logs": [
                    "--browser",
                    "--follow",
                    "-f",
                    "--lines",
                    "-l",
                    "--level",
                    "--tail",
                    "-t",
                    "--since",
                    "--no-cache",
                    "--help",
                ]
            },
            "servers": {
                "list": [
                    "--show-passwords",
                    "--columns",
                    "--filter",
                    "--no-headers",
                    "--output",
                    "-o",
                    "--help",
                ],
                "add": [
                    "--url",
                    "--username",
                    "--password",
                    "--description",
                    "--default",
                    "--help",
                ],
                "remove": ["--help"],
                "set-default": ["--help"],
            },
        }

        return options_map.get(command, {}).get("list", [])
