"""
Форматтеры для вывода данных
"""

import json
import yaml
import re
import shutil
import io
import os
from typing import Any, Dict, List, Optional
from rich.console import Console
from rich.table import Table

# Создаем Console с параметрами для совместимости с различными терминалами
console = Console(
    force_terminal=True,
    legacy_windows=False,
    color_system="truecolor",  # Расширенный набор цветов (24-битная палитра)
)


def display_console_header(
    console_name: str, console_color: str = "#ffffff", version: str = None
) -> None:
    """
    Отображает заголовок консоли во всю ширину терминала с заливкой цветом

    Args:
        console_name: Название консоли
        console_color: Цвет фона в формате HEX (например, "#2d8080")
        version: Версия системы (опционально)
    """
    try:
        # Получаем ширину терминала
        terminal_width = shutil.get_terminal_size().columns

        # Создаем текст заголовка слева
        left_text = f" ᪣ Imagenarium: {console_name}"

        # Создаем текст версии справа (если есть)
        right_text = f"v{version} " if version else ""

        # Вычисляем отступы
        if right_text:
            # Есть версия - размещаем слева и справа
            padding_needed = terminal_width - len(left_text) - len(right_text)
            if padding_needed > 0:
                middle_padding = " " * padding_needed
                full_line = left_text + middle_padding + right_text
            else:
                # Не помещается - показываем только левую часть
                full_line = left_text + " " * (terminal_width - len(left_text))
        else:
            # Нет версии - только левая часть
            padding_needed = terminal_width - len(left_text)
            full_line = left_text + " " * padding_needed

        # Определяем цвет текста в зависимости от текущего фона терминала
        def get_adaptive_text_color():
            """Определяет оптимальный цвет текста для текущего фона терминала"""
            try:
                # Проверяем переменную окружения TERM для определения типа терминала
                term = os.environ.get("TERM", "").lower()

                # Для темных терминалов (iTerm2, Terminal.app в темной теме)
                if any(
                    dark_term in term
                    for dark_term in ["iterm", "xterm-256color", "screen-256color"]
                ):
                    # Проверяем переменные окружения для темной темы
                    if os.environ.get("ITERM_PROFILE", "").lower() in [
                        "dark",
                        "midnight",
                    ]:
                        return "white"
                    # Проверяем цветовую схему macOS Terminal
                    if os.environ.get("COLORFGBG", "").endswith(";0"):  # темный фон
                        return "white"

                # Проверяем настройки Rich Console
                if hasattr(console, "color_system") and console.color_system:
                    # Если Rich определяет темную тему
                    if console.color_system == "standard" and term in [
                        "dumb",
                        "unknown",
                    ]:
                        return "black"  # Для простых терминалов
                    elif console.color_system in ["256", "truecolor"]:
                        # Для продвинутых терминалов проверяем переменные окружения
                        if os.environ.get("ITERM_PROFILE", "").lower() in [
                            "dark",
                            "midnight",
                        ]:
                            return "white"
                        elif os.environ.get("COLORFGBG", "").endswith(";0"):
                            return "white"
                        else:
                            return "black"

                # Для светлых терминалов или по умолчанию
                return "black"

            except Exception:
                # Fallback: белый текст
                return "white"

        # Получаем адаптивный цвет текста
        text_color = get_adaptive_text_color()

        # Выводим заголовок с заливкой цветом
        console.print(
            f"[bold {text_color} on {console_color}]{full_line}[/bold {text_color} on {console_color}]"
        )

    except Exception:
        # Fallback: простой вывод без Rich
        fallback_text = f" ᪣ Imagenarium: {console_name}"
        if version:
            fallback_text += f" v{version} "
        console.print(
            f"[bold white on {console_color}]{fallback_text}[/bold white on {console_color}]"
        )


def show_console_header(api_client, show_header: bool = True) -> None:
    """
    Получает конфиг консоли и отображает заголовок

    Args:
        api_client: API клиент для получения конфига
        show_header: Показывать ли заголовок (по умолчанию True)
    """
    # В shell режиме не показываем заголовок для внутренних команд
    # (заголовок уже показан при входе в shell)
    import os
    if os.environ.get("IMGCTL_SHELL_MODE") == "1":
        return
    
    if not show_header:
        return

    try:
        # Получаем конфиг консоли
        config = api_client.get_console_config()

        console_name = config.get("consoleName", "Imagenarium")
        console_color = config.get("consoleColor", "#ffffff")

        # Получаем версию (с кэшированием)
        try:
            version = api_client.get_version()
        except Exception:
            version = None

        # Отображаем заголовок
        display_console_header(console_name, console_color, version)

    except Exception:
        # Fallback: заголовок по умолчанию
        display_console_header("Imagenarium", "#ffffff")


def parse_columns_spec(
    columns_spec: str, default_columns: List[str], all_columns: List[str]
) -> List[str]:
    """
    Парсит спецификацию столбцов с поддержкой префиксов +/-

    Args:
        columns_spec: Спецификация столбцов (например: "NAME,STATUS" или "+REPLICAS,-NAMESPACE")
        default_columns: Столбцы по умолчанию
        all_columns: Все доступные столбцы

    Returns:
        Список столбцов для отображения
    """
    if not columns_spec:
        return default_columns

    # Разделяем по запятым и убираем пробелы
    parts = [part.strip() for part in columns_spec.split(",")]

    # Проверяем, есть ли префиксы +/-
    has_prefixes = any(part.startswith(("+", "-")) for part in parts)

    if has_prefixes:
        # Режим с префиксами: начинаем с столбцов по умолчанию
        result_columns = default_columns.copy()

        for part in parts:
            if part.startswith("+"):
                # Добавляем столбец
                column = part[1:].upper()
                if column in all_columns and column not in result_columns:
                    result_columns.append(column)
            elif part.startswith("-"):
                # Удаляем столбец
                column = part[1:].upper()
                if column in result_columns:
                    result_columns.remove(column)
            else:
                # Обычный столбец (без префикса) - заменяем весь список
                return [part.upper() for part in parts if part.upper() in all_columns]

        return result_columns
    else:
        # Обычный режим: явное указание столбцов
        return [part.upper() for part in parts if part.upper() in all_columns]


def parse_filters(filters: List[str]) -> List[Dict[str, Any]]:
    """
    Парсит список фильтров в формате "COLUMN=value", "COLUMN!=value", "COLUMN~pattern"

    Args:
        filters: Список строк фильтров

    Returns:
        Список словарей с информацией о фильтрах
    """
    parsed_filters = []

    for filter_str in filters:
        # Поддерживаемые операторы
        operators = ["!=", ">=", "<=", "~", "=", ">", "<"]

        # Находим оператор в строке
        operator = None
        for op in operators:
            if op in filter_str:
                operator = op
                break

        if not operator:
            continue

        # Разделяем на колонку и значение
        parts = filter_str.split(operator, 1)
        if len(parts) != 2:
            continue

        column = parts[0].strip().upper()
        value = parts[1].strip()

        # Убираем кавычки если есть
        if value.startswith('"') and value.endswith('"'):
            value = value[1:-1]
        elif value.startswith("'") and value.endswith("'"):
            value = value[1:-1]

        parsed_filters.append({"column": column, "operator": operator, "value": value})

    return parsed_filters


def apply_filters(
    data: List[Dict[str, Any]], filters: List[Dict[str, Any]]
) -> List[Dict[str, Any]]:
    """
    Применяет фильтры к данным

    Args:
        data: Список словарей с данными
        filters: Список фильтров

    Returns:
        Отфильтрованные данные
    """
    if not filters:
        return data

    filtered_data = []

    for row in data:
        matches = True

        for filter_info in filters:
            column = filter_info["column"]
            operator = filter_info["operator"]
            value = filter_info["value"]

            # Получаем значение из строки
            import re

            # Убираем Rich markup и лишние пробелы
            raw_value = str(row.get(column, ""))
            cell_value = re.sub(
                r"\[[^\]]*\]", "", raw_value
            )  # Убираем Rich markup [green]...[/green]
            cell_value = re.sub(
                r"\s+", " ", cell_value.strip()
            ).lower()  # Убираем лишние пробелы
            filter_value = str(value).strip().lower()

            # Применяем оператор
            if operator == "=":
                if cell_value != filter_value:
                    matches = False
                    break
            elif operator == "!=":
                if cell_value == filter_value:
                    matches = False
                    break
            elif operator == "~":
                try:
                    if not re.search(filter_value, cell_value):
                        matches = False
                        break
                except re.error:
                    # Если регулярное выражение некорректное, используем простой поиск
                    if filter_value not in cell_value:
                        matches = False
                        break
            elif operator == ">":
                try:
                    if not (cell_value > filter_value):
                        matches = False
                        break
                except (ValueError, TypeError):
                    # Для нечисловых значений сравниваем как строки
                    if not (cell_value > filter_value):
                        matches = False
                        break
            elif operator == "<":
                try:
                    if not (cell_value < filter_value):
                        matches = False
                        break
                except (ValueError, TypeError):
                    if not (cell_value < filter_value):
                        matches = False
                        break
            elif operator == ">=":
                try:
                    if not (cell_value >= filter_value):
                        matches = False
                        break
                except (ValueError, TypeError):
                    if not (cell_value >= filter_value):
                        matches = False
                        break
            elif operator == "<=":
                try:
                    if not (cell_value <= filter_value):
                        matches = False
                        break
                except (ValueError, TypeError):
                    if not (cell_value <= filter_value):
                        matches = False
                        break

        if matches:
            filtered_data.append(row)

    return filtered_data


def highlight_matches(text: str, filters: List[Dict[str, str]]) -> str:
    """
    Подсвечивает совпадения в тексте на основе фильтров

    Args:
        text: Исходный текст (уже без Rich markup)
        filters: Список фильтров для подсветки

    Returns:
        Текст с подсветкой совпадений
    """
    if not filters or not text:
        return text

    # Убираем Rich markup из текста для сравнения
    clean_text = re.sub(r"\[[^\]]*\]", "", text)

    for filter_item in filters:
        column = filter_item["column"]
        operator = filter_item["operator"]
        value = filter_item["value"]

        # Подсвечиваем только для операторов = и ~
        if operator in ["=", "~"]:
            if operator == "=":
                # Точное совпадение
                if clean_text.lower() == value.lower():
                    # Заменяем весь текст на подсвеченный
                    text = f"[bold yellow]{clean_text}[/bold yellow]"
            elif operator == "~":
                # Регулярное выражение
                try:
                    # Ищем совпадения в чистом тексте
                    matches = list(re.finditer(value, clean_text, re.IGNORECASE))
                    if matches:
                        # Строим новый текст с подсветкой
                        result = ""
                        last_end = 0
                        for match in matches:
                            # Добавляем текст до совпадения
                            result += clean_text[last_end : match.start()]
                            # Добавляем подсвеченное совпадение
                            result += f"[bold yellow]{match.group()}[/bold yellow]"
                            last_end = match.end()
                        # Добавляем оставшийся текст
                        result += clean_text[last_end:]
                        text = result
                except re.error:
                    # Если регулярное выражение некорректное, используем простой поиск
                    if value.lower() in clean_text.lower():
                        # Заменяем первое вхождение
                        start = clean_text.lower().find(value.lower())
                        if start != -1:
                            end = start + len(value)
                            result = (
                                clean_text[:start]
                                + f"[bold yellow]{clean_text[start:end]}[/bold yellow]"
                                + clean_text[end:]
                            )
                            text = result

    return text


def format_table(
    data: List[Dict[str, Any]],
    columns: Optional[List[str]] = None,
    no_headers: bool = False,
    highlight_filters: Optional[List[Dict[str, str]]] = None,
) -> None:
    """
    Форматирует данные в стиле kubectl (без рамок, с правильным выравниванием)
    Адаптируется к ширине терминала

    Args:
        data: Список словарей с данными
        columns: Список колонок для отображения
        no_headers: Не показывать заголовки колонок таблицы
        highlight_filters: Список фильтров для подсветки совпадений
    """
    if not data:
        console.print("Данные не найдены")
        return

    if columns is None:
        columns = list(data[0].keys())

    # Получаем ширину терминала
    terminal_width = shutil.get_terminal_size().columns

    # Создаем Rich Table для правильного выравнивания
    from rich.box import HEAVY_HEAD

    table = Table(
        show_header=not no_headers, show_footer=False, show_edge=False, box=None
    )

    # Вычисляем ширину колонок
    column_widths = {}
    for col in columns:
        # Начинаем с ширины заголовка (если заголовки показываются)
        min_width = len(col) if not no_headers else 0

        # Проверяем все значения в колонке
        for item in data:
            value = str(item.get(col, ""))
            min_width = max(min_width, len(value))

        column_widths[col] = min_width

    # Вычисляем общую ширину
    total_width = sum(column_widths.values()) + (len(columns) - 1) * 2

    # Если таблица не помещается, ограничиваем ширину колонок
    if total_width > terminal_width:
        available_width = terminal_width - (len(columns) - 1) * 2
        total_content_width = sum(column_widths.values())

        for col in columns:
            proportion = column_widths[col] / total_content_width
            column_widths[col] = max(int(available_width * proportion), len(col))

    # Добавляем колонки в таблицу
    for col in columns:
        width = column_widths[col]

        # Определяем выравнивание
        if col.lower() in ["replicas", "age", "restarts", "components"]:
            justify = "right"
        else:
            justify = "left"

        if no_headers:
            # Для режима без заголовков используем пустую строку как заголовок
            table.add_column("", width=width, justify=justify, style="white")
        else:
            table.add_column(
                col,
                width=width,
                justify=justify,
                style="white",
                header_style="bold white",
            )

    # Добавляем строки данных
    for item in data:
        row = []
        for col in columns:
            value = str(item.get(col, ""))
            width = column_widths[col]

            # Обрезаем длинные значения
            if len(value) > width:
                if width > 3:
                    display_value = value[: width - 3] + "..."
                else:
                    display_value = value[:width]
            else:
                display_value = value

            # Сначала подсвечиваем совпадения с фильтрами (до цветового кодирования)
            if highlight_filters:
                # Создаем фильтры для текущего столбца
                column_filters = [f for f in highlight_filters if f["column"] == col]
                if column_filters:
                    display_value = highlight_matches(display_value, column_filters)

            # Цветовое кодирование для статусов и доступности
            if col.lower() in ["status", "state"]:
                # Проверяем, есть ли уже Rich markup в значении
                has_markup = "[" in display_value and "]" in display_value
                
                if not has_markup:
                    # Применяем цветовое кодирование только если markup еще не применен
                    if display_value.upper() in [
                        "RUNNING",
                        "ACTIVE",
                        "READY",
                        "HEALTHY",
                        "DEPLOYED",
                    ]:
                        styled_value = f"[bold green]{display_value}[/bold green]"
                    elif display_value.upper() in [
                        "STOPPED",
                        "INACTIVE",
                        "TERMINATED",
                        "FAILED",
                        "ERROR",
                        "OFF",
                    ]:
                        styled_value = f"[bold red]{display_value}[/bold red]"
                    elif display_value.upper() in ["PENDING", "WAITING", "STARTING", "BROKEN", "CANCELED"]:
                        styled_value = f"[bold yellow]{display_value}[/bold yellow]"
                    elif display_value.upper().startswith("PARTIAL"):
                        styled_value = f"[bold orange3]{display_value}[/bold orange3]"
                    else:
                        styled_value = display_value
                else:
                    # Если markup уже есть, используем значение как есть
                    styled_value = display_value
            elif col.lower() == "availability":
                if display_value.upper() in ["ACTIVE", "READY", "AVAILABLE"]:
                    styled_value = f"[bold green]{display_value}[/bold green]"
                elif display_value.upper() in ["DRAIN", "DRAINING", "UNAVAILABLE"]:
                    styled_value = f"[bold red]{display_value}[/bold red]"
                elif display_value.upper() in ["PAUSE", "PAUSED"]:
                    styled_value = f"[bold yellow]{display_value}[/bold yellow]"
                else:
                    styled_value = display_value
            else:
                styled_value = display_value

            row.append(styled_value)

        table.add_row(*row)

    # Выводим таблицу
    console.print(table)


def _convert_params_to_object(row: Dict[str, Any], prefix: str) -> Dict[str, Any]:
    """
    Конвертирует PARAMS или ENV из строки в объект с сохранением регистра ключей

    Args:
        row: Строка данных
        prefix: Префикс для поиска столбцов (PARAMS или ENV)

    Returns:
        Объект с параметрами/переменными окружения
    """
    result = {}

    # Ищем все столбцы с префиксом prefix.
    for key, value in row.items():
        if key.startswith(f"{prefix}."):
            # Извлекаем имя параметра/переменной (сохраняем регистр)
            param_name = key[len(f"{prefix}.") :]
            # Убираем _RAW суффикс если есть
            if param_name.endswith("_RAW"):
                param_name = param_name[:-4]
            # Очищаем Rich markup
            if isinstance(value, str):
                clean_value = re.sub(r"\[[^\]]*\]", "", value).strip()
            else:
                clean_value = value
            result[param_name] = clean_value

    # Если не нашли динамические столбцы, но есть строка, парсим её
    if not result and prefix.lower() in row:
        string_value = row[prefix]
        if isinstance(string_value, str) and string_value.strip():
            # Парсим строку вида "KEY1=value1, KEY2=value2"
            pairs = string_value.split(",")
            for pair in pairs:
                if "=" in pair:
                    key, value = pair.split("=", 1)
                    result[key.strip()] = value.strip()

    # Также проверяем оригинальный ключ (с заглавными буквами)
    if not result and prefix in row:
        string_value = row[prefix]
        if isinstance(string_value, str) and string_value.strip():
            # Парсим строку вида "KEY1=value1, KEY2=value2"
            pairs = string_value.split(",")
            for pair in pairs:
                if "=" in pair:
                    key, value = pair.split("=", 1)
                    result[key.strip()] = value.strip()

    return result


def format_json(data: Any, indent: int = 2) -> None:
    """
    Форматирует данные в JSON

    Args:
        data: Данные для форматирования
        indent: Отступ для JSON
    """
    try:
        # Конвертируем ключи в нижний регистр и очищаем Rich markup
        converted_data = []
        for row in data:
            converted_row = {}
            for key, value in row.items():
                # Пропускаем столбцы вида PARAMS.<ключ> и ENV.<ключ> - они будут в объектах
                if key.startswith("PARAMS.") or key.startswith("ENV."):
                    continue

                # Очищаем Rich markup и конвертируем в нижний регистр
                if isinstance(value, str):
                    clean_value = re.sub(r"\[[^\]]*\]", "", value).strip()
                else:
                    clean_value = value
                converted_row[key.lower()] = clean_value

            # Конвертируем PARAMS в объект с сохранением регистра ключей
            if "params" in converted_row:
                params_obj = _convert_params_to_object(row, "PARAMS")
                if params_obj:
                    converted_row["params"] = params_obj

            # Конвертируем ENV в объект с сохранением регистра ключей
            if "env" in converted_row:
                env_obj = _convert_params_to_object(row, "ENV")
                if env_obj:
                    converted_row["env"] = env_obj

            converted_data.append(converted_row)

        json_str = json.dumps(converted_data, indent=indent, ensure_ascii=False)
        console.print(json_str)
    except Exception as e:
        console.print(f"[red]Ошибка форматирования JSON: {e}[/red]")


def format_yaml(data: Any, default_flow_style: bool = False) -> None:
    """
    Форматирует данные в YAML

    Args:
        data: Данные для форматирования
        default_flow_style: Стиль потока по умолчанию
    """
    try:
        # Конвертируем ключи в нижний регистр и очищаем Rich markup
        converted_data = []
        for row in data:
            converted_row = {}
            for key, value in row.items():
                # Пропускаем столбцы вида PARAMS.<ключ> и ENV.<ключ> - они будут в объектах
                if key.startswith("PARAMS.") or key.startswith("ENV."):
                    continue

                # Очищаем Rich markup и конвертируем в нижний регистр
                if isinstance(value, str):
                    clean_value = re.sub(r"\[[^\]]*\]", "", value).strip()
                else:
                    clean_value = value
                converted_row[key.lower()] = clean_value

            # Конвертируем PARAMS в объект с сохранением регистра ключей
            if "params" in converted_row:
                params_obj = _convert_params_to_object(row, "PARAMS")
                if params_obj:
                    converted_row["params"] = params_obj

            # Конвертируем ENV в объект с сохранением регистра ключей
            if "env" in converted_row:
                env_obj = _convert_params_to_object(row, "ENV")
                if env_obj:
                    converted_row["env"] = env_obj

            converted_data.append(converted_row)

        yaml_str = yaml.dump(
            converted_data,
            default_flow_style=default_flow_style,
            allow_unicode=True,
            sort_keys=False,
        )
        console.print(yaml_str)
    except Exception as e:
        console.print(f"[red]Ошибка форматирования YAML: {e}[/red]")


def format_template(data: List[Dict[str, Any]], template: str) -> None:
    """
    Форматирует данные по шаблону (как в kubectl)

    Args:
        data: Список словарей с данными
        template: Шаблон с плейсхолдерами (например: "{{.NAME}} {{.STATUS}}")
    """
    if not data:
        return

    for row in data:
        # Убираем Rich markup из значений
        clean_row = {}
        for key, value in row.items():
            if isinstance(value, str):
                clean_row[key] = re.sub(r"\[[^\]]*\]", "", value).strip()
            else:
                clean_row[key] = value

        # Заменяем плейсхолдеры в шаблоне
        formatted_line = template
        for key, value in clean_row.items():
            placeholder = f"{{{key}}}"  # {KEY}
            formatted_line = formatted_line.replace(placeholder, str(value))

        # Заменяем \n на реальные переносы строк
        formatted_line = formatted_line.replace("\\n", "\n")

        console.print(formatted_line)


def format_output(
    data: List[Dict[str, Any]], format_spec: str, columns: Optional[List[str]] = None
) -> None:
    """
    Форматирует данные в указанном формате

    Args:
        data: Список словарей с данными
        format_spec: Спецификация формата (json, yaml, tsv, или template с шаблоном)
        columns: Столбцы для TSV (если применимо)
    """
    # Если формат не указан или это table, используем стандартное табличное форматирование
    if not format_spec or format_spec == "table":
        format_table(data, columns=columns)
        return

    # Проверяем, является ли это template форматом (содержит {})
    if "{" in format_spec and "}" in format_spec:
        format_template(data, format_spec)
    elif format_spec == "json":
        format_json(data)
    elif format_spec == "yaml":
        format_yaml(data)
    elif format_spec == "tsv":
        # TSV - это табличный вывод без заголовков колонок
        format_table(data, columns=columns, no_headers=True)
    else:
        console.print(f"[red]Неподдерживаемый формат: {format_spec}[/red]")
        console.print(
            "Доступные форматы: json, yaml, tsv, или template (например: '{NAME} - {STATUS}')"
        )
