"""
Утилиты для работы с динамическими столбцами (ENV, PARAMS)
"""

from typing import List, Dict, Any


def normalize_column_name(column_name: str, all_columns: List[str]) -> str:
    """
    Нормализует имя столбца с учетом особенностей ENV столбцов

    Args:
        column_name: Имя столбца для нормализации
        all_columns: Список всех доступных столбцов

    Returns:
        Нормализованное имя столбца
    """
    # Для столбцов ENV.* сохраняем оригинальный регистр
    if column_name.startswith("ENV."):
        # Проверяем, есть ли столбец с таким именем (с учетом регистра)
        if column_name in all_columns:
            return column_name
        # Если не найден, пробуем найти в верхнем регистре
        upper_name = column_name.upper()
        if upper_name in all_columns:
            return upper_name
        # Возвращаем оригинальное имя, если не найден
        return column_name
    else:
        # Для остальных столбцов используем верхний регистр
        return column_name.upper()


def parse_columns_with_env_support(
    columns_spec: str, default_columns: List[str], all_columns: List[str]
) -> List[str]:
    """
    Парсит спецификацию столбцов с поддержкой ENV столбцов

    Args:
        columns_spec: Спецификация столбцов (например: "NAME,STATUS" или "+REPLICAS,-NAMESPACE")
        default_columns: Столбцы по умолчанию
        all_columns: Все доступные столбцы

    Returns:
        Список столбцов для отображения
    """
    if not columns_spec:
        return default_columns

    # Разделяем по запятым и убираем пробелы
    parts = [part.strip() for part in columns_spec.split(",")]

    # Проверяем, есть ли префиксы +/-
    has_prefixes = any(part.startswith(("+", "-")) for part in parts)

    if has_prefixes:
        # Режим с префиксами: начинаем с столбцов по умолчанию
        result_columns = default_columns.copy()

        for part in parts:
            if part.startswith("+"):
                # Добавляем столбец
                column_spec = part[1:]
                column = normalize_column_name(column_spec, all_columns)
                if column in all_columns and column not in result_columns:
                    result_columns.append(column)
            elif part.startswith("-"):
                # Удаляем столбец
                column_spec = part[1:]
                column = normalize_column_name(column_spec, all_columns)
                if column in result_columns:
                    result_columns.remove(column)
            else:
                # Обычный столбец (без префикса) - заменяем весь список
                result = []
                for p in parts:
                    column = normalize_column_name(p, all_columns)
                    if column in all_columns:
                        result.append(column)
                return result

        return result_columns
    else:
        # Обычный режим: явное указание столбцов
        result = []
        for part in parts:
            column = normalize_column_name(part, all_columns)
            if column in all_columns:
                result.append(column)

        return result


def parse_filters_with_env_support(filters: List[str]) -> List[Dict[str, Any]]:
    """
    Парсит список фильтров с поддержкой ENV столбцов

    Args:
        filters: Список строк фильтров

    Returns:
        Список словарей с информацией о фильтрах
    """
    parsed_filters = []

    for filter_str in filters:
        # Поддерживаемые операторы
        operators = ["!=", ">=", "<=", "~", "=", ">", "<"]

        # Находим оператор в строке
        operator = None
        for op in operators:
            if op in filter_str:
                operator = op
                break

        if not operator:
            continue

        # Разделяем на колонку и значение
        parts = filter_str.split(operator, 1)
        if len(parts) != 2:
            continue

        column_spec = parts[0].strip()
        # Для столбцов ENV.* сохраняем оригинальный регистр
        if column_spec.startswith("ENV."):
            column = column_spec
        else:
            column = column_spec.upper()
        value = parts[1].strip()

        # Убираем кавычки если есть
        if value.startswith('"') and value.endswith('"'):
            value = value[1:-1]
        elif value.startswith("'") and value.endswith("'"):
            value = value[1:-1]

        parsed_filters.append({"column": column, "operator": operator, "value": value})

    return parsed_filters


def convert_params_filters_to_raw(
    filters: List[Dict[str, Any]],
) -> List[Dict[str, Any]]:
    """
    Преобразует фильтры PARAMS в фильтры по исходным значениям (до маскирования)

    Args:
        filters: Список фильтров

    Returns:
        Список фильтров с преобразованными именами столбцов
    """
    converted_filters = []

    for filter_item in filters:
        column = filter_item["column"]

        # Если это фильтр по PARAMS.<параметр>, заменяем на PARAMS.<параметр>_RAW
        if column.startswith("PARAMS.") and not column.endswith("_RAW"):
            # Проверяем, есть ли соответствующий _RAW столбец
            raw_column = column + "_RAW"
            converted_filters.append(
                {
                    "column": raw_column,
                    "operator": filter_item["operator"],
                    "value": filter_item["value"],
                }
            )
        else:
            # Оставляем фильтр как есть
            converted_filters.append(filter_item)

    return converted_filters


def convert_env_filters_to_raw(filters: List[Dict[str, Any]]) -> List[Dict[str, Any]]:
    """
    Преобразует фильтры ENV в фильтры по исходным значениям (до маскирования)

    Args:
        filters: Список фильтров

    Returns:
        Список фильтров с преобразованными именами столбцов
    """
    converted_filters = []

    for filter_item in filters:
        column = filter_item["column"]

        # Если это фильтр по ENV.<переменная>, заменяем на ENV.<переменная>_RAW
        if column.startswith("ENV.") and not column.endswith("_RAW"):
            # Проверяем, есть ли соответствующий _RAW столбец
            raw_column = column + "_RAW"
            converted_filters.append(
                {
                    "column": raw_column,
                    "operator": filter_item["operator"],
                    "value": filter_item["value"],
                }
            )
        else:
            # Оставляем фильтр как есть
            converted_filters.append(filter_item)

    return converted_filters
