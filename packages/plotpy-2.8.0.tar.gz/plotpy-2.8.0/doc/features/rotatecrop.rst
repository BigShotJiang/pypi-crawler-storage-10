.. automodule:: plotpy.widgets.rotatecrop
