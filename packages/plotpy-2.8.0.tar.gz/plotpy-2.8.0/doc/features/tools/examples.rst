Example
-------

The following example add all the existing image tools to a :class:`.PlotWidget`
object for testing purpose:

.. literalinclude:: ../../../plotpy/tests/tools/test_image_plot_tools.py
   :start-after: guitest:

.. image:: /images/screenshots/image_plot_tools.png
