.. _panels:

Plot panels
===========

.. toctree::
   :maxdepth: 2
   :caption: Contents:

   overview
   reference
