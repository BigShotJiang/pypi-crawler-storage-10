Features
========

.. toctree::
   :maxdepth: 2
   :caption: Contents:

   plot/index
   items/index
   tools/index
   styles/index
   panels/index
   colormapmanager
   fit
   pyplot
   resizedialog
   rotatecrop
   fliprotate
   selectdialog
   imagefile
   io
   signals
   mathutils/index
   events
