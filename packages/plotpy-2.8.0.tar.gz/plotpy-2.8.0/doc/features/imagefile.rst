.. automodule:: plotpy.widgets.imagefile
