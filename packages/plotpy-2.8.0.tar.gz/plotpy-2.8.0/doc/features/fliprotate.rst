.. automodule:: plotpy.widgets.fliprotate
