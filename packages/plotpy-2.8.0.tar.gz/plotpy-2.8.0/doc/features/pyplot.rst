.. module:: pyplot
.. automodule:: plotpy.pyplot
