.. automodule:: plotpy.widgets.selectdialog
