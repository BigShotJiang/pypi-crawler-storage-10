This directory contains functions and data useful to generate default colormaps used
in Plotpy. Launch `colormap.py` to create/overwrite the colormaps_default.json file.